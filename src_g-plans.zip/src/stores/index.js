// @flow

import { create } from 'mobx-persist';
import { AsyncStorage } from 'react-native';

import App     from './App';
import Account from './Account';
import Funnel from './Funnel';
import User    from './User';
import MealPlan    from './MealPlan';
import Recipe    from './Recipe';
import DayIndex from './DayIndex';
import HealthKit from './HealthKit'
import WaterTrack from './WaterTrack';
import ExerciseTrack from './ExerciseTrack';
import Profile from './Profile';
import Checkin from './Checkin';
import SearchFood from './viewStore/SearchFood';
// import Constants from '../global/Constants';
import Tips from './Tips';
import GroceryList from './GroceryList';
import FirebaseStore from './FirebaseStore'

const hydrate = create({ storage: AsyncStorage });

class Stores {

  getStores = () => ({
    Global: this,
    App: this.appStore,
    Account: this.accountStore,
    User: this.userStore,
    MealPlan: this.mealPlanStore,
    Funnel: this.funnelStore,
    Recipe: this.recipeStore,
    DayIndex: this.dayIndex,
    HealthKit: this.healthKit,
    WaterTrack: this.waterTrackStore,
    ExerciseTrack: this.exerciseTrackStore,
    SearchFood: this.searchFood,
    Profile: this.profile,
    Checkin: this.checkin,
    Tips: this.tipsStore,
    GroceryList: this.groceryList,
    FirebaseStore: this.firebaseStore,
  })

  hydrateStores = () =>
    // you can hydrate stores here with mobx-persist
    Promise.all(
      [
        hydrate('Account', this.accountStore),
        hydrate('User', this.userStore),
        hydrate('WaterTrack', this.waterTrackStore),
        hydrate('Funnel', this.funnelStore),
        hydrate('GroceryList', this.groceryList),
      ]
    );

  fetchData = async () => {
    const stores = this.getStores()
    try {
      const methods = Object.keys(stores).reduce((res, store) => {
        if (stores[store].fetch) res.fetch.push(stores[store].fetch())
        if (stores[store].postfetch) res.postfetch.push(stores[store].postfetch)
        return res
      }, { fetch: [], postfetch: [] })
      await Promise.all(methods.fetch)
      methods.postfetch.map(pf => pf())
      return Promise.resolve()
    } catch (e) {
      return Promise.reject(e)
    }
  }

  appStore = new App(this.getStores);
  accountStore = new Account(this.getStores);
  funnelStore = new Funnel(this.getStores);
  userStore = new User(this.getStores);
  mealPlanStore = new MealPlan(this.getStores);
  recipeStore = new Recipe(this.getStores);
  dayIndex = new DayIndex(this.getStores);
  waterTrackStore = new WaterTrack(this.getStores);
  exerciseTrackStore = new ExerciseTrack(this.getStores);
  searchFood = new SearchFood(this.getStores);
  healthKit = new HealthKit(this.getStores);
  profile = new Profile(this.getStores);
  tipsStore = new Tips(this.getStores)
  checkin = new Checkin(this.getStores);
  groceryList = new GroceryList(this.getStores)
  firebaseStore = new FirebaseStore(this.getStores)
}

const stores = new Stores();

// stores.hydrateStores();

export const getStores = stores.getStores

export default {
  instance: stores,
  ...stores.getStores()
};
