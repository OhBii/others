/*
*   author: denis
*   date:   8/24/2018
*/

import { observable, action, computed } from 'mobx';
import { ShareDialog } from 'react-native-fbsdk'
import { Alert } from 'react-native'
import SharingWinstagram from '../../node_modules/@micabe/react-native-share-instagram'

import Api from '../utils/Api';
import { downloadData/*, deleteCacheFile*/ } from '../utils/GlobalFunctions'
import Constants from '../global/Constants';

class Profile {
  constructor(getStores) {
    this.getStores = getStores;
  }

  fetch = () => Promise.all([
    this.getCheckinImages(),
    this.getOverallStats()
  ])

  @observable checkinImages = [];
  @observable overallStats;

  @action getCheckinImages = async () => {
    const { User: {token} } = this.getStores();
    try {
      const { data } = await Api.getCheckinImages(token);
      this.checkinImagesSuccess(data);
      return Promise.resolve();
    } catch(error) {
      // this.checkinImagesError(error);
      return Promise.reject(error);
    }
  }

  @action getOverallStats = async () =>{
    const { User: {token} } = this.getStores()
    try {
      const { data } = await Api.getOverallStats(token)
      this.overallStats = {
        water: Math.round(parseFloat(data.water) * 10) / 10,
        exercises: Math.round(parseFloat(data.exercises) * 10) / 10,
        calories: Math.round(parseFloat(data.calories) * 10) / 10
      }
    } catch (error) {
      this.overallStats = {
        water: 0,
        exercises: 0,
        calories: 0
      }
    }
  }

  @action checkinImagesSuccess = (data) => {
    this.checkinImages = data;
  }

  // @action checkinImagesError = (error) => {
  //   // console.log(error.response);
  // }

  @action uploadCheckinImage = async (imageUri) => {
    const { User: {token, userInfo} } = this.getStores();
    try {
      const { data } = await Api.uploadCheckinImage(token, userInfo.last_checkin.id, imageUri);
      this.checkinImages.push(data);
    } catch(error) {
      return Promise.reject(error);
    }
  }

  @computed get getLastImage() {
    const sortedImages = this.checkinImages.sort((first, second) => {
      return (first.id - second.id);
    });
    const length = sortedImages.length
    const lastImage = length > 0
      ? sortedImages[length - 1].image.medium
      : ''
    return lastImage
  }

  @computed get getFirstAndLastImages() {
    const sortedImages = this.checkinImages.sort((first, second) => {
      return (first.id - second.id);
    });
    const length = sortedImages.length;
    const first = length > 0
      ? sortedImages[0].image.medium
      : ''
    const last = length > 1
      ? sortedImages[length - 1].image.medium
      : ''
    return {
      firstImage: first,
      lastImage: last
    };
  }

  @computed get allProfileImages() {
    const sortedImages = this.checkinImages.sort((first, second) => {
      return (first.id - second.id);
    });
    const allImages = sortedImages.map((item) => {
      return item.image.medium;
    });
    return allImages;
  }

  async facebookShareImage(imageUrls) {
    let imageDatas = []
    let img
    for (let i = 0; i < imageUrls.length; i++) {
      try {
        img = await downloadData(imageUrls[i])
        imageDatas.push(img)
      } catch (error) {
        img = null
      }
    }
    if (!imageDatas.length)
      throw new Error('There is no photo to share!')
    const sharePhotoContent = {
      contentType: 'photo',
      photos: imageDatas.map(img =>
        Constants.platform === 'ios'
        ? { imageUrl: img.path() }
        : { imageUrl: 'file://' + img.path() }
      )
    }
    try {
      const canShow = await ShareDialog.canShow(sharePhotoContent)
      //console.log('canShow: ', canShow)
      if (!canShow) throw new Error('You need to install facebook app to share your photos!')
      const result = await ShareDialog.show(sharePhotoContent)
      //Alert.alert('Posted to Facebook!')
      // delete files
      //setTimeout(sharePhotoContent.photos.forEach(el => deleteCacheFile(el.imageUrl)), 300000)
      //await Promise.all(sharePhotoContent.photos.map(el => deleteCacheFile(el.imageUrl)))
      return result
    } catch (error) {
      //console.log('error of facebookSharing: ', error)
      // delete files
      //await Promise.all(sharePhotoContent.photos.map(el => deleteCacheFile(el.imageUrl)))
      //setTimeout(sharePhotoContent.photos.forEach(el => deleteCacheFile(el.imageUrl)), 300000)
      throw error
    }
  }

  async instagramShareImage(imageUrls) {
    let imageDatas = []
    let img
    for (let i = 0; i < imageUrls.length; i++) {
      try {
        img = await downloadData(imageUrls[i])
        imageDatas.push(img)
      } catch (error) {
        img = null
      }
    }
    const length = imageDatas.length
    if (!length)
      throw new Error('There is no photo to share!')
    try {
      const imgShared = length > 1
        ? imageDatas[length - 1]
        : imageDatas[0]
      const name = length > 1 ? 'LastImage' : 'FirstImage'
      const imgData64 = await imgShared.base64()
      SharingWinstagram.shareWithInstagram(name, imgData64,
        // handle success
        message => {
          if (message) Alert.alert(message)
        },
        // handle error
        error => {
          Alert.alert('Error', error.message)
        }
      )
      // delete files
      //await Promise.all(imageDatas.map(el => deleteCacheFile(el.path())))
      return true
    } catch (error) {
      // delete files
      //await Promise.all(imageDatas.map(el => deleteCacheFile(el.path())))
      throw error
    }
  }

  @action setOverallStats = (type, amount, forAdd) => {
    this.overallStats[type] = forAdd
      ? this.overallStats[type] + amount
      : this.overallStats[type] - amount
  }
}

export default Profile;
