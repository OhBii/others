import { observable, action, computed, toJS } from 'mobx';
import moment from 'moment'
//import { persist } from 'mobx-persist';

//import Api from '../utils/Api';
import Constants from '../global/Constants'
import Api from '../utils/Api'

const Multilingual = Constants.Multilingual

class ExerciseTrack {
  constructor(getStores) {
    this.getStores = getStores;
  }

  @observable exercises = [
    {
      icon: Constants.Images.ICON_EX1,
      title: 'Running'
    },
    {
      icon: Constants.Images.ICON_EX2,
      title: 'Walking'
    },
    {
      icon: Constants.Images.ICON_EX3,
      title: 'Weight Lifting'
    },
    {
      icon: Constants.Images.ICON_EX4,
      title: 'Swimming'
    },
    {
      icon: Constants.Images.ICON_EX5,
      title: 'Yoga'
    },
    {
      icon: Constants.Images.ICON_EX6,
      title: 'Field Sport'
    },
    {
      icon: Constants.Images.ICON_EX7,
      title: 'Pilates'
    },
    {
      icon: Constants.Images.ICON_EX8,
      title: 'Dance'
    }
  ]

  @observable exerciseList = []
  @observable latestWeekTrackedData = []
  @observable monthlyTrackedData = []
  defaultExerciseList = []

  /**
   * dayTracker
   *
   * { id, checkin, day, week, logged_exercises, minutes, total_calories, total_minutes ... }
   * id is used to tracked the individual exercise for the certain day
   */
  dayTracker = null

  fetch = () => this.initExerciseTracker()

  postfetch = () => {
    return Promise.all([
      this.getMonthlyTrackedData(),
    ])
  }

  initExerciseTracker = () =>
    Promise.all([
      this.getExerciseList(),
      this.getLatestWeekTrackedData()
    ])

  @action getExerciseList = async () => {
    const { User: { token, language } } = this.getStores()
    try {
      const { data } = await Api.getExercisesList(token)
      this.exerciseList = data
      const running = this.exerciseList.find(exercise => exercise.title.toLowerCase().includes('running'))
      const lifting = this.exerciseList.find(exercise => exercise.title.toLowerCase().includes('lifting'))
      const cycling = this.exerciseList.find(exercise => exercise.title.toLowerCase().includes('cycling'))
      this.defaultExerciseList = [running, lifting, cycling]

    } catch (error) {
      //console.log('Error from getExerciseList: ', error)
      throw new Error(Multilingual.MSG_FETCH_EXERCISE_LIST[language])
    }
  }

  @action getLatestWeekTrackedData = async () => {
    const {
      User: {
        token,
        lastCheckinId,
        language,
      }
    } = this.getStores()
    try {
      const { data } = await Api.getExerciseTracker(token, lastCheckinId)
      data.sort((prev, next) => prev.day - next.day)
      this.latestWeekTrackedData = data
    } catch (error) {
      //console.log('Error from getLatestWeekTrackedData: ', error)
      throw new Error(Multilingual.MSG_FETCH_EXERCISE_TRACKER[language])
    }
  }

  /**
   *
   * dayIndex of exercise
   *
   * initialize dayIndex of exercise tracker as user dayIndex
   * if dayIndex > 6, it means it needs checkin. we just make it 0.
   * TODO fix the dayIndex logic globally
   *
   */
  @computed get dayIndex() {
    const { DayIndex: { homeDayIndex } } = this.getStores()
    return isFinite(homeDayIndex) && homeDayIndex <= 6 ? homeDayIndex : 0
  }

  @action getMonthlyTrackedData = async () => {
    const {
      Checkin: { allCheckins },
      User: {
        token,
        language,
      }
    } = this.getStores()
    const checkinsMonth = allCheckins.slice(1, 4)  // except current week data
    try {
      const pmGetExerciseTrackers = checkinsMonth.map(checkin =>
        Api.getExerciseTracker(token, checkin.id)
      )
      const exerciseTrackersMonth = (await Promise.all(pmGetExerciseTrackers)).map(res => res.data)
      this.monthlyTrackedData = exerciseTrackersMonth.filter(weekData => weekData.length > 0).sort((prev, next) => prev[0].week - next[0].week)
    } catch (error) {
      //console.log('Error from getMonthlyTrackedData: ', error)
      throw new Error(Multilingual.MSG_FETCH_EXERCISE_TRACKER[language])
    }
  }

  @computed get latestWeekBarGraphData() {
    let graphData = []
    for (let day = 1; day <= 7; day++) {
      const dayData = this.latestWeekTrackedData.find(el => el.day === day)
      graphData.push(dayData ? dayData.total_minutes : 0)
    }
    return graphData
  }

  @computed get selectedDayTrackedData() {
    return this.latestWeekTrackedData.find(dayData => dayData.day === this.dayIndex + 1)
  }

  /**
   *
   * createDayTracker
   *
   * Creates the initial track data for the day if nothing was tracked for the day
   * It tries to get the dayTracker before its creation
   * If it's empty then it makes the creation api call
   *
   * All tracking behaviour must go through this process
   * to make sure day tracking was initialized
   *
   * NOTE: It always compare dayTracker and currentDayTrackedData
   * to make sure that there is data sync issue.
   *
   */
  @action createDayTracker = async () => {
    const {
      User: {
        lastCheckinId,
        token,
      },
      MealPlan: {
        currentWeekNumber,
      }
    } = this.getStores()
    try {
      await this.getDayTracker()
      if (!this.dayTracker && !this.selectedDayTrackedData) {
        const { data } = await Api.createExerciseTracker(
          token,
          lastCheckinId,
          currentWeekNumber,
          this.dayIndex + 1,
        )
        this.dayTracker = data
        this.latestWeekTrackedData.push(data)
        this.latestWeekTrackedData = toJS(this.latestWeekTrackedData).sort((prev, next) => prev.day - next.day)
        return
      } else if (this.dayTracker && this.selectedDayTrackedData) {
        return
      }
      throw new Error('Error in exercises data sync!')
    } catch (error) {
      //console.log('Error from createDayTracker: ', error.response)
      this.dayTracker = null
      throw new Error('Error when creating day tracker!')
    }
  }

  @action getDayTracker = async () => {
    try {
      if (!this.dayTracker) {
        const {
          User: {
            lastCheckinId,
            token,
          },
          MealPlan: {
            currentWeekNumber,
          },
        } = this.getStores()
        const { data } = await Api.getExerciseTracker(
          token,
          lastCheckinId,
          currentWeekNumber,
          this.dayIndex + 1,
        )
        this.dayTracker = data.length > 0 ? data[0] : null
      }
    } catch (error) {
      this.dayTracker = null
      throw new Error('Error when fetching day tracker!')
    }
  }

  @action trackExercise = async (id, mins) => {
    const {
      User: {
        mealPlanPaused,
        token,
      },
      Profile: {
        setOverallStats
      },
      FirebaseStore: {
        setAppVersionFirebase,
      },
      //meals: { setFirebaseAppVersion },
      HealthKit: { getCaloriesBurnData },
    } = this.getStores()
    try {
      if (mins <= 0 || !id || +mealPlanPaused > 0) {
        throw new Error('Sorry, Can\'t track exercise because meal plan be paused!')
      }
      await this.createDayTracker()
      const data = {
        exercise: id,
        tracker: this.dayTracker.id,
        cal: this.getCalsById(id, mins),
        minutes: mins,
      }
      const { data: newTrackedData } = await Api.trackExercise(token, data)
      const dayData = this.latestWeekTrackedData.find(daily => daily.day === this.dayIndex + 1)
      dayData.total_minutes += newTrackedData.minutes
      dayData.total_calories += newTrackedData.cal
      dayData.logged_exercises.push(newTrackedData)
      // Update health kit data
      getCaloriesBurnData()
      // sync to web
      setAppVersionFirebase()

      setOverallStats('exercises', mins, true)
    } catch (error) {
      //console.log('Error from trackExercise: ', error.response)
      throw new Error('Error when track exercise!')
    }
  }

  @action untrackExercise = async id => {
    const {
      //meals: { setfirebaseAppVersion },
      HealthKit: { getCaloriesBurnData },
      User: {
        token,
      },
      Profile: {
        setOverallStats
      },
      FirebaseStore: {
        setAppVersionFirebase,
      }
    } = this.getStores()
    try {
      await Api.untrackExercise(token, id)
      const dayData = this.latestWeekTrackedData.find(daily => daily.day === this.dayIndex + 1)
      const curExercise = this.selectedDayTrackedData.logged_exercises.find(el => el.id === id)
      dayData.total_minutes -= curExercise.minutes
      dayData.total_calories -= curExercise.cal
      dayData.logged_exercises = dayData.logged_exercises.filter(el => el.id !== id)
      // setFirebaseAppVersion()
      getCaloriesBurnData()
      // sync to web
      setAppVersionFirebase()

      const mins = curExercise.minutes
      setOverallStats('exercises', mins, false)
    } catch (error) {
      //console.log('Error from untrackExercise: ', error.response)
      throw new Error('Error when untracking exercise!')
    }
  }

  @action unpdateExercise = async (id, mins/*, day*/) => {
    const {
      User: {
        mealPlanPaused,
        token,
      },
      // meals: { setFirebaseAppVersion },
      HealthKit: { getCaloriesBurnData },
      FirebaseStore: {
        setAppVersionFirebase,
      }
    } = this.getStores()
    try {
      if (!id || mins <= 0 || +mealPlanPaused > 0) {
        throw new Error('Sorry, Can\'t update exercise!')
      }
      await this.createDayTracker()
      const data = {
        exercise: id,
        tracker: this.dayTracker.id,
        cal: this.getCalsById(id, mins),
        minutes: mins,
      }
      const dayData = this.latestWeekTrackedData.find(daily => daily.day === this.dayIndex + 1)
      const loggedExercise = dayData.logged_exercises.find(exerciseData => exerciseData.exercise === id)
      let res
      if (loggedExercise) {
        res = await Api.updateExercise(token, loggedExercise.id, data)
      } else {
        res = await Api.trackExercise(token, data)
      }
      res
      //const newTrackedData = res.data
      await this.getLatestWeekTrackedData()
      getCaloriesBurnData()
      // sync to web
      setAppVersionFirebase()
    } catch (error) {
      //console.log('Error from updateExercise: ', error)
      throw new Error('Error when updating exercise!')
    }
  }

  getExerciseDataById = id =>
    this.exerciseList.find(exercise => exercise.id === id)

  getCalsById = (id, mins) => {
    const {
      User: {
        weight,
        weightCategory,
      }
    } = this.getStores()
    const exerciseData = this.getExerciseDataById(id)
    const cals = (weight * exerciseData[`ib${weightCategory}`]) / weightCategory
    return Math.round(cals * mins / 60)
  }

  @computed get caloriesBurnData() {
    const {
      User: {
        lastCheckinDate,
      },
    } = this.getStores()
    const caloriesData = this.latestWeekTrackedData.map(dayData => {
      const date = moment(Date.parse(lastCheckinDate)).add(dayData.day - 1, 'days').toISOString()
      return {
        value: dayData.total_calories,
        startDate: date,
        endDate: date,
      }
    })
    return caloriesData
  }
}

export default ExerciseTrack
