import { observable, computed, action } from 'mobx'
import moment from 'moment'

import Api from '../utils/Api'

const strKeyViewdTips = 'ViewedTipIDs'

export default class Tips {
  constructor(getStores) {
    this.getStores = getStores
  }

  @observable tips = []

  fetch = () => Promise.all([
    this.getTips()
  ])

  @action getTips = async () => {
    const { User: { token } } = this.getStores()
    try {
      const { data } = await Api.getTips(token)
      data.forEach(el => this.addGeneralTip(el))
      // this.sortTipsByTime()
      await this.getReadTips()

      return Promise.resolve();
    }
    catch (err) {
      return Promise.reject(err);
    }
  }

  // @action sortTipsByTime = () => {
  //   if (this.tips) {
  //     this.tips.sort((tip1, tip2) => {
  //       if (moment(tip1.created_at).isAfter(moment(tip2.created_at))) return 1
  //       else if (moment(tip1.created_at).isBefore(moment(tip2.created_at))) return -1
  //       else return 0
  //     })
  //   }
  // }

  @action getReadTips = async () => {
    try {
      const { User: { token } } = this.getStores()
      const { data } = await Api.getMisc(token, strKeyViewdTips)
      if (data.value && this.tips && this.tips.length) {
        const readTips = JSON.parse(data.value)
        this.tips = this.tips.map(tip => {
          if (readTips.find(tipID => tipID === tip.id)) {
            tip.isRead = true
          } else {
            tip.isRead = false
          }
          return tip
        })
      }
    } catch (err) {
      //
    }
  }

  @computed get unreadTipsLen() {
    const unreadTips = this.tips.filter(tip => !tip.isRead)
    return unreadTips ? unreadTips.length : 0
  }

  @computed get latestUnreadTip() {
    const unreadTips = this.tips.filter(tip => !tip.isRead)
    return unreadTips ? unreadTips[0] : null
  }

  @action addGeneralTip = tip => {
    const isExist = this.tips.find(el => el.id === tip.id)
    if (!isExist) {
      const tipTmp = {
        ...tip,
        isRead: false,
        created_at: moment(Date.parse(tip.created_at ? tip.created_at : (tip.date ? tip.date : moment()))).local().calendar(),
      }
      this.tips.push(tipTmp)
    }
  }

  @action removeTipById = async id => {
    try {
      const idx = this.tips.findIndex(tip => tip.id === id)
      if (idx === -1) {
        return false
      }
      const { User: { token } } = this.getStores()
      await Api.removeTip(token, id)
      this.tips.splice(idx, 1)
    } catch (error) {
      //console.warn(error)
      throw error
    }
  }

  @action setAsReadTipById = async id => {
    try {
      const currentTip = this.getTipById(id)
      if (currentTip && !currentTip.isRead) {
        currentTip.isRead = true
        const readTips = this.tips.filter(tip => tip.isRead).map(tip => tip.id)
        const { User: { token } } = this.getStores()
        await Api.setMisc(token, {
          key: 'ViewedTipIDs',
          value: JSON.stringify(readTips)
        })
        this.tips.splice(
          this.tips.indexOf(currentTip),
          1,
          {
            ...currentTip,
            isRead: true,
          }
        )
      }
    } catch (error) {
      //console.warn(error)
      return error
    }
  }

  getTipById = id =>
    this.tips.find(tip => tip.id === id)

  @observable todayTip = { isRead: false, title: 'Hey Brian! Quick Tip', text: 'Remember to try and get all of your water in today. I think its gonna really help show the results you want. Remember to try and get all of your water in today. I think its gonna really help show the results you want.' }

  // add tip from firebase
  @action addDayMealTip = tip => {
    const { MealPlan: { currentMealId } } = this.getStores()
    if (currentMealId) {
      this.dayTips.push({
        mealId: this.currentMealId,
        tip,
      })
    }
  }
}
