/*
*   author: denis
*   date:   08/26/2018
*/

import { observable, action, computed } from 'mobx';
import Converter from 'convert-units';
import moment from 'moment';

import Api from '../utils/Api';

class Checkin {
  constructor(getStores) {
    this.getStores = getStores;
  }

  fetch = () => Promise.all([
    this.getAllCheckins()
  ])

  @action getAllCheckins = async () => {
    const { User: { token } } = this.getStores()
    try {
      const { data } = await Api.getAllCheckins(token)
      this.allCheckins = data
      // this.sortCheckinsByTime()

      return Promise.resolve();
    }
    catch (err) {
      return Promise.reject(err);
    }
  }

  // @action sortCheckinsByTime = () => {
  //   if (this.allCheckins) {
  //     this.allCheckins.sort((checkin1, checkin2) => {
  //       if (moment(checkin1.created_at).isAfter(moment(checkin2.created_at))) return 1
  //       else if (moment(checkin1.created_at).isBefore(moment(checkin2.created_at))) return -1
  //       else return 0
  //     })
  //   }
  // }

  @computed get getHipsAndWaist() {
    const data = this.allCheckins.reverse().reduce((accumulator, checkin, index) => {
      accumulator.createdAt.push(checkin.created_at)
      accumulator.hips.push(
        checkin.hips
          ? (Math.round(checkin.hips * 10) / 10)
          : index === 0
            ? 0
            : accumulator.hips[index - 1]
      )
      accumulator.waist.push(
        checkin.waist
          ? (Math.round(checkin.waist * 10) / 10)
          : index === 0
            ? 0
            : accumulator.waist[index - 1]
      )
      return accumulator
    }, {
      createdAt: [],
      hips: [],
      waist: []
    })

    const count = data.createdAt.length
    data.createdAt.push(moment().format())
    data.hips.push(data.hips[count - 1])
    data.waist.push(data.waist[count - 1])

    return {
      ...data,
      count: (count + 1),
      lastHips: (Math.round(data.hips[count] * 10) / 10),
      lastWaist: (Math.round(data.waist[count] * 10) / 10)
    }
  }

  @action getRoundedHipsAndWaist = (value) => {
    const { User: { unit } } = this.getStores()
    const val = parseFloat(value)
    if (unit === 'us') {
      return (Math.round(val * 10) / 10)
    } else {
      return (Math.round(Converter(val).from('in').to('cm') * 10) / 10)
    }
  }

  @computed get getHipsAndWaistUnit() {
    const { User: { unit } } = this.getStores()
    if (unit === 'us') {
      return 'in'
    } else {
      return 'cm'
    }
  }

  @action getRoundedWeight = (value) => {
    const { User: { unit } } = this.getStores()
    const val = parseFloat(value)
    if (unit === 'us') {
      return (Math.round(val * 10) / 10)
    } else {
      return (Math.round(Converter(val).from('lb').to('kg') * 10) / 10)
    }
  }

  @computed get getWeightUnit() {
    const { User: { unit } } = this.getStores()
    if (unit === 'us') {
      return 'lbs'
    } else {
      return 'kg'
    }
  }

  @computed get getBodyFat() {
    const bodyFats = this.allCheckins.reverse().reduce((accumulator, checkin) => {
      if (checkin.bodyfat && checkin.bodyfat > 0) {
        accumulator.push(Math.round(checkin.bodyfat * 10) / 10)
      }
      return accumulator
    }, [])
    const count = bodyFats.length
    return {
      firstBodyFat: bodyFats[0] ? bodyFats[0] : 0,
      currentBodyFat: bodyFats[count - 1] ? bodyFats[count - 1] : 0
    }
  }

  @observable allCheckins = []

  @observable checkin = [
    {
      id: 0,
      type: 'info',
      title: 'Hey name, it’s time for your weekly check-in',
      description: 'Check-in and update your measurments so we can update your plan for next week!'
    },
    {
      id: 1,
      type: 'select',
      title: 'How’s your mood this past week?',
      highlightedTitle: 'mood',
      select: [
        {
          id: 'GREAT',
          title: 'Great - Feeling good',
        },
        {
          id: 'OK',
          title: 'OK - Good & Bad Days',
        },
        {
          id: 'BAD',
          title: 'Not Great - Irritable'
        }
      ]
    },
    {
      id: 2,
      type: 'select',
      title: 'How’s your hunger been this past week?',
      highlightedTitle: 'hunger',
      select: [
        {
          id: 'OK',
          title: 'Great - I get enough food'
        },
        {
          id: 'FULL',
          title: 'Too full '
        },
        {
          id: 'HUNGRY',
          title: 'Really hungry'
        }
      ]
    },
    {
      id: 3,
      type: 'select',
      title: 'How’s your sleep been this past week?',
      highlightedTitle: 'sleep',
      select: [
        {
          id: 'AWAKE',
          title: 'Great - Sleeping like a baby'
        },
        {
          id: 'OK',
          title: 'OK - Good & Bad Nights'
        },
        {
          id: 'BAD',
          title: 'Not Great - Feeling Tired'
        }
      ]
    },
    {
      id: 4,
      type: 'input',
      ref: 'weight',
      metric: {
        unit: 'kg',
        max: 225,
        min: 30,
      },
      imperial: {
        unit: 'lbs',
        max: 500,
        min: 50,
      },
      title: 'Let’s update your current weight',
      description: 'Enter your current weight',
      highlightedTitle: 'current weight',
    },
    {
      id: 5,
      type: 'input',
      ref: 'hips',
      metric: {
        unit: 'cm',
        max: 250,
        min: 50,
      },
      imperial: {
        unit: 'in',
        max: 100,
        min: 20,
      },
      title: 'Let’s take your hip measurement',
      description: 'Enter your hip measurement',
      highlightedTitle: 'hip',
    },
    {
      id: 6,
      type: 'input',
      ref: 'waist',
      metric: {
        unit: 'cm',
        max: 250,
        min: 50,
      },
      imperial: {
        unit: 'in',
        max: 100,
        min: 20,
      },
      title: 'Let’s take your waist measurement',
      description: 'Enter your waist measurement',
      highlightedTitle: 'waist'
    },
    // {
    //   id: 'prior_week_success',
    //   type: 'selectValue',
    //   title: 'How much of the\nmeal plan did you eat last week?',
    //   highlightedTitle: '',
    //   text: 'Did you complete 70% of your meals successfully this week?',
    //   // values: '100% Perfect, Less than 100%',
    //   values: 'Yes, No'
    // },
    {
      id: 7,
      type: 'takePhoto',
      title: 'Let’s update your',
      highlightedTitle: 'progress picture',
    },
    {
      id: 8,
      type: 'info_complete',
      title: 'You’re all set!',
      description: 'Your plan has been updated and you’re ready to go'
    },
    // {
    //   id: 'fitpic',
    //   type: 'editPhoto',
    // },
    // {
    //   type: 'gears'
    // },
    // {
    //   type: 'last',
    // }
  ]

  @observable checkinResult = [];
  @observable checkinBoolean = false

  @action setCheckinResult = (data) => {
    const findRes = this.checkinResult.find(res => res.id === data.id)
    if(!findRes) {
      this.checkinResult.push(data)
    } else {
      this.checkinResult.splice(this.checkinResult.indexOf(findRes), 1, data)
    }
  }

  @action createCheckin = async (imageUri) => {
    const {
      User: {
        token,
        checkAuth
      },
      Global,
      HealthKit: {
        setWeight,
      },
      FirebaseStore: {
        clearMealsFirebase
      }
    } = this.getStores();
    try {
        const mood = this.checkinResult[0].value.id
        const hunger = this.checkinResult[1].value.id
        const sleep = this.checkinResult[2].value.id
        const weight = this.checkinResult[3].value
        const hips = this.checkinResult[4] ? this.checkinResult[4].value : null
        const waist = this.checkinResult[5] ? this.checkinResult[5].value : null

        const results = {
          mood: mood,
          hunger: hunger,
          sleep: sleep,
          weight: weight,
          hips: hips,
          waist: waist
        };
        const { data: { id: checkinId } } = await Api.createCheckin(token, results);
        this.checkinBoolean = true;
        const { data } = await Api.checkAuth(token);
        checkAuth(data);

        // write to healthkit
        setWeight(results.weight)

        clearMealsFirebase()

        if (imageUri) {
          await Api.uploadCheckinImage(token, checkinId, imageUri);
        }
        await Global.fetchData();

        return Promise.resolve();
    } catch (error) {
        return Promise.reject(error);
    }
  }

  @action initializeCheckinBoolean = () => {
    this.checkinBoolean = false;
  }
}

export default Checkin;
