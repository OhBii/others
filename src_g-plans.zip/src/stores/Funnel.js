// @flow

import { observable, action } from 'mobx';
import { persist } from 'mobx-persist';
import Api from '../utils/Api';

class Funnel {
  constructor(getStores) {
    this.getStores = getStores;
    this.getIntroItems()
  }

  @persist @observable quizId = null
  @persist @observable signUpUUID = null

  @action setQuizId = (id) => {
    this.quizId = id
  }

  @action setSignUpUUID = (uuid) => {
    this.signUpUUID = uuid
  }

  @action clearQuiz = () => {
    this.quizId = null
    this.signUpUUID = null
  }

  @observable quiz = [
    {
      id: 1,
      type: 'gender',
      question: 'Are you male or female?',
      question_en: '',
      question_es: '',
      question_zh_hans: '',
      description: 'Women and men have different metabolic rates, and this info helps maximize your unique Keto N8 Challenge. Click your gender below:',
      description_en: '',
      description_es: '',
      description_zh_hans: '',
      select: [
        {
          id: 1,
          title: 'Male',
          title_en: 'Male',
          title_es: 'Masculino',
          title_zh_hans: '男'
        },
        {
          id: 2,
          title: 'Female',
          title_en: 'Female',
          title_es: 'Hembra',
          title_zh_hans: '女'
        }
      ],
    },
    {
      id: 2,
      type: 'age',
      question: 'How old are you?',
      question_en: '',
      question_es: '',
      question_zh_hans: '',
      description: '',
      description_en: '',
      description_es: '',
      description_zh_hans: '',
    },
    {
      id: 3,
      type: 'picker',
      question: 'How tall are you?',
      question_en: '',
      question_es: '',
      question_zh_hans: '',
      description: '',
      description_en: '',
      description_es: '',
      description_zh_hans: '',
    },
    {
      id: 4,
      type: 'select',
      question: 'Do you like to get Physical?',
      question_en: '',
      question_es: '',
      question_zh_hans: '',
      description: 'Tell us about your weekly physical activity:',
      description_en: '',
      description_es: '',
      description_zh_hans: '',
      select: [
        {
          id: 3,
          title: 'Chillin’ with my Remote ',
          title_en: '',
          title_es: '',
          title_zh_hans: '',
          text: '(Most of my müvement is done from the desk or a couch.)',
          text_en: '(Most of my müvement is done from the desk or a couch.)',
          text_es: '',
          text_zh_hans: ''
        },
        {
          id: 4,
          title: 'Work in Progress',
          title_en: '',
          title_es: '',
          title_zh_hans: '',
          text: '(I make a conscious effort to workout 1-2 times a week.)',
          text_en: '(I make a conscious effort to workout 1-2 times a week.)',
          text_es: '',
          text_zh_hans: ''
        },
        {
          id: 5,
          title: 'Fitness on my Mind',
          title_en: '',
          title_es: '',
          title_zh_hans: '',
          text: '(I get to the gym or workout 3-5 times a week.)',
          text_en: '(I get to the gym or workout 3-5 times a week.)',
          text_es: '',
          text_zh_hans: ''
        },
        {
          id: 6,
          title: 'Love my Müvement',
          title_en: '',
          title_es: '',
          title_zh_hans: '',
          text: '(I do a legitimate workout once a day at least 6 days a week.)',
          text_en: '(I do a legitimate workout once a day at least 6 days a week.)',
          text_es: '',
          text_zh_hans: ''
        },
        {
          id: 7,
          title: 'MAX Activity',
          title_en: '',
          title_es: '',
          title_zh_hans: '',
          text: '(Some call me obsessed. I call me ripped.)',
          text_en: '(Some call me obsessed. I call me ripped)',
          text_es: '',
          text_zh_hans: ''
        }
      ]
    },
    {
      id: 5,
      type: 'select',
      question: 'For the love of Food, tell us about your eating habits',
      question_en: '',
      question_es: '',
      question_zh_hans: '',
      description: '',
      description_en: '',
      description_es: '',
      description_zh_hans: '',
      select: [
        {
          id: 8,
          title: '',
          title_en: '',
          title_es: '',
          title_zh_hans: '',
          text: 'I eat clean - If it’s processed, it’s not getting near this body.',
          text_en: '',
          text_es: '',
          text_zh_hans: '',
        },
        {
          id: 9,
          title: '',
          title_en: '',
          title_es: '',
          title_zh_hans: '',
          text: 'I eat generally pretty well but fall off the wagon every now and then with a "Cheat Day."',
          text_en: '',
          text_es: '',
          text_zh_hans: '',
        },
        {
          id: 10,
          title: '',
          title_en: '',
          title_es: '',
          title_zh_hans: '',
          text: 'I have an awareness of healthy eating and make a conscious effort…but late night ice cream or potato chips are kind of my jam.',
          text_en: '',
          text_es: '',
          text_zh_hans: '',
        },
        {
          id: 11,
          title: '',
          title_en: '',
          title_es: '',
          title_zh_hans: '',
          text: 'Fast food, sodas, and packaged snacks are no strangers to me.',
          text_en: '',
          text_es: '',
          text_zh_hans: '',
        }
      ]
    },
    {
      id: 6,
      type: 'select',
      question: 'Energy is everything. Tell us how you feel:',
      question_en: '',
      question_es: '',
      question_zh_hans: '',
      description: '',
      description_en: '',
      description_es: '',
      description_zh_hans: '',
      select: [
        {
          id: 12,
          title: '',
          title_en: '',
          title_es: '',
          title_zh_hans: '',
          text: 'Honestly, I feel like crap. My energy is non-existent and I struggle to stay positive.',
          text_en: '',
          text_es: '',
          text_zh_hans: '',
        },
        {
          id: 13,
          title: '',
          title_en: '',
          title_es: '',
          title_zh_hans: '',
          text: 'Swings are a normal thing for me. My energy is up and down and so is my mood.',
          text_en: '',
          text_es: '',
          text_zh_hans: '',
        },
        {
          id: 14,
          title: '',
          title_en: '',
          title_es: '',
          title_zh_hans: '',
          text: 'My energy stays pretty high, and I consider myself well balanced and generally positive.',
          text_en: '',
          text_es: '',
          text_zh_hans: '',
        },
        {
          id: 15,
          title: '',
          title_en: '',
          title_es: '',
          title_zh_hans: '',
          text: 'I have AMAZING energy ALL THE TIME. I love life and today is always THE BEST DAY EVER!!!',
          text_en: '',
          text_es: '',
          text_zh_hans: '',
        }
      ]
    },
    {
      id: 7,
      type: 'select',
      question: 'Tell us how well you slay the stress in your life:',
      question_en: '',
      question_es: '',
      question_zh_hans: '',
      description: '',
      description_en: '',
      description_es: '',
      description_zh_hans: '',
      select: [
        {
          id: 16,
          title: '',
          title_en: '',
          title_es: '',
          title_zh_hans: '',
          text: 'I rarely feel "stressed out;” Zen is more my MO.',
          text_en: '',
          text_es: '',
          text_zh_hans: '',
        },
        {
          id: 17,
          title: '',
          title_en: '',
          title_es: '',
          title_zh_hans: '',
          text: 'There is stress in my life, but I tend to cope fairly well and rarely freak out.',
          text_en: '',
          text_es: '',
          text_zh_hans: '',
        },
        {
          id: 18,
          title: '',
          title_en: '',
          title_es: '',
          title_zh_hans: '',
          text: 'I have multiple areas of stress in my life, and I have a difficult time keeping it all together.',
          text_en: '',
          text_es: '',
          text_zh_hans: '',
        },
        {
          id: 19,
          title: '',
          title_en: '',
          title_es: '',
          title_zh_hans: '',
          text: 'Stress is an all the time thing for me, and a Zen Master couldn’t even help me.',
          text_en: '',
          text_es: '',
          text_zh_hans: '',
        }
      ]
    },
    {
      id: 8,
      slide: 'refer',
      question: 'Who referred you?',
      question_en: '',
      question_es: '',
      question_zh_hans: '',
      description: 'Please enter your referring\n member\'s web ID:',
      description_en: '',
      description_es: '',
      description_zh_hans: '',
    }
  ]
  @observable quizFromServer = null

  @action getQuiz = async () => {
    try {
      const response = await Api.getQuiz()
      // console.log(response.data[0])
      this.getQuizSuccess(response.data)
      return Promise.resolve()
    } catch (err) {
      // console.log(err.response)
      Promise.reject(err)
    }
  }

  @action getQuizSuccess = (data) => {
    this.quizFromServer = data[0].questions.reverse()
  }

  @action createQuiz = async () => {
    try {
      const response = await Api.createQuiz()
      this.setQuizId(response.data.id)
      Promise.resolve()
    } catch (err) {
      Promise.reject(err)
    }
  }

  @action getQuizAnswer = async (id) => {
    try {
      const response = await Api.getQuizAnswer(id)
      this.initQuizResult(response.data)
      // console.log(this.quizResult.slice())
      Promise.resolve()
    } catch (err) {
      Promise.reject(err)
    }
  }

  @persist('object') @observable quizResult
  @action initQuizResult = (data) => {
    this.quizResult = []
    data.forEach(answer => {
      const data = {
        uid: answer.id,
        id: answer.question,
        value: this.quiz[answer.question - 1].select
          ? this.quiz[answer.question - 1].select.find(el => el.id === answer.answer_choice)
          : answer.answer_choice
      }
      this.quizResult.push(data)
    })
  }

  @action setQuizResult = async (data) => {
    const index = this.quizResult.findIndex(el => el.id === data.id)
    try {
      if(index === -1) {
        // post
        if (data.value.id) {
          await Api.postQuizAnswer(this.quizId, data.id, data.value.id)
          // const response = await Api.postQuizAnswer(this.quizId, data.id, data.value.id)
          // console.log(response)
        }
        this.quizResult.push(data)
      } else {
        // put
        if (data.value.id) {
          await Api.putQuizAnswer(this.quizId, this.quizResult[index].uid, data.value.id)
        }
        this.quizResult.splice(index, 1, data)
      }
      Promise.resolve()
    } catch (err) {
      // console.log(err.response)
      Promise.reject(err)
    }
  }

  // intro
  @observable intro = [
    {
      id: 1,
      type: 'info',
      title: 'Welcome!',
      description: 'Lets go through a quick into to show you some cool features of the app!',
      image: 0
    },
    {
      id: 2,
      type: 'info',
      title: 'Recipe Cards',
      description: 'Click on recipe cards to see your perfect keto meals. You can easily modify any recipe inside the card!',
      image: 1
    },
    {
      id: 3,
      type: 'info',
      title: 'N8 Plate',
      description: 'Counting calories is dead. Come alive with N8 Plate tracking. Score all your meals tracked by macros! ',
      image: 2
    },
    {
      id: 4,
      type: 'info',
      title: 'Plan Ahead!',
      description: 'With your the meal planner, you can plan your meals ahead of time and even add up a grocery list for the shopping time!',
      image: 3
    },
    {
      id: 5,
      type: 'info',
      title: 'Your Almost Done!',
      description: 'Before we get going, lets customize your plan with what you like to eat!',
      image: 4
    },
    {
      id: 6,
      title: 'What proteins\ndo you like to eat?',
      type: 'select',
      items: [{title: 'beef', checked: false}, {title: 'chicken', checked: false}, {title: 'eggs', checked: false}, {title: 'pork', checked: false}, {title: 'seafood', checked: false}]
    },
    {
      id: 7,
      title: 'What Veggies\ndo you like to eat?',
      type: 'select',
      items: [{title: 'broccoli', checked: false}, {title: 'kale', checked: false}, {title: 'leafy greens', checked: false}, {title: 'roots veggies', checked: false}, {title: 'squashes', checked: false}]
    },
    {
      id: 8,
      title: 'What Snacks\ndo you like to eat?',
      type: 'select',
      items: [{title: 'berries', checked: false}, {title: 'fruits', checked: false}, {title: 'melons (watermelon, cantaloupe, etc)', checked: false}]
    },
    {
      id: 9,
      title: 'Track progress with a selfie',
      type: 'select',
      items: [{title: 'Sure I can take a selfie now', camera: true}, {title: 'No I can’t do this now', camera: false}]
    }
  ]

  @observable introFlex = [
    {
      id: 1,
      type: 'info',
      title: 'Welcome!',
      description: 'Lets go through a quick into to show you some cool features of the app!',
      image: 0
    },
    {
      id: 2,
      type: 'info',
      title: 'Recipe Cards',
      description: 'Click on recipe cards to see your perfect keto meals. You can easily modify any recipe inside the card!',
      image: 1
    },
    {
      id: 3,
      type: 'info',
      title: 'N8 Plate',
      description: 'Counting calories is dead. Come alive with N8 Plate tracking. Score all your meals tracked by macros! ',
      image: 2
    }
  ]

  @observable introResult = []
  getIntroItems = () => {
    this.intro.map((elm) => {
      if(elm.type === 'select') {
        this.introResult.push({id: elm.id, items: elm.items})
      }
    })
  }

  @action setIntroResult = (data, ind) => {
    for(let i = 0; i <= this.introResult.length - 1; i++) {
      if(this.introResult[i].id === data.id) {
        this.introResult[i].items[ind].checked = !this.introResult[i].items[ind].checked
      }
    }
    return this.introResult
  }
}
export default Funnel;
