
import { observable, action } from 'mobx';

class SearchFood {

  constructor(getStores) {
    this.getStores = getStores;
  }

  fetch = () => Promise.all([

  ])

  @observable mealId = null;
  @observable foodList = [];
  @observable addedFoodList = [];
  @observable pageIndex = 0; // 0: empty, 1: search, 2: add
  @observable searchLoading = false;
  @observable recendAddedFoodList = []

  @action initallFoodList = () => {
    this.foodList = [];
  }

  @action getSearchResult = (pageIndex, result) => {
    // Each item's exchange should be set 1 if it is undefined
    result.forEach(item => {
      if (!isFinite(item.exchanges)) item.exchanges = 1
    })
    this.foodList = result
    this.pageIndex = pageIndex
  }

  @action addItem = (pageIndex, item) => {
    this.pageIndex = pageIndex;
    if (!this.addedFoodList.find(el => item.name === el.name)) {
      this.addedFoodList.push(item);
    }
  }

  @action deleteItem = (item) => {
    const idx = this.addedFoodList.findIndex(el => el.name === item.name)
    if (idx !== -1) {
      const temp = this.addedFoodList.slice()
      temp.splice(idx, 1)
      this.addedFoodList = temp
    }
  }

  @action addItemToRecent = (item) => {
    if (!this.recendAddedFoodList.find(el => item.name === el.name)) {
      this.recendAddedFoodList.push(item)
    }
  }

  @action resetStore = () => {
    this.mealId = null;
    this.addedFoodList = [];
    this.resetSearchList()
  }

  @action resetSearchList = () => {
    this.foodList = [];
    this.pageIndex = 0;
  }

  @action onDone = (mealId) => {
    const {
      MealPlan: { addItemsToMeal }
    } = this.getStores();
    addItemsToMeal(mealId, this.addedFoodList)
  }

  @action setPageIndx = (pageIndex) => {
    this.pageIndex = pageIndex;
  }
  @action handleLoading = (flag) => this.searchLoading = flag

}

export default SearchFood;
