// @flow

import { Platform } from 'react-native';
import { observable, action } from 'mobx';
import Api from '../utils/Api';
import Constants from '../global/Constants'

class App {
  constructor(getStores) {
    this.getStores = getStores;
  }

  fetch = () => Promise.all([
    //this.getProducts(),
    this.getBlogs()
  ])

  @observable isAndroid = Platform.OS === 'android';
  @observable isIOS     = Platform.OS === 'ios';
  @observable products = [];
  @observable blogs = {};
  @observable recipes = [
    {
      id: 1,
      title: 'Skillet Ham Hash',
      type: 'easy',
      dateFrom: '8.00',
      dateTo: '9.00',
      image: 'https://www.goredforwomen.org/wp-content/uploads/2014/03/Skillet-Ham-Hash.jpg',
      logged: false,
      missed: false,
      pro: 22,
      fats: 6,
      carbs: 30,
      recipeItems: [
        {
          itemName: 'Coffee',
          itemAmount: 2,
          itemUnit: 'cups'
        },
        {
          itemName: 'Keto / Kreme Keto / Kreme Keto / Kreme',
          itemAmount: 2,
          itemUnit: 'pkg'
        },
        {
          itemName: 'Sugar',
          itemAmount: 2,
          itemUnit: 'tbsp'
        },
      ]
    },
    {
      id: 2,
      title: 'Curried Pork Tenderloin with Cranberry Chutney',
      type: 'hard',
      dateFrom: '8.00',
      dateTo: '9.00',
      image: 'https://www.goredforwomen.org/wp-content/uploads/2013/10/Curried-Pork-Tenderloin-Fall-2013-Meats.png',
      logged: false,
      missed: false,
      pro: 22,
      fats: 6,
      carbs: 30,
      recipeItems: [
        {
          itemName: 'Coffee',
          itemAmount: 2,
          itemUnit: 'cups'
        },
        {
          itemName: 'Keto / Kreme Keto / Kreme Keto / Kreme',
          itemAmount: 2,
          itemUnit: 'pkg'
        },
        {
          itemName: 'Sugar',
          itemAmount: 2,
          itemUnit: 'tbsp'
        },
      ]
    },
    {
      id: 3,
      title: 'Spicy Pumpkin Burritos',
      type: 'middle',
      dateFrom: '8.00',
      dateTo: '9.00',
      image: 'https://www.goredforwomen.org/wp-content/uploads/2013/10/Spicy-Pumpkin-Burritos-Fall-2013-Veg-Entrees.png',
      logged: false,
      missed: false,
      pro: 22,
      fats: 6,
      carbs: 30,
      recipeItems: [
        {
          itemName: 'Coffee',
          itemAmount: 2,
          itemUnit: 'cups'
        },
        {
          itemName: 'Keto / Kreme Keto / Kreme Keto / Kreme',
          itemAmount: 2,
          itemUnit: 'pkg'
        },
        {
          itemName: 'Sugar',
          itemAmount: 2,
          itemUnit: 'tbsp'
        },
      ]
    },
    {
      id: 4,
      title: 'Skillet Apples',
      type: 'easy',
      dateFrom: '8.00',
      dateTo: '9.00',
      image: 'https://www.goredforwomen.org/wp-content/uploads/2013/10/Skillet-Apples-Fall-2013-Vegs-and-Sides.png',
      logged: false,
      missed: false,
      pro: 22,
      fats: 6,
      carbs: 30,
      recipeItems: [
        {
          itemName: 'Coffee',
          itemAmount: 2,
          itemUnit: 'cups'
        },
        {
          itemName: 'Keto / Kreme Keto / Kreme Keto / Kreme',
          itemAmount: 2,
          itemUnit: 'pkg'
        },
        {
          itemName: 'Sugar',
          itemAmount: 2,
          itemUnit: 'tbsp'
        },
      ]
    },
    {
      id: 5,
      title: 'Curried Pork Tenderloin with Cranberry Chutney',
      type: 'hard',
      dateFrom: '8.00',
      dateTo: '9.00',
      image: 'https://www.goredforwomen.org/wp-content/uploads/2013/10/Curried-Pork-Tenderloin-Fall-2013-Meats.png',
      logged: false,
      missed: false,
      pro: 22,
      fats: 6,
      carbs: 30,
      recipeItems: [
        {
          itemName: 'Coffee',
          itemAmount: 2,
          itemUnit: 'cups'
        },
        {
          itemName: 'Keto / Kreme Keto / Kreme Keto / Kreme',
          itemAmount: 2,
          itemUnit: 'pkg'
        },
        {
          itemName: 'Sugar',
          itemAmount: 2,
          itemUnit: 'tbsp'
        },
      ]
    },
    {
      id: 6,
      title: 'Spicy Pumpkin Burritos',
      type: 'middle',
      dateFrom: '8.00',
      dateTo: '9.00',
      image: 'https://www.goredforwomen.org/wp-content/uploads/2013/10/Spicy-Pumpkin-Burritos-Fall-2013-Veg-Entrees.png',
      logged: false,
      missed: false,
      pro: 22,
      fats: 6,
      carbs: 30,
      recipeItems: [
        {
          itemName: 'Coffee',
          itemAmount: 2,
          itemUnit: 'cups'
        },
        {
          itemName: 'Keto / Kreme Keto / Kreme Keto / Kreme',
          itemAmount: 2,
          itemUnit: 'pkg'
        },
        {
          itemName: 'Sugar',
          itemAmount: 2,
          itemUnit: 'tbsp'
        },
      ]
    },
    {
      id: 7,
      title: 'Skillet Ham Hash',
      type: 'easy',
      dateFrom: '8.00',
      dateTo: '9.00',
      image: 'https://www.goredforwomen.org/wp-content/uploads/2014/03/Skillet-Ham-Hash.jpg',
      logged: false,
      missed: false,
      pro: 22,
      fats: 6,
      carbs: 30,
      recipeItems: [
        {
          itemName: 'Coffee',
          itemAmount: 2,
          itemUnit: 'cups'
        },
        {
          itemName: 'Keto / Kreme Keto / Kreme Keto / Kreme',
          itemAmount: 2,
          itemUnit: 'pkg'
        },
        {
          itemName: 'Sugar',
          itemAmount: 2,
          itemUnit: 'tbsp'
        },
      ]
    }
  ]

  @observable challenges = [
    {
      id: 0,
      image: Constants.Images.CH_WATER,
      name: 'Water Warrior',
      points: 300,
      backgound: 'rgba(57,238,255,0.1)',
      description: 'Track 64 fluid ounces of water in a single day',
      complete: true,
      type: 'hard',
      total: 64
    },
    {
      id: 1,
      image: Constants.Images.CH_CHILLI,
      name: 'Snack Smash',
      points: 200,
      backgound: 'rgba(191,190,56,0.2)',
      description: 'Lorem ipsum dolor sit amet, consectetur.',
      complete: false,
      type: 'easy',
      total: 64
    },
    {
      id: 2,
      image: Constants.Images.CH_SIGN,
      name: 'Swap Warrior',
      points: 500,
      backgound: 'rgba(77,160,155,0.2)',
      description: 'Lorem ipsum dolor sit amet, consectetur.',
      complete: false,
      type: 'medium',
      total: 64
    },
    {
      id: 3,
      image: Constants.Images.CH_WATER,
      name: 'Water Warrior',
      points: 300,
      backgound: 'rgba(57,238,255,0.1)',
      description: 'Track 64 fluid ounces of water in a single day',
      complete: true,
      type: 'hard',
      total: 64
    },
    {
      id: 4,
      image: Constants.Images.CH_CHILLI,
      name: 'Snack Smash',
      points: 200,
      backgound: 'rgba(191,190,56,0.2)',
      description: 'Track 64 fluid ounces of water in a single day',
      complete: false,
      type: 'medium',
      total: 64
    },
    {
      id: 5,
      image: Constants.Images.CH_SIGN,
      name: 'Swap Warrior',
      points: 500,
      backgound: 'rgba(77,160,155,0.2)',
      description: 'Track 64 fluid ounces of water in a single day',
      complete: false,
      type: 'hard',
      total: 64
    },
    {
      id: 6,
      image: Constants.Images.CH_WATER,
      name: 'Water Warrior',
      points: 300,
      backgound: 'rgba(57,238,255,0.1)',
      description: 'Track 64 fluid ounces of water in a single day',
      complete: true,
      type: 'hard',
      total: 64
    },
    {
      id: 7,
      image: Constants.Images.CH_CHILLI,
      name: 'Snack Smash',
      points: 200,
      backgound: 'rgba(191,190,56,0.2)',
      description: 'Track 64 fluid ounces of water in a single day',
      complete: false,
      type: 'hard',
      total: 64
    },
    {
      id: 8,
      image: Constants.Images.CH_SIGN,
      name: 'Swap Warrior',
      points: 500,
      backgound: 'rgba(77,160,155,0.2)',
      description: 'Track 64 fluid ounces of water in a single day',
      complete: false,
      type: 'hard',
      total: 64
    }
  ]

  @observable modules = [
    {
      name: '3 Week Summmer Body',
      text: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil, iure.',
      color1: 'rgb(241, 39, 17)',
      color2: 'rgb(255, 246, 87)',
      likes: 100
    },
    {
      name: 'Atlethic Body',
      text: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil, iure.',
      color1: 'rgb(255, 55, 232)',
      color2: 'rgb(255, 156, 168)',
      likes: 200
    }
  ]

  @observable scrollTo = 0; //1: card, 2: water, 3: top
  @action setScrollTo = (index) => this.scrollTo = index;

  @action getProducts = () => {
    Api.getRecommendedProducts()
    .then( response => {
      this.products = response.data;
    })
  }

  @action getBlogs = async () => {
    try{
      const BlogsAll = await Promise.all([
        Api.getBlogs('en'),
        Api.getBlogs('es'),
        Api.getBlogs("zh"),
      ]);
      const { data:enBlogs } = BlogsAll[0];
      const { data:esBlogs } = BlogsAll[1];
      const { data:zhBlogs } = BlogsAll[2];
      this.blogs = {
        "en":enBlogs,
        "es":esBlogs,
        "zh_hans":zhBlogs
      }
      return Promise.resolve();
    } catch (error){
      return Promise.reject(error)
    }
  }

}

export default App;
