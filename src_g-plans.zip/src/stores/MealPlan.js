/*
*   author: denis
*   date:   08/05/2018
*/

import { observable, action, computed } from 'mobx';
import { normalize, schema } from 'normalizr';
import { merge } from 'lodash';
import { Alert } from 'react-native'

import Api from '../utils/Api';
import { roundValue } from '../utils/GlobalFunctions'

//
const ItemSchema = new schema.Entity('meal_items');

const MealSchema = new schema.Entity('meals', {
  meal_items: [ItemSchema]
}, {
  processStrategy: entity => merge(entity, {
    extra_items: []
  })
});

const DaySchema = new schema.Entity('days', {
  meals: [MealSchema]
}, {
  idAttribute: ({ day_number: dayNumber }) => dayNumber - 1
});

const MealPlanSchema = new schema.Object({
  days: [DaySchema]
});
//

class MealPlan {
  constructor(getStores) {
    this.getStores = getStores;
  }

  fetch = () => Promise.all([
    this.getMealPlan()
  ])
  // previous week
  @observable predays;
  @observable premeals;
  @observable premealItems;
  // current week
  @observable days;
  @observable meals;
  @observable mealItems;

  // next week
  @observable nextdays;
  @observable nextmeals;
  @observable nextmealItems;
  @observable currentWeekNumber;

  @observable weekStatistic = [];

  // for Swap
  @observable swapableMealItems = [];

  // for Firebase Meal Tip
  currentMealId = null

  @action getMealPlan = async () => {
    const { User: { token, userInfo:{ last_checkin }} } = this.getStores();
    this.currentWeekNumber = last_checkin ? last_checkin.week_number : 1;
    const { prevWeekNumber, nextWeekNumber } = this.prevAndNextWeekNumber;
    try {
      const dataAll = await Promise.all([
        Api.getMealPlan(token, `week_number=${prevWeekNumber}`),
        Api.getMealPlan(token),
        Api.getMealPlan(token, `week_number=${nextWeekNumber}`)
      ])
      const { data:previousData } = dataAll[0];
      const { data:cureentData } = dataAll[1];
      const { data:nextData } = dataAll[2];
      this.mealPlanSuccess(previousData, cureentData, nextData);
      return Promise.resolve();
    } catch (error){
      return Promise.reject(error);
    }
  }

  @action mealPlanSuccess = (previousData, currentData, nextData) => {
    // previous week
    const previousNormalizedData = normalize(previousData, MealPlanSchema);
    const { entities: { days: predays, meals: premeals, meal_items: premealItems } } = previousNormalizedData;
    this.predays = predays;
    this.premeals = premeals;
    this.premealItems = premealItems;

    // current week
    const currentNormalizedData = normalize(currentData, MealPlanSchema);
    const { entities: { days, meals, meal_items: mealItems } } = currentNormalizedData;
    this.days = days;
    this.meals = meals;
    this.mealItems = mealItems;

    // next week
    const nextNormalizedData = normalize(nextData, MealPlanSchema);
    const { entities: { days: nextdays, meals: nextmeals, meal_items: nextmealItems } } = nextNormalizedData;
    this.nextdays = nextdays;
    this.nextmeals = nextmeals;
    this.nextmealItems = nextmealItems;

    //weekStatistic
    const weekStatistic = Object.values(this.days).map((dayInfos) => {
      return {
        logged_meals_calories: parseFloat(dayInfos.logged_meals_calories),
        logged_meals_proteins: parseFloat(dayInfos.logged_meals_proteins),
        logged_meals_fats: parseFloat(dayInfos.logged_meals_fats),
        logged_meals_carbohydrates: parseFloat(dayInfos.logged_meals_carbohydrates),
        planned_meals_calories: parseFloat(dayInfos.planned_meals_calories)
          ? parseFloat(dayInfos.planned_meals_calories) : 0.0001,
        planned_meals_proteins: parseFloat(dayInfos.planned_meals_proteins)
          ? parseFloat(dayInfos.planned_meals_proteins) : 0.0001,
        planned_meals_fats: parseFloat(dayInfos.planned_meals_fats)
          ? parseFloat(dayInfos.planned_meals_fats) : 0.0001,
        planned_meals_carbohydrates: parseFloat(dayInfos.planned_meals_carbohydrates)
          ? parseFloat(dayInfos.planned_meals_carbohydrates) : 0.0001
      }
    });
    this.weekStatistic = weekStatistic;
  }

  // @action mealPlanError = (err) => {
  //   // handle error
  // }

  @computed get mealsWrap() {
    const {
      FirebaseStore: { useMealsFirebase, mealsFirebase }
    } = this.getStores();
    try {
      const wrap = {
        ...this.meals
      }
      Object.keys(mealsFirebase).forEach(mealId => {
        if (wrap[mealId]) {
          const data = useMealsFirebase(mealId)
          wrap[mealId] = data.meal
          data.mealItems.forEach(item => {
            this.mealItems[item.id] = item
          })
        }
      })
      return wrap
    }
    catch (error) {
      return this.meals
    }
  }

  @computed get premealsWrap() {
    const {
      User: { isFreemium },
      FirebaseStore: { useMealsFirebase, mealsFirebase }
    } = this.getStores();
    try {
      const wrap = {
        ...this.premeals
      }
      Object.keys(mealsFirebase).forEach(mealId => {
        if (wrap[mealId] && !isFreemium) {
          const data = useMealsFirebase(mealId)
          wrap[mealId] = data.meal
          data.mealItems.forEach(item => {
            this.premealItems[item.id] = item
          })
        }
      })
      return wrap
    }
    catch (error) {
      return this.premeals
    }
  }

  @computed get nextmealsWrap() {
    const {
      User: { isFreemium },
      FirebaseStore: { useMealsFirebase, mealsFirebase }
    } = this.getStores();
    try {
      const wrap = {
        ...this.nextmeals
      }
      Object.keys(mealsFirebase).forEach(mealId => {
        if (wrap[mealId] && !isFreemium) {
          const data = useMealsFirebase(mealId)
          wrap[mealId] = data.meal
          data.mealItems.forEach(item => {
            this.nextmealItems[item.id] = item
          })
        }
      })
      return wrap
    }
    catch (error) {
      return this.nextmeals
    }
  }

  @computed get getMealsByDay() {
    const {
      DayIndex: { homeDayIndex },
    } = this.getStores();

    if (this.days && this.days[homeDayIndex]) {
      const meals = this.days[homeDayIndex].meals.map(mealId => this.mealsWrap[mealId]);
      return meals;
    } else {
      return [];
    }
  }

  @action getMealsByIndex = (index) => {
    if (this.days && this.days[index]) {
      const meals = this.days[index].meals.map(mealId => this.mealsWrap[mealId]);
      return meals;
    } else {
      return [];
    }
  }

  @computed get getMealsByIndexes() {
    const {
      DayIndex: { weekNumber, prevPlannerDayIndex, plannerDayIndex, nextPlannerDayIndex },
    } = this.getStores();
    const { prevWeekNumber, nextWeekNumber } = this.prevAndNextWeekNumber;
    switch(weekNumber){
      case (prevWeekNumber):
        if (this.predays && this.predays[prevPlannerDayIndex]) {
          const meals = this.predays[prevPlannerDayIndex].meals.map(mealId => this.premealsWrap[mealId]);
          return meals;
        } else {
          return [];
        }
      case (nextWeekNumber):
        if (this.nextdays && this.nextdays[nextPlannerDayIndex]) {
          const meals = this.nextdays[nextPlannerDayIndex].meals.map(mealId => this.nextmealsWrap[mealId]);
          return meals;
        } else {
          return [];
        }
    }

    if (this.days && this.days[plannerDayIndex]) {
      const meals = this.days[plannerDayIndex].meals.map(mealId => this.mealsWrap[mealId]);
      return meals;
    } else {
      return [];
    }
  }

  @action getIdOfRecipesByDay = (dayNumber) => {
    const meals = this.getMealsByDay(dayNumber);
    const idOfRecipes = meals.map((meal) => meal.recipe ? meal.recipe.id : -1);
    // console.log('---idOfRecipes---');
    // console.log(idOfRecipes);
    return idOfRecipes;
  }

  @computed get getAllMeals() {
    const allMeals = this.premealsWrap
      ? this.nextmealsWrap
        ? Object.assign({}, Object.assign({}, this.premealsWrap, this.nextmealsWrap), this.mealsWrap)
        : Object.assign({}, this.premealsWrap, this.mealsWrap)
      : this.nextmealsWrap
        ? Object.assign({}, this.nextmealsWrap, this.mealsWrap)
        : this.mealsWrap
    return allMeals;
  }

  @action getAllMealItems = () => {
    const allMealItems = this.premealItems
      ? this.nextmealItems
        ? Object.assign({}, Object.assign({}, this.premealItems, this.nextmealItems), this.mealItems)
        : Object.assign({}, this.premealItems, this.mealItems)
      : this.nextmealItems
        ? Object.assign({}, this.nextmealItems, this.mealItems)
        : this.mealItems
    return allMealItems;
  }

  @action getMealById = (mealId) => {
    const meal = this.getAllMeals[mealId];
    return meal;
  }

  @action getRecipeByMealId = (mealId) => {
    const meal = this.getAllMeals[mealId];
    const recipe = meal.recipe;
    return recipe;
  }

  @action getMealItemsByIds = (ids) => {
    const allMealItems = this.getAllMealItems();
    const mealItems = ids.map((id) => allMealItems[id]);
    return mealItems;
  }

  @action getPFCByMealId = (mealId) => {
    const meal = this.getAllMeals[mealId];
    const valuePFC = {
        calories: meal.calories
          ? (Math.round(parseFloat(meal.calories) * 10) / 10)
          : 0,
        pro: meal.proteins
          ? (Math.round(parseFloat(meal.proteins) * 10) / 10)
          : 0,
        fats: meal.fats
          ? (Math.round(parseFloat(meal.fats) * 10) / 10)
          : 0,
        carbs: meal.carbohydrates
          ? (Math.round(parseFloat(meal.carbohydrates) * 10) / 10)
          : 0
    }
    return valuePFC;
  }

  @action swapRecipe = async (mealId, recipeId) => {
    const {
      User: { token },
      Recipe: { getRecipeById }
    } = this.getStores()
    try {
      const meal = this.getAllMeals[mealId]
      const mealItems = this.getMealItemsByIds(meal.meal_items)
      const recipe = getRecipeById(recipeId)

      const newMeal = JSON.parse(JSON.stringify({
        ...meal,
        meal_items: mealItems,
        recipe: recipe
      }))

      const { data } = await Api.swapRecipe(token, mealId, newMeal)

      this.swapRecipeSuccess(mealId, data)
      return Promise.resolve(data.recipe.id)
    }
    catch (err) {
      return Promise.reject(err)
    }
  }

  @action swapRecipeSuccess = (mealId, newMeal) => {
    const {
      FirebaseStore: {
        setMealsFirebase,
        setAppVersionFirebase
      }
    } = this.getStores()
    //normalize
    const MealSchema = new schema.Object({
      meal_items: [ItemSchema]
    });
    const normalizedData = normalize(newMeal, MealSchema);
    const { entities: { meal_items: items }, result: meal } = normalizedData;
    //
    const ids = items
      ? Object.keys(items)
      : []
    const newItems = ids.reduce((accumulator, id) => {
      if (this.mealItems[id] == undefined)
        accumulator[id] = items[id];
      return accumulator;
    }, {});
    this.mealItems = {
      ...this.mealItems,
      ...newItems
    }

    const oldMeal = this.getAllMeals[mealId];
    this.meals[mealId] = meal;

    setAppVersionFirebase()
    setMealsFirebase(meal)
    //
    const indexOfDay = this.getIndexOfDayByMealId(mealId);
    this.weekStatistic[indexOfDay].planned_meals_calories += parseFloat(meal.calories) - parseFloat(oldMeal.calories);
    this.weekStatistic[indexOfDay].planned_meals_proteins += parseFloat(meal.proteins) - parseFloat(oldMeal.proteins);
    this.weekStatistic[indexOfDay].planned_meals_fats += parseFloat(meal.fats) - parseFloat(oldMeal.fats);
    this.weekStatistic[indexOfDay].planned_meals_carbohydrates += parseFloat(meal.carbohydrates) - parseFloat(oldMeal.carbohydrates);
    //
  }

  @action trackMeal = async (mealId, items) => {
    const {
      User: { token }
    } = this.getStores()
    try {
      this.currentMealId = mealId
      const { data } = await Api.logMeal(token, mealId)

      await this.trackMealSuccess(mealId, data.id, items, token)
      return Promise.resolve()
    } catch (err) {
      // console.log(err.response)
      return Promise.reject(err)
    }
  }

  @action trackMealSuccess = async (mealId, loggedMealId, items, token) => {
    const reqItems = items ? items.map(item => {
      return {
        ...item,
        logged_meal: loggedMealId,
      }
    }) : []
    try {
      this.currentMealId = mealId
      const { data } = await Api.logMealItems(token, reqItems)
      this.trackMealItemsSuccess(loggedMealId, mealId, data)
      return Promise.resolve()
    } catch (err) {
      // console.log(err.response)
      return Promise.reject(err)
    }
  }

  @action trackMealItemsSuccess = (loggedMealId, mealId, loggedMealItems) => {
    const {
      Profile: { setOverallStats },
      FirebaseStore: {
        removeMealsFirebase,
        setAppVersionFirebase
      }
    } = this.getStores()

    this.meals[mealId] = {
      ...this.getAllMeals[mealId],
      logged: true,
      logged_meal_id: loggedMealId,
      logged_meal_items: loggedMealItems
    }
    setAppVersionFirebase()
    removeMealsFirebase(mealId)

    //
    const indexOfDay = this.getIndexOfDayByMealId(mealId);
    const loggedInfos = this.getLoggedInfosOfDay(indexOfDay);

    const diffCalories = loggedInfos.calories - this.weekStatistic[indexOfDay].logged_meals_calories
    const calories = Math.round(diffCalories * 10) / 10
    setOverallStats('calories', calories, true)

    this.weekStatistic[indexOfDay].logged_meals_calories = loggedInfos.calories;
    this.weekStatistic[indexOfDay].logged_meals_proteins = loggedInfos.proteins;
    this.weekStatistic[indexOfDay].logged_meals_fats = loggedInfos.fats;
    this.weekStatistic[indexOfDay].logged_meals_carbohydrates = loggedInfos.carbohydrates;
  }

  @action untrackMeal = async (mealId, loggedId) => {
    const {
      User: { token }
    } = this.getStores()
    try {
      this.currentMealId = mealId
      await Api.unlogMeal(token, mealId, loggedId)
      this.untrackSuccess(mealId)
      return Promise.resolve()
    } catch (err) {
      // console.log(err.response)
      return Promise.reject(err)
    }
  }

  @action untrackSuccess = (mealId) => {
    const {
      Profile: { setOverallStats },
      FirebaseStore: {
        setMealsFirebase,
        setAppVersionFirebase
      }
    } = this.getStores()

    this.meals[mealId] = {
      ...this.getAllMeals[mealId],
      logged: false,
      skipped: false,
      logged_meal_items: [],
      logged_meal_id: 0,
      logged_meal_calories: 0
    }

    setAppVersionFirebase()
    setMealsFirebase(this.meals[mealId])
    //
    const indexOfDay = this.getIndexOfDayByMealId(mealId);
    const loggedInfos = this.getLoggedInfosOfDay(indexOfDay);

    const diffCalories = this.weekStatistic[indexOfDay].logged_meals_calories - loggedInfos.calories
    const calories = Math.round(diffCalories * 10) / 10
    setOverallStats('calories', calories, false)

    this.weekStatistic[indexOfDay].logged_meals_calories = loggedInfos.calories;
    this.weekStatistic[indexOfDay].logged_meals_proteins = loggedInfos.proteins;
    this.weekStatistic[indexOfDay].logged_meals_fats = loggedInfos.fats;
    this.weekStatistic[indexOfDay].logged_meals_carbohydrates = loggedInfos.carbohydrates;
  }

  @action skipMeal = async (mealId) => {
    const {
      User: { token }
    } = this.getStores()
    try {
      this.currentMealId = mealId
      const { data } = await Api.skipMeal(token, mealId)
      this.skipMealSuccess(mealId, data.id)
      return Promise.resolve()
    } catch (err) {
      // console.log(err.response)
      return Promise.reject(err)
    }
  }

  @action skipMealSuccess = (mealId, loggedMealId) => {
    const {
      FirebaseStore: {
        removeMealsFirebase,
        setAppVersionFirebase
      }
    } = this.getStores()

    this.meals[mealId] = {
      ...this.getAllMeals[mealId],
      skipped: true,
      logged_meal_id: loggedMealId,
    }

    setAppVersionFirebase()
    removeMealsFirebase(mealId)
  }

  @action addItemsToMeal = (mealId, items) => {
    const {
      FirebaseStore: { setMealsFirebase }
    } = this.getStores()
    const extraItems = this.getAllMeals[mealId].extra_items || []
    const newItems = extraItems.concat(items.map((item) => item))
    const meal = {
      ...this.getAllMeals[mealId],
      extra_items: newItems
    }
    setMealsFirebase(meal)
  }

  @action deleteItemsFromMeal = (mealId, item) => {
    const {
      FirebaseStore: { setMealsFirebase }
    } = this.getStores()

    const extraItems = this.getAllMeals[mealId].extra_items
    if (extraItems && extraItems.length) {
      const idx = extraItems.findIndex(el => el.name === item.name)
      if (idx !== -1) {
        extraItems.splice(idx, 1)
        const meal = {
          ...this.getAllMeals[mealId],
          extra_items: extraItems,
        }
        setMealsFirebase(meal)
      }
    }
  }

  @action groceryList = (week) => {
    const mealItemsGrocery =
      week === 'this'
      ? this.mealItems
      : week === 'last'
        ? this.premealItems
        : week === 'next'
          ? this.nextmealItems
          : null

    if (!mealItemsGrocery) return [];
    const arrayMealItems = Object.values(mealItemsGrocery);
    const grocery = arrayMealItems.reduce((accumulator, mealItem) => {
      const index = accumulator.findIndex((item) => {
        return item.name === mealItem.name;
      });
      // const amounts = {
      //   groceries_replacement_ratio: parseFloat(mealItem.groceries_replacement_ratio),
      //   groceries_unit: mealItem.groceries_unit,
      //   portion: parseFloat(mealItem.portion),
      //   portion_si: parseFloat(mealItem.portion_si),
      //   unit: mealItem.unit,
      //   unit_si: mealItem.unit_si,
      //   exchanges: parseFloat(mealItem.exchanges)
      // };
      if (index === -1) {
        const newItem = {
          name: mealItem.name,
          category: mealItem.category,
          carbohydrates: parseFloat(mealItem.carbohydrates),
          fats: parseFloat(mealItem.fats),
          proteins: parseFloat(mealItem.proteins),
          // amounts: [
          //   amounts
          // ],
          portion: parseFloat(mealItem.portion),
          portion_si: parseFloat(mealItem.portion_si),
          unit: mealItem.unit,
          unit_si: mealItem.unit_si
        }
        accumulator.push(newItem);
      }
      else {
        accumulator[index].carbohydrates += parseFloat(mealItem.carbohydrates);
        accumulator[index].fats += parseFloat(mealItem.fats);
        accumulator[index].proteins += parseFloat(mealItem.proteins);
        // accumulator[index].amounts.push(amounts);
        accumulator[index].portion += parseFloat(mealItem.portion);
        accumulator[index].portion_si += parseFloat(mealItem.portion_si);
      }
      return accumulator;
    }, []);

    return grocery;
  }

  @action getSwapableMealItems = async mealItem => {
    try {
      const { User: { token } } = this.getStores()
      const { status, data } = await Api.getFoodsByCategory(token, mealItem.category)
      if (status === 200) {
        this.swapableMealItems = data
      } else {
        this.swapableMealItems = []
      }
    } catch (e) {
      Alert.alert('There is problem in Internet connection.')
      this.swapableMealItems = []
      return e
    }
  }

  @action swapMealItem = async (curItem, newItem) => {
    try {
      //console.log('dest item: ', item)
      const curMealId = curItem.meal
      const curMealItemId = curItem.id

      // add exchanges to newItem as 1.0
      newItem.exchanges = 1

      // change macros
      const amountCur = curItem.portion * curItem.exchanges
      const updatedNewItem = this.getAmountChangedItem(newItem, amountCur, true, 3)

      // set exchanges to updatedNewItem as curItem's exchanges
      updatedNewItem.exchanges = curItem.exchanges

      const itemSwap = {
        ...updatedNewItem,
        id: curMealItemId,
        meal: curMealId,
      }
      const {
        User: { token }
      } = this.getStores()
      this.currentMealId = curMealId
      const { data: responseItem } = await Api.swapMealItem(token, curMealItemId, itemSwap)
      this.itemSwapSuccess(responseItem)
      return Promise.resolve()
    } catch (err) {
      Alert.alert('Sorry, something went wrong!')
      //console.log(err)
      return Promise.reject(err)
    }
  }

  @action itemSwapSuccess = newItem => {
    const {
      FirebaseStore: { setMealsFirebase }
    } = this.getStores()
    // add new meal item to this.mealItems
    const oldItem = this.mealItems[newItem.id]
    this.mealItems[newItem.id] = newItem
    const mealId = newItem.meal
    const meal  = {
      ...this.getAllMeals[mealId],
      recipe: null,
      calories: parseFloat(this.getAllMeals[mealId].calories) + parseFloat(newItem.calories) - parseFloat(oldItem.calories),
      proteins: parseFloat(this.getAllMeals[mealId].proteins) + parseFloat(newItem.proteins) - parseFloat(oldItem.proteins),
      fats: parseFloat(this.getAllMeals[mealId].fats) + parseFloat(newItem.fats) - parseFloat(oldItem.fats),
      carbohydrates: parseFloat(this.getAllMeals[mealId].carbohydrates) + parseFloat(newItem.carbohydrates) - parseFloat(oldItem.carbohydrates)
    }
    setMealsFirebase(meal)
    //
    const indexOfDay = this.getIndexOfDayByMealId(mealId);
    this.weekStatistic[indexOfDay].planned_meals_calories += parseFloat(newItem.calories) - parseFloat(oldItem.calories);
    this.weekStatistic[indexOfDay].planned_meals_proteins += parseFloat(newItem.proteins) - parseFloat(oldItem.proteins);
    this.weekStatistic[indexOfDay].planned_meals_fats += parseFloat(newItem.fats) - parseFloat(oldItem.fats);
    this.weekStatistic[indexOfDay].planned_meals_carbohydrates += parseFloat(newItem.carbohydrates) - parseFloat(oldItem.carbohydrates);
    //
  }

  @action getLoggedAmounts = (mealId) => {
    const meal = this.getAllMeals[mealId];

    if (!meal) return { calories: 0, proteins: 0, fats: 0, carbohydrates: 0 };

    if (meal.logged_meal_items && meal.logged_meal_items.length > 0) {
      const loggedAmounts = meal.logged_meal_items.reduce((accumulator, item) => {
        accumulator.calories += parseFloat(item.calories);
        accumulator.proteins += parseFloat(item.proteins);
        accumulator.fats += parseFloat(item.fats);
        accumulator.carbohydrates += parseFloat(item.carbohydrates);
        return accumulator;
      }, {
        calories: 0,
        proteins: 0,
        fats: 0,
        carbohydrates: 0
      });
      return loggedAmounts;
    }
    else {
      return { calories: 0, proteins: 0, fats: 0, carbohydrates: 0 };
    }
  }

  @action getMealAmounts = (mealId) => {
    const meal = this.getAllMeals[mealId];

    if (!meal) return { calories: 0, proteins: 0, fats: 0, carbohydrates: 0 };

    if (meal.meal_items && meal.meal_items.length > 0) {
      const items = this.getMealItemsByIds(meal.meal_items);
      const mealAmounts = items.reduce((accumulator, item) => {
        accumulator.calories += parseFloat(item.calories);
        accumulator.proteins += parseFloat(item.proteins);
        accumulator.fats += parseFloat(item.fats);
        accumulator.carbohydrates += parseFloat(item.carbohydrates);
        return accumulator;
      }, {
        calories: 0,
        proteins: 0,
        fats: 0,
        carbohydrates: 0
      });
      return mealAmounts;
    }
    else {
      return { calories: 0, proteins: 0, fats: 0, carbohydrates: 0 };
    }
  }

  @action getPercentage = (mealId) => {
    const meal = this.getAllMeals[mealId];

    if (!meal) return { percent: 0, pro: 0, fats: 0, carbs: 0 };

    const loggedValues = this.getLoggedAmounts(mealId);
    const mealValues = this.getMealAmounts(mealId);
    const value = {
      percent: parseFloat(meal.calories) ? Math.round(loggedValues.calories / mealValues.calories * 100) : 100,
      pro: parseFloat(meal.proteins) ? Math.round(loggedValues.proteins / mealValues.proteins * 100) : 100,
      fats: parseFloat(meal.fats) ? Math.round(loggedValues.fats / mealValues.fats * 100) : 100,
      carbs: parseFloat(meal.carbohydrates) ? Math.round(loggedValues.carbohydrates / mealValues.carbohydrates * 100) : 100
    }

    return {
      percent: value.percent ? value.percent : 0,
      pro: value.pro ? value.pro : 0,
      fats: value.fats ? value.fats : 0,
      carbs: value.carbs ? value.carbs : 0
    };
  }

  @action getLoggedInfosOfDay = (indexOfDay) => {

    const loggedInfos = this.getMealsByIndex(indexOfDay).reduce((accumulator, meal) => {
      const loggedValues =  this.getLoggedAmounts(meal.id);
      accumulator.calories += loggedValues.calories;
      accumulator.proteins += loggedValues.proteins;
      accumulator.fats += loggedValues.fats;
      accumulator.carbohydrates += loggedValues.carbohydrates;
      return accumulator;
    }, {
      calories: 0,
      proteins: 0,
      fats: 0,
      carbohydrates: 0
    });
    return loggedInfos;
  }

  @computed get getPercentageOfWeek() {
    try {
      const { User: { isFreemium } } = this.getStores()
      if (isFreemium) {
        return Array(7).fill({ percent: 0, pro: 0, fats: 0, carbs: 0 })
      }
      const result = this.weekStatistic.map((dayStatistic) => {
        return {
          percent: Math.round(dayStatistic.logged_meals_calories / dayStatistic.planned_meals_calories * 100),
          pro: Math.round(dayStatistic.logged_meals_proteins / dayStatistic.planned_meals_proteins * 100),
          fats: Math.round(dayStatistic.logged_meals_fats / dayStatistic.planned_meals_fats * 100),
          carbs: Math.round(dayStatistic.logged_meals_carbohydrates / dayStatistic.planned_meals_carbohydrates * 100)
        };
      })
      return result
    }
    catch (err) {
      return Array(7).fill({ percent: 0, pro: 0, fats: 0, carbs: 0 })
    }
  }

  @computed get PercentageToDay() {
    try {
      const {
        User: { isFreemium },
        DayIndex: { homeDayIndex },
      } = this.getStores();
      const dayStatistic = this.weekStatistic[homeDayIndex];

      if (isFreemium) {
        return {
          calories: { data: 0, fcp: 0, fcpFull: Math.round(dayStatistic.logged_meals_calories) },
          pro: { data: 0, fcp: 0, fcpFull: 0 },
          fats: { data: 0, fcp: 0, fcpFull: 0 },
          carbs: { data: 0, fcp: 0, fcpFull: 0 }
        }
      }

      return {
        calories: {
          data: Math.round(dayStatistic.logged_meals_calories / dayStatistic.planned_meals_calories * 100),
          fcp: Math.round(dayStatistic.logged_meals_calories),
          fcpFull: Math.round(dayStatistic.planned_meals_calories)
        },
        pro: {
          data: Math.round(dayStatistic.logged_meals_proteins / dayStatistic.planned_meals_proteins * 100),
          fcp: Math.round(dayStatistic.logged_meals_proteins),
          fcpFull: Math.round(dayStatistic.planned_meals_proteins)
        },
        fats: {
          data: Math.round(dayStatistic.logged_meals_fats / dayStatistic.planned_meals_fats * 100),
          fcp: Math.round(dayStatistic.logged_meals_fats),
          fcpFull: Math.round(dayStatistic.planned_meals_fats)
        },
        carbs: {
          data: Math.round(dayStatistic.logged_meals_carbohydrates / dayStatistic.planned_meals_carbohydrates * 100),
          fcp: Math.round(dayStatistic.logged_meals_carbohydrates),
          fcpFull: Math.round(dayStatistic.planned_meals_carbohydrates)
        }
      };
    }
    catch (err) {
      return {
        calories: { data: 0, fcp: 0, fcpFull: 0 },
        pro: { data: 0, fcp: 0, fcpFull: 0 },
        fats: { data: 0, fcp: 0, fcpFull: 0 },
        carbs: { data: 0, fcp: 0, fcpFull: 0 }
      }
    }
  }

  @computed get PercentageWeek() {
    try {
      const { User: { isFreemium } } = this.getStores()

      const totalStatistic = this.weekStatistic.reduce((accumulator, dayStatistic) => {
        accumulator.logged_meals_calories += dayStatistic.logged_meals_calories;
        accumulator.logged_meals_proteins += dayStatistic.logged_meals_proteins;
        accumulator.logged_meals_fats += dayStatistic.logged_meals_fats;
        accumulator.logged_meals_carbohydrates += dayStatistic.logged_meals_carbohydrates;
        accumulator.planned_meals_calories += dayStatistic.planned_meals_calories;
        accumulator.planned_meals_proteins += dayStatistic.planned_meals_proteins;
        accumulator.planned_meals_fats += dayStatistic.planned_meals_fats;
        accumulator.planned_meals_carbohydrates += dayStatistic.planned_meals_carbohydrates;
        return accumulator;
      }, {
          logged_meals_calories: 0,
          logged_meals_proteins: 0,
          logged_meals_fats: 0,
          logged_meals_carbohydrates: 0,
          planned_meals_calories: 0,
          planned_meals_proteins: 0,
          planned_meals_fats: 0,
          planned_meals_carbohydrates: 0
      });

      if (isFreemium) {
        return {
          calories: { data: 0, fcp: 0, fcpFull: Math.round(totalStatistic.logged_meals_calories * 10) / 10 },
          pro: { data: 0, fcp: 0, fcpFull: 0 },
          fats: { data: 0, fcp: 0, fcpFull: 0 },
          carbs: { data: 0, fcp: 0, fcpFull: 0 }
        }
      }

      return {
        calories: {
          data: Math.round(totalStatistic.logged_meals_calories / totalStatistic.planned_meals_calories * 100),
          fcp: Math.round(totalStatistic.logged_meals_calories * 10) / 10,
          fcpFull: Math.round(totalStatistic.planned_meals_calories * 10) / 10
        },
        pro: {
          data: Math.round(totalStatistic.logged_meals_proteins / totalStatistic.planned_meals_proteins * 100),
          fcp: Math.round(totalStatistic.logged_meals_proteins * 10) / 10,
          fcpFull: Math.round(totalStatistic.planned_meals_proteins * 10) / 10
        },
        fats: {
          data: Math.round(totalStatistic.logged_meals_fats / totalStatistic.planned_meals_fats * 100),
          fcp: Math.round(totalStatistic.logged_meals_fats * 10) / 10,
          fcpFull: Math.round(totalStatistic.planned_meals_fats * 10) / 10
        },
        carbs: {
          data: Math.round(totalStatistic.logged_meals_carbohydrates / totalStatistic.planned_meals_carbohydrates * 100),
          fcp: Math.round(totalStatistic.logged_meals_carbohydrates * 10) / 10,
          fcpFull: Math.round(totalStatistic.planned_meals_carbohydrates * 10) / 10
        }
      };
    }
    catch (err) {
      return {
        calories: { data: 0, fcp: 0, fcpFull: 0 },
        pro: { data: 0, fcp: 0, fcpFull: 0 },
        fats: { data: 0, fcp: 0, fcpFull: 0 },
        carbs: { data: 0, fcp: 0, fcpFull: 0 }
      }
    }
  }

  @computed get getPercentageByIndexes() {
    const { User: { isFreemium } } = this.getStores()

    const meals = this.getMealsByIndexes
    const results = meals.reduce((accumulator, meal) => {
      const planned = this.getMealItemsByIds(meal.meal_items).reduce((accum, item) => {
        accum.calories += parseFloat(item.calories)
        accum.proteins += parseFloat(item.proteins)
        accum.fats += parseFloat(item.fats)
        accum.carbohydrates += parseFloat(item.carbohydrates)
        return accum
      }, {calories: 0, proteins: 0, fats: 0, carbohydrates: 0})
      accumulator.planned_calories += planned.calories
      accumulator.planned_proteins += planned.proteins
      accumulator.planned_fats += planned.fats
      accumulator.planned_carbohydrates += planned.carbohydrates

      const logged = meal.logged_meal_items.reduce((accum, item) => {
        accum.calories += parseFloat(item.calories)
        accum.proteins += parseFloat(item.proteins)
        accum.fats += parseFloat(item.fats)
        accum.carbohydrates += parseFloat(item.carbohydrates)
        return accum
      }, {calories: 0, proteins: 0, fats: 0, carbohydrates: 0})
      accumulator.logged_calories += logged.calories
      accumulator.logged_proteins += logged.proteins
      accumulator.logged_fats += logged.fats
      accumulator.logged_carbohydrates += logged.carbohydrates

      return accumulator
    }, {
      planned_calories: 0, planned_proteins: 0, planned_fats: 0, planned_carbohydrates: 0,
      logged_calories: 0, logged_proteins: 0, logged_fats: 0, logged_carbohydrates: 0
    })

    if (isFreemium) {
      return {
        calories: { data: 0, fcp: 0, fcpFull: Math.round(results.logged_calories) },
        pro: { data: 0, fcp: 0, fcpFull: 0 },
        fats: { data: 0, fcp: 0, fcpFull: 0 },
        carbs: { data: 0, fcp: 0, fcpFull: 0 }
      }
    }

    return {
      calories: {
        data: Math.round(results.logged_calories / results.planned_calories * 100),
        fcp: Math.round(results.logged_calories),
        fcpFull: Math.round(results.planned_calories)
      },
      pro: {
        data: Math.round(results.logged_proteins / results.planned_proteins * 100),
        fcp: Math.round(results.logged_proteins),
        fcpFull: Math.round(results.planned_proteins)
      },
      fats: {
        data: Math.round(results.logged_fats / results.planned_fats * 100),
        fcp: Math.round(results.logged_fats),
        fcpFull: Math.round(results.planned_fats)
      },
      carbs: {
        data: Math.round(Math.round(results.logged_carbohydrates / results.planned_carbohydrates * 100)),
        fcp: Math.round(results.logged_carbohydrates),
        fcpFull: Math.round(results.planned_carbohydrates)
      }
    };
  }

  @action getIndexOfDayByMealId = (mealId) =>  {
    const indexOfDay = Object.values(this.days).findIndex((dayInfos) => {
      const findRes = dayInfos.meals.find((id) => mealId === id);
      return findRes;
    });
    return indexOfDay;
  }

  @action getItemCountOfMeal = (mealId) => {
    const { User: { isPremium } } = this.getStores()
    try {
      const meal = this.getAllMeals[mealId]
      if (meal.logged)
        return meal.logged_meal_items.length

      if (!isPremium)
        return meal.extra_items.length

      const countExtras = meal.extra_items
        ? meal.extra_items.length
        : 0
      const countItems = meal.meal_items
        ? meal.meal_items.length
        : 0
      return countExtras + countItems
    } catch (error) {
      return 0;
    }
  }

  getAmountChangedItem(item, amount, isUS, fixedNumber = 1) {
    let times = isUS
      ? amount / item.portion / item.exchanges
      : amount / item.portion_si / item.exchanges
    if (!isFinite(times)) {
      times = 1
    }
    return {
      ...item,
      //portion: roundValue((item.portion && isFinite(item.portion) ? item.portion : amount) * times, fixedNumber).toString(),
      //portion_si: roundValue((item.portion_si && isFinite(item.portion_si) ? item.portion_si : amount) * times, fixedNumber).toString(),
      exchanges: roundValue(item.exchanges * times, fixedNumber).toString(),
      calories: roundValue(item.calories * times, fixedNumber).toString(),
      proteins: roundValue(item.proteins * times, fixedNumber).toString(),
      fats: roundValue(item.fats * times, fixedNumber).toString(),
      carbohydrates: roundValue(item.carbohydrates * times, fixedNumber).toString(),
      all_data: {
        ...item.all_data,
        nf_cholesterol: (item.all_data && item.all_data.nf_cholesterol && roundValue(item.all_data.nf_cholesterol * times, fixedNumber).toString()) || null,
        nf_dietary_fiber: (item.all_data && item.all_data.nf_dietary_fiber && roundValue(item.all_data.nf_dietary_fiber * times, fixedNumber).toString()) || null,
        nf_monounsaturated_fat: (item.all_data && item.all_data.nf_monounsaturated_fat && roundValue(item.all_data.nf_monounsaturated_fat * times, fixedNumber).toString()) || null,
        nf_polyunsaturated_fat: (item.all_data && item.all_data.nf_polyunsaturated_fat && roundValue(item.all_data.nf_polyunsaturated_fat * times, fixedNumber).toString()) || null,
        nf_potassium: (item.all_data && item.all_data.nf_potassium && roundValue(item.all_data.nf_potassium * times, fixedNumber).toString()) || null,
        nf_saturated_fat: (item.all_data && item.all_data.nf_saturated_fat && roundValue(item.all_data.nf_saturated_fat * times, fixedNumber).toString()) || null,
        nf_sodium: (item.all_data && item.all_data.nf_sodium && roundValue(item.all_data.nf_sodium * times, fixedNumber).toString()) || null,
        nf_sugars: (item.all_data && item.all_data.nf_sugars && roundValue(item.all_data.nf_sugars * times, fixedNumber).toString()) || null,
        nf_trans_fat: (item.all_data && item.all_data.nf_trans_fat && roundValue(item.all_data.nf_trans_fat * times, fixedNumber).toString()) || null
      }
    }
  }

  @computed get prevAndNextWeekNumber() {
    const prevWeekNumber =  this.currentWeekNumber - 1 < 1 ? 12 : this.currentWeekNumber - 1;
    const nextWeekNumber = this.currentWeekNumber + 1 > 12 ? 1 : this.currentWeekNumber + 1;
    return {
      prevWeekNumber: prevWeekNumber,
      nextWeekNumber: nextWeekNumber
    }
  }

  @computed get prevWeekNumber() {
    return this.currentWeekNumber - 1 < 1 ? 12 : this.currentWeekNumber - 1
  }

  @computed get nextWeekNumber() {
    return this.currentWeekNumber + 1 > 12 ? 1 : this.currentWeekNumber + 1
  }

  /*@action getMealsFirebase = data => {
    if (!data) return
    const meals = Object.keys(data)
    meals.forEach(mealId => {
      const originFirMeal = this.
    })
  }*/
}

export default MealPlan;
