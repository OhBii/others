/*
*   author: denis
*   date:   7/27/2018
*/

import { observable, action, computed } from 'mobx';
import { persist } from 'mobx-persist';
import Intercom from 'react-native-intercom';

import Api from '../utils/Api';

const weightCategories = [0, 130, 155, 180, 201]

class User {
  constructor(getStores) {
    this.getStores = getStores;
  }

  fetch = () => Promise.all([
    //this.getRebootInfo()
  ])

  @persist @observable token = '';
  @persist @observable language = 'en';
  @persist @observable unit = 'us'    // 'us' or 'si'
  @persist('list') @observable favList = [];

  @observable userInfo;
  @observable rebootInfo; //0: No, 1: Yes, -1: Skip
  @observable mealPlanPaused = '0'  // '0': no paused, '1': first day paused, '2': second day paused

  @action getRebootInfo = async () => {
    try {
      const { data } = await Api.getMisc(this.token, 'reboot')
      this.rebootInfo = parseFloat(data.value)
    } catch (error) {
      this.rebootInfo = 0
    }
  }

  @action setRebootInfo = async (value) => {
    try {
      this.rebootInfo = value

      const rebootInfos = {
        key: 'reboot',
        value: value
      }
      await Api.setMisc(this.token, rebootInfos)
    }
    catch (error) {
      //
    }
  }

  @action registerForIntercom = () => {
    Intercom.registerIdentifiedUser({ userId: this.userInfo.intercom_id });
    Intercom.updateUser({
        email: this.userInfo.email,
        name: this.userInfo.first_name + ' ' + this.userInfo.last_name,
        phone: this.userInfo.phone,
    });
  }

  @action resetForIntercom = () => {
    Intercom.reset()
  }

  @action login = (data) => {
    // token
    this.token = data.token
    // userInfo
    this.checkAuth(data)
  }

  @action logout = () => {
    // token
    this.token = '';

    this.resetForIntercom()
  }

  @action checkAuth = (data) => {
    this.userInfo = data.user

    this.registerForIntercom()
  }

  @action getOauthToken = async () => {
    try {
      const {
        Funnel: { signUpUUID },
        Global: { fetchData }
      } = this.getStores()
      if (signUpUUID) {
        // await Api.getOauthToken(signUpUUID)
        const { data } = await Api.getOauthToken(signUpUUID)
        this.oauthSuccess(data)
        const response = await Api.checkAuth(data.token)
        this.checkAuth(response.data)
        await fetchData()
        return Promise.resolve()
      } else {
        return Promise.reject('No UUID')
      }
    } catch (err) {
      // console.log(err.response)
      return Promise.reject(err)
    }
  }

  @action oauthSuccess = (data) => {
    this.token = data.token
  }

  // @action User.language = () => {
  //   return this.language;
  // }

  @action setLanguage = (setLanguage) => {
    this.language = setLanguage;
  }

  // @action changeInfo = (field, value) => {
  //   this.userInfo[field] = value
  // }

  @action changeInfo = async (newInfo) => {
    try {
      const newUserInfo = { ...this.userInfo, ...newInfo }
      const { status, data } = await Api.putUserInfo(this.token, newUserInfo)
      if (status === 200) {
        this.userInfo = data
      }
    } catch (err) {
      throw err
    }
  }

  @action setUnit = unit => {
    this.unit = unit
  }

  @action setFavList = () => {
    const { Funnel: { introResult } } = this.getStores()
    this.favList = []
    introResult.map((list) => {
      list.items.map((item) => {
        if (item.checked) this.favList.push(item.title)
      })
    })
  }

  @action facebookLogin = async fbtoken => {
    try {
      const data = await Api.facebookLogin(fbtoken)
      return data
    } catch (error) {
      //console.log('Error on facebookLogin API: ', error)
      throw error
    }
  }

  @computed get lastCheckinId() {
    return this.userInfo ? this.userInfo.last_checkin.id : null
  }

  @computed get lastCheckinDate() {
    return this.userInfo ? this.userInfo.last_checkin.created_at : null
  }

  @computed get weight() {
    return this.userInfo ? this.userInfo.last_checkin.weight : 0
  }

  @computed get initWeight() {
    return this.userInfo ? this.userInfo.first_checkin.weight : 0
  }

  @computed get weightCategory() {
    let category = weightCategories[weightCategories.length - 1]
    for (let i = weightCategories.length - 1; i > 0; i--) {
      if (this.weight < weightCategories[i] && this.weight >= weightCategories[i - 1]) {
        category = weightCategories[i]
        break
      }
    }
    return category
  }

  @computed get firebaseToken() {
    return this.userInfo ? this.userInfo.firebase_token : null
  }

  @computed get isMaintenance() {
    return this.userInfo.subscription_plan && this.userInfo.subscription_plan.slug === 'maintenance'
  }

  @computed get isPremium() {
    return this.userInfo.subscription_plan && (this.userInfo.subscription_plan.slug === 'power' || this.userInfo.subscription_plan.slug === 'pro')
  }

  @computed get isFreemium() {
    return !this.isMaintenance && !this.isPremium
  }
}

export default User;
