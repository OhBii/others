/*
*   author: denis
*   date:   7/27/2018
*/

import { observable, action, computed } from 'mobx';
import moment from 'moment';

class DayIndex {

  constructor(getStores) {
    this.getStores = getStores;
  }

  fetch = () => Promise.all([

  ])

  postfetch = () => {
    const { User: {userInfo : { last_checkin } } } = this.getStores();
    const checkinAt = moment(last_checkin.created_at).format('YYYY-MM-DD');

    const today = moment();

    this.homeDayIndex = today.diff(checkinAt, 'd');
    this.plannerDayIndex = this.homeDayIndex;
  }

  @observable homeDayIndex;
  @observable plannerDayIndex;
  @observable weekNumber;
  @observable weekDays = [];
  @observable prevPlannerDayIndex = 0;
  @observable nextPlannerDayIndex = 0;

  @action setWeekNnmber = (weekNumber) =>{
    this.weekNumber = weekNumber;
  }

  @action setWeekDays = ( startOfWeek, endOfWeek ) =>{
    this.weekDays = [];
    while (startOfWeek <= endOfWeek) {
      this.weekDays.push(startOfWeek.toDate().toString());
      startOfWeek = startOfWeek.add(1, 'day');
    }
    return this.weekDays
  }

  @action setPlannerDayIndex = ( weekNumber, index) => {
    const {
      MealPlan: { currentWeekNumber, prevAndNextWeekNumber },
    } = this.getStores();
    const { prevWeekNumber, nextWeekNumber } = prevAndNextWeekNumber;
    switch(weekNumber){
      case undefined:
        this.plannerDayIndex = index ;
        break;
      case prevWeekNumber:
        this.prevPlannerDayIndex = index ;
        break;
      case currentWeekNumber:
        this.plannerDayIndex = index ;
        break;
      case nextWeekNumber:
        this.nextPlannerDayIndex  = index ;
        break;
    }
  }

  @action getPlannerDayIndex = (weekNumber) => {
    const {
      MealPlan: { currentWeekNumber, prevAndNextWeekNumber },
    } = this.getStores();
    const { prevWeekNumber, nextWeekNumber } = prevAndNextWeekNumber;
    switch(weekNumber){
      case undefined:
        return this.plannerDayIndex;
      case prevWeekNumber:
        return this.prevPlannerDayIndex;
      case currentWeekNumber:
        return this.plannerDayIndex;
      case nextWeekNumber:
        return this.nextPlannerDayIndex;
    }
  }

  @computed get getDayByDayIndex() {
    const { User: {userInfo : { last_checkin } } } = this.getStores();
    const startOfWeek = moment(last_checkin.created_at);
    const day = moment(startOfWeek).add(this.plannerDayIndex, 'd');
    return day;
  }

  @action setSelectedDate = (date) => {
    const {
      User: { userInfo : { last_checkin } },
      MealPlan: { currentWeekNumber, prevAndNextWeekNumber },
    } = this.getStores();
    const { prevWeekNumber, nextWeekNumber } = prevAndNextWeekNumber;

    const selectedDate = moment(date).format('YYYY-MM-DD');
    const checkinAt = moment(last_checkin.created_at).format('YYYY-MM-DD');

    const tempIndex = moment(selectedDate).diff(checkinAt, 'd');
    if (tempIndex < 0) {
      this.weekNumber = prevWeekNumber;
      this.prevPlannerDayIndex = tempIndex + 7;
    }
    else if (tempIndex < 7) {
      this.weekNumber = currentWeekNumber;
      this.plannerDayIndex = tempIndex;
    }
    else {
      this.weekNumber = nextWeekNumber;
      this.nextPlannerDayIndex = tempIndex - 7;
    }
  }

  @computed get getSelectedDate() {
    const {
      User: { userInfo : { last_checkin } },
      MealPlan: { prevAndNextWeekNumber },
    } = this.getStores();
    const { prevWeekNumber, nextWeekNumber } = prevAndNextWeekNumber;

    const checkinAt = moment(last_checkin.created_at).format('YYYY-MM-DD');
    const results = {};
    if (this.weekNumber === prevWeekNumber) {
      results.displayStr = 'Last Week';
      results.selectedDate = moment(checkinAt).subtract((7 - this.prevPlannerDayIndex), 'd').toDate();
    }
    else if (this.weekNumber === nextWeekNumber) {
      results.displayStr = 'Next Week';
      results.selectedDate = moment(checkinAt).add((7 + this.nextPlannerDayIndex), 'd').toDate();
    }
    else {
      results.displayStr = 'This Week';
      results.selectedDate = moment(checkinAt).add(this.plannerDayIndex, 'd').toDate();
    }
    return results;
  }

  @action getDateOfLimits = () => {
    const { User: { userInfo : { last_checkin } } } = this.getStores();
    const checkinAt = moment(last_checkin.created_at).format('YYYY-MM-DD');
    const downLimit = moment(checkinAt).subtract(1, 'w');
    const upLimit = moment(checkinAt).add(2, 'w').subtract(1, 'd');
    return {
      downLimit: downLimit.toDate(),
      upLimit: upLimit.toDate()
    }
  }
}

export default DayIndex;