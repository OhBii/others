import firebase from 'react-native-firebase'
import { observable, action, toJS } from 'mobx'
import { Alert } from 'react-native'

import Constants from '../global/Constants'

export default class Firebasestore {
  constructor(getStores) {
    this.getStores = getStores
    this.refStore = firebase.database()
    this.refUser = null
    this.firebaseUserID = null
    this.refApp = null
    this.refTip = null
    this.refMeal = null
    // console.log('this.refStore: ', this.refStore)

    // const ref1 = this.refStore.ref('goglia-1103')
    // console.log('ref1: ', ref1)
    // console.log('ref1.child(users): ', ref1.child('users'))
    // console.log('no path: ', this.refStore.ref())
  }

  postfetch = () => {
    const { User: { firebaseToken } } = this.getStores()
    this.initFirebase(firebaseToken)
  }

  @observable mealsFirebase = {};
  @observable appVersionFirebase = -1;

  initFirebase = firToken => {
    if (!firToken) return
    //firebase.auth().signInWithCustomToken(firToken)
    firebase.auth().signInAndRetrieveDataWithCustomToken(firToken)
      .then(authData => {
        //console.log('authData: ', authData)
        this.firebaseUserID = authData.user.uid
        this.refUser = this.refStore.ref().child('users').child(this.firebaseUserID)
        this.refApp = this.refUser.child('appVersion')
        this.refTip = this.refUser.child('tip')
        this.refMeal = this.refUser.child('user_meals')

        // console.log('refUser: ', this.refUser)
        // console.log('refApp: ', this.refApp)
        // console.log('refTip: ', this.refTip)
        // console.log('refMeal: ', this.refMeal)

        /*const {
          Tips: {
            addGeneralTip,
            addDayMealTip,
          }
        } = this.getStores()

        this.refTip.on('value', val => {
          const tip = val.val()
          console.log('tip once: ', tip)
          if (tip) {
            if (tip.delivery_place === 'home') {
              addDayMealTip(tip)
            } else {
              addGeneralTip(tip)
            }
          }
        })*/

        this.refApp.on('value', dataSnapshot => {
          const appVersion = dataSnapshot.val()
          this.getAppVersionFirebase(appVersion)
        }, () => {}, this)

        this.refMeal.on('value', dataSnapshot => {
          const meals = dataSnapshot.val()
          this.getMealsFirebase(meals)
        }, () => {}, this)

      })
      .catch(error => {
        //console.warn('Error when initFirebase: ', error)
        throw error
      })
  }

  @action getAppVersionFirebase = appVersion => {
    if (this.appVersionFirebase !== -1 && this.appVersionFirebase !== appVersion) {
      this.reload()
    }

    if (appVersion) {
      this.appVersionFirebase = appVersion
    } else {
      this.setAppVersionFirebase()
    }
  }

  @action setAppVersionFirebase = () => {
    this.appVersionFirebase += 1
    this.refApp.set(this.appVersionFirebase)
  }

  @action getMealsFirebase = meals => {
    this.mealsFirebase = meals ? meals : {}
    // console.log('-------get firebase')
    // console.log(meals)
  }

  @action setMealsFirebase = meal => {
    const { MealPlan } = this.getStores()
    const mealId = meal.id
    const meals = this.mealsFirebase
    const version = meals[mealId]
      ? meals[mealId].version_num
      : 0

    const newMeal = {
      ...meal,
      meal_items: MealPlan.getMealItemsByIds(meal.meal_items)
    }
    meals[mealId] = {
      meal_object: newMeal,
      version_num: version + 1
    }
    // console.log('-------set firebase')
    // console.log(toJS(meals))
    this.mealsFirebase = toJS(meals)
    this.refMeal.set(toJS(meals))
  }

  @action useMealsFirebase = mealId => {
    const meal = this.mealsFirebase[mealId].meal_object
    const itemIds = meal.meal_items.map(mealItem => mealItem.id)
    const mealWrap = {
      ...meal,
      recipe: meal.recipe ? meal.recipe : null,
      logged_meal_items: meal.logged_meal_items ? meal.logged_meal_items : [],
      meal_items: itemIds
    }
    return {
      meal: mealWrap,
      mealItems: meal.meal_items
    }
  }

  @action removeMealsFirebase = mealId => {
    const meals = this.mealsFirebase
    if (meals && meals[mealId]) {
      meals[mealId] = null
    }
    // console.log('-------remove firebase')
    // console.log(toJS(meals))
    this.mealsFirebase = toJS(meals)
    this.refMeal.set(toJS(meals))
  }

  @action clearMealsFirebase = () => {
    this.refMeal.set({})
  }

  @action reload = () => {
    if (!this.isReload) {
      this.isReload = true
      Alert.alert(
        'Your account data is changed',
        '',
        [{
          text: 'OK',
          onPress: () => {
            const { Global } = this.getStores()

            Constants.rootNavigator.showModal({
              ...Constants.Screens.LOADING_SCREEN,
              navigatorStyle: {
                navBarHidden: true,
                tabBarHidden: true
              }
            })

            Global.fetchData()
            .then(() => {
              this.isReload = false
              Constants.rootNavigator.dismissAllModals()
            })
            .catch(() => {
              this.isReload = false
              this.logout()
            })
          }
        }]
      )
    }
  }

  @action logout = () => {
    Alert.alert(
      'Sorry, something went wrong',
      '',
      [{
        text: 'OK',
        onPress: () => {
          const { User } = this.getStores()
          User.logout()
          Constants.Global.startSingleScreenApp()
        }
      }]
    )
  }
}
