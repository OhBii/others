/*
*   author: denis
*   date:   08/16/2018
*/

import { observable, action, computed } from 'mobx';
import { persist } from 'mobx-persist';

import Api from '../utils/Api';

const units = [ 'Ounces', 'Cups', 'Liters', 'Milliliters' ];
const unitsAbbreviated = [ 'oz', 'cup', 'ltr', 'ml' ];


class WaterTrack {
  constructor(getStores) {
    this.getStores = getStores;
  }

  fetch = () => Promise.all([
    this.getWaterTrackInfos()
  ])

  @persist @observable unit = 0;
  @observable waterTrackInfos = [];

  @computed get waterMax() {
    try {
      const { User: {userInfo} } = this.getStores();
      const weight = parseFloat(userInfo.last_checkin.weight);
      return (Math.round(weight / 8.0 * 10) / 10);
    } catch (error) {
      return 27;
    }
  }

  @action reverseConvertFromGlass = (amount, unit) => {
    if (unit === 0) return (amount * 8.0);
    if (unit === 1) return amount;
    if (unit === 2) return (amount / 4.22675);
    return (amount / 0.00422675);
  }


  @action getWaterTrackInfos = async () => {
    const { User: { token } } = this.getStores();
    try {
      const { data } = await Api.getWaterTrackInfos(token);
      this.waterTrackSuccess(data);
      return Promise.resolve();
    } catch(error) {
      // this.waterTrackError();
      return Promise.reject(error);
    }
  }

  @action waterTrackSuccess = (data) => {
    if (data) this.waterTrackInfos = data;
  }

  // @action waterTrackError = (err) => {

  // }

  @action waterTrackProc = async (amount) => {
    const {
      User: {
        token,
        userInfo: {
          last_checkin,
          last_login
        },
      },
      DayIndex: { homeDayIndex: day },
      FirebaseStore: {
        setAppVersionFirebase,
      }
    } = this.getStores();
    const week = last_checkin.week_number;
    const checkin = last_checkin.id;
    try {
      const waterTrackToday = this.WaterTrackForToday;
      if (!waterTrackToday.id) {
        const {data} = await Api.createWaterTracker(token, week, checkin, (day + 1))
        // sync to web
        setAppVersionFirebase()
        waterTrackToday.id = data.id
      }

      // const amountTotal = (amount + parseFloat(waterTrackToday.glasses)) > this.waterMax
      //   ? this.waterMax
      //   : (amount + parseFloat(waterTrackToday.glasses));
      const amountTotal = amount + parseFloat(waterTrackToday.glasses)

      const { data } = await Api.waterTrack(
        token,
        waterTrackToday.id,
        week,
        checkin,
        last_login,
        (day + 1),
        amountTotal
      );

      const index = this.waterTrackInfos.findIndex((item) => {
        return item.id === data.id;
      });

      if (index === -1) {
        this.waterTrackInfos = [
          ...this.waterTrackInfos,
          data
        ]
      }
      else {
        this.waterTrackInfos[index] = data;
      }

      const { Profile: { setOverallStats } } = this.getStores()
      setOverallStats('water', this.reverseConvertFromGlass(amount, 0), true)
    } catch(err) {
      return Promise.reject(err.response);
    }
  }

  @action setUnit = (index) => {
    this.unit = index;
  }

  @computed get WaterTrackForToday() {
    const {
      User: { userInfo: { last_checkin } },
      DayIndex: { homeDayIndex: day }
    } = this.getStores();

    if (!last_checkin) return { glasses: 0 };

    const week = last_checkin.week_number;
    const checkin = last_checkin.id;
    const waterTrackToday = this.waterTrackInfos.find((item) => {
      return item.day === (day + 1) &&
              item.week === week &&
              item.checkin === checkin;
    });

    if (!waterTrackToday) return { glasses: 0 };

    return waterTrackToday;
  }

  @computed get Unit() {
    return {
      full: units[this.unit],
      abbr: unitsAbbreviated[this.unit]
    };
  }

  @computed get Ratio() {
    return this.reverseConvertFromGlass(1, this.unit);
  }

  @computed get percentageOfTrack() {
    try {
      const percentageOfTrack = this.WaterTrackForToday.glasses / this.waterMax * 100
      return Math.round(percentageOfTrack)
    }
    catch (error) {
      return 0
    }
  }

  @computed get getPercentageOfWeek() {
    try {
      const {
        User: { userInfo: { last_checkin } }
      } = this.getStores();

      const week = last_checkin.week_number;
      const checkin = last_checkin.id;
      const result = Array(7).fill(0).map((ought, index) => {
        const tracker = this.waterTrackInfos.find((item) => {
          return item.day === (index + 1) &&
                  item.week === week &&
                  item.checkin === checkin;
        });
        const percent = tracker
          ? Math.round(parseFloat(tracker.glasses) / this.waterMax * 100)
          : 0
        return { percent: percent }
      })

      return result
    }
    catch (err) {
      return Array(7).fill({ percent: 0 })
    }
  }
}

export default WaterTrack;
