import AppleHealthKit from 'rn-apple-healthkit'
import GoogleFit from 'react-native-google-fit'
import { NativeAppEventEmitter } from 'react-native'
import moment from 'moment'
import { observable, action, computed } from 'mobx'
import Converter from 'convert-units'

import Api from '../utils/Api'
import { platform } from '../global/Constants/Var'
import { roundValue } from '../utils/GlobalFunctions'

const { PermissionsAndroid } = platform === 'ios'
  ? { PermissionsAndroid: null }
  : require('react-native')

const emptyGraphData = {
  average: 0,
  currentDayValue: 0,
  maxVal: 500,
  graph: []
}

const selectCount = 7
const collectDataDays = 7

class HealthKit {
  constructor(getStores) {
    this.getStores = getStores
    this.initEmptyData()
  }

  // Whether Apple Health Kit is enabled or disabled on Pruvit
  @observable isEnabled = false

  @observable healthKitData = {}

  postfetch = () => {
    setTimeout(
      () => this.getHealthKitFlag()
        .then(() => this.initHealthKit())
        .catch(err => err),
      3000,
    )
  }

  initEmptyData = () => {
    // init emptyGraphData.graph
    emptyGraphData.graph = []
    const now = moment()
    for (let i = 0; i < selectCount; i++) {
      const date = moment(now).subtract(selectCount - 1 - i, 'day')
      emptyGraphData.graph.push({
        //x: (selectCount - i - 1) % 7 === 0 ? `${date.format('D')}/${date.format('M')}` : '',
        x: `${date.format('D')}/${date.format('M')}`,
        y: 0,
      })
    }
  }

  @computed get isEnabledHealthKit() {
    return this.isEnabled
  }

  @action getHealthKitFlag = async () => {
    try {
      const { User: { token } } = this.getStores()
      const { data } = await Api.getMisc(token, 'appleHealthKit')
      this.isEnabled = data.value === '1' ? true : false
    } catch (err) {
      throw err
    }
  }

  @action setHealthKitFlag = async flag => {
    // For UI update ASAP, first changing this.isEnabled is needed
    const oldValue = this.isEnabled
    this.isEnabled = flag
    try {
      const { User: { token } } = this.getStores()
      await Api.setMisc(token, {
        key: 'appleHealthKit',
        value: flag ? '1' : '0'
      })

      if (flag) {
        this.initHealthKit()
      } else {
        this.clearHealthKitData()
      }
    } catch (err) {
      this.isEnabled = oldValue
      return err
    }
  }

  @action initHealthKit = () => {
    if (!this.isEnabled) return
    if (platform === 'ios') {
      const PERMS = AppleHealthKit.Constants.Permissions

      const healthKitOptions = {
        permissions: {
          read: [
            PERMS.StepCount,
            PERMS.DistanceWalkingRunning,
            PERMS.FlightsClimbed,
            PERMS.ActiveEnergyBurned,
            PERMS.BloodGlucose,
            PERMS.Weight,
            PERMS.Height,
          ],
          write: [
            PERMS.StepCount,
            PERMS.DistanceWalkingRunning,
            PERMS.FlightsClimbed,
            PERMS.BloodGlucose,
            PERMS.Weight,
          ],
        }
      }
      AppleHealthKit.initHealthKit(healthKitOptions, (err, result) => {
        if (this.handleHKError(err, 'initHealthKit')) {
          return
        }
        result

        AppleHealthKit.initStepCountObserver({}, () => {})

        this.stepCountEventListener = NativeAppEventEmitter.addListener(
          'change:steps',
          (evt) => {
            evt
            this.initEmptyData()
            this.getStepData()
            this.getFlightClimbedData()
            this.getCaloriesBurnData()
            this.getGlucoseData()
            this.getWeightData()
            this.getDistanceData()
          }
        )
      })
    } else {
      GoogleFit.onAuthorize(() => {
        this.initEmptyData()
        this.getStepData()
        this.getDistanceData()
        this.getCaloriesBurnData()
        this.getWeightData()
        GoogleFit.observeSteps(evt => {
          evt
          this.initEmptyData()
          this.getStepData()
          this.getCaloriesBurnData()
          this.getWeightData()
          this.getDistanceData()
        })
      })

      GoogleFit.onAuthorizeFailure(() => {
        // console.warn('google fit authorize error')
      })

      GoogleFit.isAvailable(() => {
        GoogleFit.authorize()
      })
    }
  }

  // method:
  // 'accumulate': steps, distance, ...
  // 'remain': weight, ...
  selectRecentlySamples(samples, selectCount, method = 'accumulate') {
    if (!samples || !samples.length) return []

    // reverse for arranging backward
    samples.reverse()

    let dayData = []
    let average
    // select latest
    const selectedSamples = samples.reduce((destAry, sample) => {
      const idx = destAry.findIndex(el =>
        moment(el.startDate).startOf('date').isSame(moment(sample.startDate).startOf('date'))
      )
      if (idx !== -1) {
        dayData.push({ ...sample })
        switch (method) {
          case 'accumulate':
            destAry[idx].value += sample.value
            break
          default:  // 'remain'
            average = dayData.reduce((total, el) => total + el.value, 0) / dayData.length
            destAry[idx].value = average
        }
      } else if (destAry.length < selectCount) {
        destAry.push({ ...sample })
        dayData = []
        dayData.push({ ...sample })
      }
      return destAry
    }, [])
    // reverse again
    selectedSamples.reverse()

    return selectedSamples
  }

  @action getCaloriesBurnData = () => {
    if (this.isEnabled) {
      if (platform === 'ios') {
        const options = {
          startDate: moment().subtract(collectDataDays, 'day').startOf('date').toISOString(),
          asending: false,
        }
        let dataSrc
        AppleHealthKit.getActiveEnergyBurned(options, (err, results) => {
          if (this.handleHKError(err, 'getActiveEnergyBurned') || results.length === 0) {
            dataSrc = this.getStores().ExerciseTrack.caloriesBurnData
          } else {
            dataSrc = results.reverse()
          }
          const caloriesBurn = this.selectRecentlySamples(dataSrc, selectCount, 'accumulate')
          this.healthKitData = {
            ...this.healthKitData,
            caloriesBurn,
          }
        })
      } else {
        const options = {
          startDate: moment().subtract(collectDataDays, 'day').startOf('date').toISOString(),
          endDate: moment().toISOString(),
          ascending: false,
        }
        let dataSrc
        GoogleFit.getDailyCalorieSamples(options, (err, res) => {
          if (this.handleHKError(err, 'getDailyCalorie') || res.length === 0) {
            dataSrc = this.getStores().ExerciseTrack.caloriesBurnData
            dataSrc.reverse()
          } else {
            const changedFieldName = res.map(el => ({
              startDate: el.startDate,
              endDate: el.endDate,
              value: el.calorie,
            }))
            dataSrc = changedFieldName
          }
          const caloriesBurn = this.selectRecentlySamples(dataSrc, selectCount, 'accumulate')
          this.healthKitData = {
            ...this.healthKitData,
            caloriesBurn,
          }
        })
      }
    }
  }

  @computed get caloriesBurnGraphData() {
    const result = this.calcAccumulateGraphData(this.healthKitData.caloriesBurn, emptyGraphData)

    return {
      averageCal: roundValue(result.average, 0),
      currentDayCal: roundValue(result.currentDayValue, 0),
      maxVal: roundValue(result.maxVal, 0),
      graph: result.graph
    }
  }

  @action getWeightData = () => {
    if (this.isEnabled) {
      if (platform === 'ios') {
        const options = {
          unit: 'pound',
          startDate: moment().subtract(collectDataDays, 'day').startOf('date').toISOString(),
          asending: false,
        }
        AppleHealthKit.getWeightSamples(options, (err, results) => {
          if (this.handleHKError(err, 'getWeightSamples')) {
            return
          }
          results.reverse()
          const weights = this.selectRecentlySamples(results, selectCount, 'remain')
          this.healthKitData = {
            ...this.healthKitData,
            weights,
          }
        })
      } else {
        const options = {
          unit: 'pound',
          startDate: moment().subtract(collectDataDays, 'day').startOf('date').toISOString(),
          endDate: moment().toISOString(),
          ascending: false,
        }
        GoogleFit.getWeightSamples(options, (err, res) => {
          if (this.handleHKError(err, 'getWeightSamples')) {
            return
          }
          const weights = this.selectRecentlySamples(res, selectCount, 'remain')
          this.healthKitData = {
            ...this.healthKitData,
            weights,
          }
        })
      }
    }
  }

  @action setWeight = weight => {
    if (this.isEnabled) {
      if (platform === 'ios') {
        const options = {
          value: weight,
        }
        AppleHealthKit.saveWeight(options, (err, results) => {
          if (this.handleHKError(err, 'saveWeight')) {
            return
          }
          results
          this.getWeightData()
        })
      } else {
        const options = {
          value: weight,
          date: moment().toISOString(),
          unit: 'pound',
        }
        GoogleFit.saveWeight(options, (err, res) => {
          if (this.handleHKError(err, 'saveWeight')) {
            return
          }
          res
          this.getWeightData()
        })
      }
    }
  }

  @computed get weightsGraphData() {
    const result = this.calcRemainGraphData(this.healthKitData.weights, emptyGraphData)

    return {
      averageWeight: result.average,
      currentDayWeight: result.currentDayValue,
      maxVal: result.maxVal,
      graph: result.graph
    }
  }

  @action getStepData = () => {
    if (this.isEnabled) {
      if (platform === 'ios') {
        const options = {
          startDate: moment().subtract(collectDataDays, 'day').startOf('date').toISOString(),
          asending: false,
        }
        AppleHealthKit.getDailyStepCountSamples(options, (err, results) => {
          if (this.handleHKError(err, 'getDailyStepCountSamples')) {
            return
          }
          results.reverse()
          const steps = this.selectRecentlySamples(results, selectCount, 'accumulate')
          this.healthKitData = {
            ...this.healthKitData,
            steps,
          }
        })
      } else {
        const options = {
          startDate: moment().subtract(collectDataDays, 'day').startOf('date').toISOString(),
          endDate: moment().toISOString(),
          ascending: false,
        }
        GoogleFit.getDailyStepCountSamples(options, (err, res) => {
          if (this.handleHKError(err, 'getDailyStepCountSamples')) {
            return
          }
          const changedFieldName = res[0].steps.map(el => ({
            startDate: el.date,
            endDate: el.date,
            value: el.value,
          }))
          const steps = this.selectRecentlySamples(changedFieldName, selectCount, 'accumulate')
          this.healthKitData = {
            ...this.healthKitData,
            steps,
          }
        })
      }
    }
  }

  @computed get stepsGraphData() {
    const result = this.calcAccumulateGraphData(this.healthKitData.steps, emptyGraphData)

    return {
      averageStep: roundValue(result.average, 0),
      currentDayStep: roundValue(result.currentDayValue, 0),
      maxVal: roundValue(result.maxVal, 0),
      graph: result.graph
    }
  }

  @action getDistanceData = () => {
    if (this.isEnabled) {
      if (platform === 'ios') {
        const collectedData = []
        this.getDistance_Recursive(collectedData, 15, 0, coledData => {
          coledData.reverse()
          const distances = this.selectRecentlySamples(coledData, selectCount, 'accumulate')
          this.healthKitData = {
            ...this.healthKitData,
            distances,
          }
        })
      } else {
        const options = {
          unit: 'meter',
          startDate: moment().subtract(collectDataDays, 'day').startOf('date').toISOString(),
          endDate: moment().toISOString(),
          ascending: false,
        }
        GoogleFit.getDailyDistanceSamples(options, (err, res) => {
          if (this.handleHKError(err, 'getDailyDistanceSamples')) {
            return
          }
          const changedFieldName = res.map(el => ({
            startDate: el.startDate,
            endDate: el.endDate,
            value: Converter(el.distance).from('m').to('mi'),
          }))
          const distances = this.selectRecentlySamples(changedFieldName, selectCount, 'accumulate')
          this.healthKitData = {
            ...this.healthKitData,
            distances,
          }
        })
      }
    }
  }

  @computed get distancesGraphData() {
    const result = this.calcAccumulateGraphData(this.healthKitData.distances, emptyGraphData)

    return {
      averageDistance: result.average,
      currentDayDistance: result.currentDayValue,
      maxVal: result.maxVal,
      graph: result.graph
    }
  }

  getDistance_Recursive(collectedData, allCount, collectedCount, finalProcess) {
    const options = {
      unit: 'mile',
      date: moment().subtract(collectedCount, 'day').startOf('date').toISOString(),
      asending: false,
    }
    AppleHealthKit.getDistanceWalkingRunning(options, (err, results) => {
      collectedCount++
      if (!this.handleHKError(err, 'getDailyStepCountSamples')) {
        collectedData.push(results)
      }
      if (collectedCount === allCount) {
        finalProcess(collectedData)
        return
      }
      this.getDistance_Recursive(collectedData, allCount, collectedCount, finalProcess)
    })
  }

  @action getFlightClimbedData = () => {
    if (this.isEnabled) {
      if (platform === 'ios') {
        const options = {
          //date: moment().toISOString(),
          //asending: false,
        }
        AppleHealthKit.getFlightsClimbed(options, (err, results) => {
          if (this.handleHKError(err, 'getFlightsClimbed')) {
            return
          }
          const flights = this.selectRecentlySamples([results], selectCount, 'accumulate')
          this.healthKitData = {
            ...this.healthKitData,
            flights,
          }
        })
      }
    }
  }

  @action getGlucoseData = () => {
    if (this.isEnabled) {
      if (platform === 'ios') {
        const options = {
          unit: 'mmolPerL',
          startDate: moment().subtract(collectDataDays, 'day').startOf('date').toISOString(),
          asending: false,
        }
        AppleHealthKit.getBloodGlucoseSamples(options, (err, results) => {
          if (this.handleHKError(err, 'getBloodGlucoseSamples')) {
            return
          }
          results.reverse()
          const glucoses = this.selectRecentlySamples(results, selectCount, 'remain')
          this.healthKitData = {
            ...this.healthKitData,
            glucoses,
          }
        })
      }
    }
  }

  calcAccumulateGraphData = (dataList, emptyGraphData) => {
    let total = 0
    let graph = []
    let maxVal = 0
    let currentDayValue = emptyGraphData.currentDayValue
    const todayStart = moment().startOf('date')
    // initialize
    graph = JSON.parse(JSON.stringify(emptyGraphData.graph))

    if (dataList && dataList.length) {
      dataList.forEach(el => {
        const day = moment(el.startDate).startOf('date')
        const y = platform === 'ios' ? el.value : el.value > 0 ? el.value : 0
        const idx = selectCount - todayStart.diff(day, 'days') - 1
        if (idx >= 0 && idx < selectCount) {
          total += y
          if (y > maxVal) {
            maxVal = y
          }
          graph[idx].y = y
        }

      })

    }
    const average = graph.length ? total / graph.length : emptyGraphData.average
    maxVal = maxVal ? maxVal : emptyGraphData.maxVal
    currentDayValue = graph[selectCount - 1].y

    return {
      average,
      currentDayValue,
      maxVal,
      graph
    }
  }

  calcRemainGraphData = (dataList, emptyGraphData) => {
    let total = 0
    let graph = []
    let maxVal = 0
    let currentDayValue = emptyGraphData.currentDayValue
    let x, y
    if (dataList && dataList.length) {
      const lastData = dataList[dataList.length - 1]
      const firstData = dataList[0]
      for (let i = 0; i < selectCount; i++) {
        const elDate = moment().subtract(selectCount - i - 1, 'day').startOf('date')
        const idx = dataList.findIndex(el => moment(el.startDate).startOf('date').isAfter(elDate))
        x = `${elDate.format('D')}/${elDate.format('M')}`
        if (idx === -1) {
          y = platform === 'ios' ? lastData.value : lastData.value > 0 ? lastData.value : 0
        } else if (idx === 0) {
          y = platform === 'ios' ? firstData.value : firstData.value > 0 ? firstData.value : 0
        } else {
          const beforeOrSameDateData = dataList[idx - 1]
          y = platform === 'ios' ? beforeOrSameDateData.value : beforeOrSameDateData.value > 0 ? beforeOrSameDateData.value : 0
        }
        maxVal = y > maxVal ? y : maxVal
        graph.push({ x, y })
        total += y
      }
      currentDayValue = graph[graph.length - 1].y
    } else {
      graph = emptyGraphData.graph
    }
    const average = graph.length ? total / graph.length : emptyGraphData.average
    maxVal = maxVal ? maxVal : emptyGraphData.maxVal

    return {
      average,
      currentDayValue,
      maxVal,
      graph
    }
  }

  sortByDate(sample1, sample2) {
    if (moment(sample1.startDate).isBefore(moment(sample2.startDate))) return -1
    else if (moment(sample1.startDate).isAfter(moment(sample2.startDate))) return 1
    return 0
  }

  handleHKError = (err, kindRequest) => {
    if (err) {
      kindRequest
      // console.warn(`${kindRequest} Error: `, err)
      return true
    }
    return false
  }

  @action clearHealthKitData = () => {
    this.healthKitData = {
      caloriesBurn: [],
      weights: [],
      steps: [],
      distances: [],
      flights: []
    }
    if (platform === 'ios' && this.stepCountEventListener) {
      this.stepCountEventListener.remove()
    }
    if (platform === 'android') {
      GoogleFit.unsubscribeListeners()
    }
  }

  requestAndroidFLPermission = async () => {
    try {
      const currentState = await PermissionsAndroid.check(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION)
      if (currentState === PermissionsAndroid.RESULTS.GRANTED) {
        this.locationPermission = true
      } else {
        const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION)
        if (granted === PermissionsAndroid.RESULTS.GRANTED) {
          this.locationPermission = true
        } else {
          this.locationPermission = false
        }
      }
    } catch (err) {
      this.locationPermission = false
      // console.warn(err)
    }
  }
}

export default HealthKit
