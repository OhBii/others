/*
*   author: denis
*   date:   08/06/2018
*/

import { observable, action, computed } from 'mobx';

import Api from '../utils/Api';

class Recipe {
  constructor(getStores) {
    this.getStores = getStores;
  }

  fetch = () => Promise.all([
    this.getRecipeAll(),
    this.getFavorites()
  ])

  @observable recipes;
  @observable favoriteRecipes;

  @action getRecipeAll = async () => {
    const { User: {token} } = this.getStores();
    try {
      const { status, data} = await Api.getRecipe(token);
      if (status === 200) {
        this.recipeSuccess(data);
      }
      return Promise.resolve();
    } catch (error) {
      // this.recipeError(error);
      return Promise.reject(error);
    }
  }

  @action getFavorites = async () => {
    const { User: {token} } = this.getStores();
    try {
      const { data } = await Api.getFavoriteRecipes(token);
      this.favoriteSuccess(data);
    } catch (error) {
      // this.favoriteError(error);
      return Promise.reject(error);
    }
  }

  @action recipeSuccess = (data) => {
    this.recipes = data;
  }

  // @action recipeError = (err) => {

  // }

  @action favoriteSuccess = (data) => {
    this.favoriteRecipes = data;
  }

  // @action favoriteError = (err) => {

  // }

  @action getRecipeById = (recipeId) => {
    const recipe = this.recipes.find((recipe) => recipe.id === recipeId);
    return recipe;
  }

  @action getPFCByRecipeId = (recipeId) => {
    const recipe = this.getRecipeById(recipeId);
    const valuePFC = recipe.template_recipe_ingredients.reduce((accumulator, ingredient) => {
      accumulator.calories += parseFloat(ingredient.calories);
      accumulator.pro += parseFloat(ingredient.proteins);
      accumulator.fats += parseFloat(ingredient.fats);
      accumulator.carbs += parseFloat(ingredient.carbohydrates);
      return accumulator;
    }, {
      calories: 0,
      pro: 0,
      fats: 0,
      carbs: 0
    });

    return {
      calories: Math.round(valuePFC.calories * 10) / 10,
      pro: Math.round(valuePFC.pro * 10) / 10,
      fats: Math.round(valuePFC.fats * 10) / 10,
      carbs: Math.round(valuePFC.carbs * 10) / 10
    };
  }

  @action addRecipeToFavorite = async (recipeId) => {
    const { User: {token} } = this.getStores();
    try {
      const { data } = await Api.addFavoriteRecipes(token, recipeId);
      this.favoriteRecipes.push(data);
    } catch(error) {
      //console.log(error.response);
    }
  }

  @action deleteRecipeFromFavorite = async (favId) => {
    const { User: {token} } = this.getStores();
    try {
      await Api.deleteFavoriteRecipes(token, favId);
      const newFavoriteRecipes = this.favoriteRecipes.filter((item) => item.id !== favId);
      this.favoriteRecipes = newFavoriteRecipes;
    } catch(error) {
      //console.log(error.response);
    }
  }

  @computed get getDataOfFavorites() {
    if (!this.favoriteRecipes) return [];
    const favorites = this.favoriteRecipes.reduce((accumulator, favorite) => {
      const value = this.recipes.find((recipe) => recipe.id === favorite.recipe);
      if (value) accumulator.push(value);
      return accumulator;
    }, []);
    return favorites;
  }

  @action getTaggedRecipes = () => {
    const { User: {favList} } = this.getStores();

    const recipePreferred = this.recipes.filter((recipe) =>
      recipe.tags.find((tag) => {
        const res = favList.find((fav) => fav === tag.name)
        if (res) return true
        else return false
      }));

    const recipeBreakfast = this.recipes.filter((recipe) =>
      recipe.tags.find((tag) => tag.name === 'breakfast'));

    const recipeLunch = this.recipes.filter((recipe) =>
      recipe.tags.find((tag) => tag.name === 'lunch'));

    const recipeDinner = this.recipes.filter((recipe) =>
      recipe.tags.find((tag) => tag.name === 'dinner'));

    const recipeOther = this.recipes.filter((recipe) => {
      if (recipeBreakfast.find(item => item.id === recipe.id)) return false
      if (recipeLunch.find(item => item.id === recipe.id)) return false
      if (recipeDinner.find(item => item.id === recipe.id)) return false
      return true
    });

    return {
      preferred: recipePreferred,
      breakfast: recipeBreakfast,
      lunch: recipeLunch,
      dinner: recipeDinner,
      other: recipeOther
    }
  }

  @action getSwappableRecipes = async(mealId) => {
    try {
      const { User: {token}, MealPlan } = this.getStores();
      const meal = MealPlan.getMealById(mealId)
      const mealItems = MealPlan.getMealItemsByIds(meal.meal_items)
      const categories = mealItems.map((item) => {
          return item.category
      })
      const { data } = await Api.getSwappableRecipes(token, categories)
      return {
        swappable: data
      }
    }
    catch (err) {
      return {
        swappable: []
      }
    }
  }
}

export default Recipe;