

import { observable, action, computed } from 'mobx';
import { persist } from 'mobx-persist';
import moment from 'moment';
class GroceryList {

	constructor(getStores) {
			this.getStores = getStores;
	}

	fetch = () => Promise.all([

	])

	postfetch = () => {
		this.groceryListInitialize()
	}

	@persist('object') @observable groceryList = {};
	@persist('object') @observable addedGroceryList = {};
	@persist('object') @observable createdDateList = {}
	@computed get mealItemsGroceryList() {
		return this.groceryList[this.email()]
	}
	@computed get addedMealItemsGroceryList() {
		return this.addedGroceryList[this.email()]
	}
	@computed get listName() {
		return Object.keys(this.groceryList[this.email()])
	}
	@computed get dateList() {
		return this.createdDateList[this.email()]
	}
	@action groceryListInitialize =  () => {
		const {
			User: {
				isPremium,
				userInfo: {
					email,
				}
			},
			MealPlan: {
				premealItems,
				mealItems,
				nextmealItems,
				currentWeekNumber,
				prevWeekNumber,
				nextWeekNumber,
			},
			Checkin:{
				checkinBoolean,
				initializeCheckinBoolean
			}
		} = this.getStores();
		//const prevWeekNumber = currentWeekNumber - 1 < 1 ? 3 : currentWeekNumber - 1;
		//const nextWeekNumber = currentWeekNumber + 1 > 3 ? 1 : currentWeekNumber + 1;
		const mealItemsGroceryArray = [premealItems, mealItems, nextmealItems];
		const groceryArray = mealItemsGroceryArray.map((items) => this.groceryArray(items));
		if (checkinBoolean) {
			if (!isPremium) return
			this.groceryList[email][nextWeekNumber] = {...this.groceryArray(nextmealItems)}
			this.createdDateList[email][nextWeekNumber] = moment().format("D/M/YYYY");
			initializeCheckinBoolean();
			return
		}
		// if ( Object.keys(this.groceryList).indexOf(email) !== -1 ) return
		if (this.groceryList[email] && Object.keys(this.groceryList[email]).length > 0) return
		if (!isPremium) {
			const newList = {...this.groceryList}
			const createdDateList = {...this.createdDateList}
			newList[email] = {}
			createdDateList[email] = {}
			this.groceryList = {...newList}
			this.createdDateList = {...createdDateList}
			return
		}
		const newList = {...this.groceryList}
		const mealItemsGroceryList = {}
		mealItemsGroceryList[prevWeekNumber] = {...groceryArray[0]}
		mealItemsGroceryList[currentWeekNumber] = {...groceryArray[1]}
		mealItemsGroceryList[nextWeekNumber] = {...groceryArray[2]}
		newList[email] = {...mealItemsGroceryList}
		this.groceryList = {...newList}

		const newAddList = {...this.addedGroceryList}
		newAddList[email] = {
			[prevWeekNumber]: {},
			[currentWeekNumber]: {},
			[nextWeekNumber]: {}
		}
		this.addedGroceryList = {...newAddList}

		const createdDateList = {...this.createdDateList}
		createdDateList[email] = {
			[prevWeekNumber]: moment().format("D/M/YYYY"),
			[currentWeekNumber]: moment().format("D/M/YYYY"),
			[nextWeekNumber]: moment().format("D/M/YYYY")
		}
		this.createdDateList = {...createdDateList}
	}

	@action groceryArray = (mealItems, listName) =>{
		if (!mealItems) return {};
		const {
			User: { isPremium }
		} = this.getStores()
		let groceryItems = {}
		// const categoryList = {}
		if( mealItems.length !== undefined){
			if (isPremium) groceryItems = {...this.addedGroceryList[this.email()][listName]}
			else groceryItems = this.groceryList[this.email()][listName]
			mealItems.map( item =>{
				const rate = +item.groceries_replacement_ratio
				if ( item.name in groceryItems){
					groceryItems[item.name].amount += rate !== 0 ? (item.exchanges * item.portion) / rate : item.exchanges * item.portion
					groceryItems[item.name].amount_si += rate !== 0 ? (item.exchanges * item.portion_si) / rate : item.exchanges * item.portion_si
					groceryItems[item.name].fats += +item.fats
					groceryItems[item.name].proteins += +item.proteins
					groceryItems[item.name].carbohydrates += +item.carbohydrates
				} else {
					groceryItems = {
						[item.name]:{
							name: item.name,
							category: item.category,
							shoppingAmount: 0,
							amount: rate !== 0 ? (item.exchanges * item.portion) / rate : item.exchanges * item.portion,
							amount_si: rate !== 0 ? (item.exchanges * item.portion_si) / rate : item.exchanges * item.portion_si,
							exchanges: item.exchanges,
							portion: item.portion,
							portion_si: item.portion_si,
							unit: item.unit,
							unit_si: item.unit_si,
							fats: +item.fats,
							proteins: +item.proteins,
							carbohydrates: +item.carbohydrates,
							checkFlag: false
						},
						...groceryItems
					}
				}
			})
		} else {
			Object.keys(mealItems).map(key => {
				const rate = +mealItems[key].groceries_replacement_ratio
				if (mealItems[key].name in groceryItems) {
					groceryItems[mealItems[key].name].amount += rate !== 0 ? (mealItems[key].exchanges * mealItems[key].portion) / rate : mealItems[key].exchanges * mealItems[key].portion
					groceryItems[mealItems[key].name].amount_si += rate !== 0 ? (mealItems[key].exchanges * mealItems[key].portion_si) / rate : mealItems[key].exchanges * mealItems[key].portion_si
					groceryItems[mealItems[key].name].fats += +mealItems[key].fats
					groceryItems[mealItems[key].name].proteins += +mealItems[key].proteins
					groceryItems[mealItems[key].name].carbohydrates += +mealItems[key].carbohydrates
				} else {
					groceryItems[mealItems[key].name] = {
						name: mealItems[key].name,
						category: mealItems[key].category,
						shoppingAmount: 0,
						amount: rate !== 0 ? (mealItems[key].exchanges * mealItems[key].portion) / rate : mealItems[key].exchanges * mealItems[key].portion,
						amount_si: rate !== 0 ? (mealItems[key].exchanges * mealItems[key].portion_si) / rate : mealItems[key].exchanges * mealItems[key].portion_si,
						exchanges: mealItems[key].exchanges,
						portion: mealItems[key].portion,
						portion_si: mealItems[key].portion_si,
						unit: mealItems[key].unit,
						unit_si: mealItems[key].unit_si,
						fats: +mealItems[key].fats,
						proteins: +mealItems[key].proteins,
						carbohydrates: +mealItems[key].carbohydrates,
						checkFlag: false
					}
				}
			})
		}
		Object.keys(groceryItems).map(mealName => {
			let input = groceryItems[mealName].amount
			let inputSI = groceryItems[mealName].amount_si
			let unitSI = groceryItems[mealName].unit_si
			if (input <= 10) input = (Math.round(input * 10) / 10).toFixed(1).replace(/[.,]0$/, '')
			else if (input > 10 && input <= 50) input = Math.round(input / 5) * 5
			else if (input > 50 && input <= 100) input = Math.round(input / 10) * 10
			else if (input > 100 && input < 500) {
				input = Math.round(input / 50) * 50
				if (input === 500) {
					input = 0.5
				}
			} else if (input >= 500) input = Math.round(input / 100) * 100
			groceryItems[mealName].amount = parseFloat(input)
			if (inputSI <= 10) inputSI = (Math.round(inputSI * 10) / 10).toFixed(1).replace(/[.,]0$/, '')
			else if (inputSI > 10 && inputSI <= 50) inputSI = Math.round(inputSI / 5) * 5
			else if (inputSI > 50 && inputSI <= 100) inputSI = Math.round(inputSI / 10) * 10
			else if (inputSI > 100 && inputSI < 500) {
				inputSI = Math.round(inputSI / 50) * 50
				if (inputSI === 500) {
					inputSI = 0.5
					if (unitSI === 'ml') unitSI = 'l'
					else if (unitSI === 'g') unitSI = 'kg'
				}
			} else if (inputSI >= 500 && (unitSI === 'ml' || unitSI === 'g')) {
				inputSI = Math.round(inputSI / 100) / 10
				if (unitSI === 'ml') unitSI = 'l'
				else if (unitSI === 'g') unitSI = 'kg'
			} else if (inputSI >= 500) inputSI = Math.round(inputSI / 100) * 100
			groceryItems[mealName].amount_si = inputSI
			groceryItems[mealName].unit_si = unitSI
		})
		// Object.keys(groceryItems).map(mealName => {
		// 	if (groceryItems[mealName].category in categoryList) {
		// 		categoryList[groceryItems[mealName].category].data.push(groceryItems[mealName])
		// 		categoryList[groceryItems[mealName].category].fats += groceryItems[mealName].fats
		// 		categoryList[groceryItems[mealName].category].proteins += groceryItems[mealName].proteins
		// 		categoryList[groceryItems[mealName].category].carbohydrates += groceryItems[mealName].carbohydrates
		// 	} else {
		// 		categoryList[groceryItems[mealName].category] = {
		// 			data: [groceryItems[mealName]],
		// 			title: groceryItems[mealName].category,
		// 			fats: groceryItems[mealName].fats,
		// 			proteins: groceryItems[mealName].proteins,
		// 			carbohydrates: groceryItems[mealName].carbohydrates,
		// 		}
		// 	}
		// })
		return groceryItems
	}

	@action email = () => {
		const { User: { userInfo: { email } } } = this.getStores();
		return email
	}

	@action deleteListItem = (listName) =>{
		const newList = {...this.groceryList}
		delete newList[this.email()][listName];
		this.groceryList = {...newList}
	}

	@action deleteItem = (listName, itemName, addedItemFlag) => {
		const {
			User: { isPremium }
		} = this.getStores()
		if (isPremium && addedItemFlag) {
			let newList = {...this.addedGroceryList}
			delete newList[this.email()][listName][itemName]
			newList[this.email()][listName] = {...newList[this.email()][listName]}
			this.addedGroceryList = {...newList}
			return
		}
		let newList = {...this.groceryList}
		delete newList[this.email()][listName][itemName]
		newList[this.email()][listName] = {...newList[this.email()][listName]}
		this.groceryList = {...newList}
	}

	@action setItemAmount = (amount, listName, itemName, isUS, addedItemFlag) => {
		const {
			User: { isPremium }
		} = this.getStores()
		if (isPremium && addedItemFlag) {
			let newList = {...this.addedGroceryList}
			if (isUS) {
				newList[this.email()][listName][itemName].amount = amount;
			} else {
				newList[this.email()][listName][itemName].amount_si = amount;
			}
			this.addedGroceryList = {...newList}
			return
		}
		let newList = {...this.groceryList}
		if (isUS) {
			newList[this.email()][listName][itemName].amount = amount;
		} else {
			newList[this.email()][listName][itemName].amount_si = amount;
		}
		this.groceryList = {...newList}
	}

	@action setCheckFlag = ( listName, name, addedItemFlag ) => {
		const {
			User: { isPremium }
		} = this.getStores()
		if (isPremium && addedItemFlag) {
			let newList = {...this.addedGroceryList};
			newList[this.email()][listName][name].checkFlag = !newList[this.email()][listName][name].checkFlag;
			if (newList[this.email()][listName][name].checkFlag == true)	newList[this.email()][listName][name].shoppingAmount += newList[this.email()][listName][name].amount;
			else if (newList[this.email()][listName][name].checkFlag == false) newList[this.email()][listName][name].shoppingAmount -= newList[this.email()][listName][name].amount;
			this.addedGroceryList = {...newList}
			return
		}
		let newList = {...this.groceryList};
		newList[this.email()][listName][name].checkFlag = !newList[this.email()][listName][name].checkFlag;
		if (newList[this.email()][listName][name].checkFlag == true)	newList[this.email()][listName][name].shoppingAmount += newList[this.email()][listName][name].amount;
		else if (newList[this.email()][listName][name].checkFlag == false) newList[this.email()][listName][name].shoppingAmount -= newList[this.email()][listName][name].amount;
		this.groceryList = {...newList}
	}

	@action addGroceryList = (listName) => {
		const today = moment().format("D/M/YYYY");
		let newcreatedDataList = {...this.createdDateList}
		newcreatedDataList[this.email()][listName] = today
		this.createdDateList = {...newcreatedDataList}
		let newList = {...this.groceryList}
		newList[this.email()][listName] = {}
		this.groceryList = {...newList}
	}

	@action setmealItemsGroceryList = ( listName, itemList ) => {
		const {
			User: { isPremium }
		} = this.getStores()
		if (isPremium) {
			let newList = {...this.addedGroceryList}
			newList[this.email()][listName] = {...this.groceryArray(itemList, listName)}
			newList[this.email()] = {...newList[this.email()]}
			this.addedGroceryList = {...newList}
			return
		}
		let newList = {...this.groceryList}
		newList[this.email()][listName] = {...this.groceryArray(itemList, listName)}
		newList[this.email()] = {...newList[this.email()]}
		this.groceryList = {...newList}
	}

}

export default GroceryList;
