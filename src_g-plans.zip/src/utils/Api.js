/*
*   author: denis
*   date:   7/30/2018
*/

import axios from 'axios';

// const domain = 'https://staging.g-plans.com/';
// const domain = 'https://mobile.d.g-plans.com/';
const domain = 'https://g-plans.com/';

export default class Api {
  //login
  static login(email, password) {
    return axios({
      method: 'post',
      url: `${domain}api/v1/auth/token/`,
      headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
      },
      data: {
        email: email,
        password: password
      }
    });
  }

  static checkAuth(token) {
    return axios({
      method: 'post',
      url: `${domain}api/v1/auth/check/`,
      headers: {
        'Authorization': `Token ${token}`,
      },
    });
  }

  static getMealPlan( token, weekNumber='') {
    return axios({
      method: 'get',
      url: `${domain}api/v2/new-mymealplan/?${weekNumber}`,
      headers: {
        'Authorization': `Token ${token}`,
      },
    });
  }

  static getRecommendedProducts() {
    return axios({
      method: 'get',
      url: `${domain}api/v1/recommended-products/`,
    });
  }

  static getBlogs() {
    return axios({
      method: 'get',
      url: `https://blog.g-plans.com/wp-json/posts?filter[tag]=story`,
    });
  }

  static getRecipe(token) {
    return axios({
      method: 'get',
      url: `${domain}api/v2/recipes/?restrictions=1`,
      headers: {
        'Authorization': `Token ${token}`,
      },
    });
  }

  static logMeal(token, mealId) {
    return axios({
      method: 'post',
      url: `${domain}/api/v2/loggedmeals/`,
      headers: {
        'Authorization': `Token ${token}`,
      },
      data: {
        meal: mealId
      },
    });
  }

  static logMealItems(token, items) {
    return axios({
      method: 'post',
      url: `${domain}/api/v2/loggedmealitems/`,
      headers: {
        'Authorization': `Token ${token}`,
      },
      data: items,
    })
  }

  static unlogMeal(token, mealId, loggedId) {
    return axios({
      method: 'delete',
      url: `${domain}/api/v2/loggedmeals/${loggedId}/?logged_meal__meal_id=${mealId}`,
      headers: {
        'Authorization': `Token ${token}`
      },
    })
  }

  static skipMeal(token, mealId) {
    return axios({
      method: 'post',
      url: `${domain}/api/v2/loggedmeals/`,
      headers: {
        'Authorization': `Token ${token}`
      },
      data: {
        meal: mealId,
        skipped: 'True'
      }
    })
  }

  static searchOnlyFood(token, foodName, language) {
    //language(Chinese X)
    //
    if(language ==="zh_hans") {
      language = "zh-hans";
    }
    return axios({
      method: 'get',
      url: `${domain}/api/v1/search-only-food/?q=${foodName}`,
      headers: {
        'Authorization': `Token ${token}`,
        'Accept-Language': language //set language info of Store
      }
    })
  }

  static searchNutrients(token, foodName, nixItemId) {
    return axios({
      method: 'get',
      url: `${domain}/api/v1/search-nutrients/?food_name=${nixItemId ? '' : foodName}&nix_item_id=${nixItemId ? nixItemId : ''}`,
      headers: {
        'Authorization': `Token ${token}`,
        'Accept-Language': 'en' //set language info of Store
      }
    })
  }

  static searchOnlyFoodBarcode(token, barcode) {
    return axios({
      method: 'get',
      url: `${domain}/api/v1/search-only-food-barcode/?q=${barcode}`,
      headers: {
        'Authorization': `Token ${token}`,
        'Accept-Language': 'en'
      }
    })
  }

  static extraSearch(token, foodName, language ,category) {
    let url = `${domain}api/v1/extra-search/`;
    if (foodName != undefined) {
      url = `${url}?q=${foodName}`;
      if (category != undefined) url = `${url}&category=${foodName}`;
    }
    else {
      if (category != undefined) url = `${url}?category=${foodName}`;
    }

    if(language ==="zh_hans") {
      language = "zh-hans";
    }
    return axios({
      method: 'get',
      url: url,
      headers: {
        'Authorization': `Token ${token}`,
        'Accept-Language': language
      }
    })
  }

  static getFavoriteRecipes(token) {
    return axios({
      method: 'get',
      url: `${domain}api/v2/recipes-favorite/`,
      headers: {
        'Authorization': `Token ${token}`
      }
    })
  }

  static addFavoriteRecipes(token, recipeId) {
    return axios({
      method: 'post',
      url: `${domain}api/v2/recipes-favorite/`,
      headers: {
        'Authorization': `Token ${token}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      data: {
        recipe: recipeId
      }
    })
  }

  static deleteFavoriteRecipes(token, favId) {
    return axios({
      method: 'delete',
      url: `${domain}api/v2/recipes-favorite/${favId}/`,
      headers: {
        'Authorization': `Token ${token}`
      }
    })
  }

  static createWaterTracker(token, week, checkin, day) {
    return axios({
      method: 'post',
      url: `${domain}api/v1/watertrackers/`,
      headers: {
        'Authorization': `Token ${token}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      data: {
        week: week,
        checkin: checkin,
        day: day
      }
    })
  }

  static waterTrack(token, id, week, checkin, logged_at, day, glasses) {
    return axios({
      method: 'put',
      url: `${domain}api/v1/watertrackers/${id}/`,
      headers: {
        'Authorization': `Token ${token}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      data: {
        week: week,
        checkin: checkin,
        logged_at: logged_at,
        day: day,
        glasses: glasses
      }
    })
  }

  static getWaterTrackInfos(token, checkin = '') {
    return axios({
      method: 'get',
      url: `${domain}api/v1/watertrackers/`,
      headers: {
        'Authorization': `Token ${token}`
      },
      params: {
        checkin
      }
    })
  }

  static getOauthUrl(webId, uuid) {
    return axios({
      method: 'get',
      // url: `${domain}oauth/mv/authorization-url/?referrer=${webId}&request_id=${uuid}`
      url: `https://mobile.d.pruvitapi.com/oauth/mv/registration-url/?referrer=${webId}&request_id=${uuid}`
    })
  }

  static getOauthToken(uuid) {
    return axios({
      method: 'post',
      url: `${domain}oauth/mv/token/`,
      data: {
        'request_id': uuid
      }
    })
  }

  static getFoodsByCategory(token, category) {
    return axios({
      method: 'get',
      url: `${domain}api/v1/foods/`,
      headers: {
        'Authorization': `Token ${token}`
      },
      params: {
        category
      },
    })
  }

  static swapMealItem(token, curMealItemId, swapMealItem) {
    return axios({
      method: 'put',
      url: `${domain}api/v2/usermealitems/${curMealItemId}/`,
      headers: {
        'Authorization': `Token ${token}`
      },
      data: swapMealItem
    })
  }

  static createMisc(token, data) {
    return axios({
      method: 'post',
      url: `${domain}api/v2/misc/`,
      headers: {
        'Authorization': `Token ${token}`
      },
      data
    })
  }

  static getMisc(token, key) {
    return axios({
      method: 'get',
      url: `${domain}api/v2/misc/${key}/`,
      headers: {
        'Authorization': `Token ${token}`
      }
    })
  }

  static putMisc(token, data) {
    return axios({
      method: 'put',
      url: `${domain}api/v2/misc/${data.key}/`,
      headers: {
        'Authorization': `Token ${token}`
      },
      data
    })
  }

  static setMisc(token, data) {
    return this.putMisc(token, data)
      .then(({data}) => data)
      .catch(() => this.createMisc(token, data)
        .then(({data}) => data)
        .catch(err => err)
      )
  }

  static getCheckinImages(token) {
    return axios({
      method: 'get',
      url: `${domain}api/v1/checkin-images/`,
      headers: {
        'Authorization': `Token ${token}`
      }
    })
  }

  static uploadCheckinImage(token, checkinId, imageUri) {
    // eslint-disable-next-line no-undef
    const data = new FormData();
    data.append('image', {
      uri: imageUri,
      name: 'image.jpg',
      type: 'multipart/form-data'
    });
    data.append('checkin', checkinId);
    return axios({
      method: 'post',
      url: `${domain}api/v1/checkin-images/`,
      headers: {
        'Authorization': `Token ${token}`,
        'content-type': 'multipart/form-data'
      },
      data
    })
  }

  static putUserInfo(token, data) {
    return axios({
      method: 'put',
      url: `${domain}api/v1/accounts/my/`,
      headers: {
        'Authorization': `Token ${token}`
      },
      data
    })
  }

  static getQuiz() {
    return axios({
      method: 'get',
      url: `${domain}api/v1/surveys/`
    })
  }

  static createQuiz() {
    return axios({
      method: 'post',
      url: `${domain}api/v1/usersurveys/`,
      data: {
        'survey': 1,
      }
    })
  }

  static getQuizAnswer(id) {
    return axios({
      method: 'get',
      url: `${domain}api/v1/usersurveys/${id}/surveyanswers/`,
    })
  }

  static postQuizAnswer(quizId, questionId, answerId) {
    return axios({
      method: 'post',
      url: `${domain}api/v1/usersurveys/${quizId}/surveyanswers/`,
      data: {
        'question': questionId,
        'answer_choice': answerId,
      }
    })
  }

  static putQuizAnswer(quizId, questionId, answerId) {
    return axios({
      method: 'put',
      url: `${domain}api/v1/usersurveys/${quizId}/surveyanswers/${questionId}/`,
      data: {
        'answer_choice': answerId,
      }
    })
  }

  static attachUserQuiz(token, quizId) {
    return axios({
      method: 'post',
      url: `${domain}api/v1/usersurveys/${quizId}/attach-to-current-user/`,
      headers: {
        'Authorization': `Token ${token}`
      },
    })
  }

  static getTips(token, delivery = '') {
    return axios({
      method: 'get',
      url: `${domain}api/v1/tips/`,
      headers: {
        'Authorization': `Token ${token}`
      },
      params: {
        delivery_place: delivery
      }
    })
  }

  static createCheckin(token, data) {
    return axios({
      method: 'post',
      url: `${domain}api/v1/checkins/`,
      headers: {
        'Authorization': `Token ${token}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      data
    })
  }

  static getAllCheckins(token) {
    return axios({
      method: 'get',
      url: `${domain}api/v1/checkins/`,
      headers: {
        'Authorization': `Token ${token}`
      }
    })
  }

  static removeTip(token, id) {
    return axios({
      method: 'delete',
      url: `${domain}api/v1/tips/${id}/`,
      headers: {
        'Authorization': `Token ${token}`
      }
    })
  }

  static facebookLogin(data) {
    return axios({
      method: 'post',
      url: `${domain}api/v1/auth/facebook/login/`,
      data: { accessToken: data }
    })
  }

  static swapRecipe(token, mealId, meal) {
    return axios({
      method: 'put',
      url: `${domain}api/v2/usermeals/${mealId}/`,
      headers: {
        'Authorization': `Token ${token}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      data: meal
    })
  }

  static getSwappableRecipes(token, categories) {
    let reqURL = `${domain}api/v2/recipes/?restrictions=1&`
    categories.forEach(category => {
      const tmp = 'category=' + category + '&'
      reqURL += tmp
    })
    return axios({
      method: 'get',
      url: reqURL,
      headers: {
        'Authorization': `Token ${token}`
      }
    })
  }

  static getExercisesList(token) {
    return axios({
      method: 'get',
      url: `${domain}api/v1/exercise/`,
      headers: {
        'Authorization': `Token ${token}`
      }
    })
  }

  static getExerciseTracker(token, checkinId, week, day) {
    return axios({
      method: 'get',
      url: `${domain}api/v1/exercisetrackers/`,
      headers: {
        'Authorization': `Token ${token}`
      },
      params: {
        checkin: checkinId,
        week,
        day,
      }
    })
  }

  static createExerciseTracker(token, checkinId, week, day) {
    return axios({
      method: 'post',
      url: `${domain}api/v1/exercisetrackers/`,
      headers: {
        'Authorization': `Token ${token}`
      },
      data: {
        checkin: checkinId,
        week,
        day,
      }
    })
  }

  static trackExercise(token, data) {
    return axios({
      method: 'post',
      url: `${domain}api/v1/loggedexercise/`,
      headers: {
        'Authorization': `Token ${token}`
      },
      data,
    })
  }

  static untrackExercise(token, id) {
    return axios({
      method: 'delete',
      url: `${domain}api/v1/loggedexercise/${id}/`,
      headers: {
        'Authorization': `Token ${token}`
      }
    })
  }

  static updateExercise(token, id, data) {
    return axios({
      method: 'put',
      url: `${domain}api/v1/loggedexercise/${id}/`,
      headers: {
        'Authorization': `Token ${token}`
      },
      data,
    })
  }

  static getOverallStats(token) {
    return axios({
      method: 'get',
      url: `${domain}api/v1/overall-stats/`,
      headers: {
        'Authorization': `Token ${token}`
      }
    })
  }
}
