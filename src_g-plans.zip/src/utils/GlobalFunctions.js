import RNFetchBlob from 'rn-fetch-blob'

function isValidEmail(email) {
  const regEmail = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
  return regEmail.test(email)
}

function isEqualPasswords(password, confirmPassword) {
  if (((password && password != '')
    || (confirmPassword && confirmPassword != ''))
    && (password != confirmPassword)) {
        //Alert.alert('Fields "Password" and "Repeat password" must be equal!')
    return false
  }
  return true
}

function isValidUrl(url) {
  regexp =  /^(?:(?:https?|ftp):\/\/)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:\/\S*)?$/;
  if (regexp.test(url)) return true
  return false
}

function numberWithCommas(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
}

/*async function downloadData(url) {
  try {
    if (!isValidUrl(url)) throw new Error('Cannot find uploaded image!')
    const result = await RNFetchBlob
      .config({
        fileCache: true,
        appendExt: 'jpg',
      })
      .fetch('GET', url)
    const status = result.info().status
    if (status === 200) {
      return result
    }
    throw new Error('Cannot find uploaded image!')
  } catch (error) {
    //console.log('Error of download: ', error)
    throw error
  }
}*/

async function downloadData(url) {
  try {
    //console.log('RNFetchBlob: ', RNFetchBlob)
    if (!isValidUrl(url)) throw new Error('Cannot find uploaded image!')
    const filename = 'photo' + new Date().getTime()
    const cacheDir = RNFetchBlob.fs.dirs.CacheDir
    const carnaval24hTmpDir = `${cacheDir}/carnaval24h`
    let path = `${carnaval24hTmpDir}/${filename}.jpg`
    const result = await RNFetchBlob
      .config({
        fileCache: true,
        indicator: true,
        path,
      })
      .fetch('GET', url)
    const status = result.info().status
    if (status === 200) {
      return result
    }
    throw new Error('Cannot find uploaded image!')
  } catch (error) {
    //console.log('Error of download: ', error)
    throw error
  }
}

async function deleteCacheFile(path) {
  return RNFetchBlob.fs.unlink(path)
}

function roundValue(value, position = 1) {
  let numValue = parseFloat(value)
  if (isFinite(numValue)) {
    switch (position) {
      case 0:
        numValue = Math.round(numValue)
        break
      case 1:
        numValue = Math.round(numValue * 10) / 10
        break
      case 2:
        numValue = Math.round(numValue * 100) / 100
        break
      case 3:
      default:
        numValue = Math.round(numValue * 1000) / 1000
    }
  }
  return numValue
}

function caseRoundValue(value) {
  // assume that value is positive value
  let rounded = value
  if (isFinite(value)) {
    if (value < 10) rounded = roundValue(value, 2)
    else if (value < 100) rounded = roundValue(value, 1)
    else rounded = roundValue(value, 0)
  }
  return rounded
}

export {
  isValidEmail,
  isEqualPasswords,
  isValidUrl,
  numberWithCommas,
  downloadData,
  roundValue,
  caseRoundValue,
  deleteCacheFile,
}
