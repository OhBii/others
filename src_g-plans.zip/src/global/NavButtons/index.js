// @flow

import Login        from './Login';
import WithSideMenu from './WithSideMenu';

export default {
  WithSideMenu,
  Login,
}
