// @flow

//import Constants from '../../Constants';

export default {
  tabBarButtonColor     : '#4a4a4a',
  tabBarSelectedButtonColor: '#007aff',
  tabBarBackgroundColor : '#ffffff',
  tabBarTranslucent     : false,
  tabBarDisableIconTint: true,
  tabBarDisableSelectedIconTint: true,
  initialTabIndex: 3 // hack for hide tabbar
}
