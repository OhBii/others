// @flow
import Images from './Images'

export default {
  //denis
  LOGIN_SCREEN: {
    screen : 'app.LoginScreen',
    title  : 'Login',
    name : 'LoginScreen'
  },
  FORGOT_SCREEN: {
    screen : 'app.ForgotScreen',
    title  : 'Forgot',
  },
  NOTIFICATION_SCREEN: {
    screen : 'app.Notification',
    title  : 'Notification',
  },
  SETTING_SCREEN: {
    screen : 'app.SettingScreen',
    title  : 'Setting',
  },
  GROCERY_SCREEN: {
    screen : 'app.GroceryScreen',
    title  : 'Grocery',
  },
  ADDGROCERY_SCREEN: {
    screen : 'app.AddGroceryScreen',
    title  : 'AddGrocery',
  },
  WEEKGROCERY_SCREEN: {
    screen : 'app.WeekGroceryScreen',
    title  : 'WeekGrocery',
  },
  ITEMCHANGE_SCREEN: {
    screen : 'app.ItemChangeScreen',
    title  : 'ItemChange'
  },
  RECIPE_SCREEN: {
    screen : 'app_RecipeScreen',
    title  : 'Recipe'
  },
  PDFASSETS_SCREEN: {
    screen : 'app_PdfAssetsScreen',
    title  : 'PdfAssets'
  },
  BLOG_SCREEN: {
    screen : 'app_BlogScreen',
    title  : 'Blog'
  },
  SHOP_SCREEN: {
    screen: 'app_ShopScreen',
    title: 'Shop'
  },
  HELP_SCREEN: {
    screen : 'app_HelpScreen',
    title  : 'Help'
  },
  PROFILE_SCREEN: {
    screen : 'app_ProfileScreen',
    title  : 'Profile'
  },
  RECIPE_ITEM_SCREEN: {
    screen : 'app_RecipeItemScreen',
    title  : 'Recipe'
  },
  CONFIRM_AMOUNT_SCREEN: {
    screen : 'app_ConfirmAmountScreen',
    title  : 'Confirm Amount'
  },
  CUSTOM_DIALOG_SCREEN: {
    screen : 'app.CustomDialogScreen',
    title  : 'Custom Dialog'
  },
  SWAP_DIALOG_SCREEN: {
    screen : 'app.SwapDialogScreen',
    title  : 'Swap Dialog'
  },
  SWAP_MODAL_SCREEN: {
    screen : 'app.SwapModalScreen',
    title  : 'Swap'
  },
  SET_LANGUAGE_DAILOG_SCREEN: {
    screen : 'app.SetLanguageDailogScreen',
    title  : 'SetLanguage Dailog'
  },
  PREVIEW_IMAGE_SCREEN: {
    screen : 'app.PreviewImageScreen',
    title  : 'Preview image'
  },
  CAMERA_SCREEN: {
    screen : 'app_CameraScreen',
    title  : 'Profile'
  },
  QUIZ_SCREEN: {
    screen : 'app.QuizScreen',
  },
  ACCEPTED_SCREEN: {
    screen : 'app.AcceptedScreen',
  },
  PLAN_SCREEN: {
    screen : 'app.PlanScreen',
  },
  INTRO_SCREEN: {
    screen : 'app.IntroScreen',
  },
  INTRO_FLEX_SCREEN: {
    screen : 'app.IntroFlexScreen',
  },
  APPLE_ID_SCREEN: {
    screen : 'app.AppleIdScreen',
  },
  REBOOT_SCREEN: {
    screen : 'app.RebootScreen',
  },
  REBOOT_INTRO_SCREEN: {
    screen : 'app.RebootIntroScreen',
  },
  CHECKIN_SCREEN: {
    screen : 'app.CheckinScreen',
  },
  PUSHED_SCREEN: {
    screen : 'app.PushedScreen',
    title  : 'Pushed Screen',
  },
  WATERTRACKER_SCREEN: {
    screen : 'app_WaterTrackerScreen',
    title  : 'WaterTracker'
  },
  EXERCISETRACKER_SCREEN: {
    screen : 'app_ExerciseTrackerScreen',
    title  : 'ExerciseTracker'
  },
  EXERCISELIST_SCREEN: {
    screen : 'app_ExerciseListScreen',
    title  : 'ExerciseList'
  },
  EXERCISEREMOVE_SCREEN: {
    screen : 'app_ExerciseRemoveScreen',
    title  : 'ExerciseRemove'
  },
  SUCCESS_SCREEN: {
    screen : 'app_SuccessScreen',
    title  : 'Success'
  },
  OAUTH_SCREEN: {
    screen: 'app.AuthScreen',
    title: 'AuthScreen',
  },
  DETAIL_TIP_SCREEN: {
    screen: 'app.DetailTipScreen',
    title: 'Tip',
  },
  LIST_TIPS_SCREEN: {
    screen: 'app.ListTipScreen',
    title: 'List Tips',
  },
  DRAWER: {
    screen : 'app.DrawerScreen',
  },
  HOME_TAB: {
    screen       : 'app.HomeTabScreen',
    title        : 'Home',
    icon         : Images.TAB_EMPTY,
    selectedIcon : Images.TAB_EMPTY_selected,
    navigatorStyle: {
      tabBarHidden: true,
      navBarHidden: true
    }
  },
  MEALPLANNER_TAB: {
    screen       : 'app.MealPlannerTabScreen',
    title        : 'MealPlanner',
    icon         : Images.TAB_EMPTY,
    selectedIcon : Images.TAB_EMPTY_selected,
    navigatorStyle: {
      tabBarHidden: true,
      navBarHidden: true
    }
  },
  DIARYPLANNER_TAB: {
    screen        : 'app.DiaryPlannerTabScreen',
    title         : 'DiaryPlanner',
    icon         : Images.TAB_EMPTY,
    selectedIcon : Images.TAB_EMPTY_selected,
    navigatorStyle: {
      tabBarHidden: true,
      navBarHidden: true
    }
  },
  STATS_TAB: {
    screen       : 'app.StatsTabScreen',
    title        : 'Stats',
    icon         : Images.TAB_EMPTY,
    selectedIcon : Images.TAB_EMPTY_selected,
    navigatorStyle: {
      tabBarHidden: true,
      navBarHidden: true
    }
  },
  MORE_TAB: {
    screen       : 'app.MoreTabScreen',
    title        : 'More',
    icon         : Images.TAB_EMPTY,
    selectedIcon : Images.TAB_EMPTY_selected,
    navigatorStyle: {
      tabBarHidden: true,
      navBarHidden: true
    }
  },
  SEARCH_SCREEN : {
    screen : 'app.SearchScreen',
    title  : 'Search'
  },
  SET_GENDER_DAILOG_SCREEN: {
    screen      : 'app.SetGenderDailogScreen',
    title       : 'SetGender Dialog'
  },
  SET_METATYPE_DAILOG_SCREEN: {
    screen      : 'app.SetMetatypeDailogScreen',
    title       : 'SetMetatype Dialog'
  },
  MEAL_DETAIL_SCREEN: {
    screen      : 'app.MealDetailScreen',
    title       : 'Meal Detail Screen'
  },
  SELECT_SHARE_DIALOG_SCREEN: {
    screen      : 'app.SelectShareDialogScreen',
    title       : 'Select Share Dialog'
  },
  TOUR: {
    screen      : 'app.Tour',
    title       : 'Tour'
  },
  CHALLENGES_LIST: {
    screen      : 'app.ChallengesListScreen',
    title       : 'Challenges'
  },
  CHALLENGE_DETAIL: {
    screen      : 'app.ChallengeDetailScreen',
    title       : 'Challenge Detail'
  },
  LOADING_SCREEN: {
    screen : 'app.LodingScreen',
    title  : 'Loding',
    name : 'LodingScreen'
  },
}
