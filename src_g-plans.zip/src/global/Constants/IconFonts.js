
import { createIconSetFromFontello } from 'react-native-vector-icons'
import glyphMap from '../../../fonts/tab.json'

const IconFonts = createIconSetFromFontello(glyphMap)

const replaceSuffixPattern = /--(active|big|small|very-big)/g;
const icons = {
  "home": [20, "#bbb"],
  "home--active": [20, "#fff"],
  'calendar': [20, "#bbb"],
  'calendar--active': [20, "#fff"],
  'pie': [22, '#fff'],
  'pie--active': [22, '#fff'],
  'more': [16, '#bbb'],
  'more--active': [16, '#fff']
}

let iconsMap = {};
let iconsLoaded = new Promise((resolve) => {
  new Promise.all(
    Object.keys(icons).map(iconName => {
      const Provider = icons[iconName][2] || IconFonts
      return Provider.getImageSource(
        iconName.replace(replaceSuffixPattern, ''),
        icons[iconName][0],
        icons[iconName][1]
      )
    })
  ).then(sources => {
    Object.keys(icons)
      .forEach((iconName, idx) => iconsMap[iconName] = sources[idx])

    // Call resolve (and we are done)
    resolve(true);
  })
});

export {
    iconsMap,
    iconsLoaded
};
