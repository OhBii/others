/*
*   author: denis
*   date:   8/13/2018
*/

//HomTab constants
const  GREETINGS= {
  en: 'Morning',
  es: 'Mañana',
  zh_hans: '早上'
};

const  LANGUAGE= {
  en: 'English',
  es: 'Español',
  zh_hans: '中文'
};

const  HI= {
  en: 'Hi',
  es: 'Hola',
  zh_hans: '嗨'
};

const  SEARCH_ITEM= {
  en: 'Search Item',
  es: 'Buscar artículo',
  zh_hans: '搜索项目'
};

const  SEARCH= {
  en: 'Search',
  es: 'Buscar',
  zh_hans: '搜索'
};

const  SEARCHED_FODDS= {
  en: 'Searched Foods',
  es: 'Alimentos buscados',
  zh_hans: '搜索食物'
};

const  FAV_FOODS= {
  en: 'Fav Foods',
  es: 'Alimentos FAV',
  zh_hans: '最爱食品'
};

const  RECENT_FOODS= {
  en: 'Recent Foods',
  es: 'Comidas Recientes',
  zh_hans: '最近的食物'
};

const  ADD_FOODS= {
  en: 'Add Foods',
  es: 'Agregar alimentos',
  zh_hans: '添加食物'
};

const  PROFILE= {
  en: 'Profile',
  es: 'Perfil',
  zh_hans: '轮廓'
};

const  SHARE= {
  en: 'SHARE',
  es: 'COMPARTIR',
  zh_hans: '分享'
};

const  GENERAL_DATA= {
  en: 'General Data',
  es: 'Informacion General',
  zh_hans: '一般数据'
};

const  MEALS_TRACKED= {
  en: 'Meals Tracked',
  es: 'Comidas seguidas',
  zh_hans: '餐点跟踪'
};

const  WATER_TRACKED= {
  en: 'Water Tracked',
  es: 'Seguimiento de agua',
  zh_hans: '跟踪水'
};
const BADGES = {
  en: 'Badges',
  es: 'Insignias',
  zh_hans: '徽章'
}

const N8 = {
  en: 'Today’s Progress',
  es: 'El progreso de hoy',
  zh_hans: '今天的进步'
};

const N8_WEEK = {
  en: 'Weekly progress',
  es: 'Progreso semanal',
  zh_hans: '每周进展'
};

const PROTEIN = {
  en: 'Protein',
  es: 'Proteína',
  zh_hans: '蛋白'
};

const FATS = {
  en: 'Fats',
  es: 'Grasas',
  zh_hans: '脂肪'
};
const CARBS = {
  en: 'Carbs',
  es: 'Carbohidratos',
  zh_hans: '碳水化合物'
};
const WATER_TRACKER = {
  en: 'Water Tracker',
  es: 'Rastreador de agua',
  zh_hans: '水追踪器'
}

const OZ_TO_GO = {
  0: {
    en: 'to go',
    es: 'ir',
    zh_hans: '去'
  },
  1: {
    en: 'over tracked',
    es: 'sobre rastreado',
    zh_hans: '过度跟踪'
  }
}

const NEXTEVENTS = {
  en: 'Next Events',
  es: 'Próximos Eventos',
  zh_hans: '下一个活动'
}

const DATEFROM = {
  en: 'Jul 29',
  es: '',
  zh_hans: ''
}

const DATETO = {
  en: 'Aug 3',
  es: '',
  zh_hans: ''
}

const FLI_EXPERIENCE = {
  en: 'Fli Experience',
  es: 'Experiencia Fli',
  zh_hans: 'Fli 体验'
}


const FAV_RECIPES = {
  en: 'Fav Recipes',
  es: 'Recetas favoritas',
  zh_hans: '收藏食谱'
}

const RECOMMENDED_PRODUCTS = {
  en: 'Recommended Products',
  es: 'Productos Recomendados',
  zh_hans: '推荐产品'
}

const BLOG = {
  en: 'Blog',
  es: 'Blog',
  zh_hans: '博客'
}

const SHOP = {
  en: 'Shop',
  es: 'tienda',
  zh_hans: '店'
}

//Meal Planner
const MEAL_PLANNER = {
  en: 'Meal Planner',
  es: 'Planificador de comidas',
  zh_hans: '膳食计划员'
}

const MEALS = {
  en: 'Meals',
  es: 'Comidas',
  zh_hans: '膳食'
}
const LAST_WEEK = {
  en: 'Last Week',
  es: 'La semana pasada',
  zh_hans: '上个星期'
}

const THIS_WEEK = {
  en: 'This Week',
  es: 'Esta Semana',
  zh_hans: '本星期'
}

const NEXT_WEEK = {
  en: 'Next Week',
  es: 'La próxima semana',
  zh_hans: '下周'
}

const MEAL = {
  en: 'meal',
  es: 'comida',
  zh_hans: '膳食'
}
//Daily stats
const DAILY_STATS = {
  en: 'Daily Stats',
  es: 'Estadísticas Diarias',
  zh_hans: '每日统计数据'
}

const WATER_INTAKE = {
  en: 'water intake',
  es: 'consumo de agua',
  zh_hans: '水摄入量'
}

const FOOD_INTAKE = {
  en: 'food intake',
  es: 'la ingesta de alimentos',
  zh_hans: '食物的摄入量'
}

const APPLE_HEALTH_KIT = {
  en: 'Apple Health Kit',
  es: 'Apple Health Kit',
  zh_hans: 'Apple Health Kit'
}

const GOOGLE_FIT = {
  en: 'Google Fit',
  es: 'Google Fit',
  zh_hans: 'Google Fit'
}

const CALORIES_BURNED = {
  en: 'Calories Burned',
  es: 'Calorías Quemadas',
  zh_hans: '燃烧的卡路里'
}

const STEPS = {
  en: 'Steps',
  es: 'Pasos',
  zh_hans: '脚步'
}

const WALKING_RUNNING_DISTANCE = {
  en: 'Walking + Running Distance',
  es: 'Distancia para caminar + correr',
  zh_hans: '步行+运行距离'
}

const TIME_TITLE = {
  en: 'Time',
  es: 'Hora',
  zh_hans: '时间'
}

const WEIGHT_TITLE = {
  en: 'Weight',
  es: 'Peso',
  zh_hans: '重量'
}

const DAILY_AVG = {
  en: 'Daily Average:',
  es: 'Promedio diario:',
  zh_hans: '每日平均值:'
}

//MoreTab
const MORE = {
  en: 'More',
  es: 'Más',
  zh_hans: '更多'
}

const ADDITIONAL_ASSETS = {
  en: 'Additional Assets',
  es: 'Activos Adicionales',
  zh_hans: '额外资产'
}
// recipes
const RECIPES = {
  en: 'Recipes',
  es: 'Recetas',
  zh_hans: '食谱'
}

const PREFERRED_RECIPES = {
  en: 'Preferred Recipes',
  es: 'Recetas preferidas',
  zh_hans: '首选食谱'
}

const BREAKFAST_RECIPES = {
  en: 'Breakfast Recipes',
  es: 'Recetas de desayuno',
  zh_hans: '早餐食谱'
}

const LUNCH_RECIPES = {
  en: 'Lunch Recipes',
  es: 'Recetas de almuerzo',
  zh_hans: '午餐食谱'
}

const DINNER_RECIPES = {
  en: 'Dinner Recipes',
  es: 'Recetas de cena',
  zh_hans: '晚餐食谱'
}

const OTHER_RECIPES = {
  en: 'Other Recipes',
  es: 'Otras recetas',
  zh_hans: '其他食谱'
}

const SNACK_RECIPES = {
  en: 'Snack Recipes',
  es: 'Recetas de refrigerios',
  zh_hans: '小吃食谱'
}

const BREAKFAST = {
  en: 'Breakfast',
  es: 'Desayuno',
  zh_hans: '早餐'
}

const QUICK_MEAL = {
  en: 'Quick Meal',
  es: 'Comida rapida',
  zh_hans: '快餐'
}

const INGREDIENTS = {
  en: 'Ingredients',
  es: 'Ingredientes',
  zh_hans: '配料'
}

const ADD_TO_GROCERY_LIST = {
  en: 'Add to Grocery List',
  es: 'Agregar a la lista de compras',
  zh_hans: '添加到杂货店列表'
}

const ADD_ITEM = {
  en: 'Add Item',
  es: 'Añadir artículo',
  zh_hans: '新增项目'
}

const DIRECTIONS = {
  en: 'Directions',
  es: 'Direcciones',
  zh_hans: '路线'
}

const TRACK = {
  en: 'Track',
  es: 'Pista',
  zh_hans: '跟踪'
}

const UNTRACK = {
  en: 'Untrack',
  es: 'Pista',
  zh_hans: '跟踪'
}

const MISSED = {
  en: 'Missed',
  es: 'Perdido',
  zh_hans: '错过'
}

const UNMISSED = {
  en: 'Unmissed',
  es: 'Perdido',
  zh_hans: '错过'
}

const READY_TO_TRACK_THIS_MEAL = {
  en: 'Ready to track this meal?',
  es: 'Listo para rastrear esta comida?',
  zh_hans: '准备跟踪这顿饭了吗？'
}

const TRACKING_THIS_MEAL = {
  en: 'Tracking this meal will check it off your list and add it to your food diary',
  es: 'El seguimiento de esta comida lo marcará en su lista y lo agregará a su diario de alimentos',
  zh_hans: '跟踪此餐将从您的清单中检查并将其添加到您的食物日记中'
}

const DID_YOU_MISS_THIS_MEAL = {
  en: 'Did you miss this meal?',
  es: '¿Te perdiste esta comida?',
  zh_hans: '你错过了这顿饭吗？'
}

const TRACKING_THIS_MEAL_WIL_CHECK = {
  en: 'Tracking this meal will check it off your list and add it to your food diary',
  es: 'El seguimiento de esta comida lo marcará en su lista y lo agregará a su diario de alimentos',
  zh_hans: '跟踪此餐将从您的清单中检查并将其添加到您的食物日记中'
}

const MISSED_MEAL = {
  en: 'Missed meal',
  es: 'Comida perdida',
  zh_hans: '错过了一顿饭'
}

//rpAssets
const RP_ASSETS = {
  en: 'Resources/ PDF Assets',
  es: 'Recursos / Activos PDF',
  zh_hans: '资源/ PDF资产'
}

const RESOURCES = {
  en: 'Resources',
  es: 'Recursos',
  zh_hans: '资源'
}
//help
const HELP = {
  en: 'Help',
  es: 'Ayuda',
  zh_hans: '帮帮我'
}
//groceryList
const GROCERY_LIST = {
  en: 'Grocery List',
  es: 'Lista de compras',
  zh_hans: '购物清单'
}

const ADD = {
  en: 'Add',
  es: 'Añadir',
  zh_hans: '加'
}

const LIST = {
  en: 'List',
  es: 'Lista',
  zh_hans: '名单'
}

const TYPE_LIST_HERE = {
  en: 'Type List Here',
  es: 'Escriba la lista aquí',
  zh_hans: '在此输入清单'
}

const EXTRA_ITEMS = {
  en: 'Extra Items',
  es: 'Artículos extra',
  zh_hans: '额外的物品'
}


const RE_SH_LISTS = {
  en: 'Recent Shopping Lists',
  es: 'Listas de compras recientes',
  zh_hans: '最近的购物清单'
}
const ADD_LIST = {
  en: 'Add List',
  es: 'Añadir lista',
  zh_hans: '添加列表'
}

const NOTIFICATIONS = {
  en: 'Notifications',
  es: 'Notificaciones',
  zh_hans: '通知'
}
const NO_NOTIFICATIONS = {
  en: 'No Notifications',
  es: 'No Notificaciones',
  zh_hans: '没有通知'
}

//settings
const SETTINGS = {
  en: 'Settings',
  es: 'Configuraciones',
  zh_hans: '设置'
}

const USER_INFORMATION = {
  en: 'User Information',
  es: 'informacion del usuario',
  zh_hans: '用户信息'
}

const USER_FIRSTNAME = {
  en: 'First Name',
  es: 'nombre de pila',
  zh_hans: '名字'
}

const USER_LASTNAME = {
  en: 'Last Name',
  es: 'apellido',
  zh_hans: '姓'
}

const META_TYPE = {
  en: 'Meta Type',
  es: 'Meta Type',
  zh_hans: '元类型'
}

const GENDER = {
  en: 'Gender',
  es: 'Género',
  zh_hans: '性别'
}

const MALE = {
  en: 'Male',
  es: 'Masculino',
  zh_hans: '男'
}

const FEMALE = {
  en: 'Female',
  es: 'Hembra',
  zh_hans: '女'
}

const ACCOUNT = {
  en: 'Account',
  es: 'Cuenta',
  zh_hans: '帐户'
}

const USERNAME = {
  en: 'Username',
  es: 'Nombre de usuario',
  zh_hans: '用户名'
}

const EMAIL = {
  en: 'Email',
  es: 'Email',
  zh_hans: '电子邮件'
}

const PASSWORD = {
  en: 'Password',
  es: 'Contraseña',
  zh_hans: '密码'
}

const REPEATPASSWORD = {
  en: 'Repeat Password',
  es: 'Repite la contraseña',
  zh_hans: '重复输入密码'
}

const LOCATION = {
  en: 'Location',
  es: 'Ubicación',
  zh_hans: '位置'
}

const MORE_SETTINGS = {
  en: 'More Settings',
  es: 'más ajustes',
  zh_hans: '更多设置'
}

const SET_LANGUAGE = {
  en: 'Select Language',
  es: 'Seleccione el idioma',
  zh_hans: '选择语言'
}

const CONNECT = {
  en: 'Connect',
  es: 'Conectar',
  zh_hans: '连'
}

const FACEBOOK = {
  en: 'FaceBook',
  es: 'FaceBook',
  zh_hans: 'Facebook'
}

const TWITTER = {
  en: 'Twitter',
  es: 'Twitter',
  zh_hans: 'Twitter'
}

const INSTAGRAM = {
  en: 'Instagram',
  es: 'Instagram',
  zh_hans: 'Instagram'
}

const LOGOUT = {
  en: 'Logout',
  es: 'Cerrar sesión',
  zh_hans: '登出'
}

const SWAP = {
  en: 'Swap',
  es: 'Intercambiar',
  zh_hans: '交换'
}

const MSG_INVALID_EMAIL = {
  en: 'Your Email address is invalid!\n Please check it again.',
  es: 'Su dirección de correo electrónico no es válida.\n Por favor, vuelva a verificarla.',
  zh_hans: '您的电子邮件地址无效！\n 请再次检查。'
}

const MSG_NOTEQUAL_PASSWORD = {
  en: 'Fields "Password" and "Repeat password" must be equal!',
  es: 'Los campos "Contraseña" y "Repetir contraseña" deben ser iguales.',
  zh_hans: '字段“密码”和“重复密码”必须相等！'
}

const MSG_EMPTY_FIRSTNAME = {
  en: 'Your First Name is empty!\n Please check it again.',
  es: 'Su primer nombre está vacío!\n Por favor, vuelva a verificarlo.',
  zh_hans: '您的名字是空的！\n 请再次检查。'
}

const MSG_EMPTY_LASTNAME = {
  en: 'Your Last Name is empty!\n Please check it again.',
  es: 'Su apellido está vacío.\n Por favor, vuelva a verificarlo.',
  zh_hans: '您的姓氏是空的！\n 请再次检查。'
}

const MSG_EMPTY_METATYPE = {
  en: 'Your Metabolic Type is empty!\n Please check it again.',
  es: 'Su tipo metabólico está vacío!\n Por favor, vuelva a verificarlo.',
  zh_hans: '您的新陈代谢类型为空！\n 请再次检查。'
}

const MSG_EMPTY_GENDER = {
  en: 'Your Gender is empty!\n Please check it again.',
  es: 'Su género está vacío!\n Por favor, vuelva a verificarlo.',
  zh_hans: '你的性别是空的！\n 请再次检查。'
}

const MSG_GENERAL = {
  en: 'Sorry, something went wrong!',
  es: '¡Perdón, algo salió mal!',
  zh_hans: '抱歉，出了一些问题！'
}

const MSG_FBLOGIN_FAILED = {
  en: 'Facebook login failed!\nPlease make sure you connected with facebook on G-Plans site and try again.',
  es: 'El inicio de sesión de Facebook falló!\nAsegúrese de conectarse con Facebook en el sitio de G-Plans y vuelva a intentarlo.',
  zh_hans: 'Facebook登录失败！\n请确保您在G-Plans网站上与Facebook连接，然后重试。'
}

const MSG_CANNOT_TRACK_NONTODAY_MEAL = {
  en: 'You can only track today\'s meal!',
  es: '¡Solo puedes rastrear la comida de hoy!',
  zh_hans: '你只能追踪今天的饭菜！'
}

const MSG_NO_MEAL_TO_ADD_ITEM = {
  en: 'There is no meal to add food because all meals were tracked!',
  es: '¡No hay comida para agregar comida porque todas las comidas fueron rastreadas!',
  zh_hans: '没有餐点可以添加食物，因为所有餐点都被跟踪了！'
}

const MSG_FETCH_EXERCISE_LIST = {
  en: 'Error when fetching exercise list!',
  es: '',
  zh_hans: ''
}

const MSG_FETCH_EXERCISE_TRACKER = {
  en: 'Error when fetching the exercise data!',
  es: '',
  zh_hans: ''
}

const TOTAL_FATS = {
  en: 'Total Fats',
  es: 'Grasas totales',
  zh_hans: '总脂肪'
}

const SATURATED_FATS = {
  en: 'Saturated Fats',
  es: 'Grasas saturadas',
  zh_hans: '饱和脂肪'
}

const TRANS_FATS = {
  en: 'Trans Fats',
  es: 'Grasas trans',
  zh_hans: '反式脂肪'
}

const POLYUNSATURATED_FATS = {
  en: 'Polyunsaturated Fats',
  es: 'Grasas poliinsaturadas',
  zh_hans: '多不饱和脂肪'
}

const MONOUNSATURATED_FATS = {
  en: 'Monounsaturated Fats',
  es: 'Grasas monoinsaturadas',
  zh_hans: '单不饱和脂肪'
}

const TOTAL_CARBS = {
  en: 'Total Carbs',
  es: 'Carbohidratos totales',
  zh_hans: '总碳水化合物'
}

const DIETARY_FIBER = {
  en: 'Dietary Fiber',
  es: 'Fibra dietética',
  zh_hans: '膳食纤维'
}

const SUGARS = {
  en: 'Sugars',
  es: 'Azúcares',
  zh_hans: '糖'
}

const SODIUM = {
  en: 'Sodium',
  es: 'Sodio',
  zh_hans: '钠'
}

const CHOlESTEROL = {
  en: 'Cholesterol',
  es: 'Colesterol',
  zh_hans: '胆固醇'
}

const POTASSIUM = {
  en: 'Potassium',
  es: 'Potasio',
  zh_hans: '钾'
}

const CANCEL = {
  en: 'Cancel',
  es: 'Cancelar',
  zh_hans: '取消'
}

const CONFIRM_AMOUNT = {
  en: 'Confirm Amount',
  es: 'Confirmar cantidad',
  zh_hans: '确认金额'
}

const CALORIES = {
  en: 'Calories',
  es: 'Calorías',
  zh_hans: '卡路里'
}

const MACRONUTRIENTS = {
  en: 'Macronutrients',
  es: 'Macronutrientes',
  zh_hans: '宏量营养素'
}

const REBOOT_DONE = {
  en: 'I\'m done with reboot',
  es: 'Estoy hecho con reinicio',
  zh_hans: '我完成了重启'
}

const REBOOT_INTRO = {
  title: [
      {
        en: 'Time To REBOOT!',
        es: 'Time To REBOOT!',
        zh_hans: 'Time To REBOOT!'
      },
      {
        en: 'Follow Along',
        es: 'Follow Along',
        zh_hans: 'Follow Along'
      },
      {
        en: 'Let’s Do This!',
        es: 'Let’s Do This!',
        zh_hans: 'Let’s Do This!'
      }
  ],
  text: [
      {
        en: 'Whether you want more energy, to get in shape, eat a healthier diet, or simply want to feel better, the N8tive Reboot is here to guide you on your Keto Quest for better.',
        es: 'Whether you want more energy, to get in shape, eat a healthier diet, or simply want to feel better, the N8tive Reboot is here to guide you on your Keto Quest for better.',
        zh_hans: 'Whether you want more energy, to get in shape, eat a healthier diet, or simply want to feel better, the N8tive Reboot is here to guide you on your Keto Quest for better.'
      },
      {
        en: 'Your Reboot guide will have step by step instructions during this 60 hour process.',
        es: 'Your Reboot guide will have step by step instructions during this 60 hour process.',
        zh_hans: 'Your Reboot guide will have step by step instructions during this 60 hour process.'
      },
      {
        en: 'Your Reboot guide will have step by step instructions during this 60 hour process.',
        es: 'Your Reboot guide will have step by step instructions during this 60 hour process.',
        zh_hans: 'Your Reboot guide will have step by step instructions during this 60 hour process.'
      }
  ]
}

const GOT_IT = {
  en: 'Got it',
  es: 'Lo tengo',
  zh_hans: '得到它了'
}

const TIP = {
  en: 'Tip',
  es: 'Pista',
  zh_hans: '帮助'
}

const TIPS = {
  en: 'Tips',
  es: 'Consejos',
  zh_hans: '提示'
}

const TRACK_MEAL_BELOW = {
  en: 'Track Your Meals Below',
  es: 'Rastrea tu comida a continuación',
  zh_hans: '跟踪下面的食物'
}

const TODAYS_KETO_MEALS = {
  en: 'Today’s Keto Meals',
  es: 'Comidas Keto de hoy',
  zh_hans: '今天的Keto餐'
}

const TRACK_OTHER_FOOD = {
  en: 'Track Other Food',
  es: 'Seguir otros alimentos',
  zh_hans: '跟踪其他食物'
}

const TRACKED = {
  en: 'Tracked',
  es: 'Seguimiento',
  zh_hans: '履带'
}

const UNTRACKED = {
  en: 'untracked',
  es: 'sin seguimiento',
  zh_hans: '未经跟踪'
}

const ADD_TO_TRACK = {
  en: 'Add items to track',
  es: 'Agregar elementos para rastrear',
  zh_hans: '添加要跟踪的项目'
}

const CARB = {
  en: 'Carbs ',
  es: 'Carb ',
  zh_hans: '碳水化合物 '
}

const PRO = {
  en: 'Pro ',
  es: 'Pro ',
  zh_hans: '朊 '
}

const FAT = {
  en: 'Fats ',
  es: 'Cras ',
  zh_hans: '脂肪 '
}

const TOUR_LIFE = {
  title: [
    {
      en: 'Overview Page Tour',
      es: 'Vista general de la página',
      zh_hans: '概述页面浏览'
    },
    {
      en: 'Meal Cards',
      es: 'Tarjetas de comida',
      zh_hans: '餐卡'
    },
    {
      en: 'Recipe Details',
      es: 'Detalles de la receta',
      zh_hans: '食谱细节'
    },
    {
      en: 'Track Meal',
      es: 'Seguir la comida',
      zh_hans: '跟踪膳食'
    },
    {
      en: 'Swap Recipes',
      es: 'Intercambiar recetas',
      zh_hans: '交换食谱'
    },
    {
      en: 'Swap Items',
      es: 'Intercambiar elementos',
      zh_hans: '交换项目'
    },
    {
      en: 'Water Tracker',
      es: 'Rastreador de agua',
      zh_hans: '水追踪器'
    },
    {
      en: 'Tour Complete',
      es: 'Tour completo',
      zh_hans: '游览完成'
    }
  ],
  text: [
    {
      en: 'Let’s have a quick look around to show you some cool stuff we have in the app.',
      es: 'Echemos un rápido vistazo para mostrarle algunas cosas interesantes que tenemos en la aplicación.',
      zh_hans: '让我们快速浏览一下，向您展示我们在应用程序中的一些很酷的东西。'
    },
    {
      en: 'These are your recommended meals for the day. Click on them to check out your perfect portions and instructions.',
      es: 'Estas son las comidas recomendadas para el día. Haz clic en ellos para ver las partes y las instrucciones perfectas.',
      zh_hans: '这些是你推荐的一天用餐。 点击它们查看完美的部分和说明。'
    },
    {
      en: 'See recipe details and check out instructions and specific portion sizes of each meal.',
      es: 'Vea los detalles de la receta y revise las instrucciones y los tamaños de porción específicos de cada comida.',
      zh_hans: '查看食谱详细信息，查看每餐的说明和特定份量。'
    },
    {
      en: 'Track your progress by hitting the track meal button.',
      es: 'Haz un seguimiento de tu progreso presionando el botón "Seguir comida".',
      zh_hans: '点击跟踪进餐按钮跟踪您的进度。'
    },
    {
      en: 'Swap any recipe and maintain your perfect Keto portions. This will help you keep in Ketosis.',
      es: 'Cambie cualquier receta y mantenga sus porciones perfectas de Keto. Esto te ayudará a mantenerte en la cetosis.',
      zh_hans: '交换任何食谱并保持完美的Keto部分。 这将帮助您保持酮症。'
    },
    {
      en: 'Swap any item and we will calculate the perfect portion for that item.',
      es: 'Cambie cualquier artículo y calcularemos la porción perfecta para ese artículo.',
      zh_hans: '交换任何项目，我们将计算该项目的完美部分。'
    },
    {
      en: 'Track your water throughout the day with your water tracker.',
      es: 'Rastree su agua durante todo el día con su rastreador de agua.',
      zh_hans: '使用水跟踪器全天跟踪您的水。'
    },
    {
      en: 'That’s it!  We think you are ready! Have fun exploring your Pruvit Life App!',
      es: '¡Eso es! ¡Creemos que estás listo! ¡Diviértete explorando tu Pruvit Life App!',
      zh_hans: '而已！ 我们认为你准备好了！ 享受探索 Pruvit Life App 的乐趣吧！'
    }
  ]
}

const SELECTED_ITEM = {
  en: 'Selected Item',
  es: 'Item seleccionado',
  zh_hans: '所选项目'
}

const UNITS = {
  en: 'Units',
  es: 'Unidades',
  zh_hans: '单位'
}

const REMOVE_FROM_LIST = {
  en: 'Remove From List',
  es: 'Quitar de la lista',
  zh_hans: '从列表中删除'
}

const COMPLETE = {
  en: 'Complete',
  es: 'Completar',
  zh_hans: '完成'
}

const VIEW = {
  en: 'View',
  es: 'Ver',
  zh_hans: '视图'
}

const DELETE = {
  en: 'Delete',
  es: 'Borrar',
  zh_hans: '删除'
}

const ITEMS = {
  en: 'Items',
  es: 'Artículos',
  zh_hans: '项目'
}

const CREATED = {
  en: 'Created',
  es: 'Creado',
  zh_hans: '创建'
}

//
export default {
  HI,
  LANGUAGE,
  GREETINGS,
  SEARCH_ITEM,
  SEARCH,
  SEARCHED_FODDS,
  FAV_FOODS,
  RECENT_FOODS,
  ADD_FOODS,
  PROFILE,
  SHARE,
  GENERAL_DATA,
  MEALS_TRACKED,
  WATER_TRACKED,
  BADGES,
  N8,
  N8_WEEK,
  PROTEIN,
  FATS,
  CARBS,
  SATURATED_FATS,
  TRANS_FATS,
  POLYUNSATURATED_FATS,
  MONOUNSATURATED_FATS,
  TOTAL_CARBS,
  DIETARY_FIBER,
  SUGARS,
  SODIUM,
  POTASSIUM,
  WATER_TRACKER,
  OZ_TO_GO,
  NEXTEVENTS,
  DATEFROM,
  DATETO,
  FLI_EXPERIENCE,
  FAV_RECIPES,
  RECOMMENDED_PRODUCTS,
  BLOG,
  SHOP,
  MEAL_PLANNER,
  MEALS,
  LAST_WEEK,
  THIS_WEEK,
  NEXT_WEEK,
  MEAL,
  DAILY_STATS,
  WATER_INTAKE,
  FOOD_INTAKE,
  APPLE_HEALTH_KIT,
  GOOGLE_FIT,
  CALORIES_BURNED,
  STEPS,
  WALKING_RUNNING_DISTANCE,
  TIME_TITLE,
  WEIGHT_TITLE,
  DAILY_AVG,
  MORE,
  ADDITIONAL_ASSETS,
  RECIPES,
  RP_ASSETS,
  RESOURCES,
  HELP,
  GROCERY_LIST,
  ADD,
  LIST,
  TYPE_LIST_HERE,
  EXTRA_ITEMS,
  RE_SH_LISTS,
  ADD_LIST,
  NOTIFICATIONS,
  NO_NOTIFICATIONS,
  SETTINGS,
  USER_INFORMATION,
  USER_FIRSTNAME,
  USER_LASTNAME,
  META_TYPE,
  GENDER,
  MALE,
  FEMALE,
  MORE_SETTINGS,
  SET_LANGUAGE,
  ACCOUNT,
  USERNAME,
  EMAIL,
  PASSWORD,
  REPEATPASSWORD,
  LOCATION,
  CONNECT,
  FACEBOOK,
  TWITTER,
  INSTAGRAM,
  LOGOUT,
  BREAKFAST_RECIPES,
  BREAKFAST,
  QUICK_MEAL,
  INGREDIENTS,
  ADD_TO_GROCERY_LIST,
  ADD_ITEM,
  DIRECTIONS,
  TRACK,
  UNTRACK,
  MISSED,
  UNMISSED,
  READY_TO_TRACK_THIS_MEAL,
  TRACKING_THIS_MEAL,
  DID_YOU_MISS_THIS_MEAL,
  TRACKING_THIS_MEAL_WIL_CHECK,
  MISSED_MEAL,
  PREFERRED_RECIPES,
  LUNCH_RECIPES,
  DINNER_RECIPES,
  SWAP,
  MSG_INVALID_EMAIL,
  MSG_NOTEQUAL_PASSWORD,
  MSG_EMPTY_FIRSTNAME,
  MSG_EMPTY_LASTNAME,
  MSG_EMPTY_METATYPE,
  MSG_EMPTY_GENDER,
  MSG_GENERAL,
  MSG_CANNOT_TRACK_NONTODAY_MEAL,
  MSG_NO_MEAL_TO_ADD_ITEM,
  MSG_FBLOGIN_FAILED,
  MSG_FETCH_EXERCISE_LIST,
  MSG_FETCH_EXERCISE_TRACKER,
  TOTAL_FATS,
  CHOlESTEROL,
  CANCEL,
  CONFIRM_AMOUNT,
  CALORIES,
  MACRONUTRIENTS,
  REBOOT_INTRO,
  REBOOT_DONE,
  GOT_IT,
  TIP,
  TIPS,
  OTHER_RECIPES,
  SNACK_RECIPES,
  TRACK_MEAL_BELOW,
  TODAYS_KETO_MEALS,
  TRACK_OTHER_FOOD,
  TRACKED,
  UNTRACKED,
  ADD_TO_TRACK,
  CARB,
  PRO,
  FAT,
  TOUR_LIFE,
  SELECTED_ITEM,
  UNITS,
  REMOVE_FROM_LIST,
  COMPLETE,
  VIEW,
  DELETE,
  ITEMS,
  CREATED
};
