// @flow
import { Platform }   from 'react-native';
import { Navigation } from 'react-native-navigation';
import Constants      from '../Constants';
import TabBar         from '../TabBar';

const startTabBasedApp = () => {
  Navigation.startTabBasedApp({
    tabs: [
      {
        ...Constants.Screens.HOME_TAB,
      },
      {
        // ...Constants.Screens.MEALPLANNER_TAB,
        ...Constants.Screens.DIARYPLANNER_TAB,
      },
      {
        ...Constants.Screens.STATS_TAB,
      },
      {
        ...Constants.Screens.MORE_TAB
      }
    ],
    animationType: 'fade',
    ...Platform.select({
      ios: {
        tabsStyle: TabBar.Main,
        appStyle: {
          tabBarDisableIconTint: true,
          tabBarDisableSelectedIconTint: true
        }
      },
      android: {
        appStyle: TabBar.Main,
      },
    }),
    drawer: {
      left: {
        screen: Constants.Screens.DRAWER.screen,
        fixedWidth:700
      },
      disableOpenGesture: true
    },
  })
}

const startSingleScreenApp = () => {
  Navigation.startSingleScreenApp({
    screen: {
      ...Constants.Screens.LOGIN_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      },
    }
  });
}

export default {
  startTabBasedApp,
  startSingleScreenApp,
}
