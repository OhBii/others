// @flow

import Screens from './Screens';
import Images  from './Images';
import Colors  from './Colors';
import Global  from './Global';
import Multilingual from './Multilingual';
import { iconsMap, iconsLoaded } from './IconFonts'
import { scale, verticalScale, moderateScale, windowDimensions, mainPadding, flex, fonts, platform } from './Var'

export default {
  Screens,
  Images,
  Colors,
  Global,
  Multilingual,
  iconsLoaded,
  iconsMap,
  scale,
  verticalScale,
  moderateScale,
  windowDimensions,
  mainPadding,
  flex,
  fonts,
  platform
}
