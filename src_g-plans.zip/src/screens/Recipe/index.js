/*
*   author: denis
*   date:   7/17/2018
*/

import React, { Component } from 'react';
import {
  View,
  ScrollView,
  Alert,
} from 'react-native';
import { inject, observer } from 'mobx-react/native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import SnapCarousel from 'react-native-snap-carousel'
import MainTitle from '../components/Common/MainTitle'
import SnowBox from '../components/Common/SnowBox'

import Constants from '../../global/Constants';
import ShowHeader from '../components/HeaderBar/ShowHeader';
import MealCardListItem from '../components/MealCard/MealCardListItem';
import GplansLogoLoader from '../components/Common/GplansLoader'

const { width } = Constants.windowDimensions
const multilingual = Constants.Multilingual

const ContainerView = glamorous(View)({
  flexDirection: "column",
  flex: 1,
  backgroundColor: Constants.Colors.paleGreyThree
});

const ContainerContent = glamorous(View)({
  flex: 1,
})

const ContainerLoader = glamorous(View)({
  position: 'absolute',
  left: 0,
  top: 0,
  right: 0,
  bottom: 0,
  flexDirection: "column",
  flex: 1,
  backgroundColor: 'rgba(100,100,100, 0.1)',
  alignItems: 'center',
  justifyContent: 'center'
})

const { object, bool, number } = Proptypes;
@inject('Recipe', 'User', 'MealPlan') @observer
export default class Recipe extends Component {
  static propTypes = {
    Recipe: object,
    navigator: object,
    forSwap: bool,
    MealId: number,
    MealPlan: object,
    User: object
  }

  static defaultProps = {
    forSwap: false,
    MealId: -1
  }

  constructor(props) {
    super(props);

    const { Recipe, MealId, forSwap } = this.props
    const taggedRecipe = forSwap
      ? []
      : Recipe.getTaggedRecipes(MealId);

    this.state = {
      isReady: true,
      taggedRecipe: taggedRecipe
    }

    if (forSwap) {
      Recipe.getSwappableRecipes(MealId)
      .then((data) => {
        this.setState({
          taggedRecipe: data
        })
      })
      .catch(() => {
        //
      })
    }
  }

  showRecipeDetails(id) {
    //only view recipe
    this.props.navigator.showModal({
      ...Constants.Screens.RECIPE_ITEM_SCREEN,
      passProps: {
        RecipeId: id
      },
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  toSwapDialog(id) {
    if (this.props.forSwap) {
      this.props.navigator.showLightBox({
        ...Constants.Screens.SWAP_DIALOG_SCREEN,
        style: {
          backgroundColor: "#000000a0",
          tapBackgroundToDismiss: true
        },
        passProps: {
          toSwapInDialog: () => this.toSwapInDialog(id),
          id,
          showRecipeDetails: () => this.showRecipeDetails(id)
        }
      });
    }
    else {
      this.showRecipeDetails(id);
    }
  }

  toSwapInDialog(selRecipeId) {
    const { MealPlan, MealId, navigator } = this.props;
    this.setState({
      isReady: false,
    });

    MealPlan.swapRecipe(MealId, selRecipeId)
      .then((newRecipeId) => {
        navigator.showModal({
          ...Constants.Screens.RECIPE_ITEM_SCREEN,
          passProps: {
            forView: false,
            backType: false,
            MealId: MealId,
            RecipeId: newRecipeId
          },
          navigatorStyle: {
            navBarHidden: true,
            tabBarHidden: true
          }
        });
        this.setState({
          isReady: true,
        });
      })
      .catch((error) => {
        this.setState({
          isReady: true,
        });
        const { response: { data } } = error;
        Alert.alert(data);
      });
  }

  render() {
    const { User: { language: currentLanguage } } = this.props
    const { taggedRecipe } = this.state

    return(
      <ContainerView>
        <ShowHeader
          title={ multilingual.RECIPES[currentLanguage] }
          navigator={this.props.navigator}
          hasNotify
        />
        <ContainerContent>
        {!this.state.isReady ?
          <ContainerLoader><GplansLogoLoader size={60} /></ContainerLoader>
          :
          <ScrollView>
            {
              taggedRecipe.preferred && taggedRecipe.preferred.length > 0
                ? <SnowBox noPad>
                    <MainTitle hrPad={Constants.mainPadding} title={ multilingual.PREFERRED_RECIPES[currentLanguage] } />
                    <SnapCarousel
                      onSnapToItem={() => {}}
                      inactiveSlideScale={1}
                      sliderWidth={width}
                      itemWidth={width * 0.9}
                      loopClonesPerSide={1}
                      activeSlideAlignment={'center'}
                      ref={c => { this.carousel = c }}
                      data={taggedRecipe.preferred}
                      renderItem={({item, index}) =>
                        <MealCardListItem
                          data={{ recipe: item }}
                          mealNumber={index + 1}
                          onSelected={() => this.toSwapDialog(item.id)}
                          fullMode={true}
                          isSmall={true}
                        />
                      }
                      activeSlideOffset={0}
                    />
                  </SnowBox>
                : <View />
            }
            {
              taggedRecipe.breakfast && taggedRecipe.breakfast.length > 0
                ? <SnowBox noPad>
                    <MainTitle hrPad={Constants.mainPadding} title={ multilingual.BREAKFAST_RECIPES[currentLanguage] } />
                    <SnapCarousel
                      onSnapToItem={() => {}}
                      inactiveSlideScale={1}
                      sliderWidth={width}
                      itemWidth={width * 0.9}
                      loopClonesPerSide={1}
                      activeSlideAlignment={'center'}
                      ref={c => { this.carousel = c }}
                      data={taggedRecipe.breakfast}
                      renderItem={({item, index}) =>
                        <MealCardListItem
                          data={{ recipe: item }}
                          mealNumber={index + 1}
                          onSelected={() => this.toSwapDialog(item.id)}
                          fullMode={true}
                          isSmall={true}
                        />
                      }
                      activeSlideOffset={0}
                    />
                  </SnowBox>
                : <View />
            }
            {
              taggedRecipe.lunch && taggedRecipe.lunch.length > 0
                ? <SnowBox noPad>
                    <MainTitle hrPad={Constants.mainPadding} title={ multilingual.LUNCH_RECIPES[currentLanguage] } />
                    <SnapCarousel
                      onSnapToItem={() => {}}
                      inactiveSlideScale={1}
                      sliderWidth={width}
                      itemWidth={width * 0.9}
                      loopClonesPerSide={1}
                      activeSlideAlignment={'center'}
                      ref={c => { this.carousel = c }}
                      data={taggedRecipe.lunch}
                      renderItem={({item, index}) =>
                        <MealCardListItem
                          data={{ recipe: item }}
                          mealNumber={index + 1}
                          onSelected={() => this.toSwapDialog(item.id)}
                          fullMode={true}
                          isSmall={true}
                        />
                      }
                      activeSlideOffset={0}
                    />
                  </SnowBox>
                : <View />
            }
            {
              taggedRecipe.dinner && taggedRecipe.dinner.length > 0
                ? <SnowBox noPad>
                    <MainTitle hrPad={Constants.mainPadding} title={ multilingual.DINNER_RECIPES[currentLanguage] } />
                    <SnapCarousel
                      onSnapToItem={() => {}}
                      inactiveSlideScale={1}
                      sliderWidth={width}
                      itemWidth={width * 0.9}
                      loopClonesPerSide={1}
                      activeSlideAlignment={'center'}
                      ref={c => { this.carousel = c }}
                      data={taggedRecipe.dinner}
                      renderItem={({item, index}) =>
                        <MealCardListItem
                          data={{ recipe: item }}
                          mealNumber={index + 1}
                          onSelected={() => this.toSwapDialog(item.id)}
                          fullMode={true}
                          isSmall={true}
                        />
                      }
                      activeSlideOffset={0}
                    />
                  </SnowBox>
                : <View />
            }
            {
              taggedRecipe.other && taggedRecipe.other.length > 0
                ? <SnowBox noPad>
                    <MainTitle hrPad={Constants.mainPadding} title={ multilingual.OTHER_RECIPES[currentLanguage] } />
                    <SnapCarousel
                      onSnapToItem={() => {}}
                      inactiveSlideScale={1}
                      sliderWidth={width}
                      itemWidth={width * 0.9}
                      loopClonesPerSide={1}
                      activeSlideAlignment={'center'}
                      ref={c => { this.carousel = c }}
                      data={taggedRecipe.other}
                      renderItem={({item, index}) =>
                        <MealCardListItem
                          data={{ recipe: item }}
                          mealNumber={index + 1}
                          onSelected={() => this.toSwapDialog(item.id)}
                          fullMode={true}
                          isSmall={true}
                        />
                      }
                      activeSlideOffset={0}
                    />
                  </SnowBox>
                : <View />
            }
            {
                taggedRecipe.swappable && taggedRecipe.swappable.length > 0
                  ? <SnowBox noPad>
                      <MainTitle hrPad={Constants.mainPadding} title={ 'Swappable Recipes' } />
                      <SnapCarousel
                        onSnapToItem={() => {}}
                        inactiveSlideScale={1}
                        sliderWidth={width}
                        itemWidth={width * 0.9}
                        loopClonesPerSide={1}
                        activeSlideAlignment={'center'}
                        ref={c => { this.carousel = c }}
                        data={taggedRecipe.swappable}
                        renderItem={({item, index}) =>
                          <MealCardListItem
                            data={{ recipe: item }}
                            mealNumber={index + 1}
                            onSelected={() => this.toSwapDialog(item.id)}
                            fullMode={true}
                            isSmall={true}
                          />
                        }
                        activeSlideOffset={0}
                      />
                    </SnowBox>
                  : <View />
              }
          </ScrollView>
        }
        </ContainerContent>
      </ContainerView>
    );
  }
}
