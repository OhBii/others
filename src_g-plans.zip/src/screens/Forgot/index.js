/*
*   author: denis
*   date:   7/11/2018
*/

import React, { Component } from 'react';
import {
  View,
  Text,
  TextInput,
  Image,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';

import Constants from '../../global/Constants';
const { width, height } = Constants.windowDimensions

const ContainerView = glamorous(View)({
  flexDirection: "column",
  flex: 1,
  backgroundColor: Constants.Colors.whiteFive
});

const BackgroundView = glamorous(Image)({
  marginTop: -height * 0.14,
  marginBottom: -height * 0.03,
  width,
  height: height * 0.61,
  resizeMode: 'cover'
});

const FormView = glamorous(View)({
  paddingHorizontal: Constants.mainPadding
});

const MemoView = glamorous(View)({
  alignItems: "center",
  marginVertical: 12
});

const InputView = glamorous(View)({
  flexDirection: "row",
  justifyContent: "space-between",
  alignItems: 'center',
  marginVertical: 10,
  paddingVertical: 10,
  borderStyle: "solid",
  borderBottomColor: Constants.Colors.marineTwo,
  borderBottomWidth: 1
});

const Edit = {
  width: 300,
  fontSize: 16,
  height: 40
};

const Icon = glamorous(Image)({
  marginRight: 5
});

const SendButton = glamorous(TouchableOpacity)({
  alignItems: "center",
  marginTop: 27,
  padding: 15,
  marginVertical: 10,
  backgroundColor: Constants.Colors.white,
  borderRadius: 30,
  shadowColor: 'black',
  shadowOffset: { width: 0, height: 3 },
  shadowOpacity: 0.2,
  shadowRadius: 3,
  elevation: 3
})

const DarkText = glamorous(Text)({
  fontSize: 16,
  color: Constants.Colors.marineTwo,
  textAlign: 'center'
})

const AlreadyButton = glamorous(TouchableOpacity)({
  alignItems: "center",
  width: '100%',
  marginBottom: 15
})

const scrollStyle = {
  flex: 1,
  flexDirection: 'column',
  justifyContent: 'space-around'
}

const { object } = Proptypes;
export default class Forgot extends Component {
  static propTypes = {
    navigator: object
  }

  constructor(props) {
    super(props);
  }

  toFirst() {
    this.props.navigator.dismissModal();
  }

  render() {
    return(
      <ContainerView>
        <BackgroundView
          source={require("../../../img/loginBg.png")}
        />
        <KeyboardAvoidingView
          style={scrollStyle}
          behavior="padding"
          enabled={Platform.OS === 'ios' && height < 640 ? true : false}
        >
          <FormView>
              {/* memo */}
              <MemoView>
                <DarkText>Type in your email below and we will send you a link to reset your password.</DarkText>
              </MemoView>
              {/* email */}
              <InputView>
                <TextInput placeholder={'Email'}
                      style={Edit}
                      placeholderTextColor={Constants.Colors.marineTwo}
                      underlineColorAndroid={'transparent'}
                      returnKeyType={'done'}
                      autoCorrect={false}
                      autoCapitalize={'none'}
                      keyboardType={'email-address'}
                      onSubmitEditing={() => {}}/>
                <Icon source={require("../../../img/email.png")} />
              </InputView>
              {/* Button */}
              <View>
                <SendButton>
                  <DarkText>Send Email Link</DarkText>
                </SendButton>
              </View>
          </FormView>
          <AlreadyButton onPress={() => this.toFirst()}>
            <DarkText>Already Have Account?</DarkText>
          </AlreadyButton>
        </KeyboardAvoidingView>
      </ContainerView>
    );
  }
}
