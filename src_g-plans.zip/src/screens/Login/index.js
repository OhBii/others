/*
*   author: denis
*   date:   7/11/2018
*/

import React, { Component } from 'react';
import {
  View,
  Text,
  TextInput,
  Image,
  Alert,
  TouchableOpacity,
  ActivityIndicator,
  AsyncStorage,
  Animated
} from 'react-native';
import { inject, observer } from 'mobx-react/native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import moment from 'moment';
import LinearGradient from 'react-native-linear-gradient';
import { LoginManager, AccessToken } from 'react-native-fbsdk'

import GplansLogoLoader from '../components/Common/GplansLoader'
import Constants from '../../global/Constants';
import Api from '../../utils/Api';
import stores from '../../stores';

const { width, height } = Constants.windowDimensions

const glamorousAnimatedView = glamorous(Animated.View)
const ANIMETED_LOGIN_WIDHT = width - (Constants.mainPadding * 2)

const ContainerView = glamorous(View)({
  flexDirection: "column",
  flex: 1,
  justifyContent: 'center',
  backgroundColor: Constants.Colors.white
});

const ContainerLoader = glamorous(View)({
  flexDirection: "column",
  flex: 1,
  backgroundColor: '#2A9AF1',
  alignItems: 'center',
  justifyContent: 'center'
});

const ContentView = glamorous(View)({
  marginTop: -height * 0.23,
  alignItems: 'center',
  paddingHorizontal: Constants.mainPadding,
  zIndex: 3
});

const EditView = glamorous(View)({
  flexDirection: 'row',
  justifyContent: 'center',
  borderRadius: 30,
  backgroundColor: Constants.Colors.paleGreyThree,
  paddingTop: Constants.platform === 'ios' ? 15 : 10,
  paddingBottom: Constants.platform === 'ios' ? 12 : 7,
  paddingHorizontal: 18,
  marginBottom: 10
});

const FBLoginButton = glamorous(TouchableOpacity)({
  alignItems: "center",
  paddingVertical: 15,
  marginTop: 15,
  borderRadius: 30,
  borderColor: Constants.Colors.dodgerBlueFour,
  borderWidth: 1,
  borderStyle: 'solid',
  shadowColor: 'black',
  shadowOffset: { width: 0, height: 3 },
  shadowOpacity: 0.2,
  shadowRadius: 3,
  backgroundColor: Constants.Colors.dodgerBlueFour,
  elevation: 3,
  width: '100%'
});

const LoginButton = glamorous(TouchableOpacity)({
  alignItems: "center",
  paddingVertical: 15,
  marginTop: 15,
  borderRadius: 30,
  borderColor: Constants.Colors.dodgerBlueFour,
  borderWidth: 1,
  borderStyle: 'solid',
  shadowColor: "rgba(0, 0, 0, 0.15)",
  shadowOffset: {
    width: 0,
    height: 4
  },
  shadowRadius: 15,
  shadowOpacity: 1,
  elevation: 4,
  backgroundColor: "white",
  width: '100%'
});

const AnimatedLogin = glamorousAnimatedView({
  width: ANIMETED_LOGIN_WIDHT
});

AnimatedLogin.propsAreStyleOverrides = true

const LightText = glamorous(Text)({
  fontSize: 18,
  fontWeight: "bold",
  color: "#4da0ff"
});

const FBLightText = glamorous(Text)({
  fontSize: 18,
  fontWeight: 'bold',
  color: Constants.Colors.white,
});

const ForgotButton = glamorous(TouchableOpacity)({
  marginLeft: width * -0.57
})

const ForgotText = glamorous(Text)({
  fontSize: 12,
  color: Constants.Colors.blueyGrey
})

const SignupButton = glamorous(TouchableOpacity)({
  marginTop: height * 0.04
});

const SignupText = glamorous(Text)({
  fontSize: 16,
  fontWeight: '500',
  textAlign: 'center',
  color: '#4da0ff'
});

const WelcomeText = glamorous(Text)({
  fontSize: 26,
  fontWeight: 'bold',
  color: Constants.Colors.greyishBrownThree
});

const LoginText = glamorous(Text)({
  fontSize: 18,
  fontWeight: '300',
  paddingTop: height * 0.03,
  color: Constants.Colors.greyishBrownThree
});

const FormView = glamorous(View)({
  paddingTop: height * 0.03
});

const InterstitialView = glamorous(View)({
  position: 'absolute',
  bottom: 0,
  alignItems: 'center',
  width: '100%',
  zIndex: 2
});

const InterstitialImage = glamorous(Image)({
  height: height * 0.27,
  zIndex: 1
});

const Gradient = glamorous(LinearGradient)({
  width: '100%',
  marginTop: -height * 0.06,
  height: height * 0.1,
  zIndex: 0
});

const Edit = {
  width: '100%',
  fontSize: 16,
  paddingVertical: 0
};

const { object } = Proptypes;
@inject('User', 'DayIndex') @observer
export default class Login extends Component {
  static propTypes = {
    navigator: object,
    User: object,
    DayIndex: object,
  }

  constructor(props) {
    super(props);

    this.state = {
      email: '',
      password: '',
      isReady: false,
      isLoadingLogin: false,
      isLoadingFBLogin: false,
      animtedLogin: new Animated.Value(ANIMETED_LOGIN_WIDHT),
      animatedFBLogin: new Animated.Value(ANIMETED_LOGIN_WIDHT),
    }
  }

  animateWarning() {
    this.setState({
      isReady: true,
      isLoadingLogin: false,
      isLoadingFBLogin: false
    });
    this.animatedLoginButton();
    this.animatedFBLoginButton();
  }

  // toPlan(isPayed) {
  //   if (isPayed) return false;
  //   const { navigator } = this.props;

  //   navigator.push({
  //     ...Constants.Screens.PLAN_SCREEN,
  //     navigatorStyle: {
  //       navBarHidden: true,
  //       tabBarHidden: true
  //     }
  //   })

  //   this.animateWarning()
  //   return true;
  // }

  toCheckin(isCheckin) {
    if (!isCheckin) return false;
    const { navigator } = this.props;

    navigator.push({
      ...Constants.Screens.CHECKIN_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    })

    this.animateWarning()
    return true;
  }

  async toIntro() {
    const { User } = this.props;
    try {
      const key = User.isPremium
        ? User.userInfo.email + ':' + 'premium'
        : User.userInfo.email + ':' + 'maintenance-freemium'
      const value = await AsyncStorage.getItem(key);

      if (value === 'success') {
        Constants.Global.startTabBasedApp()
      }
      else {
        const screen = User.isPremium
          ? Constants.Screens.INTRO_SCREEN
          : Constants.Screens.INTRO_FLEX_SCREEN

        this.props.navigator.push({
          ...screen,
          navigatorStyle: {
            navBarHidden: true,
            tabBarHidden: true
          }
        })
      }

      this.animateWarning()
    }
    catch (err) {
      this.animateWarning()
    }
  }

  checkReboot() {
    const { User, navigator } = this.props
    //
    const today = moment();
    const checkinStart = moment().startOf('month').endOf('isoWeek').startOf('day');
    const checkinEnd = moment().startOf('month').endOf('isoWeek').add(6, 'd');

    const diffStart = today.diff(checkinStart, 's')
    const diffEnd = today.diff(checkinEnd, 's')
    //
    if (diffStart >= 0 && diffEnd <= 0) {
      if (User.rebootInfo === -1) {
        return false // skip
      }
      //reboot
      if (User.rebootInfo === 0) {
        //start
        User.setRebootInfo(1)
        navigator.push({
          ...Constants.Screens.REBOOT_INTRO_SCREEN,
          navigatorStyle: {
            navBarHidden: true,
            tabBarHidden: true
          }
        })
      }
      else {
        //already start
        navigator.push({
          ...Constants.Screens.REBOOT_SCREEN,
          navigatorStyle: {
            navBarHidden: true,
            tabBarHidden: true
          }
        })
      }

      this.animateWarning()
      return true
    }
    else {
      User.setRebootInfo(0)
      return false
    }
  }

  componentDidMount() {
    const {
      User
    } = this.props;
    // clearQuiz()
    if (User.token) {
      Api.checkAuth(User.token)
      .then((response) => {
        User.checkAuth(response.data);
        this.afterLogin()
      })
      .catch(() => {
        this.animateWarning()
      })
    }
    else {
      this.animateWarning()
    }
  }

  toForgot() {
    this.props.navigator.showModal({
      ...Constants.Screens.FORGOT_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    })
  }

  afterLogin() {
    const {
      // User,
      DayIndex,
    } = this.props
    stores.instance.fetchData()
    .then(() => {
      // const userInfo = User.userInfo
      // const isPayed = userInfo.is_payed
      const isCheckin = DayIndex.homeDayIndex > 6 ? true : false

      // if (!this.toPlan(isPayed)) {
        if (!this.toCheckin(isCheckin)) {
          this.toIntro()
        }
      // }
    })
    .catch(() => {
      this.animateWarning()
    })
  }

  login() {
    const { User } = this.props
    this.setState({ isLoadingLogin: true })
    setTimeout(() => {
      this.animatedLoginButton()
    }, 10)
    Api.login(this.state.email, this.state.password)
    .then((response) => {
      User.login(response.data)
      this.afterLogin()
    })
    .catch(() => {
      this.animateWarning()
      Alert.alert("Email or Password is not correct!");
    });
  }

  loginWithFacebook() {
    const { User: { facebookLogin, login, language }} = this.props
    LoginManager.logInWithReadPermissions(['email', 'public_profile'])
      .then(result => {
        if (!result.isCancelled) {
          this.setState({ isLoadingFBLogin: true })
          this.animatedFBLoginButton()
          AccessToken.getCurrentAccessToken()
            .then(data => {
              facebookLogin(data.accessToken.toString())
                .then(response => {
                  login(response.data)
                  this.afterLogin()
                })
                .catch(() => {
                  this.animateWarning()
                  Alert.alert(Constants.Multilingual.MSG_FBLOGIN_FAILED[language])
                })
            })
            .catch(() => {
              this.animateWarning()
              Alert.alert(Constants.Multilingual.MSG_FBLOGIN_FAILED[language])
            })
        }
      })
      .catch(() => {
        this.animateWarning()
        Alert.alert(Constants.Multilingual.MSG_FBLOGIN_FAILED[language])
      })
  }

  focusNextField() {
    this.inputPass.focus();
  }

  animatedLoginButton(){
    // this.state.isLoadingLogin
    //   ? this.state.animtedLogin.setValue(ANIMETED_LOGIN_WIDHT)
    //   : this.state.animtedLogin.setValue(50)
    Animated.timing(this.state.animtedLogin, {
      toValue: this.state.isLoadingLogin ? 50 : ANIMETED_LOGIN_WIDHT
    }).start()
  }

  animatedFBLoginButton(){
    // this.state.isLoadingFBLogin
    //   ? this.state.animatedFBLogin.setValue(ANIMETED_LOGIN_WIDHT)
    //   : this.state.animatedFBLogin.setValue(50)
    Animated.timing(this.state.animatedFBLogin, {
      toValue: this.state.isLoadingFBLogin ? 50 : ANIMETED_LOGIN_WIDHT
    }).start()
  }

  render() {
    return(
      !this.state.isReady
      ? <ContainerLoader>
          <GplansLogoLoader />
        </ContainerLoader>
      : <ContainerView>
          <ContentView>
            <WelcomeText>{'Welcome to G-Plans'}</WelcomeText>
            <LoginText>{'Log in to your account'}</LoginText>
            <AnimatedLogin width={this.state.animatedFBLogin}>
              <FBLoginButton
                onPress={!this.state.isLoadingFBLogin ? () => this.loginWithFacebook() : null}>
                {!this.state.isLoadingFBLogin
                  ? <FBLightText numberOfLines={1}>{'Login with Facebook'}</FBLightText>
                  : <ActivityIndicator size='small' color={Constants.Colors.white} />}
              </FBLoginButton>
            </AnimatedLogin>
            <FormView>
              <EditView>
                <TextInput
                  style={Edit}
                  placeholder={'Email'}
                  placeholderTextColor={Constants.Colors.blueyGrey}
                  autoCapitalize={'none'}
                  autoCorrect={false}
                  onChangeText={(text) => this.setState({email: text})}
                  underlineColorAndroid={'transparent'}
                  returnKeyType={'next'}
                  onSubmitEditing={() => this.focusNextField() }
                  blurOnSubmit={ false }
                  keyboardType={'email-address'} />
              </EditView>
              <EditView>
                <TextInput
                  style={Edit}
                  placeholder={'Password'}
                  autoCorrect={false}
                  placeholderTextColor={Constants.Colors.blueyGrey}
                  secureTextEntry={true}
                  onChangeText={(text) => this.setState({password: text})}
                  underlineColorAndroid={'transparent'}
                  autoCapitalize={'none'}
                  ref={(ref) => this.inputPass = ref}
                  returnKeyType={'go'}
                  onSubmitEditing={() => this.login()} />
              </EditView>
            </FormView>
            <ForgotButton>
              <ForgotText>Forgot password</ForgotText>
            </ForgotButton>
            <AnimatedLogin width={this.state.animtedLogin}>
              <LoginButton
                onPress={!this.state.isLoadingLogin ? () => this.login() : null}>
                {!this.state.isLoadingLogin
                  ? <LightText numberOfLines={1}>{'Login'}</LightText>
                  : <ActivityIndicator size='small' color={Constants.Colors.dodgerBlueFour} />}
              </LoginButton>
            </AnimatedLogin>
            <SignupButton>
              <SignupText>{'Don`t have an account? Sign up'}</SignupText>
            </SignupButton>
          </ContentView>
          <InterstitialView>
            <InterstitialImage
              source={Constants.Images.MOBILE_INTERSTITIAL}
              resizeMode='contain'
            />
            <Gradient
              colors={[Constants.Colors.brightCyanSix, Constants.Colors.dodgerBlueFour]}
              start={{x: 0, y: 1}}
              end={{x: 1, y: 0}} />
          </InterstitialView>
        </ContainerView>
    );
  }
}
