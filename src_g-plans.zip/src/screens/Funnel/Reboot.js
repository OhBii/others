import React, { Component } from 'react'
import {
  View,
  Image,
  Text,
  Alert,
  TouchableOpacity,
  Platform,
  Linking
} from 'react-native'
import Proptypes from 'prop-types'
import glamorous from 'glamorous-native'
import { inject, observer } from 'mobx-react/native'
import moment from 'moment'
import SafariView from "react-native-safari-view"

import CountDown from '../components/CountDown'
import RebootHeader from '../components/HeaderBar/RebootHeader'
import Constants from '../../global/Constants'

const { width, height } = Constants.windowDimensions
const multilingual = Constants.Multilingual

const ContainerView = glamorous(View)({
  flex: 1,
  backgroundColor: Constants.Colors.whiteFive
})

const Inner = glamorous(View)({
  alignItems: 'center',
  width: '100%',
  flexDirection: 'column',
  flex: 1,
  marginTop: -height * 0.53
})

const RebootImageWrap = glamorous(View)({
  marginBottom: 5
})

const RebootScale = glamorous(TouchableOpacity)({
  paddingLeft: 30,
  position: 'absolute',
  left: 40,
  top: 40,
  bottom: 40,
  right: 40,
  flexDirection: 'column',
  justifyContent: 'center'
})

const RebootImage = glamorous(Image)({
  maxWidth: width - 30,
  maxHeight: height * 0.56,
  resizeMode: 'contain'
})

const RebootButton = glamorous(TouchableOpacity)({
  width: 271,
  height: 38,
  borderRadius: 8,
  backgroundColor: Constants.Colors.white,
  borderStyle: 'solid',
  borderWidth: 1,
  borderColor: '#979797',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  marginTop: height * 0.055,
  marginBottom: height * 0.03,
})

const ButtonText = glamorous(Text)({
  fontSize: 20,
  fontWeight: 'bold',
  letterSpacing: 0,
  color: Constants.Colors.marineTwo
})

const { object } = Proptypes
@inject('User') @observer
export default class Reboot extends Component {
  static propTypes = {
    navigator: object,
    User: object
  }

  constructor(props) {
    super(props);

    const today = moment();
    const checkinEnd = moment().startOf('month').endOf('isoWeek').add(6, 'd');
    const diffSeconds = checkinEnd.diff(today, 's') < 0
      ? 30
      : checkinEnd.diff(today, 's')

    this.state = {
      seconds: diffSeconds
    }
  }

  toFinishReboot(isSkip) {
    const { User, navigator } = this.props;

    const rebootInfo = isSkip
      ? -1
      : 0
    User.setRebootInfo(rebootInfo)

    navigator.push({
      ...Constants.Screens.CHECKIN_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    })
  }

  showAlert() {
    Alert.alert(
      'Are you sure?',
      '',
      [
        {text: 'OK', onPress: () => this.toFinishReboot(true)},
        {text: 'Cancel', onPress: () => {}},
      ]
    )
  }

  toRebootProcess() {
    const url = "https://www.dropbox.com/sh/zsltvo7esd2zll1/AADf4rVHRg8NfTb5URsfRtRLa/pdfs/REBOOT-User_Guide.pdf?dl=0"
    if (Platform.OS === 'ios') {
      this.toSafariView(url)
    }
    else {
      this.toLinking(url)
    }
  }

  toSafariView(url) {
    SafariView.isAvailable()
      .then(() => {
        SafariView.show({ url: url })
      })
      .catch(() => {
        Alert.alert('Sorry, something went wrong!')
      });
  }

  toLinking(url) {
    Linking.canOpenURL(url)
      .then(() => {
        Linking.openURL(url)
      })
      .catch(() => {
        Alert.alert('Sorry, something went wrong!')
      })
  }

  render() {
    const {  User } = this.props
    const currentLanguage = User.language;
    return(
      <ContainerView>
        <RebootHeader />
        <Inner>
          <RebootImageWrap>
            <RebootImage source={Constants.Images.REBOOT_MAIN} />
            <RebootScale onPress={() => this.toRebootProcess()}>
              <Image source={Constants.Images.REBOOT_SCALE} />
            </RebootScale>
          </RebootImageWrap>
          <CountDown
            until={this.state.seconds}
            onFinish={() => this.toFinishReboot(false)}
            size={20}
            timeToShow={['D', 'H', 'M', 'S']}
          />
          <RebootButton onPress={() => this.showAlert()}>
            <ButtonText>{multilingual.REBOOT_DONE[currentLanguage]}</ButtonText>
          </RebootButton>
        </Inner>
      </ContainerView>
    );
  }
}