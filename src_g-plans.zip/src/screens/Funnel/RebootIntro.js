import React, { Component } from 'react';
import {
  View,
  Image,
  Text,
  TouchableOpacity
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import { inject, observer } from 'mobx-react/native';
import Swiper from 'react-native-swiper';

import Constants from '../../global/Constants';
const { width, height } = Constants.windowDimensions
const multilingual = Constants.Multilingual;

const ContainerView = glamorous(View)({
  flex: 1,
});

const IntroBg = glamorous(Image)({
  position: 'absolute',
  top: 0,
  right: 0,
  width,
  height,
  resizeMode: 'cover'
})

const BaseSlide = glamorous(View)({
  flex: 1
})

const Slide = glamorous(View)({
  flex: 1,
  ...Constants.flex('column', 'center', 'center')
})

const Card = glamorous(View)({
  ...Constants.flex('column', 'center', 'center'),
  width: 309,
  borderRadius: 8,
  shadowColor: "rgba(0, 0, 0, 0.2)",
  shadowOffset: {
    width: 0,
    height: 12
  },
  shadowRadius: 14,
  elevation: 14,
  shadowOpacity: 1
})

const CardHead = glamorous(Image)({
  width: 309,
  height: 197,
  borderTopLeftRadius: 8,
  borderTopRightRadius: 8,
  overflow: 'hidden',
  resizeMode: 'contain'
})

const CardHead1 = glamorous(Image)({
  width: 259,
  height: 154,
  marginBottom: 35
})

const CardHead2 = glamorous(Image)({
  width: 269,
  height: 281,
  marginBottom: -220,
  zIndex: 1
})

const CardBody = glamorous(View)(({ height, pTop }) => ({
  width: '100%',
  height: height || 261,
  borderBottomLeftRadius: 8,
  borderBottomRightRadius: 8,
  borderTopLeftRadius: height ? 8 : 0,
  borderTopRightRadius: height ? 8 : 0,
  backgroundColor: Constants.Colors.whiteFive,
  ...Constants.flex('column', 'center', 'flex-start'),
  padding: 25,
  paddingTop: pTop
}))

const CardTitle = glamorous(Text)({
  fontSize: 26,
  fontWeight: "bold",
  textAlign: "center",
  color: Constants.Colors.marineTwo,
  marginBottom: 15
})

const CardText= glamorous(Text)({
  fontSize: 16,
  textAlign: "center",
  color: Constants.Colors.greyishBrown
})

const LandNext = glamorous(View)({
  marginBottom: 0,
  width: '100%',
  ...Constants.flex('column', 'center', 'center'),
  position: 'absolute',
  bottom: 0,
  paddingBottom: 55
})

const LandView = glamorous(View)({
  marginBottom: 0,
  width: '100%',
  position: 'absolute',
  bottom: 0,
  paddingBottom: 55,
  flexDirection: 'row',
  justifyContent: 'space-around'
})

const IconNext = glamorous(Image)({
  width: 34,
  height: 21
})

const RebootButton = glamorous(TouchableOpacity)({
  borderRadius: 8,
  backgroundColor: Constants.Colors.white,
  borderStyle: 'solid',
  borderWidth: 1,
  borderColor: '#979797',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  paddingVertical: 5,
  paddingHorizontal: 10
})

const ButtonText = glamorous(Text)({
  fontSize: 16,
  letterSpacing: 0,
  color: Constants.Colors.marineTwo
})

const SlideInfo = ({ title, text, onNext, onSkip, slide1, slide2, slide3, height, pTop } = this.props) =>
  <Slide>
    <Card>
      {!!slide1 &&
        <CardHead1
          source={Constants.Images.REBOOT1}
        />
      }
      {!!slide2 &&
        <CardHead2
          source={Constants.Images.REBOOT2}
        />
      }
      {!!slide3 &&
        <CardHead
          source={Constants.Images.REBOOT3}
        />
      }
      <CardBody
        height={height}
        pTop={pTop}
      >
        <CardTitle>{ title }</CardTitle>
        <CardText>{ text }</CardText>
        {
          slide3
            ?  <LandView>
                  <RebootButton onPress={onNext}>
                    <ButtonText>Cool Got It</ButtonText>
                  </RebootButton>

                  <RebootButton onPress={onSkip}>
                    <ButtonText>No Thanks</ButtonText>
                  </RebootButton>
              </LandView>
            : <LandNext>
                <TouchableOpacity onPress={onNext}>
                  <IconNext source={Constants.Images.ICON_ACCEPTED_NEXT} />
                </TouchableOpacity>
              </LandNext>
        }
      </CardBody>
    </Card>
  </Slide>

const { object } = Proptypes
@inject('User') @observer
export default class RebootIntro extends Component {
  static propTypes = {
    navigator: object,
    User: object
  }

  constructor(props) {
    super(props);
  }

  toReboot() {
    this.props.navigator.push({
      ...Constants.Screens.REBOOT_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    })
  }

  toCheckin() {
    const { User } = this.props
    const rebootInfo = -1
    User.setRebootInfo(rebootInfo)

    this.props.navigator.push({
      ...Constants.Screens.CHECKIN_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    })
  }

  render() {
    const {  User } = this.props
    const currentLanguage = User.language;
    return(
      <ContainerView>
        <IntroBg
          source={Constants.Images.REBOOT_BG}
        />
        <Swiper
          showsPagination={false}
          showsButtons={false}
          autoplay={false}
          ref={ref => this.swiper = ref}
          loop={false}
          animated={false}
        >
            <BaseSlide>
              <SlideInfo
                title={multilingual.REBOOT_INTRO.title[0][currentLanguage]}
                text={multilingual.REBOOT_INTRO.text[0][currentLanguage]}
                onNext={() => this.swiper.scrollBy(1)}
                slide1
                height={313}
                pTop={35}
              />
            </BaseSlide>
            <BaseSlide>
              <SlideInfo
                title={multilingual.REBOOT_INTRO.title[1][currentLanguage]}
                text={multilingual.REBOOT_INTRO.text[1][currentLanguage]}
                onNext={() => this.swiper.scrollBy(1)}
                slide2
                height={511}
                pTop={240}
              />
            </BaseSlide>
            <BaseSlide>
              <SlideInfo
                title={multilingual.REBOOT_INTRO.title[2][currentLanguage]}
                text={multilingual.REBOOT_INTRO.text[2][currentLanguage]}
                onNext={() => this.toReboot()}
                onSkip={() => this.toCheckin()}
                slide3
              />
            </BaseSlide>
        </Swiper>
      </ContainerView>
    );
  }
}
