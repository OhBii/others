import React, { Component } from 'react';
import {
  View,
  Text,
  Image,
  ScrollView,
  TouchableOpacity,
  Animated,
  AsyncStorage
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import { inject, observer } from 'mobx-react'

import Constants from '../../global/Constants';

const { width } = Constants.windowDimensions
const AnimatedView = glamorous(Animated.View)

const ContainerView = glamorous(View)({
  flex: 1,
  backgroundColor: Constants.Colors.whiteFive
});

const Header = glamorous(View)({
  width,
  height: 334,
  ...Constants.flex('column', 'center', 'center')
})

const HeaderBG = glamorous(Image)({
  position: 'absolute',
  left: 0,
  top: 0,
  width,
  height: 334
})

const Logo = glamorous(Image)({
  width: 129,
  height: 129,
  marginTop: 10
})

const LogoTitle = glamorous(Text)({
  fontSize: 36,
  fontWeight: 'bold',
  textAlign: 'center',
  color: Constants.Colors.white,
  textShadowColor: 'rgba(0, 0, 0, 0.23)',
  textShadowOffset: {
    width: 0,
    height: 2
  },
  textShadowRadius: 8,
  marginVertical: 5
})

const LogoAsk = glamorous(Text)({
  fontSize: 20,
  fontWeight: '500',
  textAlign: 'center',
  color: Constants.Colors.marineTwo
})

const KetoVideo = glamorous(View)({
  ...Constants.flex('column', 'center', 'center'),
  marginBottom: -110,
  zIndex: 1
})

const VideoPic = glamorous(Image)({
  width: 350,
  height: 307
})

const VideoTitle = glamorous(Text)({
  fontSize: 24,
  fontWeight: 'bold',
  textAlign: 'center',
  color: Constants.Colors.marineTwo,
  marginTop: 20
})

const VideoSubTitle = glamorous(Text)({
  fontSize: 14,
  fontWeight: '500',
  textAlign: 'center',
  color: Constants.Colors.greyishBrown,
  marginBottom: 15
})

const Keto2 = glamorous(Image)({
  width,
  height: 878
})

const Keto3 = glamorous(Image)({
  width,
  height: 678
})

const Features = glamorous(View)({
  flexDirection: 'column',
  marginTop: -280,
  marginBottom: 50
})

const FeaturesInner = glamorous(View)({
  flexDirection: 'column',
  backgroundColor: Constants.Colors.white,
  width: 324,
  alignSelf: 'center'
})

const FeaturesHead = glamorous(View)({
  ...Constants.flex('row', 'flex-end', 'center')
})

const FeaturesRow = glamorous(View)({
  ...Constants.flex('row', 'stretch', 'center')
})

const FeaturesCell1 = glamorous(View)({
  width: 117,
  paddingVertical: 12,
  paddingLeft: 20,
  paddingRight: 12,
  borderStyle: "solid",
  borderWidth: 1,
  borderTopWidth: 0,
  borderColor: "#dbdbdb",
  backgroundColor: "#f9f9f9"
})

const FeaturesCell2 = glamorous(View)({
  width: 90,
  borderBottomWidth: 1,
  borderBottomColor: "#dbdbdb",
  ...Constants.flex('row', 'center', 'center')
})

const FeaturesCell3 = glamorous(View)({
  width: 118,
  borderBottomWidth: 1,
  borderRightWidth: 1,
  borderBottomColor: "#dbdbdb",
  borderRightColor: "#dbdbdb",
  ...Constants.flex('row', 'center', 'center')
})

const CellText = glamorous(Text)({
  fontSize: 15,
  color: Constants.Colors.greyishBrown
})

const HeadItem1 = glamorous(View)({
  width: 115,
  height: 44,
  backgroundColor: "#d8d9da",
  ...Constants.flex('row', 'center', 'center')
})

const HeadItem2 = glamorous(View)({
  width: 88,
  height: 51,
  backgroundColor: "#0a5691",
  ...Constants.flex('row', 'flex-end', 'center'),
  paddingBottom: 13,
  marginHorizontal: 3
})

const HeadItem3 = glamorous(View)({
  width: 117,
  height: 59,
  backgroundColor: "#2790e2",
  ...Constants.flex('row', 'flex-end', 'center'),
  paddingBottom: 13
})

const HeadItemText1 = glamorous(Text)({
  fontSize: 15,
  fontWeight: "bold",
  color: Constants.Colors.marineTwo
})

const HeadItemIcon2 = glamorous(Image)({
  width: 58,
  height: 19,
})

const HeadItemIcon3 = glamorous(Image)({
  width: 91,
  height: 18
})

const IconOk = glamorous(Image)(({ opacity }) => ({
  width: 31,
  height: 31,
  opacity: opacity ? 0.2 : 1
}))

const FeaturesBg = glamorous(Image)({
  position: 'absolute',
  right: 0,
  bottom: 0
})

const Footer = glamorous(View)({
  width,
  height: 668,
  paddingTop: 50,
  ...Constants.flex('column', 'center', 'flex-start')
})

const FooterBg = glamorous(Image)({
  position: 'absolute',
  left: 0,
  top: 0,
  width,
  height: 668
})

const Plans = glamorous(View)(({ mTop }) => ({
  ...Constants.flex('row', 'flex-start', 'center'),
  marginTop: mTop || 0,
  marginBottom: mTop ? 20 : 0
}))

const PlanWrap = AnimatedView(({ selected }) => ({
  width: 155,
  shadowColor: selected ? 'rgba(0, 38, 137, 0.23)' : 'rgba(0, 0, 0, 0.13)',
  shadowOffset: {
    width: 0,
    height: 2
  },
  shadowRadius: 14,
  elevation: 14,
  shadowOpacity: 1,
  borderStyle: "solid",
  borderWidth: 2,
  borderColor: selected ? "#99e9ff" : 'transparent',
  zIndex: selected ? 2 : 1,
  marginHorizontal: width * 0.02,
  borderRadius: 4
}))

PlanWrap.propsAreStyleOverrides = true

const PlanInner = glamorous(TouchableOpacity)({
  width: '100%',
  ...Constants.flex('column', 'center', 'flex-start')
})

const PlanHead = glamorous(Image)({
  width: 155,
  height: 125,
  borderTopLeftRadius: 4,
  borderTopRightRadius: 4,
  overflow: 'hidden'
})

const PlanBody = glamorous(View)({
  width: '100%',
  backgroundColor: Constants.Colors.white,
  ...Constants.flex('column', 'center', 'flex-start'),
  padding: 15,
  borderBottomLeftRadius: 4,
  borderBottomRightRadius: 4
})

const PlanTitle = glamorous(Text)({
  fontSize: 13,
  fontWeight: '500',
  letterSpacing: 7,
  textAlign: 'center',
  color: Constants.Colors.warmGreyTwo
})

const PlanPrice = glamorous(Text)({
  fontSize: 18,
  fontWeight: '500',
  textAlign: 'center',
  color: Constants.Colors.greyishBrown,
  marginVertical: 8
})

const PlanText = glamorous(Text)({
  fontSize: 12,
  fontWeight: '500',
  fontStyle: 'normal',
  letterSpacing: 0,
  textAlign: 'center',
  color: Constants.Colors.warmGreyTwo
})

const SelectPlan = ({ source, price, text, selected, onSelected, scale } = this.props) =>
  <PlanWrap selected={selected} transform={[{ scale: scale }]}>
    <PlanInner onPress={onSelected}>
      <PlanHead
        source={source}
      />
      <PlanBody>
        <PlanTitle>{'PLAN'}</PlanTitle>
        <PlanPrice>{ price }</PlanPrice>
        <PlanText>{ text }</PlanText>
      </PlanBody>
    </PlanInner>
  </PlanWrap>



const { object } = Proptypes;
@inject('User') @observer
export default class Plan extends Component {
  static propTypes = {
    User: object,
    navigator: object
  }

  constructor(props) {
    super(props);
    this.state = {
      selectedPlan: '',
      scalePlan: new Animated.Value(0)
    }
  }

  onSelectedPlan(plan) {
    if(this.state.selectedPlan !== plan) {
      this.state.scalePlan.setValue(0)
      Animated.spring(this.state.scalePlan, {
        toValue: 1,
        tension: 2,
        friction: 3,
        useNativeDriver: true
      }).start(() => {
        this.onShowAppleIDBox()
      })

      this.setState({
        selectedPlan: plan
      })
    } else {
      this.props.navigator.dismissLightBox()
      this.state.scalePlan.setValue(1)
      Animated.timing(this.state.scalePlan, {
        toValue: 1,
        duration: 400,
        useNativeDriver: true
      }).start()
      this.setState({
        selectedPlan: ''
      })
    }
  }

  onShowAppleIDBox() {
    this.props.navigator.showLightBox({
      ...Constants.Screens.APPLE_ID_SCREEN,
      style: {
        backgroundColor: "#000000a0",
        tapBackgroundToDismiss: false
      },
      passProps: {
        onCancel: () => this.onCancelAppleId(),
        onDone: () => this.onDoneAppleId()
      }
    });
  }

  async toScreen() {
    const { userInfo } = this.props.User;
    try {
      const key = userInfo.email + ':' + this.state.selectedPlan;
      const value = await AsyncStorage.getItem(key);
      if (value === 'success') {
        Constants.Global.startTabBasedApp()
      }
      else {
        const screen = this.state.selectedPlan === 'life'
          ? Constants.Screens.INTRO_SCREEN
          : Constants.Screens.INTRO_FLEX_SCREEN

        this.props.navigator.push({
          ...screen,
          navigatorStyle: {
            navBarHidden: true,
            tabBarHidden: true
          }
        })
      }
    } catch (error) {
      // console.log(error);
    }
  }

  toQuiz() {
    this.props.navigator.push({
      ...Constants.Screens.ACCEPTED_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      },
      passProps: {
        title: 'Web ID Accepted!',
        text: 'Well done! You are almost done, lets pick your plan and get you started',
        onNext: () => this.toScreen()
      }
    })
  }

  onCancelAppleId() {
    this.props.navigator.dismissLightBox()
    this.state.scalePlan.setValue(1)
    Animated.timing(this.state.scalePlan, {
      toValue: 1,
      duration: 400,
      useNativeDriver: true
    }).start()
    this.setState({
      selectedPlan: ''
    })
  }

  onDoneAppleId() {
    this.props.navigator.dismissLightBox()
    this.toQuiz()
  }

  render() {

    const features = [
      {
        title: 'N8 Keto Flex PDF Guide',
        row1: true,
        row2: true
      },
      {
        title: 'N8 Keto Lifestyle PDF Guide',
        row1: true,
        row2: true
      },
      {
        title: 'Keto Macro Tracker',
        row1: true,
        row2: true
      },
      {
        title: 'Daily Intake Tracker',
        row1: true,
        row2: true
      },
      {
        title: 'Full Maco Diary',
        row1: true,
        row2: true
      },
      {
        title: 'Keto Exchange List',
        row1: true,
        row2: true
      },
      {
        title: 'Full Recipes',
        row1: false,
        row2: true
      },
      {
        title: 'Personlized Custom Keto Meal Plan',
        row1: false,
        row2: true
      },
      {
        title: 'Personal Progress Profile Page',
        row1: false,
        row2: true
      },
      {
        title: 'Full Meal Planner',
        row1: true,
        row2: true
      }
    ]

    const animatedPlanScale = this.state.scalePlan.interpolate({
      inputRange: [0, 0.5, 1],
      outputRange: [1, 0.7, 1.1]
    })

    const animatedPlanScaleOut = this.state.scalePlan.interpolate({
      inputRange: [0, 1],
      outputRange: [1, 1]
    })

    return(
      <ContainerView>
        <ScrollView
          bounces={false}
        >
          <Header>
            <HeaderBG
              source={Constants.Images.LAND_KETO1}
            />
            <Logo
              source={Constants.Images.KETO_LOGO}
            />
            <LogoTitle>{'Pick Your Plan'}</LogoTitle>
            <LogoAsk>{'How do you Keto?'}</LogoAsk>
          </Header>
          <Plans
            mTop={-20}
          >
            <SelectPlan
              onSelected={() => this.onSelectedPlan('flex')}
              selected={this.state.selectedPlan === 'flex'}
              source={Constants.Images.KETO_FLEX}
              price={'$9.99 mo'}
              text={'Keep track of your keto life.  With KetoFlex you can stay on track with ease'}
              scale={this.state.selectedPlan === 'flex' ? animatedPlanScale : animatedPlanScaleOut}
            />
            <SelectPlan
              onSelected={() => this.onSelectedPlan('life')}
              selected={this.state.selectedPlan === 'life'}
              source={Constants.Images.KETO_LIFE}
              price={'$39.99 mo'}
              text={'Absolutely everything you need to be a Keto superstar. Recipes, tracking tools, exclusive content and amazing tips, all right at your fingertips.'}
              scale={this.state.selectedPlan === 'life' ? animatedPlanScale : animatedPlanScaleOut}
            />
          </Plans>
          <KetoVideo>
            <VideoTitle>{'Join the Movment'}</VideoTitle>
            <VideoSubTitle>{'Watch this video below'}</VideoSubTitle>
            <TouchableOpacity>
              <VideoPic
                source={Constants.Images.KETO_VIDEO}
              />
            </TouchableOpacity>
          </KetoVideo>
          <Keto2
            source={Constants.Images.LAND_KETO2}
          />
          <Features>
            <FeaturesHead>
              <HeadItem1>
                <HeadItemText1>{'FEATURES'}</HeadItemText1>
              </HeadItem1>
              <HeadItem2>
                <HeadItemIcon2
                  source={Constants.Images.LAND_ICONHEAD1}
                />
              </HeadItem2>
              <HeadItem3>
                <HeadItemIcon3
                  source={Constants.Images.LAND_ICONHEAD2}
                />
              </HeadItem3>
            </FeaturesHead>
            <FeaturesInner>
              <FeaturesBg
                source={Constants.Images.LAND_FEAT_BG}
              />
              {
                features.map((elm, ind) =>
                  <FeaturesRow
                    key={ind}
                  >
                    <FeaturesCell1>
                      <CellText>{ elm.title }</CellText>
                    </FeaturesCell1>
                    <FeaturesCell2>
                      <IconOk
                        source={Constants.Images.LAND_OK}
                        opacity={!elm.row1}
                      />
                    </FeaturesCell2>
                    <FeaturesCell3>
                      <IconOk
                        source={Constants.Images.LAND_OK}
                      />
                    </FeaturesCell3>
                  </FeaturesRow>)
              }
            </FeaturesInner>
          </Features>
          <Keto3
            source={Constants.Images.LAND_KETO3}
          />
          <Footer>
            <FooterBg
              source={Constants.Images.LAND_KETO4}
            />
            <Logo
              source={Constants.Images.KETO_LOGO}
            />
            <LogoTitle>{'Pick Your Plan'}</LogoTitle>
            <Plans
              mTop={20}
            >
              <SelectPlan
                onSelected={() => this.onSelectedPlan('flex')}
                selected={this.state.selectedPlan === 'flex'}
                source={Constants.Images.KETO_FLEX}
                price={'$9.99 mo'}
                text={'Keep track of your keto life.  With KetoFlex you can stay on track with ease'}
                scale={this.state.selectedPlan === 'flex' ? animatedPlanScale : animatedPlanScaleOut}
              />
              <SelectPlan
                onSelected={() => this.onSelectedPlan('life')}
                selected={this.state.selectedPlan === 'life'}
                source={Constants.Images.KETO_LIFE}
                price={'$39.99 mo'}
                text={'Absolutely everything you need to be a Keto superstar. Recipes, tracking tools, exclusive content and amazing tips, all right at your fingertips.'}
                scale={this.state.selectedPlan === 'life' ? animatedPlanScale : animatedPlanScaleOut}
              />
            </Plans>
          </Footer>
        </ScrollView>

      </ContainerView>
    );
  }
}
