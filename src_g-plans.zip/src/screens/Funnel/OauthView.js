import React, { Component } from 'react';
import {
  View,
  WebView
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';

import Constants from '../../global/Constants';
import ShowHeader from '../components/HeaderBar/ShowHeader';

const ContainerView = glamorous(View)({
  flexDirection: "column",
  flex: 1,
  backgroundColor: Constants.Colors.whiteFive
});

const { object, string, func } = Proptypes;
export default class OauthView extends Component {
  static propTypes = {
    navigator: object,
    url: string,
    onBack: func,
  }

  constructor(props) {
    super(props);
  }

  componentWillUnmount() {
    this.props.onBack()
  }

  render() {
    return(
      <ContainerView>
        <ShowHeader
          navigator={this.props.navigator}
          isModal
        />
        <WebView
          source = {{ uri: this.props.url }}
        />
      </ContainerView>
    );
  }
}
