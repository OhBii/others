import React, { Component } from 'react';
import {
  View,
  Image,
  Text,
  TouchableOpacity
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import LinearGradient from 'react-native-linear-gradient';

import Constants from '../../global/Constants';

const ContainerView = glamorous(LinearGradient)({
  ...Constants.flex('column', 'center', 'center'),
  flex: 1,
  position: 'relative'
});

const AcceptBg = glamorous(Image)({
  position: 'absolute',
  left: 0,
  top: 0,
  width: 246,
  height: 335
})

const Land = glamorous(View)({
  width: 309,
  height: 509,
  backgroundColor: '#F5FBFF',
  borderRadius: 8,
  shadowColor: 'rgba(0, 0, 0, 0.2)',
	shadowOffset: {
		width: 0,
		height: 12
	},
	shadowRadius: 14,
	shadowOpacity: 1,
  elevation: 12,
  padding: 20,
  ...Constants.flex('column', 'center', 'center')
})

const LandBg = glamorous(Image)({
  position: 'absolute',
  right: 0,
  top: 0,
  width: 309,
  height: 509
})

const Title = glamorous(Text)({
  fontSize: 26,
  fontWeight: 'bold',
  textAlign: 'center',
  color: Constants.Colors.marineTwo,
  marginTop: 120,
  marginBottom: 20
})

const Description = glamorous(Text)({
  fontSize: 16,
  textAlign: 'center',
  color: Constants.Colors.marineTwo,
  marginBottom: 30
})

const LandNext = glamorous(TouchableOpacity)({
  top: 50
})

const IconNext = glamorous(Image)({
  width: 34,
  height: 21
})

const { object, string, func } = Proptypes;
export default class Accepted extends Component {
  static propTypes = {
    navigator: object,
    title: string,
    text: string,
    onNext: func
  }

  constructor(props) {
    super(props);
  }

  render() {
    const { title, text, onNext } = this.props
    return(
      <ContainerView
        colors={['rgb(84,202,249)', 'rgb(42,154,241)']}
        start={{x: 0, y: 0}} end={{x: 0, y: 1}}
      >
        <AcceptBg
          source={Constants.Images.CIRCLE_ACCEPT_BG}
        />
        <Land>
          <LandBg
            source={Constants.Images.LAND_ACCEPT_BG}
          />
          <Title>{ title }</Title>
          <Description>{ text }</Description>
          <LandNext
            onPress={onNext}
          >
            <IconNext
              source={Constants.Images.ICON_ACCEPTED_NEXT}
            />
          </LandNext>
        </Land>
      </ContainerView>
    );
  }
}
