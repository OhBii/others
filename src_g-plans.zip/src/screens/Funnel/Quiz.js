import React, { Component } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Alert
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import { inject, observer } from 'mobx-react/native';
import Swiper from 'react-native-swiper';
import Picker from 'react-native-picker'

import Constants from '../../global/Constants';
import Api from '../../utils/Api';

const { width } = Constants.windowDimensions

const Container = glamorous(View)({
  flex: 1
})

const Header = glamorous(View)({
  flexDirection: 'column',
  width: '100%',
  position: 'absolute',
  left: 0,
  top: 0,
  justifyContent: 'space-between',
  paddingTop: 40,
  paddingHorizontal: Constants.mainPadding,
})

const HeaderDots = glamorous(View)({
  width: '100%',
  marginTop: 30,
  ...Constants.flex('row', 'center', 'space-between')
})

const ItemDot = glamorous(View)(({ active }) => ({
  width: width * 0.09,
  height: 5,
  borderRadius: 2.5,
  backgroundColor: active ? '#9013fe' : Constants.Colors.pinkishGrey
}))

const HeaderBack = glamorous(Image)({
  width: 11,
  height: 19
})

const QuizHeader = ({ data, index, onBack } = this.props) =>
  <Header>
    <TouchableOpacity
      onPress={onBack}
    >
      <HeaderBack
        source={Constants.Images.ICON_QUIZ_BACK}
      />
    </TouchableOpacity>
    {!!index !== data.length -1 && <HeaderDots>
      {
        data.map((el, ind) =>
          !!el.type && <ItemDot
            active={ind <= index}
            key={ind}
          />)
      }
    </HeaderDots>}
  </Header>

const Slide = glamorous(View)({
  backgroundColor: Constants.Colors.whiteFive,
  flex: 1,
  paddingHorizontal: Constants.mainPadding,
  paddingTop: 100,
  ...Constants.flex('column', 'center', 'flex-start')
})

const Question = glamorous(Text)({
  fontSize: 38,
  fontWeight: 'bold',
  textAlign: 'center',
  color: Constants.Colors.marineTwo,
  marginVertical: 25
})

const Description = glamorous(Text)({
  fontSize: 18,
  textAlign: 'center',
  color: Constants.Colors.marineTwo,
  marginBottom: 30
})

// Slides

const GenderWrap = glamorous(View)({
  width: '100%',
  ...Constants.flex('row', 'center', 'space-around')
})

const GenderItem = glamorous(View)({
  ...Constants.flex('column', 'center', 'center')
})

const Gender = glamorous(Image)({
  width: 99,
  height: 129
})

const GenderTitle = glamorous(Text)({
  fontSize: 20,
  textAlign: 'center',
  color: Constants.Colors.greyishBrown,
  marginVertical: 10
})

const GenderRadio = glamorous(View)(({ active }) => ({
  width: 27,
  height: 27,
  borderRadius: 13.5,
  backgroundColor: active ? '#9013fe' : Constants.Colors.white,
  borderStyle: 'solid',
  borderWidth: 1,
  borderColor: '#9013fe'
}))

const SelectGender = ({ slide, onSelect, selected } = this.props) =>
  <GenderWrap>
    {
      slide.select.map(el => <TouchableOpacity
        onPress={() => onSelect(el)}
        key={el.id}
      >
        <GenderItem>
          <Gender
            source={ el.title === 'Male'
              ? Constants.Images.ICON_QUIZ_MAN
              : Constants.Images.ICON_QUIZ_WOMAN
            }
          />
          <GenderTitle>{el.title}</GenderTitle>
          <GenderRadio
            active={selected === el}
          />
        </GenderItem>
      </TouchableOpacity>)
    }
  </GenderWrap>

const BigInputWrap = glamorous(View)({
  minWidth: 118,
  height: Constants.platform === 'ios' ? 110 : 120,
  borderRadius: 6,
  borderStyle: 'solid',
  borderWidth: 1,
  borderColor: '#d6d6d6',
  ...Constants.flex('column', 'center', 'center'),
  padding: Constants.platform === 'ios' ? 0  : 5,
  paddingHorizontal: 5
})

const BigInputTitle = glamorous(Text)({
  width: '100%',
  textAlign: 'center',
  fontSize: 16,
  fontWeight: 'bold',
  fontStyle: 'normal',
  color: Constants.Colors.marineTwo
})

const BigInput = {
  fontSize: 56,
  fontWeight: 'bold',
  textAlign: 'center',
  color: Constants.Colors.marineTwo,
  padding: 0,
  minWidth: 118
}

const Age = ({ children } = this.props) =>
  <BigInputWrap>
    { children }
    <BigInputTitle>{'years old'}</BigInputTitle>
  </BigInputWrap>

const TallPress = glamorous(TouchableOpacity)({
  position: 'absolute',
  left: 0,
  top: 0,
  right: 0,
  bottom: 0
})

const Tall = ({ onPress, ...props } = this.props) =>
  <BigInputWrap>
      <TextInput
        style={BigInput}
        keyboardType={'number-pad'}
        underlineColorAndroid={'transparent'}
        editable={false}
        placeholder={'5,0'}
        {...props}
      />
    <TallPress
      onPress={onPress}
    />
  </BigInputWrap>


const SelectWrap = glamorous(View)({
  flex: 1,
  paddingBottom: 30
})

const SelectInner = glamorous(View)({
  ...Constants.flex('column', 'center', 'flex-start')
})

const SelectItem = glamorous(TouchableOpacity)({
  borderRadius: 4,
  borderStyle: 'solid',
  borderWidth: 1,
  borderColor: '#979797',
  padding: 15,
  width: '100%',
  marginBottom: 15,
  ...Constants.flex('row', 'center', 'flex-start')
})

const SelectLabel = glamorous(View)({
  justifyContent: 'center',
  marginRight: 16,
  flexDirection: 'column'
})

const SelectRadio = glamorous(View)(({ active }) => ({
  width: 18,
  height: 18,
  borderRadius: 9,
  backgroundColor: active ? '#979797' : Constants.Colors.white,
  borderStyle: 'solid',
  borderWidth: 1,
  borderColor: '#979797',
  alignSelf: 'center'
}))

const SelectContent = glamorous(View)({
  width: '90%',
  ...Constants.flex('column', 'flex-start', 'flex-start')
})

const SelectBold = glamorous(Text)({
  fontSize: 18,
  fontWeight: 'bold',
  color: Constants.Colors.marineTwo
})

const SelectText = glamorous(Text)({
  fontSize: 18,
  color: Constants.Colors.marineTwo
})

const Select = ({ slide, onSelect, selected } = this.props) =>
  <SelectWrap>
    <ScrollView>
      <SelectInner>
        {
          slide.select.map((el, ind) =>
          <SelectItem
            key={ind}
            onPress={() => onSelect(el)}
          >
            <SelectLabel>
              <SelectRadio
                active={selected === el}
              />
            </SelectLabel>
            <SelectContent>
              {!!el.title && <SelectBold>{ el.title }</SelectBold>}
              <SelectText>{ el.text }</SelectText>
            </SelectContent>
          </SelectItem>)
        }
      </SelectInner>
    </ScrollView>
  </SelectWrap>

const RoundInput = {
  width: '100%',
  height: 48,
  borderRadius: 24,
  backgroundColor: Constants.Colors.white,
  borderStyle: 'solid',
  borderWidth: 1,
  borderColor: '#979797',
  fontSize: 17,
  color: Constants.Colors.warmGreyTwo,
  padding: 15
}

const { object, shape, func } = Proptypes;
@inject('Funnel', 'User') @observer
export default class Quiz extends Component {
  static propTypes = {
    Funnel: shape({ quiz: object, quizResult: object, setQuizResult: func }),
    navigator: object,
    User: object,
  }

  constructor(props) {
    super(props);
    this.state = {
      swiperIndex: 0,
      tallValue: null,
      validationAge: false
    }

    let feetMum = []
    let valNum = []
    for (let i = 0; i <= 60; i++) {
      feetMum.push(i)
    }
    for (let i = 1; i <= 10; i++) {
      valNum.push({[i] : feetMum})
    }

    this.dataTall = [
      {
        'Feet/inches' : valNum
      },
      {
        'Feet/cm' : valNum
      },
    ]
  }

  toAccepted() {
    this.props.navigator.push({
      ...Constants.Screens.PLAN_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    })
  }

  openOauthUrl() {
    const {
      Funnel: { setSignUpUUID }
    } = this.props
    const uuidv1 = require('uuid/v1')
    const uuid = uuidv1()
    setSignUpUUID(uuid)
    Api.getOauthUrl('kalin', uuid)
    .then(({
      // data: { authorization_url: url },
      data: { registration_url: url }
    }) => {
      // console.log(url)
      this.props.navigator.showModal({
        ...Constants.Screens.OAUTH_SCREEN,
        navigatorStyle: {
          navBarHidden: true,
          tabBarHidden: true
        },
        passProps: {
         url,
         onBack: () => this.getOauthToken()
        }
      });
    })
    // .catch(e => {
    //   console.log(e.response)
    // })
  }

  getOauthToken() {
    const {
      User: { getOauthToken },
    } = this.props
    getOauthToken()
    .then(() => {
      this.toAccepted()
    })
    .catch(() => {
      // handle error here
      // this.toAccepted()
      Alert.alert('Error occured!')
    })
  }

  goBack() {
    if(this.state.swiperIndex === 0) {
      this.props.navigator.popToRoot()
    }
    if(!!this.state.swiperIndex > 0 && this.state.swiperIndex <= this.props.Funnel.quiz.length - 1) {
      this.swiper.scrollBy(-1)
    }
  }

  onSwiperSliderChange(index) {
    this.setState({ swiperIndex : index })
    setTimeout(() => {
      index === 1 ? this.inputAge.focus() : this.inputAge.blur()
      index === 2 ? this.showPicker(this.props.Funnel.quiz[2]) : Picker.hide()
      index === this.props.Funnel.quiz.length - 1 ? this.inputRefer.focus() : this.inputRefer.blur()
    }, 400)
  }

  showPicker(slide) {
    Picker.init({
      pickerData: this.dataTall,
      pickerFontSize: 23,
      pickerFontColor: [51, 51, 51, 1],
      pickerTitleText: 'Please select',
      pickerConfirmBtnText: 'Done',
      pickerCancelBtnText: 'Cancel',
      onPickerConfirm: pickedValue => {
        this.setState({ tallValue : `${pickedValue[1]}.${pickedValue[2]}` })
        if(+this.state.tallValue > 2) {
          this.props.Funnel.setQuizResult({ id: slide.id, value: this.state.tallValue }).then(() => this.swiper.scrollBy(1))
        } else {
          Alert.alert('Please enter correct value\nTall should be > 2')
        }
      },
      onPickerSelect: pickedValue => {
        this.setState({ tallValue : `${pickedValue[1]}.${pickedValue[2]}` })
      },
      onPickerCancel: () => {
        this.setState({
          tallValue: this.state.tallValue
        })
      },
    })
    if(!Picker.isPickerShow()) {
      Picker.show()
    } else {
      Picker.hide()
    }
  }

  getValue(slide) {
    const curResult = this.props.Funnel.quizResult
    let result
    curResult[curResult.indexOf(curResult.find(res => res.id === slide.id))] !== undefined
    ? result = curResult[curResult.indexOf(curResult.find(res => res.id === slide.id))].value
    : result = ''
    return result
  }

  render() {
    const { Funnel: { quiz, setQuizResult } } = this.props
    return(
      <Container>
        <Swiper
          showsPagination={false}
          onIndexChanged={(index) => this.onSwiperSliderChange(index)}
          showsButtons={false}
          autoplay={false}
          scrollEnabled={false}
          ref={ref => this.swiper = ref}
        >
          {quiz.map((slide, i) =>
            <Slide
              key={i}
            >
              {!!slide.question && <Question>{ slide.question }</Question>}
              {!!slide.description && <Description>{ slide.description }</Description>}

              {
                slide.type === 'gender' ?
                  <SelectGender
                    slide={slide}
                    onSelect={(value) => {
                        setQuizResult({ id: slide.id, value: value }).then(() => this.swiper.scrollBy(1))
                      }
                    }
                    selected={this.getValue(slide)}
                  />
                : slide.type === 'age' ?
                  <Age>
                    <TextInput
                      ref={(ref) => this.inputAge = ref}
                      keyboardType={'number-pad'}
                      underlineColorAndroid={'transparent'}
                      placeholder={'0'}
                      returnKeyType={'done'}
                      style={BigInput}
                      onChangeText={(value) => {
                          if(+value > 13) {
                            setQuizResult({ id: slide.id, value: value })
                            this.setState({validationAge: true})
                          } else {
                            this.setState({validationAge: false})
                          }
                        }
                      }
                      onSubmitEditing={() => {
                          if(this.state.validationAge) {
                            this.swiper.scrollBy(1)
                          } else {
                            Alert.alert('Please enter correct value!\nAge should be > 13')
                          }
                        }
                      }
                      value={this.getValue(slide)}
                    />
                  </Age>
                : slide.type === 'picker' ?
                  <Tall
                    onPress={() => this.showPicker(slide)}
                    value={this.state.tallValue}
                  />
                : slide.type === 'select' ?
                  <Select
                    slide={slide}
                    onSelect={(value) => {
                        setQuizResult({ id: slide.id, value: value }).then(() => this.swiper.scrollBy(1))
                      }
                    }
                    selected={this.getValue(slide)}
                  />
                : slide.slide === 'refer' ?
                <GenderWrap>
                  <TextInput
                    ref={(ref) => this.inputRefer = ref}
                    style={RoundInput}
                    placeholder={'Web ID'}
                    keyboardType={'number-pad'}
                    underlineColorAndroid={'transparent'}
                    returnKeyType={'done'}
                    // onSubmitEditing={() => this.toAccepted()}
                    onSubmitEditing={() => this.openOauthUrl()}
                  />
                </GenderWrap>
                : null
              }
            </Slide>)
          }
        </Swiper>
        <QuizHeader
          index={this.state.swiperIndex}
          data={quiz}
          onBack={() => this.goBack()}
        />
      </Container>
    )
  }
}
