import React, { Component } from 'react';
import {
  View,
  Image,
  Text,
  TouchableOpacity,
  ScrollView,
  Animated,
  AsyncStorage,
  Alert,
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import { inject, observer } from 'mobx-react/native';
import Swiper from 'react-native-swiper';
import ImagePicker from 'react-native-image-picker';

import Constants from '../../global/Constants';

const AnimatedView = glamorous(Animated.View)

const { width, height } = Constants.windowDimensions
const slidePadding = width * 0.1

const ContainerView = glamorous(View)({
  flex: 1,
});

const IntroBg = glamorous(Image)({
  position: 'absolute',
  top: 0,
  right: 0,
  width,
  height: height + 120,
  resizeMode: 'cover'
})

const BaseSlide = glamorous(View)({
  flex: 1
})

const Slide = glamorous(View)({
  flex: 1,
  ...Constants.flex('column', 'center', 'center')
})

const Card = glamorous(View)({
  ...Constants.flex('column', 'center', 'center'),
  width: 309,
  borderRadius: 8,
  shadowColor: "rgba(0, 0, 0, 0.2)",
  shadowOffset: {
    width: 0,
    height: 12
  },
  shadowRadius: 14,
  elevation: 14,
  shadowOpacity: 1
})

const CardHead = glamorous(Image)({
  width: 309,
  height: 233,
  borderTopLeftRadius: 8,
  borderTopRightRadius: 8,
  overflow: 'hidden',
  resizeMode: 'cover'
})

const CardBody = glamorous(View)({
  width: '100%',
  height: 261,
  borderBottomLeftRadius: 8,
  borderBottomRightRadius: 8,
  backgroundColor: Constants.Colors.whiteFive,
  ...Constants.flex('column', 'center', 'flex-start'),
  padding: 25
})

const CardTitle = glamorous(Text)({
  fontSize: 26,
  fontWeight: "bold",
  textAlign: "center",
  color: Constants.Colors.marineTwo,
  marginBottom: 15
})

const CardText= glamorous(Text)({
  fontSize: 16,
  textAlign: "center",
  color: Constants.Colors.greyishBrown
})

const LandNext = glamorous(View)({
  marginBottom: 0,
  width: '100%',
  ...Constants.flex('column', 'center', 'center'),
  position: 'absolute',
  bottom: 0,
  paddingBottom: 55
})

const IconNext = glamorous(Image)({
  width: 34,
  height: 21
})

const SlideInfo = ({ title, text, source, onNext } = this.props) =>
  <Slide>
    <Card>
      <CardHead
        source={source}
      />
      <CardBody>
        <CardTitle>{ title }</CardTitle>
        <CardText>{ text }</CardText>
        <LandNext>
          <TouchableOpacity onPress={onNext}>
            <IconNext source={Constants.Images.ICON_ACCEPTED_NEXT} />
          </TouchableOpacity>
        </LandNext>
      </CardBody>
    </Card>
  </Slide>


const Slide2 = glamorous(View)({
  flex: 1,
  ...Constants.flex('column', 'center', 'flex-start'),
  paddingTop: 100,
  zIndex: 2
})

const ContainerTitle2 = glamorous(View)({
  width: '100%',
  alignItems: 'flex-start',
})

const TitleSlide2 = glamorous(Text)({
  fontSize: 34,
  fontWeight: 'bold',
  letterSpacing: 0,
  color: Constants.Colors.white,
  marginBottom: 15,
  paddingHorizontal: slidePadding,
})

const DataSelect = glamorous(View)({
  ...Constants.flex('column', 'stretch', 'flex-start'),
  width: '100%',
  paddingHorizontal: slidePadding
})

const SelectItem = glamorous(TouchableOpacity)(({ active }) => ({
  borderRadius: 8,
  borderStyle: "solid",
  borderWidth: 2,
  borderColor: Constants.Colors.white,
  padding: 15,
  width: '100%',
  alignItems: 'center',
  minHeight: 68,
  backgroundColor: active ? 'rgba(255,255,255, 0.3)' : 'transparent',
  marginBottom: 12
}))

const SelectItemText = glamorous(Text)({
  fontSize: 24,
  color: Constants.Colors.white
})

const SlideFooter = AnimatedView({
  height: height * 0.13,
  width: '100%',
  ...Constants.flex('row', 'center', 'flex-end'),
  backgroundColor: Constants.Colors.whiteFive,
  borderStyle: "solid",
  borderTopWidth: 1,
  borderTopColor: "#979797",
  paddingHorizontal: slidePadding,
  zIndex: 2
})

const NextButton = glamorous(TouchableOpacity)({
  ...Constants.flex('row', 'center', 'center'),
})

const NextText = glamorous(Text)({
  fontSize: 24,
  color: Constants.Colors.marineTwo,
  marginRight: 10
})

const SlideSelectScroll = {
  width: '100%'
}

const SlideSelect = ({ title, data, selected, onSelect, onNext } = this.props) =>
  <Slide2>
    <ContainerTitle2>
      <TitleSlide2>{ title }</TitleSlide2>
    </ContainerTitle2>
    <ScrollView
      style={SlideSelectScroll}
    >
      <DataSelect>
        {data.map((elm, ind) => {
          return (
          <SelectItem
            key={ind}
            onPress={() => onSelect(ind)}
            active={selected(ind)}
          >
            <SelectItemText>{ elm.title }</SelectItemText>
          </SelectItem>)})
        }
      </DataSelect>
    </ScrollView>
    <SlideFooter>
      <NextButton
        onPress={onNext}
      >
        <NextText>{'Next'}</NextText>
        <IconNext source={Constants.Images.ICON_ACCEPTED_NEXT} />
      </NextButton>
    </SlideFooter>
  </Slide2>

const Dots = glamorous(View)({
  ...Constants.flex('row', 'center', 'center'),
  position: 'absolute',
  bottom: 40,
  left: 0,
  right: 0,
  height: 16
})

const DotWrap = glamorous(View)({
  width: 16,
  marginHorizontal: 4,
})

const Dot = glamorous(View)(({ active, visible }) => ({
  width: active ? 16 : 11,
  height: active ? 16 : 11,
  borderRadius: active ? 8 : 5.5,
  backgroundColor: active ? Constants.Colors.white : Constants.Colors.marineTwo,
  opacity: visible ? 1 : 0
}))

const CustomDots = ({ data, index } = this.props) =>
  <Dots>
  {
    data.map((elm, ind) =>
      !!elm.type === 'info' &&
      <DotWrap key={ind}>
        <Dot
          active={ind === index}
          visible={true}
        /></DotWrap>)
  }
  </Dots>

const BackButton = glamorous(TouchableOpacity)({
  position: 'absolute',
  top: 35,
  left: width * 0.06,
})

const HeaderBack = glamorous(Image)({
  width: 11,
  height: 19
})

const { object, shape, func } = Proptypes;
@inject('User', 'Funnel', 'Profile') @observer
export default class Intro extends Component {
  static propTypes = {
    User: object,
    Funnel: shape({ intro: object, setIntroResult: func }),
    navigator: object,
    Profile: object,
  }

  constructor(props) {
    super(props);
    this.state = {
      swiperIndex: 0,
      rerenderKey: 0
    }
  }

  toScreen(screen) {
    this.props.navigator.push({
      ...screen,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    })
  }

  onSwiperSliderChange(index) {
    this.setState({ swiperIndex : index })
  }

  getValue(slide, ind) {
    const curResult = this.props.Funnel.introResult
    let result
    for(let i = 0; i <= curResult.length - 1; i++) {
      if(curResult[i].id === slide.id) {
        result = curResult[i].items[ind].checked
      }
    }
    return result
  }

  async completeIntro() {
    const { User: { userInfo, setFavList } } = this.props;
    try {
      const key = userInfo.email + ':premium';
      await AsyncStorage.setItem(key, 'success');

      setFavList();
    } catch(error) {
      // console.log(error);
    }
    Constants.Global.startTabBasedApp()
  }

  toUploadImage() {
    const options = {
      title: 'Select Avatar',
      storageOptions: {
        skipBackup: true,
        path: 'images'
      },
      quality: 0.3
    }

    ImagePicker.showImagePicker(options, response => {
      if (response.didCancel) {
        //
      } else if (response.error) {
        //
        Alert.alert(response.error)
      } else {
        //
        this.props.navigator.showModal({
          ...Constants.Screens.PREVIEW_IMAGE_SCREEN,
          navigatorStyle: {
            navBarHidden: true,
            tabBarHidden: true
          },
          passProps: {
            imageUri: response.uri,
            uploadImage: () => this.uploadImage(response.uri)
          }
        })
      }
    })
  }

  uploadImage(imageUri) {
    this.props.Profile.uploadCheckinImage(imageUri)
    this.setState({ imageUri: imageUri })
    this.toAccepted()
  }

  toAccepted() {
    this.props.navigator.push({
      ...Constants.Screens.ACCEPTED_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      },
      passProps: {
        title: 'You Are All Set!',
        text: 'Great job! Its time to dive into your personalized keto plan!',
        onNext: () => this.completeIntro()
      }
    })
  }

  needToUploadPhoto() {
    const {
      User: { userInfo },
      Profile: { checkinImages },
    } = this.props
    if (!checkinImages.length) return true
    const lastCheckin = userInfo.last_checkin
    if (lastCheckin && lastCheckin.id)
      return checkinImages.findIndex(el => el.checkin === lastCheckin.id) === -1
    const firstCheckin = userInfo.first_checkin
    if (firstCheckin && firstCheckin.id)
      return checkinImages.findIndex(el => el.checkin === firstCheckin.id) === -1
    return true
  }

  onNext() {
    const { Funnel: { intro } } = this.props
    const swiperIndex = this.state.swiperIndex
    if (swiperIndex === intro.length - 2 && !this.needToUploadPhoto()) {  // screen before take photo screen
      this.toAccepted()
      return
    }
    swiperIndex < intro.length -1
      ? this.swiper.scrollBy(1)
      : this.toAccepted()
  }

  render() {
    const { Funnel: { intro, setIntroResult } } = this.props
    return(
      <ContainerView>
        <IntroBg
          source={Constants.Images.INTRO_BG}
        />
        <CustomDots
          index={this.state.swiperIndex}
          data={intro}
        />
        <Swiper
          showsPagination={false}
          onIndexChanged={(index) => this.onSwiperSliderChange(index)}
          showsButtons={false}
          autoplay={false}
          ref={ref => this.swiper = ref}
          loop={false}
          animated={false}
        >
        {
          intro.map((slide) =>
            <BaseSlide key={ slide.id }>
              {slide.type === 'info' ?
                <SlideInfo
                  title={ slide.title }
                  text={ slide.description }
                  image={ slide.image }
                  onNext={() => this.swiper.scrollBy(1)}
                  source={ slide.image === 0
                    ? Constants.Images.INTRO_SLIDE_0
                    : slide.image === 1
                    ? Constants.Images.INTRO_SLIDE_1
                    : slide.image === 2
                    ? Constants.Images.INTRO_SLIDE_2
                    : slide.image === 3
                    ? Constants.Images.INTRO_SLIDE_3
                    : slide.image === 4
                    ? Constants.Images.INTRO_SLIDE_4
                    : null
                  }
                />
              : slide.type === 'select' ?
                <SlideSelect
                  title={slide.title}
                  data={slide.items}
                  selected={ind => this.getValue(slide, ind)}
                  onSelect={(ind) => {
                    if (slide.id !== 9) {
                      setIntroResult(slide, ind)
                    } else {
                      // take photo
                      slide.items[ind].camera
                        ? this.toUploadImage()
                        : this.toAccepted()
                    }
                    this.setState({rerenderKey: Math.random()})
                  }}
                  onNext={() => this.onNext()}
                /> : null}
            </BaseSlide>)
        }
        </Swiper>
        {!!this.state.swiperIndex > 0 && <BackButton
          onPress={() => this.swiper.scrollBy(-1)}
        >
          <HeaderBack
            source={Constants.Images.ICON_QUIZ_BACK}
          />
        </BackButton>}
      </ContainerView>
    );
  }
}
