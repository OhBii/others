import React, { Component } from 'react';
import {
  View,
  Image,
  Text,
  TouchableOpacity,
  AsyncStorage
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import { inject, observer } from 'mobx-react/native';
import Swiper from 'react-native-swiper';

import Constants from '../../global/Constants';

const { width, height } = Constants.windowDimensions

const ContainerView = glamorous(View)({
  flex: 1,
});

const IntroBg = glamorous(Image)({
  position: 'absolute',
  top: 0,
  right: 0,
  width,
  height: height + 120,
  resizeMode: 'cover'
})

const BaseSlide = glamorous(View)({
  flex: 1
})

const Slide = glamorous(View)({
  flex: 1,
  ...Constants.flex('column', 'center', 'center')
})

const Card = glamorous(View)({
  ...Constants.flex('column', 'center', 'center'),
  width: 309,
  borderRadius: 8,
  shadowColor: "rgba(0, 0, 0, 0.2)",
  shadowOffset: {
    width: 0,
    height: 12
  },
  shadowRadius: 14,
  elevation: 14,
  shadowOpacity: 1
})

const CardHead = glamorous(Image)({
  width: 309,
  height: 233,
  borderTopLeftRadius: 8,
  borderTopRightRadius: 8,
  overflow: 'hidden',
  resizeMode: 'cover'
})

const CardBody = glamorous(View)({
  width: '100%',
  height: 261,
  borderBottomLeftRadius: 8,
  borderBottomRightRadius: 8,
  backgroundColor: Constants.Colors.whiteFive,
  ...Constants.flex('column', 'center', 'flex-start'),
  padding: 25
})

const CardTitle = glamorous(Text)({
  fontSize: 26,
  fontWeight: "bold",
  textAlign: "center",
  color: Constants.Colors.marineTwo,
  marginBottom: 15
})

const CardText= glamorous(Text)({
  fontSize: 16,
  textAlign: "center",
  color: Constants.Colors.greyishBrown
})

const LandNext = glamorous(View)({
  marginBottom: 0,
  width: '100%',
  ...Constants.flex('column', 'center', 'center'),
  position: 'absolute',
  bottom: 0,
  paddingBottom: 55
})

const IconNext = glamorous(Image)({
  width: 34,
  height: 21
})

const SlideInfo = ({ title, text, source, onNext } = this.props) =>
  <Slide>
    <Card>
      <CardHead
        source={source}
      />
      <CardBody>
        <CardTitle>{ title }</CardTitle>
        <CardText>{ text }</CardText>
        <LandNext>
          <TouchableOpacity onPress={onNext}>
            <IconNext source={Constants.Images.ICON_ACCEPTED_NEXT} />
          </TouchableOpacity>
        </LandNext>
      </CardBody>
    </Card>
  </Slide>

const { object, shape, func } = Proptypes;
@inject('User', 'Funnel') @observer
export default class Intro extends Component {
  static propTypes = {
    User: object,
    Funnel: shape({ intro: object, setIntroResult: func }),
    navigator: object
  }

  constructor(props) {
    super(props);
    this.state = {
      swiperIndex: 0,
      rerenderKey: 0
    }
  }

  onSwiperSliderChange(index) {
    this.setState({ swiperIndex : index })
  }

  async completeIntro() {
    const { userInfo } = this.props.User;
    try {
      const key = userInfo.email + ':maintenance-freemium';
      await AsyncStorage.setItem(key, 'success');
    } catch(error) {
      // console.log(error);
    }
    Constants.Global.startTabBasedApp()
  }

  render() {
    const { Funnel: { introFlex } } = this.props
    return(
      <ContainerView>
        <IntroBg
          source={Constants.Images.INTRO_BG}
        />
        <Swiper
          showsPagination={false}
          onIndexChanged={(index) => this.onSwiperSliderChange(index)}
          showsButtons={false}
          autoplay={false}
          ref={ref => this.swiper = ref}
          loop={false}
          animated={false}
        >
        {
          introFlex.map((slide) =>
            <BaseSlide key={ slide.id }>
                <SlideInfo
                  title={ slide.title }
                  text={ slide.description }
                  image={ slide.image }
                  onNext={() =>
                    this.state.swiperIndex === introFlex.length - 1
                      ? this.completeIntro()
                      : this.swiper.scrollBy(1)}
                  source={ slide.image === 0
                    ? Constants.Images.INTRO_SLIDE_FLEX_0
                    : slide.image === 1
                    ? Constants.Images.INTRO_SLIDE_FLEX_1
                    : slide.image === 2
                    ? Constants.Images.INTRO_SLIDE_FLEX_2
                    : null
                  }
                />
            </BaseSlide>)
        }
        </Swiper>
      </ContainerView>
    );
  }
}
