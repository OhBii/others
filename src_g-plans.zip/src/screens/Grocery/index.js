/*
*   author: denis
*   date:   7/13/2018
*/

import React, { Component } from 'react';
import {
  View,
  Text,
  ScrollView
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import { inject, observer } from 'mobx-react/native';

import Constants from '../../global/Constants';
import ShowHeader from '../components/HeaderBar/ShowHeader';
import ParallelButton from '../components/Common/ParallelButton';
import WeekItem from '../components/Grocery/WeekItem';

const multilingual = Constants.Multilingual;

const ContainerView = glamorous(View)({
  flexDirection: "column",
  flex: 1,
  backgroundColor: Constants.Colors.whiteFive
});

const AddView = glamorous(View)({
  flexDirection: "row",
  justifyContent: "space-between",
  paddingHorizontal: 15,
  marginVertical: 10
});

const DarkText = glamorous(Text)({
  fontSize: 16,
  color: Constants.Colors.marineTwo,
  marginTop: 15
})
const ItemsView = glamorous(View)({
  flex:1
})
const { object } = Proptypes;
@inject('User', 'GroceryList', 'MealPlan') @observer
export default class Grocery extends Component {
  static propTypes = {
    navigator: object,
    User: object,
    MealPlan: object,
    GroceryList: object
  }

  constructor(props) {
    super(props);
  }

  toAddList() {
    const { User: { language } } = this.props
    this.props.navigator.push({
      ...Constants.Screens.ADDGROCERY_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      },
      passProps: {
        navigator: this.props.navigator,
        name: multilingual.LIST[language]
      }
    });
  }

  deleteList(listName) {
    const {
      GroceryList:{
        deleteListItem
      }
    } = this.props
    deleteListItem(listName);
  }

  render() {
    const {
      User: {
        language,
        isPremium,
      } ,
      GroceryList,
      MealPlan: {
        currentWeekNumber,
        prevWeekNumber,
        nextWeekNumber,
      }
    } = this.props
    //const prevWeekNumber = currentWeekNumber - 1 < 1 ? 3 : currentWeekNumber - 1;
    //const nextWeekNumber = currentWeekNumber + 1 > 3 ? 1 : currentWeekNumber + 1;
    const count = (listName) =>{
      const count = Object.values(GroceryList.mealItemsGroceryList[listName]).length
      const AddedCount = Object.values(GroceryList.addedMealItemsGroceryList[listName]).length
      return count + AddedCount
    }
    return(
      <ContainerView>
        <ShowHeader
          title= { multilingual.GROCERY_LIST[language] }
          navigator={this.props.navigator}
          hasNotify
        />

          { isPremium
            ? <ItemsView>
                <AddView>
                  <DarkText>{ multilingual.RE_SH_LISTS[language] }</DarkText>
                </AddView>
                <ScrollView>
                  <WeekItem
                    navigator={this.props.navigator}
                    name={multilingual.LAST_WEEK[language]}
                    cntItem={count(prevWeekNumber)}
                    createdDate={GroceryList.dateList[prevWeekNumber]}
                    listName={prevWeekNumber}
                  />
                  <WeekItem
                    navigator={this.props.navigator}
                    name={multilingual.THIS_WEEK[language]}
                    cntItem={count(currentWeekNumber)}
                    createdDate={GroceryList.dateList[currentWeekNumber]}
                    listName={currentWeekNumber}
                  />
                  <WeekItem
                    navigator={this.props.navigator}
                    name={multilingual.NEXT_WEEK[language]}
                    cntItem={count(nextWeekNumber)}
                    createdDate={GroceryList.dateList[nextWeekNumber]}
                    listName={nextWeekNumber}
                  />
                </ScrollView>
              </ItemsView>
            : <ItemsView>
                <AddView>
                  <DarkText>{ multilingual.RE_SH_LISTS[language] }</DarkText>
                  <ParallelButton
                    title={ multilingual.ADD_LIST[language] }
                    icon={"plus"}
                    proc={ () => this.toAddList() }/>
                </AddView>
                <ScrollView>
                  {
                    GroceryList.listName.map(( listName, index ) => {
                      let count = 0;
                      if (GroceryList.mealItemsGroceryList[listName])  {
                        count = Object.values(GroceryList.mealItemsGroceryList[listName]).length
                      }
                      return (
                        <WeekItem
                          key={index}
                          navigator={this.props.navigator}
                          name={listName}
                          cntItem={count}
                          createdDate={GroceryList.dateList[listName]}
                          listName={listName}
                          deleteList={() => this.deleteList(listName)}
                        />
                      )
                    })
                  }
                </ScrollView>
              </ItemsView>
          }
      </ContainerView>
    );
  }
}
