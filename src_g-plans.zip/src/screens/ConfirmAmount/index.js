import React, { Component } from 'react'
import {
  View,
  Text,
  TouchableOpacity,
  TouchableWithoutFeedback,
  Image,
  ScrollView,
  Platform
} from 'react-native'
import { inject, observer } from 'mobx-react/native'
import Proptypes from 'prop-types'
import glamorous from 'glamorous-native'
import Icon from 'react-native-vector-icons/MaterialIcons'
import LinearGradient from 'react-native-linear-gradient'

import ShowHeader from '../components/HeaderBar/ShowHeader'
import SnowBox from '../components/Common/SnowBox'
import Constants from '../../global/Constants'
import { caseRoundValue } from '../../utils/GlobalFunctions'

const multilingual = Constants.Multilingual;

const ContainerView = glamorous(View)({
  flexDirection: "column",
  flex: 1,
  backgroundColor: Constants.Colors.paleGreyThree
});

const Inner = glamorous(View)({
  flex: 1,
  paddingHorizontal: Constants.mainPadding,
  marginBottom: 80
})

const Title = glamorous(Text)({
  fontSize: Platform.OS === 'ios' ? Constants.moderateScale(20, 0.8) : 20,
  color: Constants.Colors.greyishBrown
})

const ViewTitle = glamorous(View)({
  width: '100%',
  flexDirection: 'row',
  justifyContent: 'space-between',
  alignItems: 'center',
  paddingTop: 20
})

const ViewTitleInfo = glamorous(View)({
  width: '70%'
})

const ViewPFC = glamorous(View)({
  flexDirection: 'row',
  width: '100%'
})

const ViewPFCItem = glamorous(Text)({
  paddingHorizontal: 10,
  paddingVertical: 4,
  borderRadius: 12,
  borderStyle: 'solid',
  borderWidth: 1,
  borderColor: '#979797',
  overflow: 'hidden',
  fontSize: 12,
  color: 'black',
  marginRight: 4
})

const Tags = glamorous(View)({
  flexDirection: 'column',
  justifyContent: 'center',
  paddingVertical: 25,
  width: '100%',
  borderTopWidth: 1,
  borderBottomWidth: 1,
  borderTopColor: Constants.Colors.whiteSix,
  borderBottomColor: Constants.Colors.whiteSix,
  marginTop: 20
})

const Cals = glamorous(View)({
  alignItems: 'flex-end',
  flexDirection: 'row',
  marginBottom: 20,
  marginTop: -12
})

const Flame = glamorous(Image)({
  width: 19,
  height: 20
})

const CalsValue = glamorous(Text)({
  fontSize: 24,
  fontWeight: 'bold',
  color: Constants.Colors.greyishBrown,
  marginHorizontal: 5,
  top: 5
})

const CalsTitle = glamorous(Text)({
  fontSize: 12,
  fontWeight: 'bold',
  color: Constants.Colors.greyishBrown
})

const SmallTitle = glamorous(Text)({
  fontSize: 12,
  fontWeight: "bold",
  fontStyle: "normal",
  letterSpacing: 0,
  color: Constants.Colors.warmGreyTwo,
  marginBottom: 10
})

const SubTitle = glamorous(View)({
  width: '100%',
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'space-between',
  paddingTop: 15,
  paddingBottom: 20,
  marginVertical: 5,
  borderBottomWidth: 1,
  borderBottomColor: Constants.Colors.whiteSix
})

const SubTitleText = glamorous(Text)({
  fontSize: Platform.OS === 'ios'
    ? Constants.moderateScale(20, 0.8)
    : 20,
  fontWeight: '500',
  letterSpacing: -0.5,
  color: Constants.Colors.greyishBrown
})

const Value = glamorous(View)({
  minWidth: 82,
  height: 41,
  flexDirection: 'row',
  flex: 1,
  borderRadius: 5,
  backgroundColor: Constants.Colors.white,
  shadowColor: "rgba(45, 187, 241, 0.37)",
  shadowOffset: {
    width: 0,
    height: 0
  },
  shadowRadius: 4,
  shadowOpacity: 1,
  borderStyle: "solid",
  borderWidth: 1,
  borderColor: "#4ea1ff",
  elevation: 4,
  alignItems: 'center',
  justifyContent: 'center',
  paddingHorizontal: 10
})

const ValueText = glamorous(Text)({
  fontSize: 15,
  color: Constants.Colors.warmGreyFour
})

const Ingedient = glamorous(View)({
  paddingVertical: 10,
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'space-between',
  borderBottomWidth: 1,
  borderBottomColor: Constants.Colors.whiteSix
})

const IngedientText = glamorous(Text)({
  fontSize: 14,
  color: Constants.Colors.greyishBrown
})

const DetailRow = ({ title, value, unit } = this.props) =>
  <Ingedient>
    <IngedientText>{title}</IngedientText>
    <IngedientText>{[value, ' ', unit]}</IngedientText>
  </Ingedient>

const SubTitleRow = ({ title, value, unit } = this.props) =>
  <SubTitle>
    <SubTitleText>{title}</SubTitleText>
    <SubTitleText>{[value, ' ', unit]}</SubTitleText>
  </SubTitle>

const FooterView = glamorous(LinearGradient) ({
  position: 'absolute',
  bottom: 0,
  width: '100%',
  zIndex: 3
})

const ActionText = glamorous(Text) ({
  marginLeft: 7,
  fontSize: 15,
  color: Constants.Colors.dodgerBlueFour
})

const Footer = glamorous(View)({
  flexDirection: 'row',
  marginTop: 20,
  marginBottom: 30,
  marginHorizontal: Constants.mainPadding,
  justifyContent: 'space-between',
  borderRadius: 30,
  borderWidth: 1,
  borderStyle: 'solid',
  borderColor: Constants.Colors.dodgerBlueFour,
  backgroundColor: Constants.Colors.white,
})

const ActionButton = glamorous(TouchableOpacity) ({
  flexDirection: 'row',
  justifyContent: 'center',
  alignItems: 'center',
  flex: 1,
  paddingVertical: 12
})

const SnowBoxStyle = {
  flex: 1
}

const { object, func } = Proptypes;
@inject('Recipe', 'MealPlan', 'User') @observer
export default class ConfirmAmount extends Component {
  static propTypes = {
    navigator: object,
    User: object,
    item: object,
    addItem: func,
    MealPlan: object,
  }

  constructor(props) {
    super(props);
    this.state = {
      item: props.item,
    }
  }

  onChangeAmount() {
    const {
      item,
      User: {
        unit,
        language,
        setUnit,
      },
    } = this.props
    let itemName = item[`name_${language}`]
    if (!itemName) itemName = item.name
    this.props.navigator.showLightBox({
      ...Constants.Screens.ITEMCHANGE_SCREEN,
      style: {
        backgroundColor: "#000000a0",
        tapBackgroundToDismiss: true
      },
      passProps: {
        navigator: this.props.navigator,
        itemName,
        item: { ...this.state.item },
        ratioSIOverUS : parseFloat(item.portion_si) / parseFloat(item.portion),
        unitType: unit,
        changeValue : (amount, isUS) => this.changeAmount(amount, isUS),
        changeUnit : setUnit,
      }
    });
  }

  changeAmount(amount, isUS) {
    const {
      item,
      MealPlan: {
        getAmountChangedItem,
      },
    } = this.props
    this.setState({
      item: getAmountChangedItem(item, amount, isUS, 2)
    })
  }

  onAdd() {
    const { navigator, addItem } = this.props
    navigator.dismissModal()
    addItem(2, this.state.item)
  }

  onCancel() {
    this.props.navigator.dismissModal()
  }

  render() {
    const { User: { language, unit } } = this.props
    const item = this.state.item
    const isUSUnit = unit === 'us'
    const emptyString = '__ '
    return(
      <ContainerView>
        <ShowHeader
          navigator={this.props.navigator}
          title={multilingual.CONFIRM_AMOUNT[language]}
          isModal
          hasBack
        />
        <SnowBox noPad noPadV style={SnowBoxStyle}>
          <ScrollView>
            <Inner>
              <ViewTitle>
                <ViewTitleInfo>
                  <Title>{item.name}</Title>
                </ViewTitleInfo>
                <TouchableWithoutFeedback
                  onPress={() => this.onChangeAmount()}
                >
                  <Value>
                    <ValueText numberOfLines={1}>
                      {`${isUSUnit ? caseRoundValue(item.portion * item.exchanges) : caseRoundValue(item.portion_si * item.exchanges)} ${isUSUnit ? item.unit : item.unit_si}`}
                    </ValueText>
                  </Value>
                </TouchableWithoutFeedback>
              </ViewTitle>
              <Tags>
                <SmallTitle>{ multilingual.CALORIES[language] }</SmallTitle>
                <Cals>
                  <Flame source={Constants.Images.FLAME}/>
                  <CalsValue>{caseRoundValue(item.calories)}</CalsValue>
                  <CalsTitle>{ multilingual.CALORIES[language] }</CalsTitle>
                </Cals>
                <SmallTitle>{ multilingual.MACRONUTRIENTS[language] }</SmallTitle>
                <ViewPFC>
                  <ViewPFCItem>{`${multilingual.PROTEIN[language]}: ${caseRoundValue(item.proteins)}g`}</ViewPFCItem>
                  <ViewPFCItem>{`${multilingual.FATS[language]}: ${caseRoundValue(item.fats)}g`}</ViewPFCItem>
                  <ViewPFCItem>{`${multilingual.CARBS[language]}: ${caseRoundValue(item.carbohydrates)}g`}</ViewPFCItem>
                </ViewPFC>
              </Tags>
              <SubTitleRow
                title={ multilingual.TOTAL_FATS[language] }
                value={caseRoundValue(item.fats)}
                unit={'g'}
              />
              <DetailRow
                title={ multilingual.SATURATED_FATS[language] }
                value={item.all_data && caseRoundValue(item.all_data.nf_saturated_fat) || emptyString}
                unit={'g'}
              />
              <DetailRow
                title={ multilingual.TRANS_FATS[language] }
                value={item.all_data && caseRoundValue(item.all_data.nf_trans_fat) || emptyString}
                unit={'g'}
              />
              <DetailRow
                title={ multilingual.POLYUNSATURATED_FATS[language] }
                value={item.all_data && caseRoundValue(item.all_data.nf_polyunsaturated_fat) || emptyString}
                unit={'g'}
              />
              <DetailRow
                title={ multilingual.MONOUNSATURATED_FATS[language] }
                value={item.all_data && caseRoundValue(item.all_data.nf_monounsaturated_fat) || emptyString}
                unit={'g'}
              />
              <SubTitleRow
                title={ multilingual.TOTAL_CARBS[language] }
                value={caseRoundValue(item.carbohydrates)}
                unit={'g'}
              />
              <DetailRow
                title={ multilingual.DIETARY_FIBER[language] }
                value={item.all_data && caseRoundValue(item.all_data.nf_dietary_fiber) || emptyString}
                unit={'g'}
              />
              <DetailRow
                title={ multilingual.SUGARS[language] }
                value={item.all_data && caseRoundValue(item.all_data.nf_sugars) || emptyString}
                unit={'g'}
              />
              <SubTitleRow
                title={ multilingual.PROTEIN[language] }
                value={caseRoundValue(item.proteins)}
                unit={'g'}
              />
              <SubTitleRow
                title={ multilingual.SODIUM[language] }
                value={item.all_data && caseRoundValue(item.all_data.nf_sodium) || emptyString}
                unit={'g'}
              />
              <SubTitleRow
                title={ multilingual.CHOlESTEROL[language] }
                value={item.all_data && caseRoundValue(item.all_data.nf_cholesterol) || emptyString}
                unit={'g'}
              />
              <SubTitleRow
                title={ multilingual.POTASSIUM[language] }
                value={item.all_data && caseRoundValue(item.all_data.nf_potassium) || emptyString}
                unit={'g'}
              />
            </Inner>
          </ScrollView>
        </SnowBox>
        <FooterView
          colors={['#ffffff00', '#ffffffff']}
          start={{x: 0, y: 0}}
          end={{x: 0, y: 1}}
        >
          <Footer>
            <ActionButton
              onPress={() => this.onAdd()}
            >
              <Icon name="check" size={18} color={Constants.Colors.dodgerBlueFour} />
              <ActionText>{ multilingual.ADD_ITEM[language] }</ActionText>
            </ActionButton>
            <ActionButton
              onPress={() => this.onCancel()}
            >
              <Icon name="clear" size={18} color={Constants.Colors.dodgerBlueFour} />
              <ActionText>{ multilingual.CANCEL[language] }</ActionText>
            </ActionButton>
          </Footer>
        </FooterView>
      </ContainerView>
    );
  }
}
