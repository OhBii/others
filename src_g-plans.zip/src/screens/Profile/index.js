/*
*   author: denis
*   date:   7/17/2018
*/

import React, { Component } from 'react';
import {
  View,
  Text,
  Alert,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { inject, observer } from 'mobx-react';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import ImagePicker from 'react-native-image-picker';
import SnapCarousel from 'react-native-snap-carousel'
import { CachedImage, ImageCacheProvider } from 'react-native-cached-image'
import SnowBox from '../components/Common/SnowBox'
import MainTitle from '../components/Common/MainTitle'

import Constants from '../../global/Constants';
import ShowHeader from '../components/HeaderBar/ShowHeader';
import ScrollEntries from '../components/Common/ScrollEntries'
import ChallengeItem from '../components/Challenges/ChallengeItem'
import ModuleItem from '../components/Modules/ModuleItem'
// import { caseRoundValue } from '../../utils/GlobalFunctions'
import GplansLogoLoader from '../components/Common/GplansLoader'

const multilingual = Constants.Multilingual;

const { width, height } = Constants.windowDimensions
const mainPadding = width * 0.045

const ContainerView = glamorous(View)(({isFull}) => ({
  flexDirection: "column",
  flex: 1,
  backgroundColor: isFull
    ? 'black'
    : Constants.Colors.paleGreyThree
}));

const PhotoView = glamorous(View)({
  height: height * 0.5,
  marginVertical: 18,
  overflow: 'hidden',
  borderRadius: 7
});

const ContainerLoader = glamorous(View)({
  position: 'absolute',
  left: 0,
  top: 0,
  right: 0,
  bottom: 0,
  flexDirection: "column",
  flex: 1,
  backgroundColor: Constants.Colors.white,
  alignItems: 'center',
  justifyContent: 'center'
})

const WrapView = glamorous(View)({
  flexDirection: "row",
  width: '100%',
  height: '100%',
  borderRadius: 15,
});

const PhotoWrap = glamorous(View)({
  width: '50%',
  height: '100%'
});

const Photo = glamorous(CachedImage)({
  width: '100%',
  height: '100%'
})

const NameText = glamorous(Text)({
  fontSize: 20,
  color: Constants.Colors.greyishBrownThree,
  marginVertical: 3
})

const RowView = glamorous(View)({
  flexDirection: 'row',
  justifyContent: 'center',
})

const LevelText = glamorous(Text)({
  fontSize: 22,
  color: Constants.Colors.greyishBrownThree
})

const BackButton = glamorous(TouchableOpacity)({
  position: "absolute",
  left: 15,
  top: 35
});

const RealView = glamorous(View)({
  flexDirection: 'column',
  flex: 1
});

const FullImage = glamorous(CachedImage)({
  width: '100%',
  height: '100%'
});

const InfoView = glamorous(View) ({
  alignItems: 'center'
})

const AvatarView = glamorous(TouchableOpacity) ({
  width: 80,
  height: 80,
  borderRadius: 80 / 2,
  shadowColor: "rgba(0, 0, 0, 0.32)",
  shadowOffset: {
    width: 0,
    height: 2
  },
  shadowRadius: 4,
  shadowOpacity: 1,
  marginVertical: 7
})

const AvatarImage = glamorous(CachedImage) ({
  width: 80,
  height: 80,
  borderRadius: 80 / 2
})

const MetabolicText = glamorous(Text) ({
  fontSize: 13,
  color: Constants.Colors.battleshipGrey
})

const WeightView = glamorous(View)(({isLeft}) => ({
  flex: 1,
  alignItems: 'center',
  marginBottom: 18,
  paddingVertical: 7,
  borderRightWidth: isLeft ? 1 : 0,
  borderStyle: 'solid',
  borderRightColor: Constants.Colors.veryLightPink
}))

const WeightText = glamorous(Text) ({
  fontSize: 12,
  color: Constants.Colors.brownGrey,
  marginBottom: 12
})

const WeightAmountText = glamorous(Text) ({
  fontSize: 25,
  color: Constants.Colors.greyishBrownThree
})

const WeightUnitText = glamorous(Text) ({
  fontSize: 12,
  color: Constants.Colors.greyishBrownThree,
  marginTop: 12
})

const ShareButton = glamorous(TouchableOpacity) ({
  flexDirection: 'row',
  flex: 1,
  justifyContent: 'center',
  paddingVertical: 12,
  marginBottom: 20,
  marginHorizontal: 5,
  borderRadius: 25,
  borderStyle: "solid",
  borderWidth: 1,
  borderColor: Constants.Colors.softBlueThree
})

const ShareText = glamorous(Text) ({
  fontSize: 18,
  marginTop: -3,
  marginLeft: 5,
  color: Constants.Colors.softBlueThree
})

const StatsView = glamorous(View) ({
  paddingVertical: 12
})

const StatsText = glamorous(Text) ({
  fontSize: 14,
  color: Constants.Colors.greyishBrown
})

const StatsAmountText = glamorous(Text) ({
  fontSize: 22,
  color: Constants.Colors.greyishBrown
})

const PointsText = glamorous(Text) ({
  fontSize: 14,
  color: Constants.Colors.greyishBrownThree,
  marginTop: 20
})

const CameraButton = glamorous(TouchableOpacity) ({
  justifyContent: 'center',
  alignItems: 'center',
  position: 'absolute',
  bottom: 20,
  right: width * 0.15,
  width: 60,
  height: 60,
  borderRadius: 60 / 2,
  borderWidth: 1,
  borderColor: Constants.Colors.white,
  borderStyle: 'solid'
})

const SnowBoxStyle = {
  marginTop: 0
}

const { object } = Proptypes;
@inject('User', 'Profile', 'App' ) @observer
export default class Profile extends Component {
  static propTypes = {
    navigator: object,
    User: object,
    Profile: object,
    App: object
  }

  constructor(props) {
    super(props);
    this.state = {
      isUploading: false,
      isFull: false
    }
  }

  toUploadImage() {
    const options = {
      title: 'Select Avatar',
      storageOptions: {
        skipBackup: true,
        path: 'images'
      },
      quality: 0.3
    }

    ImagePicker.showImagePicker(options, response => {
      if (response.didCancel) {
        //
      } else if (response.error) {
        //
        Alert.alert(response.error);
      } else {
        //
        this.props.navigator.showModal({
          ...Constants.Screens.PREVIEW_IMAGE_SCREEN,
          navigatorStyle: {
            navBarHidden: true,
            tabBarHidden: true
          },
          passProps: {
            imageUri: response.uri,
            uploadImage: () => this.uploadImage(response.uri)
          }
        });
      }
    })
  }

  async uploadImage(imageUri){
    this.setState({isUploading: true});
    await this.props.Profile.uploadCheckinImage(imageUri);
    this.setState({isUploading: false});
  }

  toFullScreen() {
    const { Profile } = this.props;
    if (Profile.allProfileImages.length === 0) return;
    this.setState({isFull: true});
  }

  toBack() {
    this.setState({isFull: false});
  }

  facebookShare(images) {
    this.props.Profile.facebookShareImage(images)
      .then(result => {
        result
        //console.log(result)
        // if (result.isCancelled)
        //   Alert.alert('Share cancelled!')
        // else
        //   Alert.alert('Share success with postId: ' + result.postId)
      })
      .catch(error => {
        Alert.alert('Error', error.message)
      })
  }

  instagramShare(images) {
    this.props.Profile.instagramShareImage(images)
      .then(result => {
        result
      })
      .catch(error => {
        Alert.alert('Error', error.message)
      })
  }

  render() {
    const {
      User,
      Profile,
      App: { challenges, modules }
    } = this.props

    const currentLanguage = User.language;

    const firstName = User.userInfo.first_name ? User.userInfo.first_name : ''
    const lastName = User.userInfo.last_name ? User.userInfo.last_name : ''
    const userName = firstName + ' ' + lastName

    const metabolic = User.userInfo.meal_plan.metabolic_type.name

    const startingWeight = User.userInfo.first_checkin.weight
    const currentWeight = User.userInfo.last_checkin.weight

    const userLevel = 'level ' + User.userInfo.last_checkin.week_number;

    const {firstImage, lastImage} = Profile.getFirstAndLastImages;

    const avatarImage = Profile.getLastImage
      ? Profile.getLastImage
      : 'https://static0.misionesonline.net/wp-content/uploads/2017/07/angelina-10j7i2e4qnf8.jpg'

    return(
      <ContainerView isFull={this.state.isFull}>
        {
          this.state.isFull
            ? <RealView>
                <ImageCacheProvider
                  urlsToPreload={Profile.allProfileImages}>
                  <SnapCarousel
                    onSnapToItem={() => {}}
                    inactiveSlideScale={1}
                    sliderWidth={width}
                    itemWidth={width}
                    loopClonesPerSide={1}
                    activeSlideAlignment={'center'}
                    ref={c => { this.carousel = c }}
                    data={Profile.allProfileImages}
                    renderItem={({item}) =>
                      <FullImage source={{ uri: item }} />
                    }
                    activeSlideOffset={0}
                  />
                </ImageCacheProvider>
                <BackButton onPress={() => this.toBack()}>
                  <Icon name="angle-left" size={60} color="white" />
                </BackButton>
              </RealView>
            : <RealView>
                <ShowHeader
                  title= { multilingual.PROFILE[currentLanguage] }
                  navigator={this.props.navigator}
                  isModal={true}
                  hasNotify
                />
                <ScrollView
                  bounces={false}
                >
                  <SnowBox noPadV style={SnowBoxStyle}>
                    <InfoView>
                      <AvatarView onPress={() => this.toFullScreen()}>
                        <ImageCacheProvider
                          urlsToPreload={[avatarImage]}
                        >
                          <AvatarImage source={{ uri: avatarImage }} />
                        </ImageCacheProvider>
                      </AvatarView>
                      <NameText>{ userName }</NameText>
                      <MetabolicText>{ metabolic }</MetabolicText>
                    </InfoView>
                    <PhotoView>
                      {
                        this.state.isUploading
                          ? <ContainerLoader><GplansLogoLoader size={60} /></ContainerLoader>
                          : <ImageCacheProvider
                              urlsToPreload={[firstImage, lastImage]}>
                              <WrapView>
                                <PhotoWrap>
                                    <Photo
                                      source={firstImage
                                        ? { uri: firstImage }
                                        : require('../../../img/photo.png')}
                                      blurRadius={firstImage ? 0 : 20} />
                                </PhotoWrap>
                                <PhotoWrap>
                                    <Photo
                                      source={lastImage
                                        ? { uri: lastImage }
                                        : firstImage
                                          ? { uri: firstImage }
                                          : require('../../../img/photo2.png')}
                                      blurRadius={lastImage ? 0 : 20} />
                                </PhotoWrap>
                                <CameraButton onPress={() => this.toUploadImage()}>
                                   <Icon name="camera" size={24} color={Constants.Colors.white} />
                                </CameraButton>
                              </WrapView>
                            </ImageCacheProvider>
                      }
                    </PhotoView>
                    <RowView>
                      <WeightView isLeft={true}>
                        <WeightText>{ 'Starting Weight' }</WeightText>
                        <RowView>
                          <WeightAmountText>{startingWeight}</WeightAmountText>
                          <WeightUnitText>lbs</WeightUnitText>
                        </RowView>
                      </WeightView>
                      <WeightView isLeft={false}>
                        <WeightText>{ 'Current Weight' }</WeightText>
                        <RowView>
                          <WeightAmountText>{currentWeight}</WeightAmountText>
                          <WeightUnitText>lbs</WeightUnitText>
                        </RowView>
                      </WeightView>
                    </RowView>
                    <RowView>
                      <ShareButton onPress={() => this.facebookShare([firstImage, lastImage])} >
                        <Icon name="facebook-square" size={18} color={Constants.Colors.softBlueThree} />
                        <ShareText>Share</ShareText>
                      </ShareButton>
                      <ShareButton onPress={() => this.instagramShare([firstImage, lastImage])}>
                        <Icon name="instagram" size={18} color={Constants.Colors.softBlueThree} />
                        <ShareText>Share</ShareText>
                      </ShareButton>
                    </RowView>
                  </SnowBox>
                  <SnowBox>
                    <MainTitle title={'Overall Stats'} />
                    <StatsView>
                      <StatsText>Food Eaten</StatsText>
                      <StatsAmountText>{`${Profile.overallStats.calories} calories`}</StatsAmountText>
                    </StatsView>
                    <StatsView>
                      <StatsText>Water Drank</StatsText>
                      <StatsAmountText>{`${Profile.overallStats.water} ounces`}</StatsAmountText>
                    </StatsView>
                    <StatsView>
                      <StatsText>Exercise Done</StatsText>
                      <StatsAmountText>{`${Profile.overallStats.exercises} minutes`}</StatsAmountText>
                    </StatsView>
                  </SnowBox>
                  <SnowBox>
                    <MainTitle title={'Rank'} />
                    <LevelText>{ userLevel }</LevelText>
                    <PointsText>{'3245 points'}</PointsText>
                  </SnowBox>
                  <SnowBox noPad>
                    <MainTitle hrPad={mainPadding} title={'Trophy Case'} />
                    <ScrollEntries
                      data={challenges}
                      elem={ChallengeItem}
                      onSelected={() => {}}
                      paddingLeft={mainPadding}
                      active={this.state.activeChallenge}
                    />
                  </SnowBox>
                  <SnowBox noPad>
                    <MainTitle hrPad={mainPadding} title={'Modules'} />
                    <ScrollEntries
                      data={modules}
                      elem={ModuleItem}
                      onSelected={() => {}}
                      paddingLeft={mainPadding}
                    />
                  </SnowBox>
                </ScrollView>
              </RealView>
        }
      </ContainerView>
    );
  }
}
