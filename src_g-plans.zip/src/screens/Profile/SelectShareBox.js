import React, { Component } from 'react'
import {
  Text,
  TouchableOpacity,
  View,
} from 'react-native'
import glamorous from 'glamorous-native'
import Proptypes from 'prop-types'
import LinearGradient from 'react-native-linear-gradient'
import FAIcon from 'react-native-vector-icons/FontAwesome'

import Constants from '../../global/Constants'

const Dialog = glamorous(View)({
  width: 316,
  height: 250,
  paddingVertical: 0,
  justifyContent: 'space-around',
  alignItems: 'center',
  backgroundColor: Constants.Colors.white,
  borderRadius: 10,
})

// const ShareView = glamorous(View)({
//   flexDirection: 'row',
//   justifyContent: 'space-around',
//   alignItems: 'center',
// })

const ShareButton = glamorous(LinearGradient)({
  flexDirection: 'row',
  justifyContent: 'center',
  alignItems: 'center',
  width: 160,
  height: 42,
  borderRadius: 32,
  shadowColor: 'rgba(0, 0, 0, 0.23)',
  shadowOffset: {
    width: 0,
    height: 7,
  },
  shadowRadius: 6,
  shadowOpacity: 1,
  elevation: 6,
})

const FacebookIcon = glamorous(FAIcon)({
  backgroundColor: 'transparent',
  marginRight: 10,
})

const ShareText = glamorous(Text)({
  fontSize: 16,
  fontWeight: '600',
  color: Constants.Colors.white,
})

const { string, func, object } = Proptypes

export default class SelectShareBox extends Component {
  constructor(props) {
    super(props)
  }

  static propTypes = {
    navigator: object,
    image: string,
    onFacebookShare: func,
    onInstagramShare: func,
  }

  render() {
    const { onFacebookShare, /*onInstagramShare,*/ image } = this.props
    return (
      <Dialog>
        <TouchableOpacity
          onPress={() => onFacebookShare(image)}
        >
          <ShareButton
            colors={['rgb(59, 89, 152)', 'rgb(139, 157, 195)']}
            start={{ x: 0, y: 1 }}
            end={{ x: 1, y: 1 }}
          >
            <FacebookIcon
              name={'facebook'}
              color={Constants.Colors.white}
              size={24}
            />
            <ShareText>Share</ShareText>
          </ShareButton>
        </TouchableOpacity>
      </Dialog>
    )
  }
}
