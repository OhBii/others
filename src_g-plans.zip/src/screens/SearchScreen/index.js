/*
*   author: denis
*   date:   7/19/2018
*/

import React, { Component } from 'react';
import {
  Text,
  View,
  FlatList,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import Icon from 'react-native-vector-icons/MaterialIcons'
import { inject, observer } from 'mobx-react';
import ActionSheetAndroid from 'react-native-actionsheet'
import LinearGradient from 'react-native-linear-gradient'

import Constants from '../../global/Constants';
import ShowHeader from '../components/HeaderBar/ShowHeader';
import SearchBar from '../components/SearchScreen/SearchBar';
import SearchItem from '../components/SearchScreen/SearchItem';
import GplansLogoLoader from '../components/Common/GplansLoader'
import SnowBox from '../components/Common/SnowBox'

const multilingual = Constants.Multilingual;

const ContainerView = glamorous(View) ({
  flexDirection: "column",
  flex: 1,
  backgroundColor: Constants.Colors.paleGreyThree
});

const TitleText = glamorous(Text)({
  fontSize: 16,
  color: Constants.Colors.marineTwo
});

const TitleView = glamorous(View)({
  paddingHorizontal: 15,
  paddingVertical: 20,
  borderStyle: "solid",
  borderBottomColor: Constants.Colors.borderColorThree,
  borderBottomWidth: 1
});

const ColumnView = glamorous(View)({
  flexDirection: "column",
  flex: 1,
  justifyContent: "space-between"
});

const ContainerLoader = glamorous(View)({
  position: 'absolute',
  left: 0,
  top: 0,
  right: 0,
  bottom: 0,
  flexDirection: "column",
  flex: 1,
  alignItems: 'center',
  justifyContent: 'center'
});

const ActionView = glamorous(LinearGradient) ({
  position: 'absolute',
  bottom: 0,
  width: '100%'
})

const ActionButton = glamorous(TouchableOpacity)({
  flexDirection: 'row',
  justifyContent: 'center',
  marginTop: 20,
  marginBottom: 30,
  marginHorizontal: Constants.mainPadding,
  borderRadius: 30,
  borderWidth: 1,
  borderStyle: 'solid',
  borderColor: Constants.Colors.dodgerBlueFour,
  backgroundColor: Constants.Colors.white,
  alignItems: 'center',
  flex: 1,
  paddingVertical: 12,
})

const ActionText = glamorous(Text) ({
  marginLeft: 7,
  fontSize: 15,
  color: Constants.Colors.dodgerBlueFour
})

const Inner = glamorous(View) ({
  flex: 1,
  marginBottom: 80
})

const SnowBoxStyle = {
  flex: 1
}

const { object, number, bool, string } = Proptypes;
@inject( 'User', 'SearchFood', 'MealPlan', 'GroceryList' ) @observer
export default class SearchScreen extends Component {
  static propTypes = {
    navigator: object,
    User: object,
    SearchFood: object,
    MealPlan: object,
    GroceryList:object,
    mealId: number,
    listName: string,
    forFlex: bool
  }

  static defaultProps = {
    forFlex: false
  }

  constructor(props) {
    super(props)
    this.state = {
      isSearching: false,
      sarchLoading: false,
    }
    const mealLabels = props.MealPlan.getMealsByDay.map(meal => ({
      id: meal.id,
      label: meal.label,
      forFlex: meal.recipe ? false : true,
      logged: meal.logged,
    }))
    this.mealId = props.mealId
    this.forFlex = props.forFlex
    // If Count of snack is more than 1, add number to label with snack
    if (mealLabels && mealLabels.length) {
      const snacks = mealLabels.filter(el => el.label === 'Snack')
      if (snacks && snacks.length > 1) {
        let counterSnack = 0
        snacks.forEach(el => {
          el.label += ++counterSnack
        })
      }
      // remove logged meals
      this.mealLabels = mealLabels.filter(el => !el.logged)
    }
  }

  startSearch() {
    this.setState({
      isSearching: true,
    })
  }

  endSearch(pageIndex, searchRes) {
    const {
      SearchFood: { getSearchResult }
    } = this.props
    // Keyboard.dismiss()
    getSearchResult(pageIndex, searchRes)
    this.setState({
      isSearching: false,
    })
  }

  addItem(item) {
    // For directly search
    if(this.props.listName){
      this.showConfirmAmountScreen(item)
      return
    }
    if (!this.mealId) {
      if (this.mealLabels && this.mealLabels.length) {
        if (Constants.platform === 'ios') {
          const { ActionSheetIOS } = require('react-native')
          ActionSheetIOS.showActionSheetWithOptions({
            options: [
              ...this.mealLabels.map(el => el.label),
              'Cancel'
            ],
            cancelButtonIndex: this.mealLabels.length
          },
          buttonIndex => {
            if (buttonIndex === this.mealLabels.length) return
            this.onActionSheetHandle(buttonIndex, item)
          })
        } else {
          this.ActionSheetAndroid.item = item
          this.ActionSheetAndroid.show()
        }
        return
      } else {
        Alert.alert(multilingual.MSG_NO_MEAL_TO_ADD_ITEM[this.User.language])
        return
      }
    }
    // For add extra item with meal id
    this.showConfirmAmountScreen(item)
  }

  onActionSheetHandle(buttonIndex, item) {
    this.forFlex = this.mealLabels[buttonIndex].forFlex
    this.mealId = this.mealLabels[buttonIndex].id
    this.showConfirmAmountScreen(item)
  }

  showConfirmAmountScreen(item) {
    const {
      SearchFood: { addItem, addItemToRecent },
      navigator,
    } = this.props
    navigator.showModal({
      ...Constants.Screens.CONFIRM_AMOUNT_SCREEN,
      passProps: {
        item,
        addItem: (pageIndex, item) => {
          addItem(pageIndex, item)
          addItemToRecent(item)
        },
      },
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    })
  }

  onDone(mealId) {
    if(this.props.listName) {
      const {
        navigator,
        listName,
        SearchFood: {
          addedFoodList
        },
        GroceryList
      } = this.props
      GroceryList.setmealItemsGroceryList(listName, addedFoodList);
      navigator.dismissModal()
      return
    }
    else if (!mealId) {
      Alert.alert('Please select meal first!');
      return
    }

    const {
      SearchFood: { onDone, resetStore },
      MealPlan: { getRecipeByMealId },
      navigator
    } = this.props;

    const recipe = getRecipeByMealId(mealId);
    onDone(mealId);
    resetStore();
    if (this.forFlex) {
      navigator.showModal({
        ...Constants.Screens.MEAL_DETAIL_SCREEN,
        passProps: {
          MealId: mealId,
          backType: false
        },
        navigatorStyle: {
          navBarHidden: true,
          tabBarHidden: true
        }
      });
    }
    else {
      navigator.showModal({
        ...Constants.Screens.RECIPE_ITEM_SCREEN,
        passProps: {
          forView: false,
          MealId: mealId,
          RecipeId: recipe && recipe.id,
          backType: false
        },
        navigatorStyle: {
          navBarHidden: true,
          tabBarHidden: true
        }
      });
    }
  }

  componentWillUnmount() {
    this.props.SearchFood.initallFoodList();
  }

  render() {
    const {
      User,
      SearchFood: {
        foodList,
        pageIndex,
        addedFoodList,
        deleteItem,
        searchLoading,
        recendAddedFoodList,
        // initallFoodList
        // mealId,
      },
    } = this.props
    const isUSUnit = User.unit === 'us';

    return(
      <ContainerView>
        <View>
          <ShowHeader
            navigator={this.props.navigator}
            title={ 'Add Items' }
            isModal
            hasBack
          />
          <SearchBar
            navigator={this.props.navigator}
            startSearch={() => this.startSearch()}
            endSearch={(pageIndex, result) => this.endSearch(pageIndex, result)}
          />
        </View>
        <SnowBox noPad noPadV style={SnowBoxStyle}>
        {
          pageIndex === 1
            ? <FlatList
                data={foodList}
                renderItem={({item}) =>
                  <SearchItem
                    itemName={ item.food_name? item.food_name: item.name }
                    cals={parseFloat(item.calories)}
                    portion={isUSUnit ? parseFloat(item.portion) : parseFloat(item.portion_si)}
                    exchanges={item.exchanges}
                    unit={isUSUnit ? item.unit : item.unit_si}
                    toAdd={() => this.addItem(item)} />
                }
                keyExtractor={(item, index) => index.toString()}
              />
            :
              pageIndex === 2
                ? <ColumnView>
                      <TitleView>
                        <TitleText>You Just Added:</TitleText>
                      </TitleView>
                      <ScrollView>
                        <Inner>
                        {
                          addedFoodList.map((item, index) =>
                            <SearchItem
                              key={index}
                              itemName={ item.food_name? item.food_name: item.name }
                              cals={parseFloat(item.calories)}
                              portion={isUSUnit ? parseFloat(item.portion) : parseFloat(item.portion_si)}
                              exchanges={item.exchanges}
                              unit={isUSUnit ? item.unit : item.unit_si}
                              isActive
                              minusButton
                              toDelete={() => deleteItem(item)}
                              navigator={this.props.navigator}
                            />
                          )
                        }
                        </Inner>
                      </ScrollView>
                      <ActionView
                        colors={['#ffffff00', '#ffffffff']}
                        start={{x: 0, y: 0}}
                        end={{x: 0, y: 1}}
                      >
                        <ActionButton
                           onPress={() => this.onDone(this.mealId)}
                        >
                          <Icon name="check" size={18} color={Constants.Colors.dodgerBlueFour} />
                          <ActionText>Done</ActionText>
                        </ActionButton>
                      </ActionView>
                  </ColumnView>
                : pageIndex === 4
                  ? <FlatList
                      data={recendAddedFoodList}
                      renderItem={({item}) =>
                        <SearchItem
                          itemName={ item.food_name? item.food_name: item.name }
                          cals={parseFloat(item.calories)}
                          portion={isUSUnit ? parseFloat(item.portion) : parseFloat(item.portion_si)}
                          exchanges={item.exchanges}
                          unit={isUSUnit ? item.unit : item.unit_si}
                          toAdd={() => this.addItem(item)} />
                      }
                      keyExtractor={(item, index) => index.toString()}
                    />
                  : <View />
              }
              <ActionSheetAndroid
                ref={ref => this.ActionSheetAndroid = ref}
                options={[
                  ...this.mealLabels.map(el => el.label),
                  'Cancel'
                ]}
                cancelButtonIndex={this.mealLabels.length}
                onPress={ buttonIndex => {
                  if (buttonIndex === this.mealLabels.length) return;
                  this.onActionSheetHandle(buttonIndex, this.ActionSheetAndroid.item)}
                }
              />
              {!!searchLoading &&
                <ContainerLoader>
                  <GplansLogoLoader
                    size={60}
                  />
                </ContainerLoader>}
        </SnowBox>
      </ContainerView>
    );
  }
}
