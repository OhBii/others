/*
*   author: denis
*   date:   7/23/2018
*/

import React, { Component } from 'react';
import {
  Text,
  View,
  Alert,
  TouchableOpacity,
  Vibration,
} from 'react-native';
import { RNCamera } from 'react-native-camera';
import { inject, observer } from 'mobx-react/native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import Icon from 'react-native-vector-icons/FontAwesome';

import Api from '../../utils/Api';
import GplansLogoLoader from '../components/Common/GplansLoader'

const ContainerView = glamorous(View)({
  flexDirection: "column",
  flex: 1
});

const ContainerLoader = glamorous(View)({
  position: 'absolute',
  left: 0,
  top: 0,
  right: 0,
  bottom: 0,
  flexDirection: "column",
  flex: 1,
  backgroundColor: 'rgb(0, 0, 0)',
  alignItems: 'center',
  justifyContent: 'center'
})

const BackButton = glamorous(TouchableOpacity)({
  position: "absolute",
  left: 15,
  top: 35
});

const CameraRN = glamorous(RNCamera)({
  flex: 1
});

const AuthorizedView = glamorous(View)({
  backgroundColor: "black",
  flexDirection: "column",
  flex: 1,
  justifyContent: 'center',
  alignItems: 'center'
});

const WhiteText = glamorous(Text)({
  color: "white",
  fontSize: 16
});

const { object, func } = Proptypes;
@inject('User') @observer
export default class Camera extends Component {
  static propTypes = {
    navigator: object,
    User: object,
    getBarcodeRes: func
  }

  constructor(props) {
    super(props);
    this.state = {isDetected: false}
  }

  toBack() {
    this.props.navigator.dismissModal();
  }

  detectBarcode(res) {
    if (this.state.isDetected) return;
    const { User: { token } } = this.props;
    const barcode = res.data;
    Vibration.vibrate(500);
    this.setState({isDetected: true});
    Api.searchOnlyFoodBarcode(token, barcode)
      .then((data) => {
        const searchRes = data.data;
        if (searchRes.length != 0) {
          const getNutrients = searchRes.map(el => Api.searchNutrients(token, el.food_name, el.nix_item_id))
          Promise.all(getNutrients)
            .then(res2 => {
              const nutrientFoods = res2.map(el => el.data)
              this.props.getBarcodeRes(nutrientFoods)
              this.toBack();
              this.setState({isDetected: false});
            })
            .catch((/*err*/) => {
              //console.warn(err)
              this.setState({isDetected: false});
              this.showAlert(`There is no information about barcode ${barcode}`)
            })
        }
        else {
          this.setState({isDetected: false});
          this.showAlert(`There is no information about barcode ${barcode}`);
        }
      })
      .catch(() => {
        this.setState({isDetected: false});
        this.showAlert(`There is no information about barcode ${barcode}`);
      })
  }

  showAlert(str) {
    Alert.alert(str);
  }

  render() {
    return(
      <ContainerView>
      {this.state.isDetected ?
        <ContainerLoader><GplansLogoLoader size={60} /></ContainerLoader>
        :
        <CameraRN
          ref={ref => {
            this.camera = ref;
          }}
          permissionDialogTitle={'Permission to use camera'}
          permissionDialogMessage={'We need your permission to use your camera phone'}
          notAuthorizedView={
            <AuthorizedView>
              <BackButton onPress={() => this.toBack()}>
                <Icon name="angle-left" size={60} color="white" />
              </BackButton>
              <WhiteText>Camera not authorized</WhiteText>
            </AuthorizedView>
          }
          onBarCodeRead={(res) => this.detectBarcode(res)}>
          <BackButton onPress={() => this.toBack()}>
            <Icon name="angle-left" size={60} color="white" />
          </BackButton>
        </CameraRN>
      }
      </ContainerView>
    )
  }
}
