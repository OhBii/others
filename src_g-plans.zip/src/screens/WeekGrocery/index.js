/*
*   author: denis
*   date:   7/16/2018
*/

import React, { Component } from 'react';
import {
  View,
  ScrollView,
  Text,
  FlatList
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import { inject, observer } from 'mobx-react/native';

import Constants from '../../global/Constants';
import ShowHeader from '../components/HeaderBar/ShowHeader';
import ParallelButton from '../components/Common/ParallelButton';
import ShowItem from '../components/WeekGrocery/ShowItem';

const multilingual = Constants.Multilingual;
const ContainerView = glamorous(View)({
  flexDirection: "column",
  flex: 1,
  backgroundColor: Constants.Colors.whiteFive
});

const AddView = glamorous(View)({
  flexDirection: "row",
  justifyContent: "flex-end",
  paddingHorizontal: 15,
  marginVertical: 10
});

const AddedView = glamorous(View)({
  flexDirection: "row",
  justifyContent: "flex-start",
  paddingVertical: 15,
  paddingLeft: 30,
  marginVertical: 10,
  backgroundColor: Constants.Colors.whiteFive
});

const AddedItemText = glamorous(Text)({
  fontSize: 24,
  color: Constants.Colors.marineTwo
})
const { object, string } = Proptypes;
@inject('GroceryList', 'User') @observer
export default class WeekGrocery extends Component {
  static propTypes = {
    navigator: object,
    name: string,
    listName: string,
    GroceryList: object,
    User:object
  }

  constructor(props) {
    super(props);
  }

  toAddItem() {
    this.props.navigator.showModal({
      ...Constants.Screens.SEARCH_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      },
      passProps: {
        listName :this.props.listName
      }
    });
  }

  changeCheckFlag(name, addedItemFlag) {
    const { listName, GroceryList:{ setCheckFlag } } = this.props
    setCheckFlag( listName, name, addedItemFlag);
  }

  render() {
    const {
      listName,
      GroceryList,
      User: {
        isPremium,
        language,
      }
      } = this.props;
    let data =[];
    let addedData = []
    if (GroceryList.mealItemsGroceryList[listName]) {
      data = Object.values(GroceryList.mealItemsGroceryList[listName])
    }
    if (isPremium) {
      if (GroceryList.addedMealItemsGroceryList[listName]) {
        addedData = Object.values(GroceryList.addedMealItemsGroceryList[listName])
      }
    }
    return (
      <ContainerView>
        <ShowHeader
          title={this.props.name}
          navigator={this.props.navigator}
          hasNotify />
        <AddView>
          <ParallelButton
            title={multilingual.ADD_ITEM[language]}
            icon={"plus"}
            proc={ () => this.toAddItem() }/>
        </AddView>
        <ScrollView>
          <FlatList
            data={ data }
            renderItem={ ({item}) =>
              <ShowItem
                navigator={this.props.navigator}
                itemName={item.name}
                listName={listName}
                itemAmount={item.amount}
                changeCheckFlag={() => this.changeCheckFlag(item.name)}
                addedItemFlag={false} />
            }
            keyExtractor={(item, index) => index.toString()}
          />
          { isPremium &&
            <View>
              <AddedView>
                <AddedItemText>{multilingual.EXTRA_ITEMS[language]}</AddedItemText>
              </AddedView>
              <FlatList
              data={ addedData }
              renderItem={ ({item}) =>
                <ShowItem
                  navigator={this.props.navigator}
                  itemName={item.name}
                  listName={listName}
                  itemAmount={item.amount}
                  changeCheckFlag={() => this.changeCheckFlag(item.name, true)}
                  addedItemFlag={true} />
              }
              keyExtractor={(item, index) => index.toString()}
              />
            </View>
          }
        </ScrollView>
      </ContainerView>
    );
  }
}
