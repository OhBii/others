/*
*   author: denis
*   date:   11/12/2018
*/

import React, { Component } from 'react';
import {
  View
} from 'react-native';
import glamorous from 'glamorous-native';

import GplansLogoLoader from '../components/Common/GplansLoader'

const ContainerView = glamorous(View)({
  flexDirection: "column",
  flex: 1,
  backgroundColor: '#2A9AF1',
  alignItems: 'center',
  justifyContent: 'center'
});

export default class Loading extends Component {
  constructor(props) {
    super(props)
  }

  render() {
    return (
      <ContainerView>
        <GplansLogoLoader />
      </ContainerView>
    )
  }
}