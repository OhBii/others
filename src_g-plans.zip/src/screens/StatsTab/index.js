// @flow
import React, { Component } from 'react';
import Proptypes from 'prop-types';
import {
  ScrollView,
  View,
  Image,
  Text,
  Platform,
  //TouchableOpacity,
  Animated,
  ActivityIndicator,
  Alert,
} from 'react-native'
import {
  VictoryAxis,
  VictoryChart,
  VictoryArea,
  VictoryScatter,
  VictoryZoomContainer
} from 'victory-native'
import { inject, observer } from 'mobx-react'
import moment from 'moment'
import Converter from 'convert-units'
import LinearGradient from 'react-native-linear-gradient';
import glamorous from 'glamorous-native';
import FAIcon from 'react-native-vector-icons/FontAwesome';

import NavBar      from '../../global/NavBar';
import MainTitle from '../components/Common/MainTitle'
import SnowBox from '../components/Common/SnowBox'
import ShowHeader from '../components/HeaderBar/ShowHeader'
import Constants   from '../../global/Constants';
import { roundValue, numberWithCommas } from '../../utils/GlobalFunctions'
import CustomTabs from '../components/CustomTabs'

const multilingual = Constants.Multilingual;

const { height } = Constants.windowDimensions

const ContainerView = glamorous(View)({
  flex: 1,
  backgroundColor: Constants.Colors.paleGreyThree
})

const Wrap = glamorous(View)({
  height,
  paddingBottom: 75
})

const WrapView = glamorous(View)({
  elevation: 10
})

const AnimatedView = glamorous(Animated.View)

const WeekDayStatBar = AnimatedView(({ height }) => ({
  height: height || 0,
  position: 'absolute',
  bottom: 0,
  borderRadius: 10.5,
  backgroundColor: Constants.Colors.white,
  width: 12
}))

WeekDayStatBar.propsAreStyleOverrides = true

const HealthKitStatus = glamorous(View)({
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'flex-start',
  marginTop: -18,
  height: 20,
  marginBottom: 20,
})

const HealthKitStatusTxt = glamorous(Text)(({ active }) => ({
  fontSize: 14,
  color: active ? '#4A90E2' : '#7F7F7F',
}))

const HealthKitLoading = glamorous(ActivityIndicator)({
  marginRight: 6,
})

const HealthKitContainer = glamorous(View)({
  paddingHorizontal: 10,
  paddingTop: 10,
  paddingBottom: 0,
  borderRadius: 10,
  width: '100%',
  marginBottom: 30,
  shadowColor: 'rgba(0, 0, 0, 0.13)',
	shadowOffset: {
		width: 0,
		height: 12
	},
	shadowRadius: 14,
	shadowOpacity: 1,
  elevation: 12
})

const HealthKitChart = glamorous(View)({
  width: '100%',
  paddingVertical: 15
})

const HealthKitGradient = glamorous(LinearGradient)({
  position: 'absolute',
  top: 0,
  bottom: 0,
  right: 0,
  left: 0,
  borderRadius: 10,
  overflow: 'hidden'
})

const HealthKitTop = glamorous(View)({
  ...Constants.flex('row-reverse', 'flex-end', 'space-between'),
  borderBottomColor: '#FBFA6C',
  borderBottomWidth: 0.5,
  paddingBottom: 4,
})

const HealthKitLeft = glamorous(View)({
  ...Constants.flex('column', 'flex-start', 'flex-start'),
  flex: 1,
})

const HealthKitTitle = glamorous(Text)({
  fontSize: Platform.OS === 'ios' ? Constants.moderateScale(20, 1.2) : 20,
	color: '#ffffff',
  backgroundColor: 'transparent'
})

const HealthKitSubTitle = glamorous(Text)({
  fontSize: Platform.OS === 'ios' ? Constants.moderateScale(12, 1.2) : 12,
	color: '#FBFA6C',
  backgroundColor: 'transparent',
  fontWeight: '600'
})

const HealthKitRight = glamorous(View)({
  ...Constants.flex('column', 'flex-end', 'flex-end')
})

const HealthKitCurValue = glamorous(View)({
  ...Constants.flex('row', 'flex-end', 'flex-end')
})

const HealthKitValue = glamorous(Text)({
  fontSize: Platform.OS === 'ios' ? Constants.moderateScale(30, 1.2) : 30,
	fontWeight: '600',
	color: '#ffffff',
  backgroundColor: 'transparent',
  marginRight: 5
})

const HealthKitUnit = glamorous(Text)({
  fontSize: Platform.OS === 'ios' ? Constants.moderateScale(14, 1.2) : 14,
  fontWeight: '600',
  color: '#ffffff',
  backgroundColor: 'transparent',
  top: -6
})

const HealthKitTime = glamorous(Text)({
  fontSize: Platform.OS === 'ios' ? Constants.moderateScale(12, 1.2) : 12,
	color: '#FBFA6C',
  backgroundColor: 'transparent',
  fontWeight: '600'
})

/*const HealthKitRightTime = glamorous(Text)({
  fontSize: Platform.OS === 'ios' ? Constants.moderateScale(12, 1.2) : 12,
	textAlign: 'right',
	color: '#FBFA6C',
  width: '100%',
  backgroundColor: 'transparent',
  paddingVertical: 1
})*/

const HeaderChart = glamorous(View)({
  backgroundColor: Constants.Colors.white
})

const InfoLabels = glamorous(View)({
  width:'100%',
  flexDirection: 'row',
  justifyContent: 'center',
  marginTop: -100,
  marginBottom: 30
})

const InfoLabelsInner = glamorous(View)({
  width: '80%',
  alignItems: 'center',
  justifyContent: 'space-between',
  flexDirection: 'row'
})

const InfoLabelItem = glamorous(View)({
  flexDirection: 'row'
})

const InfoLabelItemLeft = glamorous(View)({
  width: 26
})

const InfoLabelScatter = glamorous(View)(({ color }) => ({
  width: 13,
  height: 13,
  backgroundColor: color || Constants.Colors.dodgerBlueTwo,
  borderRadius: 13 /2,
  top: 5
}))

const InfoLabelItemRight = glamorous(View)({
  flexDirection: 'column'
})

const InfoLabelTitle = glamorous(Text)({
  fontSize: 18,
  fontWeight: 'bold',
  letterSpacing: 0,
  color: Constants.Colors.brownGrey,
  marginBottom: 6
})

const InfoLabelData = glamorous(Text)({
  fontSize: 25,
  fontWeight: 'bold',
  color: Constants.Colors.greyishBrownThree
})

const VerticalDivider = glamorous(View)({
  borderStyle: 'solid',
  borderWidth: 1,
  borderColor: '#979797',
  height: '100%'
})

const Measurements = glamorous(View)({
  flexDirection: 'column',
  width: '100%',
  marginTop: 10
})

const MeasureItem = glamorous(View)({
  flexDirection: 'column',
  width: '100%',
  marginBottom: 15
})

const MeasureItemIcon = glamorous(Image)({
  marginBottom: 5
})

const MeasureItemWeight = glamorous(View)({
  flexDirection: 'row',
  justifyContent: 'space-between'
})

const MeasureItemLeft = glamorous(View)({
  flexDirection: 'column'
})

const MeasureItemRight = glamorous(View)({
  flexShrink: 1,
  flexDirection: 'column',
  alignItems: 'center',
  minWidth: 110
})

const TitleWeight1 = glamorous(Text)({
  fontSize: 14,
  fontWeight: 'bold',
  color: Constants.Colors.greyishBrown
})

const TitleWeight2 = glamorous(Text)({
  fontSize: 14,
  color: Constants.Colors.greyishBrown
})

const TitleTotal = glamorous(Text)({
  fontSize: 25,
  color: Constants.Colors.greyishBrown,
  marginTop: 4
})

const TitleUnit = glamorous(Text)({
  color: Constants.Colors.greyishBrown,
  paddingLeft: 5,
  fontSize: 12,
})

const TotalArrow = glamorous(View)({
  flexDirection: 'row',
  justifyContent: 'center',
  alignItems: 'center',
  marginTop: 12
})

const ArrowText = glamorous(Text)({
  color: Constants.Colors.greyishBrown,
  fontSize: 14
})

const ArrowIcon = glamorous(FAIcon)({
  marginLeft: 12
})

const LabelItem = ({ color, title, data, unit } = this.props) =>
  <InfoLabelItem>
    <InfoLabelItemLeft>
      <InfoLabelScatter color={color} />
    </InfoLabelItemLeft>
    <InfoLabelItemRight>
      <InfoLabelTitle>{ title }</InfoLabelTitle>
      <InfoLabelData>{ `${data} ${unit}` }</InfoLabelData>
    </InfoLabelItemRight>
  </InfoLabelItem>

const { object } = Proptypes;
@inject( 'User', 'MealPlan', 'WaterTrack', 'DayIndex', 'HealthKit', 'Checkin' ) @observer
class StatsTab extends Component {
  static navigatorStyle   = NavBar.Default

  static propTypes = {
    App: object,
    navigator: object,
    Account: object,
    User: object,
    MealPlan: object,
    WaterTrack: object,
    DayIndex: object,
    HealthKit: object,
    Checkin: object
  }

  constructor(props) {
    super(props);

    this.state = {
      changingHealthkit: false,
    }
    this.isConnecting = false
  }

  onSelect(index) {
    this.props.DayIndex.plannerDayIndex = index;
  }

  getRoundedDistance(value, dstUnit) {
    // value is mile value
    const mValue = Converter(value).from('mi').to('m')
    if (dstUnit) {
      if (dstUnit === 'mi') return roundValue(value, 2)
      else if (dstUnit === 'ft') return roundValue(Converter(value).from('mi').to('ft-us'), 1)
      else if (dstUnit === 'km') return roundValue(mValue / 1000, 2)
      else roundValue(mValue, 1)
    }
    if (this.props.User.unit === 'us') {
      if (value >= 0.1) return roundValue(value, 2)
      else return roundValue(Converter(value).from('mi').to('ft-us'), 1)
    } else {
      if (mValue >= 100) return roundValue(mValue / 1000, 2)
      else return roundValue(mValue, 1)
    }
  }

  getDistanceUnit(value) {
    // value is mile value
    if (this.props.User.unit === 'us') {
      if (value >= 0.1) return 'mi'
      else return 'mi'//'ft'
    } else {
      const mValue = Converter(value).from('mi').to('m')
      if (mValue >= 100) return 'km'
      else return 'km'//'m'
    }
  }

  render() {
    const {
      User: {
        userInfo: { last_checkin, first_checkin },
        language,
      },
      MealPlan,
      WaterTrack,
      DayIndex,
      HealthKit: {
        isEnabledHealthKit,
        setHealthKitFlag,
        weightsGraphData,
        stepsGraphData,
        distancesGraphData,
      },
      Checkin
    } = this.props
    const currentLanguage = language

    // adjust distance
    const distancesDataTmp = distancesGraphData
    const currentDayUnit = this.getDistanceUnit(distancesDataTmp.currentDayDistance)
    let distancesData
    if (distancesDataTmp.averageDistance === 0) {
      distancesData = distancesDataTmp
      distancesData.unit = currentDayUnit
    } else {
      distancesData = {
        currentDayDistance: this.getRoundedDistance(distancesDataTmp.currentDayDistance, currentDayUnit),
        maxVal: this.getRoundedDistance(distancesDataTmp.maxVal, currentDayUnit),
        averageDistance: this.getRoundedDistance(distancesDataTmp.averageDistance, currentDayUnit),
        graph: distancesDataTmp.graph.map(el => ({
          x: el.x,
          y: this.getRoundedDistance(el.y, currentDayUnit)
        })),
        unit: currentDayUnit,
      }
    }

    // adjust weight
    const weightsDataTmp = weightsGraphData
    let weightsData
    if (weightsDataTmp.averageWeight === 0) {
      weightsData = weightsDataTmp
      weightsData.unit = Checkin.getWeightUnit
    } else {
      weightsData = {
        currentDayWeight: Checkin.getRoundedWeight(weightsDataTmp.currentDayWeight),
        maxVal: Checkin.getRoundedWeight(weightsDataTmp.maxVal),
        averageWeight: Checkin.getRoundedWeight(weightsDataTmp.averageWeight),
        graph: weightsDataTmp.graph.map(el => ({
          x: el.x,
          y: Checkin.getRoundedWeight(el.y)
        })),
        unit: Checkin.getWeightUnit,
      }
    }

    const startOfWeek = moment(last_checkin.created_at);
    const weekDays = Array(7).fill(0).map((item, index) => {
      return moment(startOfWeek).add(index, 'd');
    })

    const dataFood = Array(9).fill(0).reduce((accumulator, value, index) => {
      if (index == 0) {
        accumulator.push({x: index, y: 0});
      }
      else if (index <= (DayIndex.homeDayIndex + 1)) {
        const percent = MealPlan.getPercentageOfWeek[index - 1].percent;
        // const displayPercent = percent > 100
        //   ? 100
        //   : percent
        accumulator.push({x: index, y: percent});
      }
      else {
        accumulator.push({x: index, y: 0});
      }

      return accumulator;
    }, []);

    const dataWater = Array(9).fill(0).reduce((accumulator, value, index) => {
      if (index == 0) {
        accumulator.push({x: index, y: 0});
      }
      else if (index <= (DayIndex.homeDayIndex + 1)) {
        const percent = WaterTrack.getPercentageOfWeek[index - 1].percent;
        // const displayPercent = percent > 100
        //   ? 100
        //   : percent
        accumulator.push({x: index, y: percent});
      }
      else {
        accumulator.push({x: index, y: 0});
      }

      return accumulator;
    }, []);

    const currentWeight = Checkin.getRoundedWeight(last_checkin.weight)
    const firstWeight = Checkin.getRoundedWeight(first_checkin.weight)
    const percentOfWeight = Math.round((currentWeight - firstWeight) / firstWeight * 100)

    const { firstBodyFat, currentBodyFat } = Checkin.getBodyFat
    const percentOfBodyFat = currentBodyFat - firstBodyFat

    return (
      <Wrap>
        <ContainerView>
          <WrapView>
            <ShowHeader
              title={'Progress'}
              hasNotify
              hasBack={false}
              navigator={this.props.navigator}
            />
          </WrapView>
          <ScrollView bounces={false}>

              <HeaderChart>
                <VictoryChart
                  maxDomain={{ y: 107 }}
                  domain={{ y: [0, 100] }}
                  domainPadding={{ x: 20, y: 20 }}
                  padding={{ top: 0, bottom: 160, left: 0, right: 0 }}
                  height={360}
                >
                  <VictoryAxis
                    tickFormat={weekDays.map((day) => moment(day, 'MMM DD').format('MM/DD'))}
                    style={{
                      axis: { stroke: '#ffffff', strokeOpacity: 0, strokeWidth: 0, size: 0 },
                      grid: { stroke: '#3F65CB', strokeOpacity: 0.2, strokeWidth: 0.5 },
                      ticks: { stroke: '#ffffff', strokeOpacity: 0, strokeWidth: 0, size: 0},
                      tickLabels: { fontSize: 10, bottom: 125, fill: Constants.Colors.greyishBrownThree, opacity: 1 }
                    }}
                  />
                  <VictoryAxis
                    dependentAxis
                    style={{
                      axis: { stroke: '#ffffff', strokeOpacity: 0, strokeWidth: 0 },
                      grid: { stroke: '#3F65CB', strokeOpacity: 0.2, strokeWidth: 0.5 },
                      ticks: { stroke: '#ffffff', strokeOpacity: 0, strokeWidth: 0, size: 0 },
                      tickLabels: { fontSize: 10, fontWeight: '500', paddingTop: 0, fill: Constants.Colors.dodgerBlueTwo, opacity: 1 }
                    }}
                    offsetX={45}
                    tickFormat={ (y) => y + '%' }
                  />
                    <VictoryArea
                      key={'area'}
                      height={110}
                      standalone={false}
                      interpolation={"catmullRom"}
                      animate={{ duration: 400 }}
                      style={{
                        data: {
                          stroke: Constants.Colors.dodgerBlueTwo,
                          strokeWidth: 2,
                          fill: 'rgb(203, 242, 255)',
                          fillOpacity: 0.1
                        }
                      }}
                      data={dataFood}
                    />
                    <VictoryArea
                      key={'area'}
                      height={110}
                      standalone={false}
                      interpolation={"catmullRom"}
                      animate={{ duration: 400 }}
                      style={{
                        data: {
                          stroke: '#06e6ff',
                          strokeWidth: 2,
                          fill: 'rgb(210, 210, 210)',
                          fillOpacity: 0.1
                        }
                      }}
                      data={dataWater}
                    />
                </VictoryChart>
                <InfoLabels>
                  <InfoLabelsInner>
                    <LabelItem
                      title={'Meals'}
                      data={MealPlan.PercentageToDay.calories.data}
                      unit={'%'}
                    />
                    <VerticalDivider />
                    <LabelItem
                      title={'Water'}
                      data={WaterTrack.percentageOfTrack}
                      color={'#2eebff'}
                      unit={'%'}
                    />
                  </InfoLabelsInner>
                </InfoLabels>
              </HeaderChart>

              <SnowBox>
                <MainTitle
                  title={'Measurments'}
                  onMore={() => {}}
                  moreText={'Edit'}
                  />
                  <Measurements>
                    <MeasureItem>
                      <MeasureItemIcon source={Constants.Images.ICON_MEASURE1}/>
                      <MeasureItemWeight>
                      <MeasureItemLeft>
                        <TitleWeight1>{'Current Weight'}</TitleWeight1>
                        <TitleTotal>
                          { currentWeight }
                          <TitleUnit>{ Checkin.getWeightUnit }</TitleUnit>
                        </TitleTotal>
                      </MeasureItemLeft>
                      <MeasureItemRight>
                        <TitleWeight2>
                          {`Starting: ${firstWeight}`}
                          <TitleUnit>{ Checkin.getWeightUnit }</TitleUnit>
                        </TitleWeight2>
                        <TotalArrow>
                          <ArrowText>{`${Math.abs(percentOfWeight)}%`}</ArrowText>
                          {
                            percentOfWeight >= 0
                              ? <ArrowIcon name='arrow-circle-up' size={20} color={Constants.Colors.blackTwo} />
                              : <ArrowIcon name='arrow-circle-down' size={20} color={Constants.Colors.dodgerBlueTwo} />
                          }
                        </TotalArrow>
                      </MeasureItemRight>
                      </MeasureItemWeight>
                    </MeasureItem>

                    <MeasureItem>
                      <MeasureItemIcon source={Constants.Images.ICON_MEASURE3}/>
                      <MeasureItemWeight>
                      <MeasureItemLeft>
                        <TitleWeight1>{'Body Fat Percentage'}</TitleWeight1>
                        <TitleTotal>{`${currentBodyFat}%`}</TitleTotal>
                      </MeasureItemLeft>
                      <MeasureItemRight>
                        <TitleWeight2>{`Starting: ${firstBodyFat}%`}</TitleWeight2>
                        <TotalArrow>
                          <ArrowText>{`${percentOfBodyFat}%`}</ArrowText>
                          {
                            percentOfBodyFat >= 0
                              ? <ArrowIcon name='arrow-circle-up' size={20} color={Constants.Colors.dodgerBlueTwo} />
                              : <ArrowIcon name='arrow-circle-down' size={20} color={Constants.Colors.blackTwo} />
                          }
                        </TotalArrow>
                      </MeasureItemRight>
                      </MeasureItemWeight>
                    </MeasureItem>
                  </Measurements>
              </SnowBox>

              <SnowBox>
              <MainTitle
                title={Constants.platform === 'ios' ? multilingual.APPLE_HEALTH_KIT[currentLanguage] : multilingual.GOOGLE_FIT[currentLanguage]}
                value={isEnabledHealthKit}
                onSwitch={value => {
                  this.isConnecting = !isEnabledHealthKit
                  this.setState({ changingHealthkit: true })
                  setHealthKitFlag(value)
                    .then(() => setTimeout(() => this.setState({ changingHealthkit: false }), 500))
                    .catch(() => {
                      Alert.alert('Sorry, couldn\'t connect with server!')
                      this.setState({ changingHealthkit: false })
                    })
                }}
              />
              <HealthKitStatus>
                {this.state.changingHealthkit &&
                  <HealthKitLoading
                    size={'small'}
                    color={this.isConnecting ? '#4A90E2' : '#7F7F7F'}
                  />
                }
                <HealthKitStatusTxt
                  active={isEnabledHealthKit}
                >
                  {this.state.changingHealthkit ? (this.isConnecting ? 'CONNECTING' :  'DISCONNECTING') : (isEnabledHealthKit ? 'CONNECTED' : 'DISCONNECTED')}
                </HealthKitStatusTxt>
              </HealthKitStatus>

              <HealthKitContainer>
                <HealthKitGradient
                  colors={['rgb(236,64,50)', 'rgb(238,136,65)', 'rgb(209,121,57)']}
                  start={{ x: 0, y: 0.9 }}
                  end={{ x: 0, y: -0.6 }}
                />
                <HealthKitTop>
                  <HealthKitRight>
                    <HealthKitCurValue>
                      <HealthKitValue>{`${numberWithCommas(stepsGraphData.currentDayStep)}`}</HealthKitValue>
                      <HealthKitUnit>{'steps'}</HealthKitUnit>
                    </HealthKitCurValue>
                    <HealthKitTime>{`Today, ${moment().format('LT')}`}</HealthKitTime>
                  </HealthKitRight>
                  <HealthKitLeft>
                    <HealthKitTitle>{ multilingual.STEPS[currentLanguage] }</HealthKitTitle>
                    <HealthKitSubTitle>{ `${multilingual.DAILY_AVG[currentLanguage]} ${numberWithCommas(stepsGraphData.averageStep)}` }</HealthKitSubTitle>
                  </HealthKitLeft>
                </HealthKitTop>
                <HealthKitChart>
                  <VictoryChart
                    domain={{ y: [0, stepsGraphData.maxVal] }}
                    domainPadding={{ x: 0, y: 0 }}
                    padding={{ top: 5, bottom: 15, left: 35, right: 80 }}
                    height={80}
                  >
                    <VictoryAxis
                      style={{
                        axis: { stroke: '#ffffff', strokeOpacity: 0.5, strokeWidth: 0.5 },
                        grid: { stroke: '#ffffff', strokeOpacity: 0, strokeWidth: 0 },
                        ticks: { stroke: '#ffffff', strokeOpacity: 0, strokeWidth: 0, size: 0 },
                        tickLabels: { fontSize: 11, padding: 5, fill: '#ffffff', opacity: 0.8 }
                      }}
                    />
                    <VictoryAxis
                      dependentAxis
                      tickValues={[0, stepsGraphData.maxVal]}
                      style={{
                        axis: { stroke: '#ffffff', strokeOpacity: 0, strokeWidth: 0 },
                        grid: { stroke: '#ffffff', strokeOpacity: 0.5, strokeWidth: 0.5 },
                        ticks: { stroke: '#ffffff', strokeOpacity: 0, strokeWidth: 0, size: 5 },
                        tickLabels: { fontSize: 11, padding: 5, fill: '#ffffff', opacity: 0.8 }
                      }}
                    />

                      <VictoryArea
                        key={'area'}
                        height={110}
                        standalone={false}
                        style={{
                          data: {
                            stroke: '#fff',
                            strokeWidth: 1,
                            fill: '#FDBD5E',
                            fillOpacity: 0.2
                          }
                        }}
                        data={stepsGraphData.graph}
                      />
                      <VictoryScatter
                        key={'scatter'}
                        style={{ data: {
                                  fill: 'rgb(238,136,65)',
                                  stroke: '#fff',
                                  strokeWidth: 1
                              } }}
                        size={2}
                        data={stepsGraphData.graph}
                      />
                  </VictoryChart>
                </HealthKitChart>
              </HealthKitContainer>

              {/*<HealthKitContainer>
                <HealthKitGradient
                  colors={['rgb(236,64,50)', 'rgb(238,136,65)', 'rgb(209,121,57)']}
                  start={{ x: 0, y: 0.9 }}
                  end={{ x: 0, y: -0.6 }}
                />
                <HealthKitTop>
                  <HealthKitCurValue>
                    <HealthKitValue>{`${distancesData.currentDayDistance}`}</HealthKitValue>
                    <HealthKitUnit>{distancesData.unit}</HealthKitUnit>
                  </HealthKitCurValue>
                  <HealthKitLeft>
                    <HealthKitTitle>{ multilingual.WALKING_RUNNING_DISTANCE[currentLanguage] }</HealthKitTitle>
                    <HealthKitSubTitle>
                      { `${multilingual.DAILY_AVG[currentLanguage]} ${distancesData.averageDistance}` }
                    </HealthKitSubTitle>
                  </HealthKitLeft>
                </HealthKitTop>
                <HealthKitRightTime>{ multilingual.TIME_TITLE[currentLanguage] }</HealthKitRightTime>
                <HealthKitChart>
                  <VictoryChart
                    domain={{ y: [0, distancesData.maxVal] }}
                    domainPadding={{ x: 0, y: 0 }}
                    padding={{ top: 5, bottom: 15, left: 35, right: 80 }}
                    height={80}
                  >
                    <VictoryAxis
                      style={{
                        axis: { stroke: '#ffffff', strokeOpacity: 0.5, strokeWidth: 0.5 },
                        grid: { stroke: '#ffffff', strokeOpacity: 0, strokeWidth: 0 },
                        ticks: { stroke: '#ffffff', strokeOpacity: 0, strokeWidth: 0, size: 0 },
                        tickLabels: { fontSize: 11, padding: 5, fill: '#ffffff', opacity: 0.8 }
                      }}
                    />
                    <VictoryAxis
                      dependentAxis
                      tickValues={[0, distancesData.maxVal]}
                      style={{
                        axis: { stroke: '#ffffff', strokeOpacity: 0, strokeWidth: 0 },
                        grid: { stroke: '#ffffff', strokeOpacity: 0.5, strokeWidth: 0.5 },
                        ticks: { stroke: '#ffffff', strokeOpacity: 0, strokeWidth: 0, size: 5 },
                        tickLabels: { fontSize: 11, padding: 5, fill: '#ffffff', opacity: 0.8 }
                      }}
                    />

                      <VictoryArea
                        key={'area'}
                        height={110}
                        standalone={false}
                        style={{
                          data: {
                            stroke: '#fff',
                            strokeWidth: 1,
                            fill: '#FDBD5E',
                            fillOpacity: 0.2
                          }
                        }}
                        data={distancesData.graph}
                      />
                      <VictoryScatter
                        key={'scatter'}
                        style={{ data: {
                                  fill: 'rgb(238,136,65)',
                                  stroke: '#fff',
                                  strokeWidth: 1
                              } }}
                        size={2}
                        data={distancesData.graph}
                      />
                  </VictoryChart>
                </HealthKitChart>
                            </HealthKitContainer>*/}

              <HealthKitContainer>
                <HealthKitGradient
                  colors={['#FFA500','#FFBF00','#FFD300']}
                  start={{ x: 0, y: 0.9 }}
                  end={{ x: 0, y: 0 }}
                />
                <HealthKitTop>
                  <HealthKitRight>
                    <HealthKitCurValue>
                      <HealthKitValue>{`${weightsData.currentDayWeight}`}</HealthKitValue>
                      <HealthKitUnit>{weightsData.unit}</HealthKitUnit>
                    </HealthKitCurValue>
                    <HealthKitTime>{`Today, ${moment().format('LT')}`}</HealthKitTime>
                  </HealthKitRight>
                  <HealthKitLeft>
                    <HealthKitTitle>{ multilingual.WEIGHT_TITLE[currentLanguage] }</HealthKitTitle>
                    <HealthKitSubTitle>{ `${multilingual.DAILY_AVG[currentLanguage]} ${weightsData.averageWeight}` }</HealthKitSubTitle>
                  </HealthKitLeft>
                </HealthKitTop>
                <HealthKitChart>
                  <VictoryChart
                    domain={{ y: [0, weightsData.maxVal] }}
                    domainPadding={{ x: 0, y: 0 }}
                    padding={{ top: 5, bottom: 15, left: 35, right: 80 }}
                    height={80}
                  >
                    <VictoryAxis
                      style={{
                        axis: { stroke: '#ffffff', strokeOpacity: 0.5, strokeWidth: 0.5 },
                        grid: { stroke: '#ffffff', strokeOpacity: 0, strokeWidth: 0 },
                        ticks: { stroke: '#ffffff', strokeOpacity: 0, strokeWidth: 0, size: 0 },
                        tickLabels: { fontSize: 11, padding: 5, fill: '#ffffff', opacity: 0.8 }
                      }}
                    />
                    <VictoryAxis
                      dependentAxis
                      tickValues={[0, weightsData.maxVal]}
                      style={{
                        axis: { stroke: '#ffffff', strokeOpacity: 0, strokeWidth: 0 },
                        grid: { stroke: '#FBFA6C', strokeOpacity: 1, strokeWidth: 0.5 },
                        ticks: { stroke: '#ffffff', strokeOpacity: 0, strokeWidth: 0, size: 5 },
                        tickLabels: { fontSize: 11, padding: 5, fill: '#ffffff', opacity: 0.8 }
                      }}
                    />

                      <VictoryArea
                        key={'area'}
                        height={110}
                        standalone={false}
                        style={{
                          data: {
                            stroke: '#fff',
                            strokeWidth: 1,
                            fill: '#FBFA6C',
                            fillOpacity: 0.15
                          }
                        }}
                        data={weightsData.graph}
                      />
                      <VictoryScatter
                        key={'scatter'}
                        style={{ data: {
                                  fill: 'rgb(238,136,65)',
                                  stroke: '#fff',
                                  strokeWidth: 1
                              } }}
                        size={2}
                        data={weightsData.graph}
                      />
                  </VictoryChart>
                </HealthKitChart>
              </HealthKitContainer>
            </SnowBox>

            <SnowBox noPad>
              <HeaderChart>
                <MainTitle title={'Hips & Waist'} hrPad={Constants.mainPadding}/>
                <VictoryChart
                  maxDomain={{ y: 107 }}
                  domain={{ y: [0, 100] }}
                  domainPadding={{ x: 0, y: 20 }}
                  padding={{ top: 0, bottom: 160, left: 20, right: 20 }}
                  height={360}
                  containerComponent={
                    <VictoryZoomContainer
                      allowPan={true}
                      allowZoom={false}
                      zoomDomain={{
                        x: Checkin.getHipsAndWaist.count > 3
                          ? [Checkin.getHipsAndWaist.count - 3, Checkin.getHipsAndWaist.count]
                          : [1, Checkin.getHipsAndWaist.count]
                      }}
                    />
                  }
                >
                  <VictoryAxis
                    tickFormat={(index) => {
                      const res = Number.isInteger(index)
                        ? moment(Checkin.getHipsAndWaist.createdAt[index - 1]).format('MM/DD')
                        : ''
                      return res
                    }}
                    style={{
                      axis: { stroke: '#ffffff', strokeOpacity: 0, strokeWidth: 0, size: 0 },
                      grid: { stroke: '#3F65CB', strokeOpacity: 0.2, strokeWidth: 0.5 },
                      ticks: { stroke: '#ffffff', strokeOpacity: 0, strokeWidth: 0, size: 0},
                      tickLabels: { fontSize: 10, bottom: 125, fill: Constants.Colors.greyishBrownThree, opacity: 1 }
                    }}
                  />
                  <VictoryAxis
                    dependentAxis
                    style={{
                      axis: { stroke: '#ffffff', strokeOpacity: 0, strokeWidth: 0 },
                      grid: { stroke: '#3F65CB', strokeOpacity: 0.2, strokeWidth: 0.5 },
                      ticks: { stroke: '#ffffff', strokeOpacity: 0, strokeWidth: 0, size: 0 },
                      tickLabels: { fontSize: 10, fontWeight: '500', paddingTop: 0, fill: Constants.Colors.dodgerBlueTwo, opacity: 1 }
                    }}
                    offsetX={60}
                    tickFormat={ (y) => Checkin.getRoundedHipsAndWaist(y)  + ' ' + Checkin.getHipsAndWaistUnit }
                  />
                    <VictoryArea
                      key={'area'}
                      height={110}
                      standalone={false}
                      interpolation={"catmullRom"}
                      animate={{ duration: 400 }}
                      style={{
                        data: {
                          stroke: Constants.Colors.dodgerBlueTwo,
                          strokeWidth: 2,
                          fill: 'rgb(203, 242, 255)',
                          fillOpacity: 0.1
                        }
                      }}
                      data={Checkin.getHipsAndWaist.hips.map((hips, index) => {
                        return {
                          x: (index + 1),
                          y: hips
                        }
                      })}
                      x='x'
                      y='y'
                    />
                    <VictoryArea
                      key={'area'}
                      height={110}
                      standalone={false}
                      interpolation={"catmullRom"}
                      animate={{ duration: 400 }}
                      style={{
                        data: {
                          stroke: '#06e6ff',
                          strokeWidth: 2,
                          fill: 'rgb(210, 210, 210)',
                          fillOpacity: 0.1
                        }
                      }}
                      data={Checkin.getHipsAndWaist.waist.map((waist, index) => {
                        return {
                          x: (index + 1),
                          y: waist
                        }
                      })}
                      x='x'
                      y='y'
                    />
                </VictoryChart>
                <InfoLabels>
                  <InfoLabelsInner>
                    <LabelItem
                      title={'Hips'}
                      data={Checkin.getRoundedHipsAndWaist(Checkin.getHipsAndWaist.lastHips)}
                      unit={Checkin.getHipsAndWaistUnit}
                    />
                    <VerticalDivider />
                    <LabelItem
                      title={'Waist'}
                      data={Checkin.getRoundedHipsAndWaist(Checkin.getHipsAndWaist.lastWaist)}
                      color={'#2eebff'}
                      unit={Checkin.getHipsAndWaistUnit}
                    />
                  </InfoLabelsInner>
                </InfoLabels>
              </HeaderChart>
            </SnowBox>
          </ScrollView>
        </ContainerView>
        <CustomTabs navigator={this.props.navigator} active={2}/>
      </Wrap>
    );
  }
}

export default StatsTab
