import React, { Component } from 'react'
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  Animated,
  Platform,
  Alert,
} from 'react-native'
import Icon from 'react-native-vector-icons/MaterialIcons'
import { inject, observer } from 'mobx-react/native'
import Proptypes from 'prop-types'
import glamorous from 'glamorous-native'
import LinearGradient from 'react-native-linear-gradient'
import { CachedImage, ImageCacheProvider } from 'react-native-cached-image'

import MealInfo from '../components/DiaryAndPlanner/MealInfo'
import Ingredients from '../components/DiaryAndPlanner/Ingredients'
import SnowBox from '../components/Common/SnowBox'
import RecipeItemTracked from '../components/Recipe/RecipeItemTracked'
import RecipeItemMissed from '../components/Recipe/RecipeItemMissed'
import Constants from '../../global/Constants'

const multilingual = Constants.Multilingual;
const { height } = Constants.windowDimensions

const HEADER_MAX_HEIGHT = height * 0.4
const HEADER_MIN_HEIGHT = height * 0.12
const HEADER_PARALLAX = HEADER_MAX_HEIGHT * 0.55
const HEADER_SCROLL_DISTANCE = HEADER_MAX_HEIGHT - HEADER_MIN_HEIGHT
const ICON_SCROLL_DISTANCE = Platform.OS === 'ios' ? HEADER_SCROLL_DISTANCE - 10 : HEADER_SCROLL_DISTANCE - 20
const glamorousAnimatedView = glamorous(Animated.View)
const glamorousAnimatedImage = glamorous(Animated.View)
const AnimatedScrollView = glamorous(Animated.ScrollView)

const ContainerView = glamorous(View)({
  flexDirection: "column",
  flex: 1,
  backgroundColor: Constants.Colors.white
});

const RecipeHeader = glamorousAnimatedView({
  flexDirection: 'column',
  width: '100%',
  height: HEADER_MAX_HEIGHT,
  position: 'absolute',
  left: 0,
  top: 0,
  zIndex: 2,
  overflow: 'hidden',
  backgroundColor: '#fff'
})

RecipeHeader.propsAreStyleOverrides = true

const Inner = glamorous(View)({
  flex: 1,
  backgroundColor: Constants.Colors.paleGreyThree,
  marginTop: HEADER_MAX_HEIGHT,
  //minHeight: height - HEADER_MIN_HEIGHT
})

const AnimatedImage = glamorousAnimatedImage({
  position: 'absolute',
  width: '100%',
  height: '100%'
})

AnimatedImage.propsAreStyleOverrides = true

const RecipeImage = glamorous(CachedImage) ({
  width: '100%',
  height: '100%'
})

const RecipeHeaderTop = glamorousAnimatedView({
  flexDirection: 'row',
  width: '100%',
  alignItems: 'center',
  justifyContent: 'space-between',
  marginTop: 40,
  paddingHorizontal: Constants.mainPadding
})

RecipeHeaderTop.propsAreStyleOverrides = true

const IconBack = glamorous(Image)({
  width: 20,
  height: 37
})

const AnimateHeadGradient = glamorousAnimatedView({
  position: 'absolute',
  top: 0,
  left: 0,
  right: 0,
  bottom: 0
})

AnimateHeadGradient.propsAreStyleOverrides = true

const Overlay = glamorous(LinearGradient)({
  width: '100%',
  height: '100%',
  position: 'absolute',
  left: 0,
  top: 0
})

const Footer = glamorous(View)({
  flexDirection: 'row',
  marginTop: 20,
  marginBottom: 30,
  marginHorizontal: Constants.mainPadding,
  justifyContent: 'space-between',
  borderRadius: 30,
  borderWidth: 1,
  borderStyle: 'solid',
  borderColor: Constants.Colors.dodgerBlueFour,
  backgroundColor: Constants.Colors.white,
})

const MainScroll = AnimatedScrollView({
  flex: 1,
  zIndex: 1
})

const RecipeFlexWrap = glamorousAnimatedView({
  position: 'absolute',
  top: 80,
  left: 0,
  right: 0,
  bottom: 0,
  flexDirection: 'column',
  justifyContent: 'flex-start',
  alignItems: 'center'
})
RecipeFlexWrap.propsAreStyleOverrides = true;

const RecipeFlexCircle = glamorous(View)({
  width: 129,
  height: 133,
  alignItems: 'center',
  justifyContent: 'center'
})

const CircleTracked = glamorous(Image)({
  width: 129,
  height: 133,
  position: 'absolute',
  left: 0,
  top: 0
})

const CircleCount = glamorous(Text)({
  fontSize: 36,
  fontWeight: "bold",
  letterSpacing: 0,
  color: Constants.Colors.white
})

const RecipeFlex = ({ count, opacityFlex } = this.props) =>
  <RecipeFlexWrap opacity={opacityFlex}>
    <RecipeFlexCircle>
      <CircleTracked
        source={Constants.Images.CIRCLE_TRACKED}
      />
      <CircleCount>{ count }</CircleCount>
    </RecipeFlexCircle>
  </RecipeFlexWrap>

const WrapView = glamorous(View)({
  backgroundColor: Constants.Colors.white,
  paddingHorizontal: Constants.mainPadding,
  paddingVertical: 10
})

const FooterView = glamorous(LinearGradient) ({
  position: 'absolute',
  bottom: 0,
  width: '100%',
  zIndex: 3
})

const ActionButton = glamorous(TouchableOpacity) (({ hasBorder = true }) => ({
  flexDirection: 'row',
  justifyContent: 'center',
  alignItems: 'center',
  flex: 1,
  paddingVertical: 12,
  borderRadius: hasBorder ? 0 : 30,
  borderWidth: hasBorder ? 0 : 1,
  borderStyle: 'solid',
  borderColor: Constants.Colors.dodgerBlueFour
}))

const ActionText = glamorous(Text) ({
  marginLeft: 7,
  fontSize: 15,
  color: Constants.Colors.dodgerBlueFour
})

const EmptyView = glamorous(View) ({
  height: 70,
  backgroundColor: Constants.Colors.white
})

const { object, number, bool } = Proptypes;
@inject('Recipe', 'MealPlan', 'User', 'DayIndex') @observer
export default class MealDetailScreen extends Component {
  static propTypes = {
    navigator: object,
    Recipe: object,
    MealPlan: object,
    User: object,
    MealId: number,
    backType: bool,
    DayIndex: object
  }

  static defaultProps = {
    backType: true
  }

  constructor(props) {
    super(props);

    const meal = this.props.MealPlan.getMealById(this.props.MealId);

    const logged = meal.logged ? meal.logged : false;
    const missed = meal.skipped ? meal.skipped : false;

    this.state = {
      trackItems: [],
      data: meal,
      logged: logged,
      missed: missed,
      scrollY: new Animated.Value(0),
      image: meal.image.medium,
      title: meal.label,
      animVal: !logged
        ? { percent: 0, pro: 0, fats: 0, carbs: 0 }
        : { ...this.props.MealPlan.getPercentage(this.props.MealId) },
      ...this.props.MealPlan.getPFCByMealId(this.props.MealId)
    }
  }

  setTrackItems (trackItems) {
    this.setState({
      trackItems: trackItems
    })
  }

  onConfirmTrack() {
    const {
      MealPlan: {
        getMealById,
        currentWeekNumber,
      },
      DayIndex: { homeDayIndex },
      User: { language, isFreemium },
      MealId,
      navigator,
    } = this.props

    if (!isFreemium) {
      const currentMeal = getMealById(MealId)
      if (currentMeal.day_number !== homeDayIndex + 1 ||
          currentMeal.week_number !== currentWeekNumber) {
        Alert.alert(multilingual.MSG_CANNOT_TRACK_NONTODAY_MEAL[language])
        return
      }
    }

    navigator.showLightBox({
      ...Constants.Screens.CUSTOM_DIALOG_SCREEN,
      style: {
        backgroundColor: "#000000a0",
        tapBackgroundToDismiss: false
      },
      passProps: {
        title: `${multilingual.READY_TO_TRACK_THIS_MEAL[language]}`,
        text: `${multilingual.TRACKING_THIS_MEAL[language]}`,
        children: () =>
          <ActionButton
            onPress={() => this.onTrack()}
            hasBorder={false}
          >
            <Icon name="check" size={18} color={Constants.Colors.dodgerBlueFour} />
            <ActionText>{ multilingual.TRACK[language] }</ActionText>
          </ActionButton>
      }
    });
  }

  onConfirmMissed() {
    const {
      MealPlan: {
        getMealById,
        currentWeekNumber,
      },
      DayIndex: { homeDayIndex },
      User: { language, isFreemium },
      MealId,
      navigator,
    } = this.props

    if (!isFreemium) {
      const currentMeal = getMealById(MealId)
      if (currentMeal.day_number !== homeDayIndex + 1 ||
          currentMeal.week_number !== currentWeekNumber) {
        Alert.alert(multilingual.MSG_CANNOT_TRACK_NONTODAY_MEAL[language])
        return
      }
    }

    navigator.showLightBox({
      ...Constants.Screens.CUSTOM_DIALOG_SCREEN,
      style: {
        backgroundColor: "#000000a0",
        tapBackgroundToDismiss: false
      },
      passProps: {
        title: `${multilingual.DID_YOU_MISS_THIS_MEAL[language]}`,
        text: `${multilingual.TRACKING_THIS_MEAL_WIL_CHECK[language]}`,
        children: () =>
          <ActionButton
            onPress={() => this.onMissed()}
            hasBorder={false}
          >
            <Icon name="clear" size={18} color={Constants.Colors.dodgerBlueFour} />
            <ActionText>{ multilingual.MISSED_MEAL[language] }</ActionText>
          </ActionButton>
      }
    });
  }

  onTrack() {
    const {
      MealPlan: {
        trackMeal,
        getPercentage,
      },

      MealId,
      navigator,
    } = this.props

    const { trackItems } = this.state

    trackMeal(MealId, trackItems)
    .then(() => {
      navigator.dismissLightBox()
      this.setState({
        animVal: {
          ...getPercentage(MealId)
        }
      })
      setTimeout(() => {
        this.setState({
          logged : true
        })
      }, 10)
      setTimeout(() => {
        this.toBack()
      }, 1000)
    })
    .catch(() => {
      // console.log(e)
    })
  }

  onMissed() {
    const {
      MealPlan: { skipMeal },
      MealId,
      navigator,
    } = this.props
    skipMeal(MealId)
    .then(() => {
      navigator.dismissLightBox()
      setTimeout(() => {
        this.setState({
          missed : true,
        })
      }, 10)
      setTimeout(() => {
        this.toBack()
      }, 1000)
    })
    .catch(() => {
      // console.log(e)
    })
  }

  onUnTrack() {
    const {
      MealPlan: { untrackMeal, getMealById },
      MealId,
    } = this.props
    const meal = getMealById(MealId)
    untrackMeal(MealId, meal.logged_meal_id)
    .then(() => {
      this.setState({
        animVal: { percent: 0, pro: 0, fats: 0, carbs: 0 },
      })
      setTimeout(() => {
        this.setState({
          logged : false,
        })
      }, 1000)
    })
    .catch(() => {
      // console.log(e.response)
    })
  }

  onUnMissed() {
    const {
      MealPlan: { untrackMeal, getMealById },
      MealId,
    } = this.props
    const meal = getMealById(MealId)
    untrackMeal(MealId, meal.logged_meal_id)
    .then(() => {
      this.setState({
        missed : false,
      })
    })
    .catch(() => {
      // console.log(e)
    })
  }

  toBack() {
    if (this.props.backType)
      this.props.navigator.dismissModal();
    else
      this.props.navigator.dismissAllModals();
  }

  toSwap() {
    this.props.navigator.push({
      ...Constants.Screens.RECIPE_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      },
      passProps: {
        navigator: this.props.navigator,
        forSwap: true,
        MealId: this.props.MealId
      }
    });
  }

  render() {
    const {
      MealPlan,
      MealId,
      User: { language, isPremium },
      navigator
    } = this.props

    const {
      logged,
      missed
    } = this.state;

    const flex = !isPremium

    const headerTranslate = this.state.scrollY.interpolate({
      inputRange: [0, HEADER_SCROLL_DISTANCE],
      outputRange: [0, -HEADER_SCROLL_DISTANCE],
      extrapolate: 'clamp',
    })

    const iconTranslateY = this.state.scrollY.interpolate({
      inputRange: [0, HEADER_SCROLL_DISTANCE / 2, HEADER_SCROLL_DISTANCE],
      outputRange: [0, HEADER_SCROLL_DISTANCE * 1.05, ICON_SCROLL_DISTANCE],
      extrapolate: 'clamp',
    })

    const imageTranslate = this.state.scrollY.interpolate({
      inputRange: [0, HEADER_SCROLL_DISTANCE / 1.5, HEADER_SCROLL_DISTANCE],
      outputRange: [0, HEADER_PARALLAX / 1.5, HEADER_PARALLAX],
      extrapolate: 'clamp',
    })

    const gradientTranslate = this.state.scrollY.interpolate({
      inputRange: [0, HEADER_SCROLL_DISTANCE / 2, HEADER_SCROLL_DISTANCE],
      outputRange: [0, 60, 120],
      extrapolate: 'clamp',
    })

    const opacityCircleChart = this.state.scrollY.interpolate({
      inputRange: [0, HEADER_SCROLL_DISTANCE / 2, HEADER_SCROLL_DISTANCE],
      outputRange: [1, 0, 0],
      extrapolate: 'clamp',
    })

    return(
      <ContainerView>
        <RecipeHeader
          transform={[{ translateY: headerTranslate }]}
        >
          <AnimatedImage
            transform={[{ translateY: imageTranslate }]}>
            <ImageCacheProvider
              urlsToPreload={[this.state.image]}>
              <RecipeImage source={{uri: this.state.image}} />
            </ImageCacheProvider>
          </AnimatedImage>

          <AnimateHeadGradient
            transform={[{ translateY: gradientTranslate }]}
          >
            <Overlay
              colors={['transparent', 'rgba(0,0,0,0.7)']}
              start={{x: 0, y: 1}} end={{x: 0, y: 0}}
            />
          </AnimateHeadGradient>
          <RecipeItemTracked
            pro={this.state.animVal.pro}
            fats={this.state.animVal.fats}
            carbs={this.state.animVal.carbs}
            percent={this.state.animVal.percent}
            opacityCircle={opacityCircleChart}
            logged={logged}
          />
          <RecipeItemMissed
            opacityCircle={opacityCircleChart}
            missed={missed}
          />
          {
            missed || logged
              ? null
              : <RecipeFlex
                  opacityFlex={opacityCircleChart}
                  count={MealPlan.getItemCountOfMeal(MealId)}
                />
          }
          <RecipeHeaderTop
            transform={[{ translateY: iconTranslateY }]}
          >
            <TouchableOpacity
              onPress={() => this.toBack()}
            >
              <IconBack
                source={Constants.Images.ICON_RECIPE_BACK}
              />
            </TouchableOpacity>
          </RecipeHeaderTop>
        </RecipeHeader>

        <MainScroll
          scrollEventThrottle={1}
          onScroll={Animated.event(
            [{ nativeEvent: { contentOffset: { y: this.state.scrollY } } }],
            { useNativeDriver: true },
          )}
        >
          <Inner>
            <WrapView>
              <MealInfo
                data={this.state.data}
                forMeal={true}
                navigator={navigator}
              />
            </WrapView>

            <SnowBox noShadow>
              <Ingredients
                data={this.state.data}
                forMeal={true}
                logged={logged}
                missed={missed}
                navigator={navigator}
                setTrackItems={(trackItems) => this.setTrackItems(trackItems)}
                forView={false}
              />
            </SnowBox>
            <EmptyView />
          </Inner>
        </MainScroll>
              <FooterView
                colors={['#ffffff00', '#ffffffff']}
                start={{x: 0, y: 0}}
                end={{x: 0, y: 1}}
              >
              {
                logged
                  ? <Footer>
                      <ActionButton
                        onPress={() => this.onUnTrack()}
                      >
                        <Icon name="clear" size={18} color={Constants.Colors.dodgerBlueFour} />
                        <ActionText>{ multilingual.UNTRACK[language] }</ActionText>
                      </ActionButton>
                    </Footer>
                  : missed
                    ? <Footer>
                        <ActionButton
                          onPress={() => this.onUnMissed()}
                        >
                          <Icon name="clear" size={18} color={Constants.Colors.dodgerBlueFour} />
                          <ActionText>{ multilingual.UNMISSED[language] }</ActionText>
                        </ActionButton>
                      </Footer>
                    : flex
                      ? <Footer>
                          <ActionButton
                            onPress={() => this.onConfirmTrack()}
                          >
                            <Icon name="check" size={18} color={Constants.Colors.dodgerBlueFour} />
                            <ActionText>{ multilingual.TRACK[language] }</ActionText>
                          </ActionButton>
                          <ActionButton
                            onPress={() => this.onConfirmMissed()}
                          >
                           <Icon name="clear" size={18} color={Constants.Colors.dodgerBlueFour} />
                            <ActionText>{ multilingual.MISSED[language] }</ActionText>
                          </ActionButton>
                        </Footer>
                      : <Footer>
                          <ActionButton
                            onPress={() => this.onConfirmTrack()}
                          >
                            <Icon name="check" size={18} color={Constants.Colors.dodgerBlueFour} />
                            <ActionText>{ multilingual.TRACK[language] }</ActionText>
                          </ActionButton>
                          <ActionButton
                            onPress={() => this.onConfirmMissed()}
                          >
                            <Icon name="clear" size={18} color={Constants.Colors.dodgerBlueFour} />
                            <ActionText>{ multilingual.MISSED[language] }</ActionText>
                          </ActionButton>
                          <ActionButton
                            onPress={() => this.toSwap()}
                          >
                            <Icon name="swap-horiz" size={18} color={Constants.Colors.dodgerBlueFour} />
                            <ActionText>Change</ActionText>
                          </ActionButton>
                        </Footer>
              }
              </FooterView>
      </ContainerView>
    );
  }
}
