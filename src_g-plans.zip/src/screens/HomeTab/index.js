// @flow

import React, { Component } from 'react';
import Proptypes from 'prop-types';
import {
  ScrollView,
  View,
  Linking,
  Alert,
  findNodeHandle,
  UIManager,
  AsyncStorage,
  Text
} from 'react-native';
import { inject, observer } from 'mobx-react/native';
import glamorous from 'glamorous-native';
import SnapCarousel from 'react-native-snap-carousel'
import SafariView from "react-native-safari-view"

import NavButtons  from '../../global/NavButtons';
import NavBar      from '../../global/NavBar';
import MainHeader from '../components/HeaderBar/MainHeader'
import MealCardListItem from '../components/MealCard/MealCardListItem'
import ScrollEntries from '../components/Common/ScrollEntries'
import FavoriteRecipeItem from '../components/Recipe/FavoriteRecipeItem'
import ChallengeItem from '../components/Challenges/ChallengeItem'
import ModuleItem from '../components/Modules/ModuleItem'
import MainTitle from '../components/Common/MainTitle'
import SnowBox from '../components/Common/SnowBox'
import BlogItem from '../components/Blog/BlogItem'
import MainProgress from '../components/Chart/MainProgress'
import WaterTrackerProgress from '../components/Tracker/WaterTrackerProgress'
import ExerciseTrackerProgress from '../components/Tracker/ExerciseTrackerProgress'
import TipsAway from '../components/Tips/TipsAway'
import CustomTabs from '../components/CustomTabs'
import Constants   from '../../global/Constants';
import ProgressBar from '../components/Chart/ProgressBar'

const multilingual = Constants.Multilingual;
const { width, height } = Constants.windowDimensions
const mainPadding = Constants.mainPadding

const MEAL_SLIDE_WIDTH = 116
const MEAL_THUMB_HEIGHT = 144
const MEAL_SLIDE_OFFSET = 10
const MEAL_SLIDE_INNER = MEAL_SLIDE_WIDTH - MEAL_SLIDE_OFFSET

const Container = glamorous(View)({
  flex: 1,
  backgroundColor: Constants.Colors.paleGreyThree
})

const MealSlider = glamorous(View)({})

const scrollStyle = {}

const CarouselStyle = {
  paddingLeft: mainPadding
}

const Wrap = glamorous(View)({
  height,
  paddingBottom: 75
})

const SnowBox1 = {
  marginBottom: 50
}

const RankHead = glamorous(View)({
  paddingHorizontal: Constants.mainPadding,
  paddingVertical: 10,
  backgroundColor: '#39d0ae',
  alignItems: 'center',
  justifyContent: 'space-between',
  flexDirection: 'row',
  marginBottom: -10,
  marginTop: 10,
  zIndex: 1
})

const RankHeadLeft = glamorous(Text)({
  fontSize: 14,
  fontWeight: 'bold',
  letterSpacing: 0,
  color: Constants.Colors.white,
  paddingRight: 10,
  flexShrink: 1
})

const RankHeadRight = glamorous(Text)({
  fontSize: 14,
  fontWeight: 'bold',
  textAlign: 'right',
  color: 'rgba(0, 0, 0, 0.4)'
})

const RankBody = glamorous(View)({
  flexDirection: 'column',
})

const RankTitle = glamorous(View)({
  flexDirection: 'row',
  marginTop: -5,
  justifyContent: 'space-between',
  alignItems: 'flex-start'
})

const RankLevel = glamorous(Text)({
  fontSize: 22,
  fontWeight: 'bold',
  color: '#4da0ff',
  flexShrink: 1
})

const MainTitleWrap = glamorous(View)({
  width: 60
})

const RankPoints = glamorous(View)({
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'space-between',
  marginBottom: 8
})

const RankPointsLeft = glamorous(Text)({
  fontSize: 14,
  fontWeight: 'bold',
  color: Constants.Colors.greyishBrownThree,
  flexShrink: 1
})

const RankPointsRight = glamorous(Text)({
  fontSize: 12,
  fontWeight: '500',
  color: '#9aa8bb'
})

const Challenge = glamorous(View)({
  paddingHorizontal: Constants.mainPadding
})

const ChallengeTitle = glamorous(Text)({
  color: Constants.Colors.greyishBrownThree,
  fontSize: 24,
  marginBottom: 8
})

const ChallengeActiveTitle = glamorous(Text)({
  fontSize: 13,
  fontWeight: 'bold',
  color: Constants.Colors.dodgerBlueFour,
  marginBottom: 5
})

const ProgressWrap = glamorous(View)({
  flexDirection: 'row',
  width: '100%',
  alignItems: 'center',
})

const Percents = glamorous(Text)({
  fontSize: 12,
  fontWeight: 'bold',
  color: Constants.Colors.greyishBrownThree,
  marginRight: 1,
  width: 35,
  flexShrink: 1
})

const ProgressBarWrap = glamorous(View)({
  maxWidth: '100%',
  width: '100%',
  flexShrink: 2
})

const Divider = glamorous(View)({
  width: width - Constants.mainPadding * 2,
  borderStyle: 'solid',
  borderBottomWidth: 1,
  borderColor: '#ededed',
  marginVertical: 18,
  marginHorizontal: Constants.mainPadding
})

const { object, shape, bool, number } = Proptypes;
@inject('App', 'MealPlan', 'User', 'Recipe', 'Tips') @observer
class HomeTab extends Component {
  static navigatorButtons = NavButtons.WithSideMenu;
  static navigatorStyle   = NavBar.Default;

  static propTypes = {
    App: object,
    Tips: shape({ todayTip: object }),
    navigator: object,
    MealPlan: object,
    User: object,
    Recipe: object
  }

  constructor(props) {
    super(props);
    this.state = {
      card: null,
      water: null,
      activeChallenge: null
    }

    Constants.rootNavigator = this.props.navigator;

    this.state = {
      tips: false
    }

    this.props.navigator.switchToTab({
      tabIndex: 0 // hack for hide tabbar
    })

  }

  toggleTips(flag) {
    setTimeout(() => {
      this.setState({ tips: flag })
    }, 10);
  }

  async toTour() {
    try {
      const { User } = this.props;
      const key = User.userInfo.email + ':' + 'tour';
      const value = await AsyncStorage.getItem(key);

      if (value !== 'success' && User.isPremium) {
        setTimeout(() => {
          this.toStartTour();
          UIManager.measure(findNodeHandle(this.card), (x, y) => {
            this.setState({
              card: y / 1.55
            })
          });
          UIManager.measure(findNodeHandle(this.water), (x, y, w, h) => {
            this.setState({
              water: y - h
            })
          })
        }, 10);
      }
      else {
        //
        this.toggleTips(true);
      }
    } catch (error) {
      //
      this.toggleTips(true);
    }
  }

  componentDidMount(){
    this.setState({ activeChallenge: 0 });
    //this.toTour();
  }

  componentDidUpdate(prevProps) {
    if(prevProps.App.scrollTo === 1) {
      this.scrollView.scrollTo({x: 0, y: this.state.card, animated: true})
    }
    if(prevProps.App.scrollTo === 2) {
      this.scrollView.scrollTo({x: 0, y: this.state.water, animated: true})
    }
    if(prevProps.App.scrollTo === 3) {
      this.scrollView.scrollTo({x: 0, y: 0, animated: true})
      this.props.App.setScrollTo(0)
    }
  }

  toStartTour() {
    this.props.navigator.showLightBox({
      ...Constants.Screens.TOUR,
      style: {
        backgroundColor: "transparent",
        tapBackgroundToDismiss: false
      },
      passProps: {
        showTips: () => this.toggleTips(true)
      }
    });
  }

  toRecipeView(recipe, mealId) {
    const flex = recipe ? false : true
    if (flex) {
      this.props.navigator.showModal({
        ...Constants.Screens.MEAL_DETAIL_SCREEN,
        passProps: {
          MealId: mealId
        },
        navigatorStyle: {
          navBarHidden: true,
          tabBarHidden: true
        }
      });
    }
    else {
      this.props.navigator.showModal({
        ...Constants.Screens.RECIPE_ITEM_SCREEN,
        passProps: {
          forView: false,
          MealId: mealId,
          RecipeId: recipe.id
        },
        navigatorStyle: {
          navBarHidden: true,
          tabBarHidden: true
        }
      });
    }
  }

  toFaVRecipeView(id) {
    this.props.navigator.showModal({
      ...Constants.Screens.RECIPE_ITEM_SCREEN,
      passProps: {
        RecipeId: id
      },
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  toWebView(url) {
    if (Constants.platform ==='ios') {
    SafariView.isAvailable()
      .then(() => {
        SafariView.show({ url: url })
      })
      .catch(() => {
        Alert.alert('Sorry, something went wrong!')
      });
    }
    else {
      Linking.canOpenURL(url)
        .then(() => {
          Linking.openURL(url)
        })
        .catch(() => {
          Alert.alert('Sorry, something went wrong!')
        })
    }
  }

  toSearch() {
    // if all meals were tracked
    const {
      MealPlan: { getMealsByDay },
      User: { language },
    } = this.props
    const mealsUnlogged = getMealsByDay.filter(meal => !meal.logged)
    if (mealsUnlogged && mealsUnlogged.length) {
      this.props.navigator.showModal({
        ...Constants.Screens.SEARCH_SCREEN,
        navigatorStyle: {
          navBarHidden: true,
          tabBarHidden: true
        }
      });
    } else {
      Alert.alert(multilingual.MSG_NO_MEAL_TO_ADD_ITEM[language])
    }
  }

  onSelectChallenge(index){
    this.setState({ activeChallenge: index });
    this.props.navigator.showModal({
      ...Constants.Screens.CHALLENGE_DETAIL,
      passProps: {
        currentComplete: 54,
        completeUsers: 15,
        bar: 80,
        friends: [],
        ...this.props.App.challenges[index]
      },
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  toChallengesList(){
    this.props.navigator.showModal({
      ...Constants.Screens.CHALLENGES_LIST,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  render() {
    const {
      App: { products, blogs, scrollTo, challenges, modules }, // don't delete scrollTo in this line
      MealPlan,
      User,
      Recipe,
      Tips: {
        //todayTip,
        unreadTipsLen,
        latestUnreadTip,
      }
    } = this.props
    const favorites = Recipe.getDataOfFavorites;
    const currentLanguage = User.language;
    const getBlogsByLanguage = blogs[currentLanguage];
    const flex = !User.isPremium;

    const latestTip = latestUnreadTip

    const selectedChallenge = this.state.activeChallengeSlide;

    return (
      <Wrap>
        <ScrollView
          contentContainerStyle={scrollStyle}
          bounces={false}
          ref={ref => this.scrollView = ref}
        >
        <Container>
          <MainHeader
            navigator={this.props.navigator}
            hideSearch={true}
          />
          <View ref={ref => this.card = ref}>
            <SnowBox noPad>
            {
              flex
                ? <MainTitle
                    hrPad={mainPadding}
                    title={'Today’s Meals'} />
                : <MainTitle
                    hrPad={mainPadding}
                    title={'Today’s Meals'}
                    onMore={() => this.toSearch()}
                    moreText={'Track Other Food'} />
            }
             <MealSlider>
               <SnapCarousel
                 onSnapToItem={() => {}}
                 inactiveSlideScale={1}
                 activeSlideAlignment={'start'}
                 sliderWidth={width}
                 itemWidth={flex ? width * 0.8 : MEAL_SLIDE_WIDTH}
                 loopClonesPerSide={1}
                 ref={c => { this.carousel = c }}
                 data={MealPlan.getMealsByDay}
                 containerCustomStyle={CarouselStyle}
                 inactiveSlideOpacity={flex ? 0.8 : 1}
                 renderItem={({item, index}) =>
                   <MealCardListItem
                     width={flex ? width * 0.765 : MEAL_SLIDE_INNER}
                     height={flex ? 180 : MEAL_THUMB_HEIGHT}
                     hideShadow={!flex}
                     radius={!flex}
                     homeMode={!flex}
                     data={item}
                     onSelected={() => this.toRecipeView(item.recipe, item.id)}
                     navigator={this.props.navigator}
                     flex={flex}
                   />
                 }
                 activeSlideOffset={0}
                />
              </MealSlider>
             </SnowBox>
           </View>

           <SnowBox>
             <MainTitle title={'Today’s Progress'} />
              <MainProgress
                calories={MealPlan.PercentageToDay.calories.fcpFull}
                percent={MealPlan.PercentageToDay.calories.data}
                bar={MealPlan.PercentageToDay.calories.data}
                fcpData={MealPlan.PercentageToDay}
                aboveFlame
              />
           </SnowBox>

           <RankHead>
            <RankHeadLeft>{'Currently Earning 2x Points'}</RankHeadLeft>
            <RankHeadRight>{'2 days left'}</RankHeadRight>
           </RankHead>
           <SnowBox>
             <RankTitle>
               <MainTitleWrap>
                <MainTitle title={'Rank'} />
               </MainTitleWrap>
               <RankLevel>{'Level 8'}</RankLevel>
             </RankTitle>
             <RankBody>
              <RankPoints>
                <RankPointsLeft>{'3,245 points'}</RankPointsLeft>
                <RankPointsRight>{'245 points to next level'}</RankPointsRight>
              </RankPoints>
              <ProgressBar
                bar={40}
              />
             </RankBody>
           </SnowBox>

           <SnowBox noPad>
             <MainTitle hrPad={mainPadding} title={'Challenges'} onMore={() => this.toChallengesList()} />
             <ScrollEntries
               data={challenges}
               elem={ChallengeItem}
               onSelected={(item) => this.onSelectChallenge(item.index)}
               paddingLeft={mainPadding}
               active={this.state.activeChallenge}
             />
             <Divider />
             <Challenge>
              <ChallengeActiveTitle>{'Active Challenge'}</ChallengeActiveTitle>
              <ChallengeTitle>{'Water Warrior'}</ChallengeTitle>

              <ProgressWrap>
                <Percents>{'70%'}</Percents>
                <ProgressBarWrap>
                  <ProgressBar
                    bar={70}
                  />
                </ProgressBarWrap>
              </ProgressWrap>
             </Challenge>
           </SnowBox>

           <View ref={ref => this.water = ref}>
             <SnowBox>
               <MainTitle title={'Water Tracker'} />
               <WaterTrackerProgress navigator={this.props.navigator} />
             </SnowBox>
           </View>
           <SnowBox noPad>
             <MainTitle hrPad={mainPadding} title={'Exercise Tracker'} />
             <ExerciseTrackerProgress navigator={this.props.navigator} />
           </SnowBox>
           {
             favorites && favorites.length > 0
               ? <View>
                  <SnowBox noPad>
                    <MainTitle hrPad={mainPadding} title={'Favorite Recipes'} />
                    <ScrollEntries
                      data={favorites}
                      elem={FavoriteRecipeItem}
                      onSelected={(id) => this.toFaVRecipeView(id)}
                      paddingLeft={mainPadding}
                    />
                  </SnowBox>
                 </View>
               :  <View />
           }
           <SnowBox noPad>
             <MainTitle hrPad={mainPadding} title={'Modules'} onMore={() => {}} />
             <ScrollEntries
               data={modules}
               elem={ModuleItem}
               onSelected={(item) => this.onSelectChallenge(item.index)}
               paddingLeft={mainPadding}
             />
           </SnowBox>
           <SnowBox noPad style={SnowBox1}>
             <MainTitle hrPad={mainPadding} title={'Blogs'} /*onMore={() => {}}*/ />
             <ScrollEntries
               data={ getBlogsByLanguage }
               elem={BlogItem}
               onSelected={(url) => this.toWebView(url)}
               paddingLeft={mainPadding}
             />
           </SnowBox>
         </Container>
        </ScrollView>
        {/*
          latestTip && this.state.tips
            ? <TipsAway
                id={latestTip.id}
                title={latestTip[`title_${currentLanguage}`] ? latestTip[`title_${currentLanguage}`] : latestUnreadTip.title}
                text={latestTip[`message_${currentLanguage}`] ? latestTip[`message_${currentLanguage}`] : latestUnreadTip.message}
                showing={!latestTip.isRead}
                navigator={this.props.navigator}
                badgeNumber={unreadTipsLen}
                hideTips={() => this.toggleTips(false)}
              />
            : <View />
        */}
        <CustomTabs navigator={this.props.navigator} active={0}/>
      </Wrap>
    )
  }
}
export default HomeTab
