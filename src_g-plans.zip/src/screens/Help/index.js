/*
*   author: denis
*   date:   7/17/2018
*/

import React, { Component } from 'react';
import {
  View,
  WebView,
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import { inject, observer } from 'mobx-react/native';

import Constants from '../../global/Constants';
import ShowHeader from '../components/HeaderBar/ShowHeader';
import GplansLogoLoader from '../components/Common/GplansLoader'

const multilingual = Constants.Multilingual;

const ContainerView = glamorous(View)({
  flexDirection: "column",
  flex: 1,
  backgroundColor: Constants.Colors.whiteFive
});

const ContainerLoader = glamorous(View)({
  position: 'absolute',
  left: 0,
  top: 0,
  right: 0,
  bottom: 0,
  flexDirection: "column",
  flex: 1,
  backgroundColor: 'rgba(100,100,100, 0.1)',
  alignItems: 'center',
  justifyContent: 'center'
})

const { object } = Proptypes;
@inject('User') @observer
export default class Help extends Component {
  static propTypes = {
    navigator: object,
    User: object
  }

  constructor(props) {
    super(props);
  }

  render() {
    const { User } = this.props
    const currentLanguage = User.language;
    return(
      <ContainerView>
        <ShowHeader
          title= { multilingual.HELP[currentLanguage] }
          navigator={this.props.navigator}
          hasNotify
        />
        <WebView
          source = {{ uri: 'http://help.g-plans.com/' }}
          renderLoading={ () => <ContainerLoader><GplansLogoLoader size={60} /></ContainerLoader> }
          startInLoadingState={true}
        />
      </ContainerView>
    );
  }
}
