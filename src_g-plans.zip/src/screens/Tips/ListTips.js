import React, { Component } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity
} from 'react-native';
import Proptypes from 'prop-types';
import { inject, observer } from 'mobx-react/native';
import glamorous from 'glamorous-native';

import Constants from '../../global/Constants';
import ShowHeader from '../components/HeaderBar/ShowHeader';

const multilingual = Constants.Multilingual;

const Container = glamorous(View)({
  flex: 1
})

const ItemView = glamorous(View)({
  borderStyle: "solid",
  borderBottomColor: Constants.Colors.borderColor,
  borderBottomWidth: 1
})

const ItemButton = glamorous(TouchableOpacity)({
  flexDirection: "row",
  justifyContent: "space-between",
  alignItems: 'center',
  marginLeft: 15,
  marginRight: 12,
  paddingTop: 8,
  paddingBottom: 10,
})

const TextView = glamorous(View)({
  flexDirection: 'column',
  alignItems: 'flex-start'
})

const DarkText = glamorous(Text)({
  fontSize: 18,
  color: Constants.Colors.marineTwo,
  fontWeight: '500'
})

const Badge = glamorous(Text)({
  overflow: 'hidden',
  paddingVertical: 2,
  paddingHorizontal: 8,
  fontSize: 10,
  borderRadius: 10,
  fontWeight: "bold",
  textAlign: "center",
  color: Constants.Colors.white,
  backgroundColor: '#787878',
  marginTop: 4
})

const TextGrey = glamorous(Text)({
  fontSize: 14,
  letterSpacing: 0,
  color: Constants.Colors.warmGrey,
  paddingLeft: 10
})

const { object, shape } = Proptypes;
@inject('User', 'Tips') @observer
export default class ListTips extends Component {
  static propTypes = {
    navigator: object,
    User: object,
    Tips: shape({ todayTip: object })
  }

  constructor(props) {
    super(props);
  }

  toTip() {
    this.props.navigator.showModal({
      ...Constants.Screens.DETAIL_TIP_SCREEN,
      passProps: {
        title: this.props.Tips.todayTip.title,
        text: this.props.Tips.todayTip.text,
        isAction: false
      },
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  render() {
    const { User, Tips: { todayTip } } = this.props
    const currentLanguage = User.language

    return(
      <Container>
        <ShowHeader
          title={ multilingual.TIPS[currentLanguage] }
          navigator={this.props.navigator}
        />
        <ScrollView>
          <ItemView>
            <ItemButton onPress={() => this.toTip()}>
              <TextView>
                <DarkText>{ todayTip.title }</DarkText>
                <Badge>{'Breakfast'}</Badge>
              </TextView>
              <TextGrey>{'9/10/2018'}</TextGrey>
            </ItemButton>
          </ItemView>
          <ItemView>
            <ItemButton onPress={() => this.toTip()}>
              <TextView>
                <DarkText>{ todayTip.title }</DarkText>
                <Badge>{'Lunch'}</Badge>
              </TextView>
              <TextGrey>{'9/10/2018'}</TextGrey>
            </ItemButton>
          </ItemView>
          <ItemView>
            <ItemButton onPress={() => this.toTip()}>
              <TextView>
                <DarkText>{ todayTip.title }</DarkText>
                <Badge>{'Breakfast'}</Badge>
              </TextView>
              <TextGrey>{'9/10/2018'}</TextGrey>
            </ItemButton>
          </ItemView>
          <ItemView>
            <ItemButton onPress={() => this.toTip()}>
              <TextView>
                <DarkText>{ todayTip.title }</DarkText>
                <Badge>{'Breakfast'}</Badge>
              </TextView>
              <TextGrey>{'9/10/2018'}</TextGrey>
            </ItemButton>
          </ItemView>
        </ScrollView>
      </Container>
    )
  }
}
