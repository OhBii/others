import React, { Component } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity
} from 'react-native';
import Proptypes from 'prop-types';
import { inject, observer } from 'mobx-react/native';
import glamorous from 'glamorous-native';

import Constants from '../../global/Constants';
import ShowHeader from '../components/HeaderBar/ShowHeader';

const multilingual = Constants.Multilingual;

const Container = glamorous(View)({
  flex: 1,
  backgroundColor: '#F4FAFF'
})

const Body = glamorous(View)({
  paddingVertical: 30,
  paddingHorizontal: Constants.mainPadding
})

const Title = glamorous(Text)({
  fontSize: 24,
  fontWeight: 'bold',
  letterSpacing: 0,
  color: Constants.Colors.marineTwo,
  marginBottom: 10
})

const TextContent = glamorous(Text)({
  fontSize: 16,
  letterSpacing: 0,
  color: Constants.Colors.marineTwo,
  marginBottom: 10
})

const Action = glamorous(View)({
  justifyContent: 'center',
  backgroundColor: Constants.Colors.white,
  shadowColor: 'rgba(0, 0, 0, 0.05)',
  shadowOffset: {
    width: 0,
    height: -6
  },
  shadowRadius: 10,
  shadowOpacity: 1,
  elevation: 10,
  width: '100%',
  height: 75,
  flexDirection: 'row',
  alignItems: 'center',
  paddingHorizontal: Constants.mainPadding
})

const ButtonLightWrap = glamorous(TouchableOpacity)({
  height: 42,
  borderRadius: 32,
  overflow: 'hidden',
  justifyContent: 'center',
  alignItems: 'center',
  flexDirection: 'column',
  paddingHorizontal: 10,
  width: 160,
  backgroundColor: 'rgba(74,74,74,0.54)'
})

const ButtonLightTitle = glamorous(Text)({
  fontSize: 16,
  fontWeight: '600',
  textAlign: 'center',
  color: '#fff'
})

const { object, string, bool } = Proptypes;
@inject('User') @observer
export default class DetailTip extends Component {
  static propTypes = {
    navigator: object,
    User: object,
    title: string,
    text: string,
    isAction: bool
  }

  static defaultProps = {
    isAction: true
  }

  constructor(props) {
    super(props);
  }

  onAction(){}

  render() {
    const { User, title, text, isAction } = this.props
    const currentLanguage = User.language

    return(
      <Container>
        <ShowHeader
          title= { multilingual.TIP[currentLanguage] }
          navigator={this.props.navigator}
          isModal={true}
        />
        <ScrollView>
          <Body>
            <Title>{title}</Title>
            <TextContent>{text}</TextContent>
          </Body>
        </ScrollView>
        {!!isAction && <Action>
          <ButtonLightWrap
            onPress={() => this.onAction()}
          >
              <ButtonLightTitle>{ multilingual.GOT_IT[currentLanguage] }</ButtonLightTitle>
          </ButtonLightWrap>
        </Action>}
      </Container>
    )
  }
}
