/*
*   author: denis
*   date:   7/13/2018
*/

import React, { Component } from 'react';
import {
  View,
  TextInput,
  Alert
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import { inject, observer } from 'mobx-react/native';

import Constants from '../../global/Constants';
import ShowHeader from '../components/HeaderBar/ShowHeader';
import ParallelButton from '../components/Common/ParallelButton';

const multilingual = Constants.Multilingual;
const ContainerView = glamorous(View)({
  flexDirection: "column",
  flex: 1,
  backgroundColor: Constants.Colors.whiteFive
});

const ContentView = glamorous(View)({
  marginHorizontal: 15,
  marginTop: 20
});

const InputView = glamorous(View)({
  marginVertical: 10,
  paddingVertical: 10,
  borderStyle: "solid",
  borderBottomColor: Constants.Colors.warmGreyTwo,
  borderBottomWidth: 1
});

const Edit = glamorous(TextInput)({
  fontSize: 18
});

const AddView = glamorous(View)({
  flexDirection: "row",
  justifyContent: "flex-end",
  marginVertical: 10,
});

const { object, string } = Proptypes;
@inject( 'GroceryList', 'User' ) @observer
export default class AddGrocery extends Component {
  static propTypes = {
    navigator: object,
    GroceryList: object,
    User: object,
    name: string
  }

  constructor(props) {
    super(props);
  }

  addValue(listName) {
    if(!listName){
      Alert.alert(
        '',
        'ListName cannot be an Empty string'
      )
      return
    }
    this.props.navigator.pop();
    this.props.GroceryList.addGroceryList(listName);
  }

  render() {
    const { User: { language } } = this.props
    let listName = "";
    return(
      <ContainerView>
        <ShowHeader
          title={multilingual.ADD_LIST[language]}
          navigator={this.props.navigator}
          hasNotify
        />
        <ContentView>
          <InputView>
            <Edit
              placeholder={multilingual.TYPE_LIST_HERE[language]}
              placeholderTextColor={Constants.Colors.warmGreyTwo}
              underlineColorAndroid={'transparent'}
              onChangeText={ text => listName = text}/>
          </InputView>
          <AddView>
            <ParallelButton
              proc={() => this.addValue(listName)}
              title={multilingual.ADD_LIST[language]} />
          </AddView>
        </ContentView>
      </ContainerView>
    );
  }
}
