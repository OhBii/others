// @flow

import React, { Component } from 'react';
import Proptypes from 'prop-types';
import {
  View,
  Text,
  TouchableOpacity,
  Platform
} from 'react-native';
import { inject, observer } from 'mobx-react/native';
import glamorous from 'glamorous-native';
import LinearGradient from 'react-native-linear-gradient';
import SIcon from 'react-native-vector-icons/Feather'
import { CachedImage, ImageCacheProvider } from 'react-native-cached-image'

import Constants from '../../global/Constants';

const multilingual = Constants.Multilingual;
const { height } = Constants.windowDimensions

const Container = glamorous(LinearGradient)({
  flex: 1,
  flexDirection: 'column',
  height,
  paddingLeft: 40,
  justifyContent: 'space-around',
  paddingVertical: 25
})

const AvatarWrap = glamorous(View)({
  alignItems: 'flex-start',
  justifyContent: 'center',
  //paddingTop: height * 0.15,
})

const AvatarWrapInner = glamorous(TouchableOpacity)({
  width: 130,
  height: 130,
  borderRadius: 130 / 2,
  shadowColor: "rgba(0, 0, 0, 0.32)",
  shadowOffset: {
    width: 0,
    height: 2
  },
  shadowRadius: 4,
  shadowOpacity: 1,
  elevation: 2
})

const AvatarImage = glamorous(CachedImage)({
  width: 130,
  height: 130,
  borderRadius: 130 / 2
})

const AvatarName = glamorous(Text)({
  color: 'white',
  fontWeight: '500',
  fontSize: Platform.OS === 'ios' ? Constants.moderateScale(24, 1.8) : 22,
  marginTop: 15,
  marginBottom: 8,
  height: 35,
  width: '90%'
})

const NextCheckin = glamorous(Text)({
  fontSize: Platform.OS === 'ios' ? Constants.moderateScale(11, 1.8) : 12,
  fontWeight: '300',
  fontStyle: 'normal',
  color: '#ffffff',
  paddingHorizontal: 18,
  paddingVertical: 4,
  borderRadius: 10,
  backgroundColor: '#2A9AF1',
  overflow: 'hidden'
})

const Controls = glamorous(View)({
  backgroundColor: 'transparent',
  flexDirection: 'column',
  justifyContent: 'flex-start'
})

const Button = glamorous(TouchableOpacity)({
  marginBottom: Platform.OS === 'ios' ? 12 : 6,
  flexDirection: 'row',
  alignItems: 'center'
})
Button.propsAreStyleOverrides = true

const ButtonText = glamorous(Text)(({ color, fontSize, fontWeight }) => ({
  fontSize: Platform.OS === 'ios' ? (Constants.moderateScale(fontSize, 1.8) || Constants.moderateScale(21, 1.8)) : 22,
  color: color || 'white',
  fontWeight: fontWeight || '300'
}))

const Sicon = glamorous(SIcon)({
  marginRight: 10
})

// const PauseSwitch = glamorous(Switch)({
//   position: 'absolute',
//   right: 20,
//   top: -2,
//   transform: [{ scale: 0.8 }]
// })

const SidebarButton = ({ text, fontSize, color, fontWeight, children, ...buttonProps} = this.props) =>
  <Button {...buttonProps}>
    {children}
    <ButtonText
      color={color}
      fontSize={fontSize}
      fontWeight={fontWeight}
    >{text}</ButtonText>
  </Button>

const { object } = Proptypes;
@inject('App', 'User', 'DayIndex', 'Profile') @observer
class Drawer extends Component {
  static propTypes = {
    App: object,
    navigator: object,
    User: object,
    DayIndex: object,
    Profile: object
  }

  constructor(props) {
    super(props);
    this.props.navigator.setOnNavigatorEvent(this.onNavigatorEvent.bind(this));
  }

  onNavigatorEvent(event) {
    // handle a deep link
    if (event.type == 'DeepLink') {
      const parts = event.link.split('/'); // Link parts
      if(parts[0] == Constants.Screens.PROFILE_SCREEN.screen) {
        this.toProfile();
      }
      else if(parts[0] == Constants.Screens.SETTING_SCREEN.screen){
        this.toSetting();
      }
    }
  }

  toProfile() {
    this.props.navigator.toggleDrawer({
      side: 'left',
      animated: true
    });
    Constants.rootNavigator.showModal({
      ...Constants.Screens.PROFILE_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  toSetting() {
    this.props.navigator.toggleDrawer({
      side: 'left',
      animated: true
    });
    Constants.rootNavigator.showModal({
      ...Constants.Screens.SETTING_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  toLogout() {
    this.props.User.logout();
    Constants.Global.startSingleScreenApp();
  }

  render() {
    const { User, DayIndex:{ homeDayIndex }, Profile } = this.props;
    const index = 6 - homeDayIndex;
    const currentLanguage = User.language;

    const firstName = User.userInfo.first_name ? User.userInfo.first_name : ''
    const lastName = User.userInfo.last_name ? User.userInfo.last_name : ''
    const userName = firstName + ' ' + lastName;

    const image = Profile.getLastImage
      ? Profile.getLastImage
      : 'https://static0.misionesonline.net/wp-content/uploads/2017/07/angelina-10j7i2e4qnf8.jpg'
    return (
      <Container
        start={{ x: 0.3, y: 1 }}
        end={{ x: -0.6, y: 0.6 }}
        colors={['#012754', '#012754']}
      >
      <AvatarWrap>
        <AvatarWrapInner onPress={() => this.toProfile()}>
          <ImageCacheProvider
            urlsToPreload={[image]}
          >
            <AvatarImage source={{ uri: image }} />
          </ImageCacheProvider>
        </AvatarWrapInner>
        <AvatarName
          ellipsizeMode={'tail'}
          numberOfLines={1}>{ userName }</AvatarName>
          <NextCheckin>{`Next Checkin in ${index} Days`}</NextCheckin>
      </AvatarWrap>

      <Controls>
        <SidebarButton
          text={ multilingual.PROFILE[currentLanguage] }
          onPress={() => this.toProfile()}
        >
          <Sicon name='user' size={18} color='white' />
        </SidebarButton>
        <SidebarButton
          text={ multilingual.SETTINGS[currentLanguage] }
          onPress={() => this.toSetting()}
        >
          <Sicon name='settings' size={18} color='white' />
        </SidebarButton>
        {/* <SidebarButton text='Help'
          onPress={() => this.toScreen(Constants.Screens.HELP_SCREEN.screen)}>
          <Sicon name='bell' size={19} color='black' />
        </SidebarButton> */}
      </Controls>

      <Controls>
        {/* <SidebarButton
          text='Share via email'
          color={'black'}
          onPress={() => {}}
        >
          <Sicon name='paper-plane' size={18} color='black' />
        </SidebarButton> */}
        {
          // <SidebarButton
          //   text='Reboot'
          //   color={'white'}
          //   onPress={() => {}}
          //   activeOpacity={0.7}
          // >
          //   <Sicon name='pause' size={19} color='white' />
          //   <PauseSwitch
          //     tintColor={'white'}
          //     thumbTintColor={'white'}
          //     onTintColor={'black'}
          //     value={true}
          //     onValueChange={() => {}}
          //   />
          // </SidebarButton>
        }
        <SidebarButton
          text={ multilingual.LOGOUT[currentLanguage] }
          color={'white'}
          onPress={() => this.toLogout()}
        >
        <Sicon name='log-out' size={18} color='white' />
        </SidebarButton>
      </Controls>

      </Container>
    )
  }
}

export default Drawer
