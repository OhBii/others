/*
*   author: denis
*   date:   15/08/2018
*/

import React, { Component } from 'react'
import { inject, observer } from 'mobx-react'
import {
  Text,
  View,
  TouchableOpacity,
  TouchableWithoutFeedback
} from 'react-native'
import Proptypes from 'prop-types'
import glamorous from 'glamorous-native'

import Constants   from '../../global/Constants'

const { width, height } = Constants.windowDimensions

const Container = glamorous(View)({
  backgroundColor: 'transparent',
  width,
  height,
  flexDirection: 'column',
  justifyContent: 'flex-end'
})

const Overlay = glamorous(View)({
  position: 'absolute',
  left: 0,
  top: 0,
  width: '100%',
  height: '100%',
  backgroundColor: 'transparent'
})

const Dialog = glamorous(View)({
  width: '100%',
  paddingVertical: 25,
  borderRadius: 26,
  backgroundColor: Constants.Colors.white,
  shadowColor: "rgba(0, 0, 0, 0.17)",
  shadowOffset: {
    width: 0,
    height: -6
  },
  shadowRadius: 10,
  shadowOpacity: 1,
  elevation: 10,
  flexDirection: 'column'
})

const BorderView = glamorous(View)({
  borderStyle: 'solid',
  borderBottomColor: Constants.Colors.warmGreyTwo,
  borderBottomWidth: 0.5
})

const ItemView = glamorous(TouchableOpacity)({
  alignItems: 'center',
  paddingVertical: 15
})

const ItemText = glamorous(Text)({
  fontSize: 18,
  color: Constants.Colors.darkSkyBlue
})

const { object } = Proptypes

const mapStores = ({ User }) => ({ User })
@inject(mapStores)
@observer
export default class SetLanguageDailog extends Component {
  static propTypes = {
    navigator: object,
    User: object,
  }

  constructor(props) {
    super(props);
  }

  toEnglish() {
    this.props.User.setLanguage('en');
    this.props.navigator.dismissLightBox();

  }

  toSpanish(){
    this.props.User.setLanguage('es');
    this.props.navigator.dismissLightBox();

  }

  toChinese(){
    this.props.User.setLanguage('zh_hans');
    this.props.navigator.dismissLightBox();

  }
  render() {
    return (
          <Container>
            <TouchableWithoutFeedback
              onPress={() => this.props.navigator.dismissLightBox()}
            >
              <Overlay />
            </TouchableWithoutFeedback>
            <Dialog>
              <BorderView>
                <ItemView onPress={() => this.toEnglish()}>
                  <ItemText>English</ItemText>
                </ItemView>
              </BorderView>
              <BorderView>
                <ItemView onPress={() => this.toSpanish()}>
                    <ItemText>Español</ItemText>
                  </ItemView>
              </BorderView>
              <BorderView>
                <ItemView onPress={() => this.toChinese()}>
                  <ItemText>中国语文</ItemText>
                </ItemView>
              </BorderView>
            </Dialog>
          </Container>
    );
  }
}
