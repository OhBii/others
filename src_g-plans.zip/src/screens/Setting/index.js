/*
*   author: denis
*   date:   7/13/2018
*/

import React, { Component } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Image,
  Alert,
  Switch
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import { inject, observer } from 'mobx-react/native';

import Constants from '../../global/Constants';
import ShowHeader from '../components/HeaderBar/ShowHeader';
import SnowBox from '../components/Common/SnowBox';
import MainTitle from '../components/Common/MainTitle'
import { isValidEmail, isEqualPasswords } from '../../utils/GlobalFunctions'

const multilingual = Constants.Multilingual;

const Icon = glamorous(Image)({
  marginHorizontal: 5
});

const ContainerView = glamorous(View)({
  flexDirection: "column",
  flex: 1,
  backgroundColor: Constants.Colors.whiteFive
});

const ItemView = glamorous(View)({
  flexDirection: "row",
  justifyContent: "space-between",
  alignItems: 'center',
  paddingVertical: 15,
  backgroundColor: Constants.Colors.white,
  borderBottomColor: Constants.Colors.borderColor,
  borderBottomWidth: 1,
  paddingHorizontal: Constants.mainPadding
})

const ItemViewWithoutBorder = glamorous(View)({
  flexDirection: "row",
  justifyContent: "space-between",
  paddingTop: 15,
  backgroundColor: Constants.Colors.white,
  paddingHorizontal: Constants.mainPadding
})

const ContainerRowItemTitle = glamorous(View)({
  width: '40%',
})

const RowItemTitle = glamorous(Text)({
  fontSize: 18,
  color: Constants.Colors.warmGreyFive,
})

const ContainerRowItemValue = glamorous(View)({
  flexDirection: 'row',
  flex: 1,
  justifyContent: 'flex-end',
})

const ContainerRowItem =glamorous(View)({
  flexDirection: 'row',
  flex: 1,
  justifyContent: "space-between"
})

const RowItemTxtInput = glamorous(TextInput)({
  width: '100%',
  fontSize: 18,
  color: Constants.Colors.warmGreyFive,
  textAlign: 'right',
})

const RowItemTxt = glamorous(Text)({
  width: '80%',
  fontSize: 18,
  color: Constants.Colors.warmGreyFive,
  textAlign: 'right',
})
// const TchRowItemSelect = glamorous(TouchableOpacity)({
//   width: '100%',
// })

const ItemText = glamorous(Text)({
  fontSize: 18,
  color: Constants.Colors.warmGreyFive
});

// const RowItemText = glamorous(Text)({
//   fontSize: 18,
//   color: Constants.Colors.warmGreyFive,
//   textAlign: 'right',
// });

// const ItemButton = glamorous(TouchableOpacity)({
//   flexDirection: 'row',
//   justifyContent: 'space-between',
//   paddingLeft: 15,
//   paddingRight: 50,
//   paddingVertical: 15,
//   backgroundColor: Constants.Colors.white
// });

// const ItemButtonWithBorder = glamorous(TouchableOpacity)({
//   borderStyle: "solid",
//   borderBottomColor: Constants.Colors.paleGreyTwo,
//   borderBottomWidth: 0.5,
//   borderTopColor: Constants.Colors.paleGreyTwo,
//   borderTopWidth: 0.5,
//   paddingLeft: 15,
//   paddingRight: 12,
//   paddingVertical: 15,
//   backgroundColor: Constants.Colors.white
// });

const ContainerApplyClearBtn = glamorous(View)(({ isVisible }) => ({
  flexDirection: 'row',
  width: Constants.windowDimensions.width,
  height: 50,
  display: isVisible ? 'flex' : 'none',
}))

const TchButton = glamorous(TouchableOpacity)({
  justifyContent: 'center',
  alignItems: 'center',
  flex: 1,
  height: '100%',
})

const ApplyButton = glamorous(TchButton)({
  backgroundColor: Constants.Colors.lightOliveGreen,
})

const ClearButton = glamorous(TchButton)({
  backgroundColor: Constants.Colors.reddish,
})

const ButtonText = glamorous(Text)({
  color: Constants.Colors.white,
})

// lightOliveGreen: '#a7cb5c',
//   turtleGreen: '#85c250',
//   offGreen: '#6fa953',
//   darkOliveGreen: '#284b00',

// pastelRed: '#e84f4f',
//   reddish: '#c94545',
//   reddishTwo: '#ca4545',

const settingsField = [
  'first_name',
  'last_name',
  'metatype',
  'gender',
  'email',
  'password',
  'confirmPassword',
  'location',
]

const fieldFirstName = settingsField[0]
const fieldLastName = settingsField[1]
const fieldMetatype = settingsField[2]
const fieldGender = settingsField[3]
const fieldEmail = settingsField[4]
const fieldPassword = settingsField[5]
const fieldConfirmPass = settingsField[6]
const fieldLocation = settingsField[7]

const { object } = Proptypes;
@inject('User') @observer
export default class Setting extends Component {
  static propTypes = {
    navigator: object,
    User: object,
  }

  constructor(props) {
    super(props);

    this.state = {
      userInfo: this.getUserInfo(),
      isModifiedInfo: false,
    }
  }

  getUserInfo() {
    let userInfoCopied = {}
    const { User: { userInfo } } = this.props
    settingsField.forEach(field => {
      userInfoCopied[field] = userInfo[field]
    })
    return userInfoCopied
  }

  toShowLanguageDailog(){
    this.props.navigator.showLightBox({
      ...Constants.Screens.SET_LANGUAGE_DAILOG_SCREEN,
      style: {
        backgroundColor: "#000000a0",
        tapBackgroundToDismiss: true
      },
      passProps: {}
    });
  }

  toShowGenderDailog() {
    this.props.navigator.showLightBox({
      ...Constants.Screens.SET_GENDER_DAILOG_SCREEN,
      style: {
        backgroundColor: '#000000A0',
        tapBackgroundToDismiss: true,
      },
      passProps: {
        onChangeValue: this.onChangeGender,
      }
    })
  }

  toShowMetatypeDailog() {
    this.props.navigator.showLightBox({
      ...Constants.Screens.SET_METATYPE_DAILOG_SCREEN,
      style: {
        backgroundColor: '#000000A0',
        tapBackgroundToDismiss: true,
      },
      passProps: {
        onChangeValue: this.onChangeMetatype,
      }
    })
  }

  onChangeFirstName = name => {
    this.onChangeValue(name, fieldFirstName)
  }

  onChangeLastName = name => {
    this.onChangeValue(name, fieldLastName)
  }

  onChangeMetatype = metatype => {
    if (this.state.userInfo.metatype != metatype) {
      this.onChangeValue(metatype, fieldMetatype)
    }
  }

  onChangeGender = gender => {
    if (this.state.userInfo.gender != gender) {
      this.onChangeValue(gender, fieldGender)
    }
  }

  onChangePassword = password => {
    this.onChangeValue(password, fieldPassword)
  }

  onChangeConfirmPassword = password => {
    this.onChangeValue(password, fieldConfirmPass)
  }

  onChangeEmail = email => {
    // alexander@five.agency
    this.onChangeValue(email, fieldEmail)
  }

  onChangeLocation = location => {
    // San Diego, CA, USA
    this.onChangeValue(location, fieldLocation)
  }

  onChangeValue = (value, field) => {
    const temp = this.state.userInfo
    temp[field] = value
    this.setModified(this.checkModified(temp, field))
    this.setState({
      userInfo: temp
    })
  }

  setModified(value) {
    if (this.state.isModifiedInfo != value) {
      this.setState({
        isModifiedInfo: value
      })
    }
  }

  isModified() {
    return this.state.isModifiedInfo
  }

  checkModified(newInfo, field) {
    const { User: { userInfo } } = this.props
    if (field
      && field != fieldPassword
      && field != fieldConfirmPass
      && ((newInfo[field] != userInfo[field]) && ((newInfo[field] && newInfo[field] != '') || (userInfo[field] && userInfo[field] != '')))) {
      return true
    }
    const keys = Object.keys(newInfo)
    const isEqual = keys.every(key => {
      if (key === fieldPassword || key === fieldConfirmPass) {
        if (newInfo[key] && newInfo[key] != '') {
          return false
        }
        return true
      }

      return (newInfo[key] === userInfo[key]) || ((!newInfo[key] || newInfo[key] === '') && (!userInfo[key] || userInfo[key] === ''))
    })
    return !isEqual
  }

  checkValidationFields = userInfo => {
    const { User: { language } } = this.props
    // names
    if (!userInfo[fieldFirstName] || userInfo[fieldFirstName] === '') {
      Alert.alert(multilingual.MSG_EMPTY_FIRSTNAME[language])
      return false
    }
    if (!userInfo[fieldLastName] || userInfo[fieldLastName] === '') {
      Alert.alert(multilingual.MSG_EMPTY_LASTNAME[language])
      return false
    }
    // Meta type
    /*if (!userInfo[fieldMetatype] || userInfo[fieldMetatype] === '') {
      Alert.alert(multilingual.MSG_EMPTY_METATYPE[language])
      return false
    }*/
    // Gender
    if (!userInfo[fieldGender] || userInfo[fieldGender] === '') {
      Alert.alert(multilingual.MSG_EMPTY_GENDER[language])
      return false
    }
    // Email
    if (!isValidEmail(userInfo[fieldEmail])) {
      Alert.alert(multilingual.MSG_INVALID_EMAIL[language])
      return false
    }
    // Password
    if (!isEqualPasswords(userInfo[fieldPassword], userInfo[fieldConfirmPass])) {
      Alert.alert(multilingual.MSG_NOTEQUAL_PASSWORD[language])
      return false
    }

    return true
  }

  applyChanges = () => {
    if (!this.isModified() || !this.checkValidationFields(this.state.userInfo)) {
      return
    }
    const { User: { changeInfo, language } } = this.props
    changeInfo(this.state.userInfo)
      .then(() => {
        this.setState({
          userInfo: this.getUserInfo(),
          isModifiedInfo: false,
        })
      })
      .catch(err => {
        err
        Alert.alert(Constants.multilingual.MSG_GENERAL[language])
      })
  }

  clearChanges = () => {
    this.setState({
      userInfo: this.getUserInfo(),
      isModifiedInfo: false,
    })
  }

  render() {
    const { User } = this.props
    const currentLanguage = User.language;
    const gender = this.state.userInfo[fieldGender] =='male' ? multilingual.MALE[currentLanguage] : multilingual.FEMALE[currentLanguage]
    return(
      <ContainerView>
        <ShowHeader
          title={ multilingual.SETTINGS[currentLanguage] }
          navigator={ this.props.navigator }
          isModal
          hasNotify
        />
        <ContainerApplyClearBtn
          isVisible={this.isModified()}
        >
          <ApplyButton
            onPress={this.applyChanges}
          >
            <ButtonText>Apply Changes</ButtonText>
          </ApplyButton>
          <ClearButton
            onPress={this.clearChanges}
          >
            <ButtonText>Clear Changes</ButtonText>
          </ClearButton>
        </ContainerApplyClearBtn>
        <ScrollView>
          <SnowBox noPad>
            <MainTitle
              hrPad={Constants.mainPadding}
              title={'User Information'}
            />
            <ItemView>
              <ContainerRowItemTitle>
                <RowItemTitle>{ 'Name' }</RowItemTitle>
              </ContainerRowItemTitle>
              <ContainerRowItemValue>
                <RowItemTxtInput
                  underlineColorAndroid={'transparent'}
                  value={this.state.userInfo[fieldFirstName]}
                  onChangeText={this.onChangeFirstName}
                />
              </ContainerRowItemValue>
            </ItemView>
            <ItemView>
              <ContainerRowItemTitle>
                <RowItemTitle>{ 'Meta Type' }</RowItemTitle>
              </ContainerRowItemTitle>
              <ContainerRowItemValue>
                <RowItemTxtInput
                  underlineColorAndroid={'transparent'}
                  value={this.state.userInfo[fieldLastName]}
                  onChangeText={this.onChangeLastName}
                />
              </ContainerRowItemValue>
            </ItemView>
            {/* <ItemView>
              <ContainerRowItemTitle>
                <ItemText>{ multilingual.META_TYPE[currentLanguage] }</ItemText>
              </ContainerRowItemTitle>
              <ContainerRowItemValue>
                <TchRowItemSelect
                  onPress={() => this.toShowMetatypeDailog()}
                >
                  <RowItemText>{this.state.userInfo[fieldMetatype]}</RowItemText>
                </TchRowItemSelect>
              </ContainerRowItemValue>
            </ItemView> */}
            <ItemViewWithoutBorder>
              <ContainerRowItemTitle>
                <ItemText>{ 'Gender' }</ItemText>
              </ContainerRowItemTitle>
              {/* <ContainerRowItemValue>
                <TchRowItemSelect
                  onPress={() => this.toShowGenderDailog()}
                >
                  <RowItemText>{this.state.userInfo[fieldGender]}</RowItemText>
                </TchRowItemSelect>
              </ContainerRowItemValue> */}
              <ContainerRowItem>
                <Icon source={require("../../../img/lock.png")} />
                <RowItemTxt>
                  {gender}
                </RowItemTxt>
              </ContainerRowItem>
            </ItemViewWithoutBorder>
          </SnowBox>
          <SnowBox noPad>
            <MainTitle
              hrPad={Constants.mainPadding}
              title={'Account'}
            />
            <ItemView>
              <ContainerRowItemTitle>
                <ItemText>{ multilingual.EMAIL[currentLanguage] }</ItemText>
              </ContainerRowItemTitle>
              <ContainerRowItem>
                <Icon source={require("../../../img/lock.png")} />
                <RowItemTxt numberOfLines={1}>
                  {this.state.userInfo[fieldEmail]}
                </RowItemTxt>
              </ContainerRowItem>
            </ItemView>
            <ItemView>
              <ContainerRowItemTitle>
                <ItemText
                  ellipsizeMode={'tail'}
                  numberOfLines={1}
                >
                  { multilingual.PASSWORD[currentLanguage] }
                </ItemText>
              </ContainerRowItemTitle>
              <ContainerRowItemValue>
                <RowItemTxtInput
                  underlineColorAndroid={'transparent'}
                  secureTextEntry
                  value={this.state.userInfo[fieldPassword]}
                  onChangeText={this.onChangePassword}
                  placeholder='New password'
                />
              </ContainerRowItemValue>
            </ItemView>
            <ItemViewWithoutBorder>
              <ContainerRowItemTitle>
                <ItemText
                  ellipsizeMode={'tail'}
                  numberOfLines={1}
                >
                  { multilingual.REPEATPASSWORD[currentLanguage] }
                </ItemText>
              </ContainerRowItemTitle>
              <ContainerRowItemValue>
                <RowItemTxtInput
                  underlineColorAndroid={'transparent'}
                  secureTextEntry
                  value={this.state.userInfo[fieldConfirmPass]}
                  onChangeText={this.onChangeConfirmPassword}
                  placeholder='Confirm password'
                />
              </ContainerRowItemValue>
            </ItemViewWithoutBorder>

            {/* <ItemViewWithoutBorder>
              <ContainerRowItemTitle>
                <ItemText>{ multilingual.LOCATION[currentLanguage] }</ItemText>
              </ContainerRowItemTitle>
              <ContainerRowItemValue>
                <RowItemTxtInput
                  value={this.state.userInfo[fieldLocation]}
                  onChangeText={this.onChangeLocation}
                />
              </ContainerRowItemValue>
            </ItemViewWithoutBorder> */}
          </SnowBox>
          <SnowBox noPad>
            <MainTitle
              hrPad={Constants.mainPadding}
              title={'User Information'}
            />
            <ItemView>
              <ContainerRowItemTitle>
                <RowItemTitle>{ multilingual.FACEBOOK[currentLanguage] }</RowItemTitle>
              </ContainerRowItemTitle>
              <ContainerRowItemValue>
                <Switch value={true}/>
              </ContainerRowItemValue>
            </ItemView>
            <ItemView>
              <ContainerRowItemTitle>
                <RowItemTitle>{ multilingual.INSTAGRAM[currentLanguage] }</RowItemTitle>
              </ContainerRowItemTitle>
              <ContainerRowItemValue>
                <Switch value={false}/>
              </ContainerRowItemValue>
            </ItemView>
            <ItemViewWithoutBorder>
              <ContainerRowItemTitle>
                <RowItemTitle>{ multilingual.TWITTER[currentLanguage] }</RowItemTitle>
              </ContainerRowItemTitle>
              <ContainerRowItemValue>
                <Switch value={true}/>
              </ContainerRowItemValue>
            </ItemViewWithoutBorder>
          </SnowBox>
          {/*<View>
            <TitleView>
              <TitleText>{ multilingual.MORE_SETTINGS[currentLanguage] }</TitleText>
            </TitleView>
            <ItemButton
              onPress = {() => { this.toShowLanguageDailog()} }
            >
              <ItemText>{ multilingual.SET_LANGUAGE[currentLanguage] }</ItemText>
              <ItemText>{ multilingual.LANGUAGE[currentLanguage] }</ItemText>
            </ItemButton>
          </View>*/}
          {/* <View>
            <TitleView>
              <TitleText>{ multilingual.CONNECT[currentLanguage] }</TitleText>
            </TitleView>
            <ItemButton>
              <ItemText>{ multilingual.FACEBOOK[currentLanguage] }</ItemText>
            </ItemButton>
            <ItemButtonWithBorder>
              <ItemText>{ multilingual.TWITTER[currentLanguage] }</ItemText>
            </ItemButtonWithBorder>
            <ItemButton>
              <ItemText>{ multilingual.INSTAGRAM[currentLanguage] }</ItemText>
            </ItemButton>
          </View> */}
        </ScrollView>
      </ContainerView>
    );
  }
}
