import React, { Component } from 'react'
import {
  View,
  Text,
  TouchableOpacity,
  TouchableWithoutFeedback,
} from 'react-native'
import { inject, observer } from 'mobx-react'
import Proptypes from 'prop-types'
import glamorous from 'glamorous-native'

import Constants   from '../../global/Constants'

const { width, height } = Constants.windowDimensions

const ContainerOverall = glamorous(View)({
  width,
  height,
  backgroundColor: 'transparent',
})

const TchBackground = glamorous(TouchableWithoutFeedback)({

})

const Overlay = glamorous(View)({
  width: '100%',
  height: '100%',
  backgroundColor: 'transparent',
})

const Dialog = glamorous(View)({
  position: 'absolute',
  bottom: 0,
  width: '100%',
  paddingVertical: 25,
  backgroundColor: Constants.Colors.white,
  borderRadius: 26,
  shadowColor: 'rgba(0, 0, 0, 0.17)',
  shadowOffset: {
    width: 0,
    height: -6,
  },
  shadowOpacity: 1,
  elevation: 10,
  shadowRadius: 10,
})

const ContainerRow = glamorous(View)({
  borderBottomWidth: 0.5,
  borderBottomColor: Constants.Colors.warmGreyTwo,
})

const TchOption = glamorous(TouchableOpacity)({
  alignItems: 'center',
  paddingVertical: 15,
})

const TxtLabel = glamorous(Text)({
  fontSize: 18,
  color: Constants.Colors.darkSkyBlue,
})

const { object, func } = Proptypes

@inject('User')
@observer
export default class SetMetatypeDailog extends Component {
  static propTypes = {
    onChangeValue: func,
    navigator: object,
    User: object,
  }

  toDualEfficient = () => {
    this.props.onChangeValue('Dual Efficient')
    this.props.navigator.dismissLightBox()
  }

  toCarboEfficient = () => {
    this.props.onChangeValue('Carbohydrate Efficient')
    this.props.navigator.dismissLightBox()
  }

  toFatProteinEfficient = () => {
    this.props.onChangeValue('Fat Protein Efficient')
    this.props.navigator.dismissLightBox()
  }

  render() {
    return (
      <ContainerOverall>
        <TchBackground
          onPress={() => this.props.navigator.dismissLightBox()}
        >
          <Overlay />
        </TchBackground>
        <Dialog>
          <ContainerRow>
            <TchOption
              onPress={this.toDualEfficient}
            >
              <TxtLabel>Dual Efficient</TxtLabel>
            </TchOption>
          </ContainerRow>
          <ContainerRow>
            <TchOption
              onPress={this.toCarboEfficient}
            >
              <TxtLabel>Carbohydrate Efficient</TxtLabel>
            </TchOption>
          </ContainerRow>
          <ContainerRow>
            <TchOption
              onPress={this.toFatProteinEfficient}
            >
              <TxtLabel>Fat Protein Efficient</TxtLabel>
            </TchOption>
          </ContainerRow>
        </Dialog>
      </ContainerOverall>
    )
  }
}
