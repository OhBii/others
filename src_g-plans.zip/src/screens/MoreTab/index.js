/*
*   author: denis
*   date:   7/12/2018
*/

import React, { Component } from 'react';
import {
  View,
  ScrollView,
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import { inject, observer } from 'mobx-react/native'
import Intercom from 'react-native-intercom'

import Constants from '../../global/Constants';
import ShowHeader from '../components/HeaderBar/ShowHeader';
import ListItem from '../components/MoreTab/ListItem'
import SnowBox from '../components/Common/SnowBox'
import CustomTabs from '../components/CustomTabs'

const multilingual = Constants.Multilingual;
const { height } = Constants.windowDimensions;

const Wrap = glamorous(View)({
  height,
  paddingBottom: 75,
  backgroundColor: Constants.Colors.whiteFive
})

const WrapView = glamorous(View)({
  elevation: 10
})

const SnowBoxStyle = {
  marginBottom: 50
}

const { object } = Proptypes;
@inject('User') @observer
export default class MoreTab extends Component {
  static propTypes = {
    navigator: object,
    User: object
  }

  constructor(props) {
    super(props);
    this.state = {
      unreadIntercomCount: 0
    }
  }

  componentDidMount() {
    Intercom.addEventListener(Intercom.Notifications.UNREAD_COUNT, this.onUnreadChange)
  }

  componentWillUnmount() {
    Intercom.removeEventListener(Intercom.Notifications.UNREAD_COUNT, this.onUnreadChange)
  }

  onUnreadChange = ({ count }) => {
    this.setState({
      unreadIntercomCount: count
    })
  }

  toNotification() {
    this.props.navigator.showModal({
      ...Constants.Screens.NOTIFICATION_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  toLogout() {
    this.props.User.logout();
    Constants.Global.startSingleScreenApp();
  }

  toSetting() {
    this.props.navigator.showModal({
      ...Constants.Screens.SETTING_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  toGrocery() {
    this.props.navigator.push({
      ...Constants.Screens.GROCERY_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  toRecipes() {
    this.props.navigator.push({
      ...Constants.Screens.RECIPE_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  toPdfAssets() {
    this.props.navigator.push({
      ...Constants.Screens.PDFASSETS_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  toTips() {
    this.props.navigator.push({
      ...Constants.Screens.LIST_TIPS_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  toBlog() {
    this.props.navigator.push({
      ...Constants.Screens.BLOG_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  toShop() {
    this.props.navigator.push({
      ...Constants.Screens.SHOP_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    })
  }

  toHelp() {
    this.props.navigator.push({
      ...Constants.Screens.HELP_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  toContactSupport() {
    setTimeout(() => {
      Intercom.displayMessageComposer()
    }, 500)
  }

  toVideoTutorial() {

  }

  render() {
    const {
      User: {
        language,
        isPremium,
      }
    } = this.props
    const currentLanguage = language;
    return (
      <Wrap>
        <WrapView>
          <ShowHeader
            hasBack={false}
            title={multilingual.MORE[currentLanguage]}
            hasNotify
            navigator={this.props.navigator}
          />
        </WrapView>
        <ScrollView>
          <SnowBox noPad noPadV style={SnowBoxStyle}>
            <ListItem
              onPress={() => this.toRecipes()}
              iconName={'silverware'}
              iconSize={24}
              iconColor={Constants.Colors.greyish}
              title={multilingual.RECIPES[currentLanguage]}
            />
            {isPremium &&
              <ListItem
                onPress={() => this.toGrocery()}
                iconName={'food-variant'}
                iconSize={24}
                iconColor={Constants.Colors.greyish}
                title={multilingual.GROCERY_LIST[currentLanguage]}
              />
            }
            <ListItem
              onPress={() => this.toBlog()}
              iconName={'message-text-outline'}
              iconSize={24}
              iconColor={Constants.Colors.greyish}
              title={multilingual.BLOG[currentLanguage]}
            />
            <ListItem
              onPress={() => this.toShop()}
              iconName={'medical-bag'}
              iconSize={24}
              iconColor={Constants.Colors.greyish}
              title={'Shop'}
            />
            <ListItem
              onPress={() => this.toHelp()}
              iconName={'help-circle'}
              iconSize={24}
              iconColor={Constants.Colors.greyish}
              title={multilingual.HELP[currentLanguage]}
            />
            <ListItem
              onPress={() => this.toContactSupport()}
              iconName={'wechat'}
              iconSize={24}
              iconColor={Constants.Colors.greyish}
              title={'Contact Support'}
              count={this.state.unreadIntercomCount}
            />
            <ListItem
              onPress={() => this.toPdfAssets()}
              iconName={'book-open-page-variant'}
              iconSize={24}
              iconColor={Constants.Colors.greyish}
              title={'Resources and Books'}
            />
            {isPremium &&
              <ListItem
                onPress={() => this.toVideoTutorial()}
                iconName={'video'}
                iconSize={24}
                iconColor={Constants.Colors.greyish}
                title={'Video Tutorial'}
              />
            }
            {/*<ItemView>
              <ItemButton onPress={() => this.toLogout()}>
                <DarkText>{ multilingual.LOGOUT[currentLanguage] }</DarkText>
                <Icon name="angle-right" size={18} color={Constants.Colors.marineTwo} />
              </ItemButton>
            </ItemView>*/}
          </SnowBox>
        </ScrollView>
        <CustomTabs navigator={this.props.navigator} active={3}/>
      </Wrap>
    );
  }
}
