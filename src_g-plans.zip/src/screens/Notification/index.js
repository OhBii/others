/*
*   author: denis
*   date:   7/12/2018
*/

import React, { Component } from 'react';
import {
  View,
  ScrollView,
  Text
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import { inject, observer } from 'mobx-react/native';
import Icon from 'react-native-vector-icons/Ionicons';

import Constants from '../../global/Constants';
import ShowHeader from '../components/HeaderBar/ShowHeader';
import NotifItem from '../components/Notification/NotifItem';

const multilingual = Constants.Multilingual;
//Notification list
const ContainerView = glamorous(View)({
  flexDirection: "column",
  flex: 1,
  backgroundColor: Constants.Colors.whiteFive
});

const ContainerMessage = glamorous(View)({
  flex:1,
  paddingTop: 70,
  flexDirection:"column",
  alignItems: "center",
})

const MessageText = glamorous(Text)({
  fontSize: 25,
  color: Constants.Colors.notificationColor,
  top: 10,
  marginBottom: 30
})

const { object, number } = Proptypes;
@inject('User', 'Tips') @observer
export default class Notification extends Component {
  static propTypes = {
    navigator: object,
    User: object,
    Tips: object,
    initalOpenId: number,
  }

  constructor() {
    super();
  }

  componentDidMount() {
    setTimeout(() => {
      if (this.initalOpenedNoti) {
        this.initalOpenedNoti.measure((fx, fy, /*width, height, px, py*/) => {
          this.scrollView.scrollTo({
            x: fx,
            y: fy,
            animated: true,
          })
        })
      }
    }, 100)
  }

  render() {
    const {
      User:{ language },
      Tips: {
        tips,
        setAsReadTipById,
        removeTipById,
      },
      initalOpenId,
    } = this.props
    return(
      <ContainerView>
        <ShowHeader
          title= { multilingual.NOTIFICATIONS[language] }
          navigator={this.props.navigator}
          isModal
        />
        {
          tips.length
            ? <ScrollView
                ref={ref => this.scrollView = ref}
              >
              {tips.map(tip => (
                <View
                  key={tip.id}
                  ref={ref => {
                    if (tip.id === initalOpenId)
                      this.initalOpenedNoti = ref
                  }}
                >
                  <NotifItem
                    id={tip.id}
                    title={tip[`title_${language}`] ? tip[`title_${language}`] : tip.title}
                    date={tip.created_at}
                    message={tip[`message_${language}`] ? tip[`message_${language}`] : tip.message}
                    event={tip.event}
                    isRead={tip.isRead}
                    iconIndex={tip.iconIndex}
                    setAsRead={setAsReadTipById}
                    deleteTip={removeTipById}
                    initalOpened={tip.id === initalOpenId}
                  />
                </View>
              ))}
              </ScrollView>
            : <ContainerMessage>
                <Icon name="ios-mail-open" size={130} color={Constants.Colors.notificationColor} />
                <MessageText>{multilingual.NO_NOTIFICATIONS[language]}</MessageText>
              </ContainerMessage>
        }
      </ContainerView>
    );
  }
}
