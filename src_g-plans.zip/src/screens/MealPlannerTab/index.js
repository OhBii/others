// @flow
import React, { Component } from 'react';
import Proptypes from 'prop-types';
import {
  ScrollView,
  View
} from 'react-native';
import { inject, observer } from 'mobx-react/native';
import glamorous from 'glamorous-native';
import moment from 'moment'

import NavButtons  from '../../global/NavButtons';
import NavBar      from '../../global/NavBar';
import MealCardListItem from '../components/MealCard/MealCardListItem'
import Header from '../components/HeaderBar/Header';
import MainTitle from '../components/Common/MainTitle';
import Constants   from '../../global/Constants';
import CustomTabs from '../components/CustomTabs'

const { width, height } = Constants.windowDimensions;
const mainPadding = Constants.mainPadding;
const multilingual = Constants.Multilingual;
const Inner = glamorous(View)({
  width,
  paddingHorizontal: mainPadding,
  paddingTop: 10
})

const Container = glamorous(View)({
  height,
  backgroundColor: Constants.Colors.whiteFive
})

const Wrap = glamorous(View)({
  height,
  paddingBottom: 75
})

const { object } = Proptypes;

@inject( 'User', 'MealPlan' ) @observer
class MealPlannerTab extends Component {
  static navigatorButtons = NavButtons.WithSideMenu;
  static navigatorStyle   = NavBar.Default;

  static propTypes = {
    // App: shape({ recipes: object }),
    User: object,
    MealPlan: object,
    navigator: object
  }

  constructor(props) {
    super(props);

    this.state = {
      mealDate: {}
    }
  }

  toRecipeView(recipe, mealId) {
    const flex = recipe ? false : true;
    if (flex) {
      this.props.navigator.showModal({
        ...Constants.Screens.MEAL_DETAIL_SCREEN,
        passProps: {
          MealId: mealId
        },
        navigatorStyle: {
          navBarHidden: true,
          tabBarHidden: true
        }
      });
    }
    else {
      this.props.navigator.showModal({
        ...Constants.Screens.RECIPE_ITEM_SCREEN,
        passProps: {
          forView: false,
          MealId: mealId,
          RecipeId: recipe.id
        },
        navigatorStyle: {
          navBarHidden: true,
          tabBarHidden: true
        }
      });
    }

  }

  render() {
    const { User, MealPlan } = this.props
    const currentLanguage = User.language;
    const flex = !User.isPremium;

    const data = MealPlan.getMealsByIndexes;
     return (
    <Wrap>
      <Container>
        <Header
          onSelect={(day) => this.setState({ mealDate: day })}
          hasBack={false}
          title={multilingual.MEAL_PLANNER[currentLanguage]}
          navigator={this.props.navigator}
          height={230}
          hasShadow={false}
          weakHeader={true}
          />
        <ScrollView>
          <Inner>
            <MainTitle title={ `${moment(this.state.mealDate, 'ddd MMM DD YYYY').format('dddd Do')} ${multilingual.MEALS[currentLanguage]}`} />
            {
              data.map((item, index) =>
                <MealCardListItem
                  key={index}
                  data={ item }
                  mealNumber={index + 1}
                  onSelected={() => this.toRecipeView(item.recipe, item.id)}
                  mBottom={25}
                  width={width - (mainPadding * 2)}
                  navigator={this.props.navigator}
                  flex={flex}
                  fullMode={!flex}
                  homeMode={!flex}
                />)
            }
          </Inner>
        </ScrollView>
      </Container>
      <CustomTabs navigator={this.props.navigator} active={1}/>
    </Wrap>
    )
  }
}

export default MealPlannerTab
