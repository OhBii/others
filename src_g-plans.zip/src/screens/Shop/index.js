
import React, { Component } from 'react'
import Proptypes from 'prop-types'
import { inject, observer } from 'mobx-react/native';

import Constants from '../../global/Constants'
import StyledWebView from '../components/Common/StyledWebView'

const multilingual = Constants.Multilingual;

const { object } = Proptypes;
@inject('User') @observer
export default class Shop extends Component {
  static propTypes = {
    navigator: object,
    User: object
  }

  constructor(props) {
    super(props);
  }

  render() {
    const { User } = this.props
    const currentLanguage = User.language
    return (
      <StyledWebView
        title={multilingual.SHOP[currentLanguage]}
        navigator={this.props.navigator}
        hasNotify
        link={'https://goglianutrition.myshopify.com/'}
      />
    )
  }
}
