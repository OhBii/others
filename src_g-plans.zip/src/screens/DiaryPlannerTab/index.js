/*
*   author: denis
*   date:   10/08/2018
*/

import React, { Component } from 'react'
import Proptypes from 'prop-types';
import {
  View
} from 'react-native';
import glamorous from 'glamorous-native'
import { TabView, TabBar, SceneMap } from 'react-native-tab-view'

import Constants from '../../global/Constants'
import Diary from '../components/DiaryAndPlanner/Diary'
import Planner from '../components/DiaryAndPlanner/Planner'
import CustomTabs from '../components/CustomTabs'

const { width, height } = Constants.windowDimensions

const Wrap = glamorous(View)({
  height,
  paddingBottom: 75
})

const { object } = Proptypes;

export default class DiaryPlannerTab extends Component {
  static propTypes = {
    navigator: object
  }

  constructor(props) {
    super(props)
    this.state = {
      index: 0,
      routes: [
        { key: 'diary', title: 'Diary' },
        { key: 'planner', title: 'Planner' },
      ],
    };

    this.props.navigator.setOnNavigatorEvent(this.onNavigatorEvent.bind(this));
  }

  onNavigatorEvent(event) {
    // console.log(event)
    if (event.id === 'didDisappear') {
      this.handleIndexChange(0)
    }
  }

  handleIndexChange(index) {
    this.setState({ index })
  }

  renderTabBar(props) {
    /* eslint-disable */
    return (
      <TabBar
        {...props}
        getLabelText={({ route }) => route.title}
        style={{
          backgroundColor: Constants.Colors.white,
          paddingTop: 24
        }}
        indicatorStyle={{
          backgroundColor: Constants.Colors.dodgerBlueFour
        }}
        labelStyle={{
          color: Constants.Colors.greyishBrown,
          fontSize: 20
        }}
      />
    )
    /* eslint-enable */
  }

  render() {
    return (
      <Wrap>
        <TabView
          navigationState={this.state}
          renderScene={
            SceneMap({
              diary: Diary,
              planner: Planner,
            })
          }
          renderTabBar={(props) => this.renderTabBar(props)}
          onIndexChange={(index) => this.handleIndexChange(index)}
          initialLayout={{
            width: width,
            height: height
          }}
          swipeEnabled={false}
        />
        <CustomTabs
          navigator={this.props.navigator}
          active={1}
          initAction={() => this.handleIndexChange(0)}/>
    </Wrap>
    );
  }
}
