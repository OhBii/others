// @flow

import { Navigation } from 'react-native-navigation';

import Constants      from '../global/Constants';

import HomeTab            from './HomeTab';
import MealPlannerTab     from './MealPlannerTab';
import DiaryPlannerTab     from './DiaryPlannerTab';
import StatsTab           from './StatsTab';
import MoreTab            from './MoreTab';
import Drawer             from './Drawer';
import RecipeItemScreen   from './RecipeItemScreen'
import Notification       from './Notification';
import SearchScreen       from './SearchScreen';
import CustomDialog       from './components/Recipe/CustomDialog'
import ConfirmAmount      from './ConfirmAmount'
import Tour               from './components/Tour'

//denis
import Login              from './Login'
import Forgot             from './Forgot'
import Setting            from './Setting'
import Grocery            from './Grocery'
import AddGrocery         from './AddGrocery'
import WeekGrocery        from './WeekGrocery'
import ItemChange         from './components/WeekGrocery/ItemChange'
import Recipe             from './Recipe'
import PdfAssets          from './PdfAssets'
import Blog               from './Blog'
import Shop               from './Shop'
import Help               from './Help'
import Profile            from './Profile'
import Camera             from './Camera'
import WaterTracker       from './components/Tracker/WaterTracker'
import ExerciseTracker    from './components/Tracker/ExerciseTracker'
import ExerciseList       from './components/Tracker/ExerciseList'
import ExerciseRemove     from './components/Tracker/ExerciseRemove'
import SuccessScreen      from './components/Tracker/SuccessScreen'
import SwapDialog         from './components/Recipe/SwapDialog'
import SwapModal          from './components/Recipe/SwapModal'
import SetLanguageDailog  from './Setting/SetLanguageDailog'
import SetGenderDailog    from './Setting/SetGenderDailog'
import PreviewImage       from './components/Profile/PreviewImage'
import Checkin            from './Checkin'
import MealDetailScreen   from './MealDetailScreen'
import SelectShareDialog  from './Profile/SelectShareBox'
import DetailTip          from './Tips/DetailTip'
import ListTips           from './Tips/ListTips'
import Loading            from './Loading'
import ChallengesListScreen        from './components/Challenges/ChallengesListScreen'
import ChallengeDetailScreen       from './components/Challenges/ChallengeDetailScreen'

//Funnel
import Quiz               from './Funnel/Quiz'
import Accepted           from './Funnel/Accepted'
import Plan               from './Funnel/Plan'
import Intro              from './Funnel/Intro'
import IntroFlex          from './Funnel/IntroFlex'
import AppleIdBox         from './components/Funnel/AppleIdBox'
import Reboot             from './Funnel/Reboot'
import RebootIntro        from './Funnel/RebootIntro'
import SetMetatypeDailog  from './Setting/SetMetatypeDialog'
import OauthView          from './Funnel/OauthView'
// import Checkin            from './Funnel/Checkin'

export function registerScreens(store, Provider) {
  Navigation.registerComponent(Constants.Screens.HOME_TAB.screen,     () => HomeTab, store, Provider);
  Navigation.registerComponent(Constants.Screens.MEALPLANNER_TAB.screen,    () => MealPlannerTab, store, Provider);
  Navigation.registerComponent(Constants.Screens.DIARYPLANNER_TAB.screen,    () => DiaryPlannerTab, store, Provider);
  Navigation.registerComponent(Constants.Screens.STATS_TAB.screen,    () => StatsTab, store, Provider);
  Navigation.registerComponent(Constants.Screens.MORE_TAB.screen,    () => MoreTab, store, Provider);

  //Funnel
  Navigation.registerComponent(Constants.Screens.QUIZ_SCREEN.screen, () => Quiz, store, Provider);
  Navigation.registerComponent(Constants.Screens.PLAN_SCREEN.screen, () => Plan, store, Provider);
  Navigation.registerComponent(Constants.Screens.INTRO_SCREEN.screen, () => Intro, store, Provider);
  Navigation.registerComponent(Constants.Screens.INTRO_FLEX_SCREEN.screen, () => IntroFlex, store, Provider);
  Navigation.registerComponent(Constants.Screens.ACCEPTED_SCREEN.screen, () => Accepted, store, Provider);
  Navigation.registerComponent(Constants.Screens.APPLE_ID_SCREEN.screen, () => AppleIdBox, store, Provider);
  Navigation.registerComponent(Constants.Screens.REBOOT_SCREEN.screen, () => Reboot, store, Provider);
  Navigation.registerComponent(Constants.Screens.REBOOT_INTRO_SCREEN.screen, () => RebootIntro, store, Provider);
  Navigation.registerComponent(Constants.Screens.CHECKIN_SCREEN.screen, () => Checkin, store, Provider);
  Navigation.registerComponent(Constants.Screens.OAUTH_SCREEN.screen, () => OauthView, store, Provider);

  //denis
  Navigation.registerComponent(Constants.Screens.LOGIN_SCREEN.screen, () => Login, store, Provider);
  Navigation.registerComponent(Constants.Screens.FORGOT_SCREEN.screen, () => Forgot, store, Provider);
  Navigation.registerComponent(Constants.Screens.NOTIFICATION_SCREEN.screen, () => Notification, store, Provider);
  Navigation.registerComponent(Constants.Screens.SETTING_SCREEN.screen, () => Setting, store, Provider);
  Navigation.registerComponent(Constants.Screens.GROCERY_SCREEN.screen, () => Grocery, store, Provider);
  Navigation.registerComponent(Constants.Screens.ADDGROCERY_SCREEN.screen, () => AddGrocery, store, Provider);
  Navigation.registerComponent(Constants.Screens.WEEKGROCERY_SCREEN.screen, () => WeekGrocery, store, Provider);
  Navigation.registerComponent(Constants.Screens.ITEMCHANGE_SCREEN.screen, () => ItemChange, store, Provider);
  Navigation.registerComponent(Constants.Screens.RECIPE_SCREEN.screen, () => Recipe, store, Provider);
  Navigation.registerComponent(Constants.Screens.PDFASSETS_SCREEN.screen, () => PdfAssets, store, Provider);
  Navigation.registerComponent(Constants.Screens.BLOG_SCREEN.screen, () => Blog, store, Provider);
  Navigation.registerComponent(Constants.Screens.SHOP_SCREEN.screen, () => Shop, store, Provider);
  Navigation.registerComponent(Constants.Screens.HELP_SCREEN.screen, () => Help, store, Provider);
  Navigation.registerComponent(Constants.Screens.PROFILE_SCREEN.screen, () => Profile, store, Provider);
  Navigation.registerComponent(Constants.Screens.CAMERA_SCREEN.screen, () => Camera, store, Provider);
  Navigation.registerComponent(Constants.Screens.WATERTRACKER_SCREEN.screen, () => WaterTracker, store, Provider);
  Navigation.registerComponent(Constants.Screens.EXERCISETRACKER_SCREEN.screen, () => ExerciseTracker, store, Provider);
  Navigation.registerComponent(Constants.Screens.EXERCISELIST_SCREEN.screen, () => ExerciseList, store, Provider);
  Navigation.registerComponent(Constants.Screens.EXERCISEREMOVE_SCREEN.screen, () => ExerciseRemove, store, Provider);
  Navigation.registerComponent(Constants.Screens.SUCCESS_SCREEN.screen, () => SuccessScreen, store, Provider);
  Navigation.registerComponent(Constants.Screens.SWAP_DIALOG_SCREEN.screen, () => SwapDialog, store, Provider);
  Navigation.registerComponent(Constants.Screens.SWAP_MODAL_SCREEN.screen, () => SwapModal, store, Provider);
  Navigation.registerComponent(Constants.Screens.SET_LANGUAGE_DAILOG_SCREEN.screen, () => SetLanguageDailog, store, Provider);
  Navigation.registerComponent(Constants.Screens.PREVIEW_IMAGE_SCREEN.screen, () => PreviewImage, store, Provider);
  Navigation.registerComponent(Constants.Screens.SET_GENDER_DAILOG_SCREEN.screen, () => SetGenderDailog, store, Provider);
  Navigation.registerComponent(Constants.Screens.SET_METATYPE_DAILOG_SCREEN.screen, () => SetMetatypeDailog, store, Provider);
  Navigation.registerComponent(Constants.Screens.MEAL_DETAIL_SCREEN.screen, () => MealDetailScreen, store, Provider);
  Navigation.registerComponent(Constants.Screens.TOUR.screen, () => Tour, store, Provider);
  Navigation.registerComponent(Constants.Screens.CHALLENGES_LIST.screen, () => ChallengesListScreen, store, Provider);
  Navigation.registerComponent(Constants.Screens.CHALLENGE_DETAIL.screen, () => ChallengeDetailScreen, store, Provider);
  Navigation.registerComponent(Constants.Screens.LOADING_SCREEN.screen, () => Loading, store, Provider);

  Navigation.registerComponent(Constants.Screens.DRAWER.screen,        () => Drawer, store, Provider);
  Navigation.registerComponent(Constants.Screens.SEARCH_SCREEN.screen,  () => SearchScreen, store, Provider);
  Navigation.registerComponent(Constants.Screens.RECIPE_ITEM_SCREEN.screen,  () => RecipeItemScreen, store, Provider);
  Navigation.registerComponent(Constants.Screens.CUSTOM_DIALOG_SCREEN.screen, () => CustomDialog, store, Provider);
  Navigation.registerComponent(Constants.Screens.CONFIRM_AMOUNT_SCREEN.screen,  () => ConfirmAmount, store, Provider);
  Navigation.registerComponent(Constants.Screens.SELECT_SHARE_DIALOG_SCREEN.screen, () => SelectShareDialog, store, Provider)
  Navigation.registerComponent(Constants.Screens.DETAIL_TIP_SCREEN.screen, () => DetailTip, store, Provider);
  Navigation.registerComponent(Constants.Screens.LIST_TIPS_SCREEN.screen, () => ListTips, store, Provider);
}
