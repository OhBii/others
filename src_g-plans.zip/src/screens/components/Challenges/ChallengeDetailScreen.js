import React, { Component } from 'react'
import {
  Text,
  View,
  Image,
  ScrollView,
  TouchableOpacity,
  Animated
} from 'react-native'
import Proptypes from 'prop-types';
import { inject, observer } from 'mobx-react/native';
import glamorous from 'glamorous-native'

import ShowHeader from '../HeaderBar/ShowHeader';
import Constants   from '../../../global/Constants'

const AnimatedView = glamorous(Animated.View)

const Container = glamorous(View)({
  flex: 1,
  backgroundColor: Constants.Colors.white
})

const Inner = glamorous(View)({
  flexDirection: 'column',
  alignItems: 'center',
  width: '100%',
  paddingHorizontal: Constants.mainPadding
})

const Picture = glamorous(View)(({ color }) => ({
  width: 250,
  height: 250,
  borderRadius: 8,
  alignItems: 'center',
  justifyContent: 'center',
  backgroundColor: color || '#edf3f9',
  marginBottom: 15
}))

const NameTitle = glamorous(Text)({
  fontSize: 26,
  fontWeight: "bold",
  color: '#171a1e',
  marginBottom: 20
})

const Type = glamorous(View)(({ color }) => ({
  borderRadius: 8,
  paddingVertical: 5,
  paddingHorizontal: 20,
  backgroundColor: color || 'rgba(208, 2, 27, 0.5)',
  marginBottom: 10
}))

const TypeText = glamorous(Text)({
  fontSize: 14,
  fontWeight: 'bold',
  textAlign: 'center',
  color: Constants.Colors.white,
  backgroundColor: 'transparent'
})

const Descr = glamorous(Text)({
  fontSize: 18,
  fontWeight: '500',
  textAlign: 'center',
  color: '#333a43',
  maxWidth: 195,
  marginBottom: 20
})

const UsersComplete = glamorous(Text)({
  fontSize: 14,
  fontWeight: 'bold',
  textAlign: 'center',
  color: '#788da5'
})

const Footer = glamorous(View)({
  height: 90,
  width: '100%',
  flexDirection: 'row',
  justifyContent: 'center',
  paddingHorizontal: Constants.mainPadding
})

const Action = glamorous(TouchableOpacity)(({ untrack }) => ({
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'center',
  width: '100%',
  height: 60,
  borderRadius: 30,
  backgroundColor: Constants.Colors.white,
  shadowColor: 'rgba(0, 0, 0, 0.15)',
  shadowOffset: {
    width: 0,
    height: 4
  },
  shadowRadius: 15,
  elevation: 4,
  shadowOpacity: 1,
  borderStyle: 'solid',
  borderWidth: 1,
  borderColor: untrack ? '#979797' : '#70b3ff'
}))

const ActionText = glamorous(Text)(({ untrack }) => ({
  fontSize: 16,
  fontWeight: 'bold',
  color: untrack ? '#979797' : '#70b3ff'
}))

const ProgressWrap = glamorous(View)({
  width: '100%',
  marginTop: 26,
  marginBottom: 34
})

const ProgressBottom = glamorous(View)({
  flexDirection: 'row',
  width: '100%',
  marginTop: 8,
  justifyContent: 'space-between'
})

const ProgressAxisLabel = glamorous(Text)({
  fontSize: 20,
  fontWeight: 'bold',
  color: '#d6dee8'
})

const ProgressContainer = glamorous(View)({
  width: '100%',
  height: 14,
  borderRadius: 7,
  backgroundColor: '#d6dee8',
  overflow: 'hidden'
})

const ProgressBarFull = AnimatedView({
  height: 14,
  borderRadius: 7,
  position: 'absolute',
  left: 0
})
ProgressBarFull.propsAreStyleOverrides = true

const ProgressBarGradient = glamorous(View)(({ color }) =>({
  width: '100%',
  position: 'absolute',
  left: 0,
  top: 0,
  bottom: 0,
  backgroundColor: color ? '#F8C91C' : '#4da0ff'
}))

const ProgressCurrentView = AnimatedView({
  position: 'absolute',
  top: 0,
  transform: [{ translateX: -30 }]
})
ProgressCurrentView.propsAreStyleOverrides = true

const ProgressCurrent = glamorous(Text)({
  fontSize: 20,
  fontWeight: '300',
  color: '#333a43'
})

const RibbonWrap = glamorous(View)({
  position: 'absolute',
  justifyContent: 'center',
  flexDirection: 'row',
  top: 10,
  left: 0,
  right: 0,
  zIndex: 2
})

const Friends = glamorous(View)({
  flexDirection: 'column',
  alignItems: 'center',
  width: '100%',
  marginBottom: 40
})

const FriendsTitle = glamorous(Text)({
  fontSize: 16,
  fontWeight: '500',
  color: '#788da5',
  marginBottom: 10
})

const NoFriends = glamorous(View)({
  width: 253,
  height: 72,
  borderRadius: 8,
  backgroundColor: '#edf3f9',
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'center'
})

const FriendsRow = glamorous(View)({
  alignItems: 'center',
  justifyContent: 'center',
  flexDirection: 'row'
})

const FriendCircle = glamorous(View)({
  width: 60,
  height: 60,
  backgroundColor: Constants.Colors.blackTwo,
  borderRadius: 30,
  marginHorizontal: 5
})

const NoFriendsText = glamorous(Text)({
  fontSize: 20,
  fontWeight: 'bold',
  color: '#d6dee8'
})

const Ribbon = glamorous(Image)({})

const { object, string, number, array, bool } = Proptypes;
@inject('App') @observer
class ChallengeDetailScreen extends Component {
  static propTypes = {
    navigator: object,
    challenge: object,
    backgound: string,
    name: string,
    image: number,
    currentComplete: number,
    completeUsers: number,
    type: string,
    description: string,
    bar: number,
    total: number,
    friends: array,
    complete: bool
  }

  static defaultProps = {
    currentComplete: 0,
    completeUsers: 0
  }

  constructor(props) {
    super(props)
    this.state = {
      bar: props.bar
    }
  }

  componentDidUpdate(prevProps){
    if(prevProps.bar !== this.state.bar) {
      this.setState({ bar: prevProps.bar });
    }
  }

  render() {
    const {
      backgound,
      name,
      image,
      type,
      description,
      total,
      currentComplete,
      completeUsers,
      friends,
      complete
    } = this.props

    const uppercaseType = type.toUpperCase();
    return(
      <Container>
        <ShowHeader
          title={'Challenges'}
          navigator={ this.props.navigator }
          hasNotify
          isModal
        />
          <ScrollView>
            <Inner>
              {!!complete && <RibbonWrap><Ribbon source={Constants.Images.RIBBON}/></RibbonWrap>}
              <Picture
                color={ backgound }
              >
                <Image source={ image } />
              </Picture>
              <NameTitle>{ name }</NameTitle>
              <Descr>{ description }</Descr>
              <Type
                color={
                  uppercaseType == 'EASY' ? '#4af173'
                  : uppercaseType == 'MEDIUM' ? '#ffa170'
                  : 'rgba(208, 2, 27, 0.5)'
                }
              >
                <TypeText>{ uppercaseType }</TypeText>
              </Type>
              {!!completeUsers && <UsersComplete>{ `${completeUsers}% of users complete this` }</UsersComplete>}
              <ProgressWrap>
                <ProgressContainer>
                  <ProgressBarFull
                    width={!complete ? `${this.state.bar}%` : '100%'}
                  >
                    <ProgressBarGradient color={complete}/>
                  </ProgressBarFull>
                </ProgressContainer>
                <ProgressBottom>
                  <ProgressAxisLabel>{0}</ProgressAxisLabel>
                  <ProgressAxisLabel>{total}</ProgressAxisLabel>
                  {!complete && currentComplete > 0 && <ProgressCurrentView left={`${this.state.bar}%`}>
                      <ProgressCurrent>
                        { `${currentComplete} fl oz` }
                      </ProgressCurrent>
                    </ProgressCurrentView>
                  }
                </ProgressBottom>
              </ProgressWrap>
              <Friends>
                <FriendsTitle>{'Friends who have earned this badge:'}</FriendsTitle>
                {!friends.length ?
                  <NoFriends>
                    <NoFriendsText>{'No one yet!'}</NoFriendsText>
                  </NoFriends>
                  : <FriendsRow>
                      {friends.map((el, idx) =>
                      <FriendCircle key={idx}></FriendCircle>
                    )}
                    </FriendsRow>
                }
              </Friends>
            </Inner>
          </ScrollView>
          <Footer>
            {!complete ? <Action onPress={() => {}} activeOpacity={0.8}>
              <ActionText>{ 'Track this challenge' }</ActionText>
            </Action>
            : <Action onPress={() => {}} activeOpacity={0.8} untrack>
              <ActionText untrack>{ 'UnTrack this challenge' }</ActionText>
            </Action>}
          </Footer>
      </Container>
    )
  }
}

export default ChallengeDetailScreen
