import React, { Component } from 'react'
import {
  ScrollView,
  TouchableOpacity
} from 'react-native'
import Proptypes from 'prop-types';
import { inject, observer } from 'mobx-react/native';
import glamorous from 'glamorous-native'

import ShowHeader from '../HeaderBar/ShowHeader';
import ChallengeItem from './ChallengeItem';
import Constants   from '../../../global/Constants'

const { width } = Constants.windowDimensions

const Container = glamorous(TouchableOpacity)({
  flex: 1,
  backgroundColor: Constants.Colors.white
})

const Grid = glamorous(TouchableOpacity)({
  flexDirection: 'row',
  flexWrap: 'wrap',
  justifyContent: 'space-between',
  paddingHorizontal: Constants.mainPadding
})

const { object } = Proptypes;
@inject('App') @observer
class ChallengesListScreen extends Component {
  static propTypes = {
    navigator: object,
    App: object
  }

  toChallengeDetail(index) {
    this.props.navigator.showModal({
      ...Constants.Screens.CHALLENGE_DETAIL,
      passProps: {
        currentComplete: 27,
        completeUsers: 15,
        bar: 60,
        friends: [],
        ...this.props.App.challenges[index]
      },
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  render() {
    const {
      App: { challenges },
    } = this.props

    return(
      <Container>
        <ShowHeader
          title={'Challenges'}
          navigator={this.props.navigator}
          hasNotify
          isModal />
          <ScrollView>
            <Grid>
              {challenges.map((el, idx) =>
                <ChallengeItem
                  key={el.id}
                  mnRight={0.01}
                  width={width * 0.43}
                  height={width * 0.43}
                  onSelected={() => this.toChallengeDetail(idx)}
                  {...el}
                />)
              }

            </Grid>
          </ScrollView>
      </Container>
    )
  }
}

export default ChallengesListScreen
