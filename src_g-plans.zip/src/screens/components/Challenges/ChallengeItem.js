import React from 'react'
import {
  Text,
  View,
  Image,
  TouchableOpacity
} from 'react-native'
import glamorous from 'glamorous-native'

import Constants   from '../../../global/Constants'

const Container = glamorous(TouchableOpacity)(({ paddingLeft, marginRight, width }) => ({
  flexDirection: 'column',
  alignItems: 'flex-start',
  width: width || 135,
  marginRight: marginRight || 15,
  marginBottom: 15,
  paddingLeft
}))

const Picture = glamorous(View)(({ active, color, height }) => ({
  width: '100%',
  height: height || 96,
  borderRadius: 6,
  alignItems: 'center',
  justifyContent: 'center',
  borderWidth: 1,
  borderColor: active ? Constants.Colors.brightCyanFive : 'transparent',
  backgroundColor: color || '#edf3f9',
}))

const Thumbnail = glamorous(Image)({
  resizeMode: 'contain',
  maxWidth: '100%'
})

const Title = glamorous(Text)({
  fontSize: 16,
  fontWeight: '600',
  color: Constants.Colors.greyishBrown,
  marginTop: 10,
  paddingRight: 10
})

const Footer = glamorous(View)({
  flexDirection: 'column',
  width: '100%'
})

const Points = glamorous(Text)({
  fontSize: 12,
  fontWeight: '500',
  color: '#9aa8bb',
  marginVertical: 2
})

const StateHome = glamorous(View)({
  alignItems: 'center',
  flexDirection: 'row'
})

const Oval = glamorous(View)(({ color }) => ({
  width: 8,
  height: 8,
  borderRadius: 4,
  backgroundColor: color || Constants.Colors.white,
  marginRight: 5
}))

const StateHomeText = glamorous(Text)(({ color }) => ({
  fontSize: 10,
  fontWeight: '500',
  letterSpacing: 0,
  color: color || Constants.Colors.pinkishGrey
}))

const ChallengeItem = ({
  index,
  backgound,
  complete,
  image,
  name,
  points,
  onSelected,
  paddingLeft,
  active,
  height,
  width,
  mnRight
} = this.props) => {
    return(
      <Container
        onPress={ () => onSelected({index: index}) }
        paddingLeft={ index === 0 ? paddingLeft : 0 }
        width={width}
        marginRight={mnRight}
      >
        <Picture
          active={active === index}
          color={backgound}
          height={height}
        >
          <Thumbnail
            source={image}
          />
        </Picture>
        <Footer>
          <Title numberOfLines={1}>{ name }</Title>
          <Points>{`${points} points`}</Points>
          <StateHome>
            <Oval color={complete ? Constants.Colors.dodgerBlueFour : '#D8D8D8'}/>
            <StateHomeText
              color={complete ? Constants.Colors.dodgerBlueFour : '#D8D8D8'}
            >
              {complete ? 'Complete' : 'inactive'}
            </StateHomeText>
          </StateHome>
        </Footer>
      </Container>
    )
  }

export default ChallengeItem
