import React, { Component } from "react";
import {
  Text,
  View,
  Animated,
  TouchableOpacity,
  TouchableWithoutFeedback,
  Image,
  Platform
} from "react-native";
import glamorous from 'glamorous-native';
import Proptypes from 'prop-types';
import { inject, observer } from 'mobx-react/native';
import LinearGradient from 'react-native-linear-gradient';
import LottieView from 'lottie-react-native';

import NavBar      from '../../../global/NavBar';
import Constants   from '../../../global/Constants'

const multilingual = Constants.Multilingual;
const glamorousAnimatedView = glamorous(Animated.View)
const glamorousAnimatedImage = glamorous(Animated.Image)
const { width, height } = Constants.windowDimensions

const Container = glamorousAnimatedView({
  position: 'absolute',
  bottom: 0,
  right: 0,
  borderRadius: 95 / 2,
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
})
Container.propsAreStyleOverrides = true

const Overlay = glamorousAnimatedView({
  backgroundColor: 'rgba(0,0,0,0.7)',
  flex: 1,
  width: 30,
  height: 30,
  borderRadius: 15,
  position: 'absolute',
  right: 30,
  bottom: 30
})
Overlay.propsAreStyleOverrides = true

const Button = glamorous(TouchableOpacity)({
  position: 'absolute',
  bottom: 0,
  right: 0,
  width: 95,
  height: 95,
  borderRadius: 95 / 2,
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  zIndex: 1
})

const Girl = glamorousAnimatedImage({
  width: 47,
  height: 47,
  resizeMode: 'cover'
})
Girl.propsAreStyleOverrides = true

const Badge = glamorous(View)({
  position: 'absolute',
  right: Platform.OS === 'ios' ? 12 : 9,
  top: Platform.OS === 'ios' ? 12 : 9,
  backgroundColor: Constants.Colors.red,
  borderRadius: 11,
  shadowColor: "rgba(0, 0, 0, 0.32)",
  shadowOffset: {
    width: 0,
    height: 2
  },
  shadowRadius: 4,
  shadowOpacity: 1,
  elevation: 2,
  width: 22,
  height: 22,
  justifyContent: 'center',
  alignItems: 'center',
  zIndex: 1
})

const BadgeText = glamorous(Text)({
  fontSize: 11,
  fontWeight: 'bold',
  color: Constants.Colors.white,
  lineHeight: 12,
})

const Circle = glamorousAnimatedView({
  width: 54,
  height: 54,
  borderRadius: 54 / 2,
  backgroundColor: Constants.Colors.white,
  shadowColor: 'rgba(18, 18, 18, 0.7)',
  shadowOffset: {
    width: 0,
    height: 0
  },
  shadowRadius: 12,
  elevation: 12,
  shadowOpacity: 1,
  alignItems: 'center',
  justifyContent: 'center',
  zIndex: 1
})
Circle.propsAreStyleOverrides = true

const Gradient = glamorous(LinearGradient)({
  width: 54,
  height: 54,
  borderRadius: 54 / 2,
  position: 'absolute',
  left: 0,
  top: 0
})

const Cloud = glamorousAnimatedView({
  width,
  height: 250,
  position: 'absolute',
  bottom: 0,
  right: 0,
  paddingHorizontal: Constants.mainPadding
})
Cloud.propsAreStyleOverrides = true

const CloudStyle = {
  width: '100%',
}

const CloudContent = glamorousAnimatedView({
  position: 'absolute',
  left: 0,
  top: 0,
  paddingLeft: Platform.OS === 'ios' ? Constants.mainPadding + 45 : Constants.mainPadding + 65,
  paddingRight:  Platform.OS === 'ios' ? 0 : 15,
  paddingTop: 20
})
CloudContent.propsAreStyleOverrides = true

const CloudTitle = glamorous(Text)({
  color: Constants.Colors.greyishBrown,
  fontSize: Platform.OS === 'ios' ? Constants.moderateScale(18, 1.8) : 18,
  marginBottom: height < 667 ? 5 : 10,
  fontWeight: '500'
})

const CloudText = glamorous(Text)({
  fontSize: Platform.OS === 'ios' ? Constants.moderateScale(13, 1.8) : 14,
  fontWeight: "normal",
  fontStyle: "normal",
  lineHeight: height < 667 ? 15 : 18,
  letterSpacing: 0,
  color: "#5a5a5a"
})

const CloudGot = glamorous(Text)({
  fontSize: Platform.OS === 'ios' ? Constants.moderateScale(13, 1.8) : 14,
  fontWeight: 'bold',
  color: '#fff',
  height: 20,
  lineHeight: 20,
  borderRadius: 11,
  paddingHorizontal: 15,
  textAlign: 'center',
  backgroundColor: Constants.Colors.skyBlue,
  overflow: 'hidden'
})

const CloudFooter = glamorous(View)({
  flexDirection: 'column',
  alignItems: 'flex-end',
  marginTop: 5,
  width: '100%'
})

const { object, string, bool, number, func } = Proptypes;
@inject('User') @observer
export default class TipsAway extends Component {

  static navigatorStyle = NavBar.Default;

  static propTypes = {
    User: object,
    navigator: object,
    title: string,
    text: string,
    showing: bool,
    badgeNumber: number,
    hideTips: func
  }

  constructor(props){
    super(props)
    this.state = {
      animation: new Animated.Value(0),
      cloud: new Animated.Value(0),
      content: new Animated.Value(0),
      show: new Animated.Value(0),
      toggle: false,
      size: 95
    }
  }

  componentDidMount() {
    if(this.props.showing) {
      Animated.timing(this.state.show, {
        toValue: 1,
        duration: 300
      }).start()
      setTimeout(() => this.toggleShow(), 200)
    }
  }

  componentDidUpdate(prev){
    if(prev !== this.props.showing) {
      const toValue = this.props.showing ? 1 : 0;

      Animated.timing(this.state.show, {
        toValue: toValue,
        duration: 300
      }).start()
    }
  }

  toTip() {
    Promise.resolve()
      .then(() => this.toggleOpen())
      .then(() => new Promise((rs, rj) => setTimeout(rs, 500)))
      .then(() =>
        /*this.props.navigator.showModal({
          ...Constants.Screens.DETAIL_TIP_SCREEN,
          passProps: {
            title: this.props.title,
            text: this.props.text
          },
          navigatorStyle: {
            navBarHidden: true,
            tabBarHidden: true
          }
        })*/
        this.props.navigator.push({
          ...Constants.Screens.NOTIFICATION_SCREEN,
          navigatorStyle: {
            navBarHidden: true,
            tabBarHidden: true
          },
          passProps: {
            initalOpenId: this.props.id,
          }
        })
      )
  }

  toggleOpen = () => {
    const toValue = this.state.toggle ? 0 : 1;

    if (!this.state.toggle) {
      this.setState({ size: '100%' });
      Animated.sequence([
        Animated.timing(this.state.animation, {
          toValue,
          duration: 500,
        }),
        Animated.parallel([
          Animated.timing(this.state.cloud, {
            toValue: toValue,
            duration: 800
          }),
          Animated.timing(this.state.content, {
            toValue: toValue,
            duration: 300,
            delay: 450
          })
        ]),
      ]).start();
    } else {
      setTimeout(() => { this.setState({ size: 95 }) }, 1000);
      Animated.sequence([
        Animated.timing(this.state.content, {
          toValue: toValue,
          duration: 100
        }),
        Animated.timing(this.state.cloud, {
          toValue,
          duration: 400,
        }),
        Animated.timing(this.state.animation, {
          toValue,
          duration: 500,
        })
      ]).start();
    }

    this.setState({ toggle: !this.state.toggle });
  }

  toggleShow() {
    if(this.props.showing) {
      Promise.resolve()
      .then(() => new Promise((rs,rj) => setTimeout(rs,10)))
      .then(() => this.toggleOpen())
      .then(() => new Promise((rs,rj) => setTimeout(rs,1000)))
      .then(() => {
        Animated.timing(this.state.show, {
          toValue: 0,
          duration: 300
        })
      })
    }
  }

  hiddenTips() {
    this.toggleShow()
    setTimeout(() => {
      this.props.hideTips()
    }, 1200)
  }

  render() {
    const { User, title, text, badgeNumber, id } = this.props
    const currentLanguage = User.language

    const scaleOverlay = this.state.animation.interpolate({
      inputRange: [0, 1],
      outputRange: [0.01, 50]
    })

    const opacityOverlay = this.state.animation.interpolate({
      inputRange: [0, 1],
      outputRange: [0, 1]
    })

    const sizeImage = this.state.animation.interpolate({
      inputRange: [0, 1],
      outputRange: [46, 54]
    })

    const shadowCircle = this.state.animation.interpolate({
      inputRange: [0, 1],
      outputRange: ['rgba(18, 18, 18, 0.7)', 'rgba(11, 177, 255, 0.5)']
    })

    const scaleCloud = this.state.animation.interpolate({
      inputRange: [0, 1],
      outputRange: [0.01, 1]
    })

    const opacityContent = this.state.content.interpolate({
      inputRange: [0, 1],
      outputRange: [0, 1]
    })

    const translateContent = this.state.content.interpolate({
      inputRange: [0, 1],
      outputRange: [-15, 0]
    })

    const translateShowing = this.state.show.interpolate({
      inputRange: [0, 1],
      outputRange: [100, 0]
    })

    const opacityShowing = this.state.show.interpolate({
      inputRange: [0, 1],
      outputRange: [0, 1]
    })

    return (
      <TouchableWithoutFeedback
        onPress={() => this.toggleShow()}
      >
        <Container
          width={this.state.size}
          height={this.state.size}
          transform={[{ translateX: translateShowing }]}
          opacity={opacityShowing}
        >
          <Overlay
            transform={[{ scale: scaleOverlay }]}
            opacity={opacityOverlay}
          />
          <Cloud
            transform={[{ scale: scaleCloud }]}
          >
            <LottieView
              source={Constants.Images.LOTTIE_CLOUD} progress={this.state.cloud}
              style={CloudStyle}
            />
            <CloudContent
              opacity={opacityContent}
              transform={[{ translateX: translateContent }]}
            >
              <TouchableOpacity
                onPress={() => this.toTip()}
              >
                <CloudTitle
                  numberOfLines={1}
                >
                  {title}
                </CloudTitle>
                <CloudText
                  numberOfLines={3}
                >
                  {text}
                </CloudText>
              </TouchableOpacity>
                <CloudFooter>
                  <TouchableOpacity
                    onPress={() => this.hiddenTips()}
                  >
                    <CloudGot>{multilingual.GOT_IT[currentLanguage]}</CloudGot>
                  </TouchableOpacity>
                </CloudFooter>
            </CloudContent>
          </Cloud>
          <Button activeOpacity={0.8} onPress={() => this.toggleOpen()}>
            <Circle
              shadowColor={shadowCircle}
            >
              <Gradient
                colors={['rgb(84,202,249)', 'rgb(42,154,241)']}
                start={{x: 0, y: -0.15}} end={{x: 0, y: 0.55}}
              />
              <Girl
                source={Constants.Images.TIPS_GIRL}
                width={sizeImage}
                height={sizeImage}
              />
            </Circle>
            <Badge>
              <BadgeText>{badgeNumber}</BadgeText>
            </Badge>
          </Button>
        </Container>
      </TouchableWithoutFeedback>
    )
  }
}
