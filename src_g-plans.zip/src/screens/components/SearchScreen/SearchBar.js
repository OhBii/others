/*
*   author: denis
*   date:   7/19/2018
*/

import React, { Component } from 'react';
import {
  Text,
  TextInput,
  View,
  ScrollView,
  TouchableOpacity,
  Keyboard,
} from 'react-native';
import { inject, observer } from 'mobx-react/native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import Icon from 'react-native-vector-icons/FontAwesome';

import Constants from '../../../global/Constants';
import Api from '../../../utils/Api';

const multilingual = Constants.Multilingual;

const ContainerView = glamorous(View)({
  backgroundColor: Constants.Colors.white
});

const RowView = glamorous(View)({
  flexDirection: "row",
  alignItems: 'center',
  paddingHorizontal: Constants.mainPadding
});

const SearchView = glamorous(View)({
  backgroundColor: "white",
  flexDirection: "row",
  justifyContent: "space-between",
  alignItems: 'center',
  height: 45,
  borderRadius: 20,
  borderColor: Constants.Colors.blueyGrey,
  borderWidth: 1,
  borderStyle: 'solid',
  paddingHorizontal: 15,
  width: "85%"
});

const Edit = glamorous(TextInput)({
  fontSize: 14,
  width: "90%",
  color: Constants.Colors.greyishBrownThree
});

const BarcodeButton = glamorous(TouchableOpacity)({
  justifyContent: 'center',
  alignItems: 'center',
  marginLeft: 10,
  width: 39,
  height: 39,
  borderRadius: 19.5,
  borderColor: Constants.Colors.blueyGrey,
  borderWidth: 1,
  borderStyle: 'solid',
  overflow: 'hidden'
});

const FoodsScrollView = {
  paddingLeft: Constants.mainPadding,
  marginVertical: 15
};

const CellText = glamorous(Text)(({pageIndex, selfIndex}) => ({
  color: pageIndex === selfIndex
    ? Constants.Colors.dodgerBlueFour
    : Constants.Colors.blueyGrey,
  fontSize: 14,
  marginLeft: 5
}));

const CellView = glamorous(TouchableOpacity)(({pageIndex, selfIndex}) => ({
  flexDirection: "row",
  alignItems:'center',
  marginRight: 12,
  paddingHorizontal: 7,
  paddingVertical: 2,
  borderRadius: 10,
  backgroundColor: Constants.Colors.white,
  borderColor: pageIndex === selfIndex
    ? Constants.Colors.dodgerBlueFour
    : Constants.Colors.blueyGrey,
  borderStyle: 'solid',
  borderWidth: 1
}));

const Tick = {
  opacity: 1,
  flexDirection: "row",
  alignItems:'center',
}

const { object, func } = Proptypes;
@inject( 'User', 'SearchFood' ) @observer
export default class SearchBar extends Component {
  static propTypes = {
    navigator: object,
    User: object,
    SearchFood: object,
    startSearch: func,
    endSearch: func,
  }

  constructor(props) {
    super(props);
    this.state = {
      search: '',
    }; //0: no select, 1: favorite, 2: recent
    this.scrollElements = {};
    this.isSearching = false
    this.triggerTimerID = null

  }
  startSearch = () => {
    this.isSearching = true
    this.props.SearchFood.resetSearchList()
    this.props.startSearch()
  }

  endSearch = (pageIndex, searchResult) => {
    this.props.endSearch(pageIndex, searchResult)
    this.isSearching = false
  }

  toSearch() {
    //if there is no result, 0
    if (this.isSearching) return
    Keyboard.dismiss()
    const { User: { token, language }, SearchFood : { handleLoading } } = this.props;

    handleLoading(true);
    const searchText = this.state.search
    this.startSearch()
    Promise.all([
      Api.searchOnlyFood(token, searchText, language),
      Api.extraSearch(token, searchText, language )
    ])
      .then((data1) => {
        const res = data1[0].data;
        const searchExtra = data1[1].data;
        //
        const nutrients = res.map((item) => {
          return Api.searchNutrients(token, item.food_name, item.nix_item_id)
        });

        Promise.all(nutrients)
          .then((data2) => {
            const searchNutrients = data2.map((item) => item.data);
            const searchRes = searchNutrients.concat(searchExtra);
            if (searchRes.length !== 0) {
              this.endSearch(1, searchRes);
              setTimeout(() => {
                handleLoading(false);
              }, 600);
            } else {
              this.endSearch(0, []);
              setTimeout(() => {
                handleLoading(false);
              }, 600);
            }
          })
          .catch(() => {
            if (searchExtra.length !== 0) {
              this.endSearch(1, searchExtra);
              setTimeout(() => {
                handleLoading(false);
              }, 600);
            } else {
              this.endSearch(0, []);
              setTimeout(() => {
                handleLoading(false);
              }, 600);
            }
          })
        //
      })
      .catch(() => {
        this.endSearch(0, []);
        setTimeout(() => {
          handleLoading(false);
        }, 600);
      })
  }

  toggleAll(ref) {
    this.props.SearchFood.setPageIndx(1);
    this.scrollToEnd(ref);
  }

  toggleFavorite(ref) {
    this.props.SearchFood.setPageIndx(3);
    this.scrollToEnd(ref);
  }

  toggleRecent(ref) {
    this.props.SearchFood.setPageIndx(4);
    this.scrollToEnd(ref);
  }

  toggleAdd(ref) {
    this.props.SearchFood.setPageIndx(2);
    this.scrollToEnd(ref);
  }

  toBarcodeScan() {
    this.props.navigator.showModal({
      ...Constants.Screens.CAMERA_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      },
      passProps: {
       getBarcodeRes: (searchRes) => this.props.endSearch(1, searchRes)
      }
    });
  }

  scrollToEnd(ref) {
    if(ref == this.scrollElements[2] || ref == this.scrollElements[3]) {
      this.scrollView.scrollToEnd();
    }
    if(ref == this.scrollElements[0] || ref == this.scrollElements[1]) {
      this.scrollView.scrollTo({x: 0, y: 0, animated: true});
    }
  }

  onChangeSearchText(text) {
    this.setState({
      search: text,
    })
    if (this.triggerTimerID) {
      clearTimeout(this.triggerTimerID)
      this.triggerTimerID = null
    }
    this.triggerTimerID = setTimeout(() => {
      this.triggerTimerID = null
      this.toSearch(false)
    }, 2500)
  }

  render() {
    const { User: { language }, SearchFood:{ pageIndex } } = this.props
    return(
      <ContainerView>
        <RowView>
          <SearchView>
            <Edit
              onChangeText={text => this.onChangeSearchText(text)}
              autoCapitalize={'none'}
              placeholder={ 'Search Items Here' }
              placeholderTextColor={Constants.Colors.blueyGrey}
              underlineColorAndroid={'transparent'}
              onSubmitEditing={() => this.toSearch()}
              onBlur={() => Keyboard.dismiss()}
              />
            <TouchableOpacity onPress={() => this.toSearch(true)}>
              <Icon name="search" size={18} color={Constants.Colors.blueyGrey} />
            </TouchableOpacity>
          </SearchView>
          <BarcodeButton onPress={() => this.toBarcodeScan()}>
            <Icon name="barcode" size={20} color={Constants.Colors.blueyGrey} />
          </BarcodeButton>
        </RowView>
        <ScrollView
          ref={c => this.scrollView = c}
          horizontal
          contentContainerStyle={FoodsScrollView}
          showsHorizontalScrollIndicator={false}
        >
          <CellView
            selfIndex={1}
            pageIndex={pageIndex}
            onPress={() => this.toggleAll(this.scrollElements[0])}
          >
            <View
              ref={el => this.scrollElements[0] = el}
              style={Tick}
            >
              <CellText
                selfIndex={1}
                pageIndex={pageIndex}
              >
                { multilingual.SEARCHED_FODDS[language] }
              </CellText>
            </View>
          </CellView>
          <CellView
            selfIndex={3}
            pageIndex={pageIndex}
            onPress={() => this.toggleFavorite(this.scrollElements[1])}
          >
            <View
              ref={el => this.scrollElements[1] = el}
              style={Tick}
            >
              <CellText
                selfIndex={3}
                pageIndex={pageIndex}
              >
                { multilingual.FAV_FOODS[language] }
              </CellText>
            </View>
          </CellView>
          <CellView
            selfIndex={4}
            pageIndex={pageIndex}
            onPress={() => this.toggleRecent(this.scrollElements[2])}>
            <View
              ref={el => this.scrollElements[2] = el}
              style={Tick}>
              <CellText
                selfIndex={4}
                pageIndex={pageIndex}
              >
                { multilingual.RECENT_FOODS[language] }
              </CellText>
            </View>
          </CellView>
          <CellView
            selfIndex={2}
            pageIndex={pageIndex}
            renderToHardwareTextureAndroid={true}
            collapsable={false}
            onPress={() => this.toggleAdd(this.scrollElements[3])}
          >
            <View
              ref={el => this.scrollElements[3] = el}
              style={Tick}
            >
              <CellText
                selfIndex={2}
                pageIndex={pageIndex}
              >
                { multilingual.ADD_FOODS[language] }
              </CellText>
            </View>
          </CellView>
        </ScrollView>
      </ContainerView>
    );
  }
}
