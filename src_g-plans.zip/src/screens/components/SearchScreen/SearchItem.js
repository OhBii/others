/*
*   author: denis
*   date:   7/20/2018
*/

import React, { Component } from 'react';
import {
  Text,
  View,
  Image,
  TouchableOpacity
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';

import Constants from '../../../global/Constants';
import { caseRoundValue } from '../../../utils/GlobalFunctions'

const ContainerView = glamorous(View)({
  flexDirection: "row",
  justifyContent: "space-between",
  backgroundColor: "white",
  paddingHorizontal: 15,
  paddingVertical: 12,
  borderStyle: "solid",
  borderBottomColor: Constants.Colors.borderColorThree,
  borderBottomWidth: 1,
});

const ItemView = glamorous(View)({
  width: '80%'
});

const ItemButton = glamorous(TouchableOpacity)({

});

const ItemName = glamorous(Text)({
  fontSize: 18,
  color: Constants.Colors.marineTwo
});

const ItemDescription = glamorous(Text)({
  fontSize: 12
});

const { object, string, number, bool, func } = Proptypes;
export default class SearchItem extends Component {
  static propTypes = {
    navigator: object,
    itemName: string,
    portion: number,
    exchanges: number,
    unit: string,
    cals: number,
    isActive: bool,
    minusButton: bool,
    toAdd: func,
    toDelete: func,
  }

  static defaultProps = {
    itemName: " ",
    cals: 0,
    isActive: false,
    toAdd: () => {},
    toDelete: () => {},
  }

  constructor(props) {
    super(props);
  }

  render() {
    const { portion, unit, cals, minusButton, isActive, toAdd, toDelete, exchanges } = this.props
    return(
      <ContainerView>
        <ItemView>
          <ItemName numberOfLines={1}>{this.props.itemName}</ItemName>
          <ItemDescription>{caseRoundValue(portion * (exchanges ? exchanges : 1))} {unit} is {cals} cals</ItemDescription>
        </ItemView>
        <ItemButton onPress={() => {
            if (minusButton)  toDelete()
            else              toAdd()
          }}
        >
          {
            minusButton
              ? <Image source={require("../../../../img/minus.png")} />
              : isActive
                  ? <Image source={require("../../../../img/btnPlus_active.png")} />
                  : <Image source={require("../../../../img/btnPlus.png")} />
          }
        </ItemButton>
      </ContainerView>
    );
  }
}
