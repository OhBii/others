import React from 'react'
import {
  Text,
  View,
  Image,
  TouchableOpacity,
  TouchableWithoutFeedback
} from 'react-native'
import glamorous from 'glamorous-native'

import Constants   from '../../../global/Constants'

const Container = glamorous(View)({
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'space-between',
  width: '100%',
  marginBottom: 10
})

const Title = glamorous(Text)({
  fontSize: 14,
  letterSpacing: 0,
  color: Constants.Colors.greyishBrown,
  width: '58%'
})

const Action = glamorous(View)({
  flexDirection: 'row',
  alignItems: 'center'
})

const ValueBox = glamorous(View) ({
  height: 34,
  borderRadius: 4,
  backgroundColor: Constants.Colors.white,
  borderStyle: "solid",
  borderWidth: 1,
  borderColor: Constants.Colors.whiteTwelve,
  alignItems: 'center',
  justifyContent: 'center',
  overflow: 'hidden',
  width: 70,
  paddingHorizontal: 5
})

const Swap = glamorous(View)({
  width: 32,
  height: 32,
  borderRadius: 3.5,
  backgroundColor: Constants.Colors.pinkishGrey,
  shadowColor: 'rgba(0, 0, 0, 0.18)',
  shadowOffset: {
    width: 0,
    height: 1
  },
  shadowRadius: 3,
  shadowOpacity: 1,
  elevation: 3,
  justifyContent: 'center',
  alignItems: 'center',
  transform: [{ skewX: '10deg' }]
})

const IconSwap = glamorous(Image)({
  width: 24,
  height: 26
})

const SwapView = glamorous(View) ({
  marginRight: 15
})

const Value = glamorous(Text) ({
  fontSize: 14,
  color: Constants.Colors.warmGreyFour
})

const RecipeRow = ({ title, value, unit, onValue, forView, onSwap } = this.props) =>
  <Container>
    <Title numberOfLines={1}>{ title }</Title>
    <Action>
      {
        forView
          ? <View />
          :
            <SwapView>
              <TouchableOpacity onPress={onSwap}>
                <Swap>
                  <IconSwap
                    source={Constants.Images.ICON_SWAP_SM}
                  />
                </Swap>
              </TouchableOpacity>
            </SwapView>
      }
      <TouchableWithoutFeedback
        onPress={onValue}
      >
        <ValueBox>
          <Value numberOfLines={1}>{ [value,' ',unit] }</Value>
        </ValueBox>
      </TouchableWithoutFeedback>
    </Action>
  </Container>

export default RecipeRow
