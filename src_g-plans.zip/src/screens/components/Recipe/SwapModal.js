import React, { Component } from 'react'
import {
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  Image
} from 'react-native'
import Proptypes from 'prop-types'
import glamorous from 'glamorous-native'
import { inject, observer } from 'mobx-react/native';
import ShowHeader from '../HeaderBar/ShowHeader';

import Constants   from '../../../global/Constants'

const Container = glamorous(View)({
  flexDirection: 'column',
  flex: 1,
  backgroundColor: '#fff'
})

const Title = glamorous(Text)({
  fontSize: 24,
  fontWeight: "bold",
  fontStyle: "normal",
  letterSpacing: 0,
  color: Constants.Colors.marineTwo,
  marginVertical: 20,
  paddingLeft: 15
})

const Item = glamorous(View)({
  height: 65,
  ...Constants.flex('row', 'center', 'space-between'),
  paddingLeft: 15,
  paddingRight: 25,
  borderTopWidth: 1,
  borderTopColor: "#e6e9ed"
})

const ItemTitle = glamorous(Text)({
  fontSize: 17,
  color: Constants.Colors.warmGreyFive,
  paddingRight: 15
})

const IconSwap = glamorous(Image)({
  width: 32,
  height: 29
})

const multilingual = Constants.Multilingual;

const { object, number } = Proptypes
@inject('User', 'MealPlan', /*'GroceryList'*/) @observer
export default class SwapModal extends Component {
  static propTypes = {
    curMealItem: object,
    MealPlan: object,
    // GroceryList: object,
    navigator: object,
    User: object,
    MealId: number
  }

  constructor(props) {
    super(props);
  }

  onSwapItem = mealItem => {
    const {
      navigator,
      MealPlan: {
        swapMealItem,
        // premeals,
        // meals,
        // nextmeals
      },
      // GroceryList: {
      //   setGroceryList
      // },
      curMealItem
    } = this.props
    swapMealItem(curMealItem, mealItem)
    .then(() => {
      navigator.showModal({
        ...Constants.Screens.MEAL_DETAIL_SCREEN,
        passProps: {
          MealId: this.props.MealId,
          backType: false
        },
        navigatorStyle: {
          navBarHidden: true,
          tabBarHidden: true
        }
      })
      // if(premeals[curMealItem.meal] !== undefined){
      //   const weekNumber = premeals[curMealItem.meal].week_number;
      //   setGroceryList( weekNumber, curMealItem, mealItem);
      // }
      // else if(meals[curMealItem.meal] !== undefined){
      //   const weekNumber = meals[curMealItem.meal].week_number;
      //   setGroceryList( weekNumber, curMealItem, mealItem);
      // }
      // else if(nextmeals[curMealItem.meal] !== undefined){
      //   const weekNumber = nextmeals[curMealItem.meal].week_number;
      //   setGroceryList( weekNumber, curMealItem, mealItem);
      // }
    })
  }

  render() {
    const {
      User,
      MealPlan: { swapableMealItems },
    } = this.props
    const currentLanguage = User.language;
    return (
      <Container>
      <ShowHeader
        title= { multilingual.SWAP[currentLanguage] }
        navigator={this.props.navigator}
      />
        <Title>{'Protein'}</Title>
        <ScrollView>
          {swapableMealItems.map(mealItem =>
            <Item
              key={mealItem.id}
            >
              <ItemTitle>{mealItem.name}</ItemTitle>
              <TouchableOpacity
                onPress={() => this.onSwapItem(mealItem)}
              >
                <IconSwap source={Constants.Images.SKEW_SWAP_GREY} />
              </TouchableOpacity>
            </Item>
          )}
        </ScrollView>
      </Container>
    );
  }
}
