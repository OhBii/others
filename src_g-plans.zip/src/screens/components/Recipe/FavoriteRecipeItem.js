import React from 'react';
import {
  Text,
  View,
  TouchableOpacity
} from 'react-native';
import glamorous from 'glamorous-native';
import { CachedImage, ImageCacheProvider } from 'react-native-cached-image';
import LinearGradient from 'react-native-linear-gradient';

import Constants   from '../../../global/Constants';

const Container = glamorous(TouchableOpacity)(({ paddingLeft }) => ({
  marginRight: 10,
  marginBottom: 15,
  flexDirection: 'column',
  alignItems: 'flex-start',
  paddingLeft
}))

const Overlay = glamorous(LinearGradient)({
  width: '100%',
  height: '100%',
  borderRadius: 6,
  position: 'absolute',
  left: 0,
  top: 0,
  flexDirection: 'row',
  justifyContent: 'flex-end',
  paddingHorizontal: 7,
  paddingTop: 10,
  paddingBottom: 15
})

const Picture = glamorous(View)({
  width: 105,
  height: 145,
  borderRadius: 6,
  backgroundColor: Constants.Colors.white,
  shadowColor: 'rgba(0, 0, 0, 0.07)',
  shadowOffset: {
    width: 0,
    height: 2
  },
  shadowRadius: 5,
  shadowOpacity: 1,
  elevation: 2
})

const Thumbnail = glamorous(CachedImage)({
  width: 105,
  height: 145,
  borderRadius: 6
})

const Title = glamorous(Text)({
  fontSize: 16,
  fontWeight: '500',
  color: Constants.Colors.greyishBrownThree,
  letterSpacing: -0.53,
  marginTop: 10,
  marginBottom: 5,
  width: 100
})

const Type = glamorous(Text)({
  fontSize: 10,
  fontWeight: '500',
  color: Constants.Colors.dodgerBlueFour
})

const FavoriteRecipeItem = ({
  id,
  index,
  paddingLeft,
  image: { medium: image },
  name,
  difficulty,
  onSelected } = this.props) =>
  <Container
    onPress={ () => onSelected(id) }
    paddingLeft={ index === 0 ? paddingLeft : 0 }
  >
    <Picture>
      <ImageCacheProvider
        urlsToPreload={[image]}>
        <Thumbnail
          source={{ uri: image }}
        />
      </ImageCacheProvider>
      <Overlay
        colors={['transparent', '#000000']}
        start={{x: 0, y: 0}} end={{x: 0, y: 1}}
      />
    </Picture>
    <Title numberOfLines={1}>{ name }</Title>
    <Type>{ difficulty.toUpperCase() }</Type>
  </Container>

export default FavoriteRecipeItem
