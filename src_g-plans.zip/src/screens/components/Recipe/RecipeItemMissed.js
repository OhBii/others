import React, { Component } from 'react';
import {
  View,
  Animated,
  Text
} from 'react-native';
import glamorous from 'glamorous-native';
import Proptypes from 'prop-types';
import LinearGradient from 'react-native-linear-gradient';
import EIcon from 'react-native-vector-icons/EvilIcons'
import Constants from '../../../global/Constants';

const AnimatedView = glamorous(Animated.View)

const Container = glamorous(View)(({ missed }) => ({
  position: 'absolute',
  width: '100%',
  height: '100%',
  ...Constants.flex('column', 'center', 'center'),
  overflow: 'hidden',
  display: missed ? 'flex' : 'none',
  opacity: missed ? 1 : 0,
  borderTopLeftRadius: 6,
  borderTopRightRadius: 6
}))

const CircleOverlay = AnimatedView({
  backgroundColor: 'rgba(120, 120, 120, 0.8)',
  position: 'absolute',
  width: 800,
  height: 800,
  borderRadius: 400
})

/*const Accept = glamorous(Image)({
  width: 78,
  height: 78
})*/

CircleOverlay.propsAreStyleOverrides = true

const Wrap = AnimatedView()
Wrap.propsAreStyleOverrides = true

const ContainerHome = glamorous(View)(({ missed }) => ({
  position: 'absolute',
  width: '100%',
  height: '100%',
  ...Constants.flex('column', 'flex-start', 'flex-end'),
  overflow: 'hidden',
  display: missed ? 'flex' : 'none',
  borderRadius: 6
}))

const Overlay = glamorous(LinearGradient)({
  position: 'absolute',
  width: '100%',
  height: '100%',
  left: 0,
  top: 0,
  borderRadius: 6
})

const Bottom = glamorous(View)({
  paddingLeft: 8,
  paddingBottom: 5,
  flexDirection: 'column',
  alignItems: 'flex-start'
})

const HomeTitle = glamorous(Text)({
  fontSize: 24,
  fontWeight: '500',
  color: Constants.Colors.white
})

const { bool } = Proptypes;
class RecipeItemMissed extends Component {
  static propTypes = {
    missed: bool,
    homeMode: bool
  }

  constructor(props) {
    super()
    this.state = {
      animateOverlay: props.missed ? new Animated.Value(1) : new Animated.Value(0.01),
      animateCircle: props.missed ? new Animated.Value(1) : new Animated.Value(0.01),
      prevMissed: props.missed
    }
  }

  componentDidUpdate(props, state) {

    if(props.missed === state.prevMissed) {
      state.animateOverlay.setValue(0.01)
      state.animateCircle.setValue(0.01)
      Animated.parallel([
        Animated.timing(state.animateOverlay, {
          toValue: 1,
          duration: 800,
          useNativeDriver: true
        }),
        Animated.spring(state.animateCircle, {
          toValue: 1,
          tension: 2,
          friction: 3,
          useNativeDriver: true
        })
      ]).start()
    }
  }

  render({ opacityCircle, missed, homeMode } = this.props) {

    return(
        missed && !homeMode
        ? <Container missed={missed}>
          <CircleOverlay
            opacity={missed ? 1 : 0}
            transform={[{ scale: this.state.animateOverlay }]}
          />
          <Wrap
            opacity={opacityCircle}
            transform={[{ scale: this.state.animateCircle }]}
          >
            {/*<Accept source={Constants.Images.ICON_ACCEPT}/>*/}
            <EIcon
              name={'close-o'}
              color={Constants.Colors.white}
              size={110}
            />
          </Wrap>
        </Container>
        : missed && homeMode
        ? <ContainerHome missed={missed}>
            <Overlay
              colors={['transparent', 'rgba(130, 130, 130, 1)']}
              start={{x: 1, y: -0.7}}
              end={{x: 0, y: 0.3}}
            />
            <Bottom>
              <HomeTitle>{ '0%' }</HomeTitle>
            </Bottom>
          </ContainerHome>
        : null
    )
  }
}

export default RecipeItemMissed
