import React, { Component } from 'react'
import {
  View,
  Animated,
  Text
} from 'react-native'
import glamorous from 'glamorous-native'
import Proptypes from 'prop-types'
import LinearGradient from 'react-native-linear-gradient';

import CircleProgress from '../Chart/CircleProgress'
import Constants from '../../../global/Constants'

const AnimatedView = glamorous(Animated.View)

const Container = glamorous(View)(({ logged }) => ({
  position: 'absolute',
  width: '100%',
  height: '100%',
  ...Constants.flex('column', 'center', 'center'),
  overflow: 'hidden',
  display: logged ? 'flex' : 'none',
  borderTopLeftRadius: 6,
  borderTopRightRadius: 6
}))

const CircleOverlay = AnimatedView({
  backgroundColor: 'rgba(77, 160, 255, 0.8)',
  position: 'absolute',
  width: 800,
  height: 800,
  borderRadius: 400
})

CircleOverlay.propsAreStyleOverrides = true

const WrapCircle = AnimatedView({})
WrapCircle.propsAreStyleOverrides = true

const labelStyle = {
  fontSize: 31,
  fontWeight: 'normal',
  fill: 'white',
  textShadowColor: Constants.Colors.black21,
  textShadowOffset: {
    width: 0,
    height: 3
  },
  textShadowRadius: 5
}

const ContainerHome = glamorous(View)(({ logged }) => ({
  position: 'absolute',
  width: '100%',
  height: '100%',
  ...Constants.flex('column', 'flex-start', 'flex-end'),
  overflow: 'hidden',
  display: logged ? 'flex' : 'none',
  borderRadius: 6
}))

const Overlay = glamorous(LinearGradient)({
  position: 'absolute',
  width: '100%',
  height: '100%',
  left: 0,
  top: 0,
  borderRadius: 6
})

const Bottom = glamorous(View)({
  paddingLeft: 8,
  paddingBottom: 5,
  flexDirection: 'column',
  alignItems: 'flex-start'
})

const HomeTitle = glamorous(Text)({
  fontSize: 24,
  fontWeight: '500',
  color: Constants.Colors.white
})

const { bool, number, object } = Proptypes;
class RecipeItemTracked extends Component {
  static propTypes = {
    logged: bool,
    percent: number,
    pro: number,
    fats: number,
    carbs: number,
    opacityCircle: object,
    homeMode: bool
  }

  constructor(props) {
    super(props)
    this.state = {
      data: [{ x: 1, y: 0 }, { x: 2, y: 0 }, { x: 3, y: 0 }, { x: 4, y: 100 }],
      animateOverlay: props.logged ? new Animated.Value(1) : new Animated.Value(0.01),
      animateCircle: props.logged ? new Animated.Value(1) : new Animated.Value(0.01),
      prevLogged: props.logged
    }
  }

  static getDerivedStateFromProps(props, state) {

    if(!props.logged && !state.prevLogged){
      state.animateOverlay.setValue(0.01)
      state.animateCircle.setValue(0.01)
    }

    if(props.logged !== state.prevLogged) {
      Animated.parallel([
        Animated.timing(state.animateOverlay, {
          toValue: 1,
          duration: 800,
          useNativeDriver: true
        }),
        Animated.spring(state.animateCircle, {
          toValue: 1,
          tension: 2,
          friction: 3,
          useNativeDriver: true
        })
      ]).start()
      return {
        pro: props.pro,
        fats: props.fats,
        carbs: props.carbs,
        percent: props.percent
      }
    }

    return null
  }

  render() {
    const { pro, fats, carbs, percent, opacityCircle, logged, homeMode } = this.props;
    return(
      logged && !homeMode
      ? <Container logged={logged}>
        <CircleOverlay
          opacity={logged ? 1 : 0}
          transform={[{ scale: this.state.animateOverlay }]}
        />
        <WrapCircle
          opacity={opacityCircle}
          transform={[{ scale: this.state.animateCircle }]}
        >
          <CircleProgress
            pro={pro}
            fats={fats}
            carbs={carbs}
            data={
              this.state,
              {percent: percent}
            }
            size={95}
            innerRadius={38}
            labelStyle={labelStyle}
          />
        </WrapCircle>
      </Container>
      : logged && homeMode
      ? <ContainerHome logged={logged}>
          <Overlay
            colors={['rgba(77, 160, 255, 0.61)', 'rgb(57, 238, 255)']}
            start={{x: 0.6, y: 1}}
            end={{x: 0, y: 0.2}}
          />
          <Bottom>
            <HomeTitle>{ `${percent}%` }</HomeTitle>
          </Bottom>
        </ContainerHome>
      : null
    )
  }
}

export default RecipeItemTracked
