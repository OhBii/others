/*
*   author: denis
*   date:   08/07/2018
*/

import React, { Component } from 'react'
import {
  Text,
  View,
  TouchableOpacity,
  TouchableWithoutFeedback
} from 'react-native'
import Proptypes from 'prop-types'
import glamorous from 'glamorous-native'

import Constants   from '../../../global/Constants'

const { width, height } = Constants.windowDimensions

const Container = glamorous(View)({
  backgroundColor: 'transparent',
  width,
  height,
  flexDirection: 'column',
  justifyContent: 'flex-end'
})

const Overlay = glamorous(View)({
  position: 'absolute',
  left: 0,
  top: 0,
  width: '100%',
  height: '100%',
  backgroundColor: 'transparent'
})

const Dialog = glamorous(View)({
  width: '100%',
  paddingVertical: 25,
  borderRadius: 26,
  backgroundColor: Constants.Colors.white,
  shadowColor: "rgba(0, 0, 0, 0.17)",
  shadowOffset: {
    width: 0,
    height: -6
  },
  shadowRadius: 10,
  shadowOpacity: 1,
  elevation: 10,
  flexDirection: 'column'
})

const BorderView = glamorous(View)({
  borderStyle: 'solid',
  borderBottomColor: Constants.Colors.warmGreyTwo,
  borderBottomWidth: 0.5
})

const ItemView = glamorous(TouchableOpacity)({
  alignItems: 'center',
  paddingVertical: 15
})

const ItemText = glamorous(Text)({
  fontSize: 18,
  color: Constants.Colors.darkSkyBlue
})

const { object, func, number } = Proptypes
export default class SwapDialog extends Component {
  static propTypes = {
    navigator: object,
    toSwapInDialog: func,
    id:number,
    showRecipeDetails: func
  }

  constructor(props) {
    super(props);
  }

  toViewRecipe() {
    //view recipe
    //
    this.props.navigator.dismissLightBox();
    setTimeout(() => {
      this.props.showRecipeDetails();
    }, 500);
  }

  toSwapRecipe() {
    //swap recipe
    this.props.toSwapInDialog();
    //
    this.props.navigator.dismissLightBox();
  }

  render() {
    return (
          <Container>
            <TouchableWithoutFeedback
              onPress={() => this.props.navigator.dismissLightBox()}
            >
              <Overlay />
            </TouchableWithoutFeedback>
            <Dialog>
              <BorderView>
                <ItemView onPress={() => this.toViewRecipe()}>
                  <ItemText>View Recipe</ItemText>
                </ItemView>
              </BorderView>
              <BorderView>
                <ItemView onPress={() => this.toSwapRecipe()}>
                    <ItemText>Swap Recipe</ItemText>
                  </ItemView>
              </BorderView>
            </Dialog>
          </Container>
    );
  }
}