import React, { Component } from 'react'
import {
  Text,
  View,
  TouchableWithoutFeedback
} from 'react-native'
import Proptypes from 'prop-types'
import glamorous from 'glamorous-native'

import Constants   from '../../../global/Constants'

const { width, height } = Constants.windowDimensions

const Container = glamorous(View)({
  backgroundColor: 'transparent',
  width,
  height,
  flexDirection: 'column',
  justifyContent: 'flex-end'
})

const Overlay = glamorous(View)({
  position: 'absolute',
  left: 0,
  top: 0,
  width: '100%',
  height: '100%',
  backgroundColor: 'transparent'
})

const Dialog = glamorous(View)({
  width: '100%',
  padding: 25,
  borderRadius: 26,
  backgroundColor: Constants.Colors.white,
  shadowColor: "rgba(0, 0, 0, 0.17)",
  shadowOffset: {
    width: 0,
    height: -6
  },
  shadowRadius: 10,
  shadowOpacity: 1,
  elevation: 10,
  flexDirection: 'column'
})

const Title = glamorous(Text)({
  fontSize: 36,
  fontWeight: "bold",
  lineHeight: 37,
  letterSpacing: 0,
  color: Constants.Colors.marineTwo,
  marginBottom: 20
})

const TextContent = glamorous(Text)({
  fontSize: 14,
  fontWeight: "500",
  letterSpacing: 0,
  color: Constants.Colors.marineTwo
})

const Footer = glamorous(View)({
  flexDirection: 'row',
  justifyContent: 'center',
  marginTop: 50
})

const { object, string, func } = Proptypes
class CustomDialog extends Component {
  static propTypes = {
    navigator: object,
    title: string,
    text: string,
    children: func
  }

  render() {
    const { title, text, children } = this.props
    return (
      <Container>
        <TouchableWithoutFeedback
          onPress={() => this.props.navigator.dismissLightBox()}
        >
          <Overlay />
        </TouchableWithoutFeedback>
        <Dialog>
          <Title>{ title }</Title>
          <TextContent>{ text }</TextContent>
          <Footer>
            {children()}
          </Footer>
        </Dialog>
      </Container>
    );
  }
}

export default CustomDialog
