/*
*   author: denis
*   date:   7/13/2018
*/
import React, { Component } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import Icon from 'react-native-vector-icons/FontAwesome';

//props
//  title
//  icon
//  func

const ContainerView = glamorous(TouchableOpacity)({
  width: 132
});

const ImageView = glamorous(Image) ({
  left: -8
});

const RowView = glamorous(View)({
  flexDirection: "row",
  marginTop: -27,
  top: -12,
  left: 20
});

const WhiteText = glamorous(Text)({
  fontSize: 16,
  color: "white",
  width: 75
});

const IconView = glamorous(View)({
  marginTop: 2,
  marginLeft: 5
});

const { func, string } = Proptypes;
export default class ParallelButton extends Component {
  static propTypes = {
    title: string,
    icon: string,
    proc: func
  }
  
  static defaultProps = {
    title: "Add List",
    icon: "plus",
    proc: () => {}
  }

  constructor(props) {
    super(props);
  }

  render() {
    return(
        <ContainerView onPress={() => this.props.proc()}>
          <View>
            <ImageView source={require("../../../../img/parallelButton.png")} />
          </View>
          <RowView>
            <WhiteText numberOfLines={1}>{this.props.title}</WhiteText>
            <IconView>
              <Icon name={this.props.icon} size={16} color="white" />
            </IconView>
          </RowView>
        </ContainerView>
    );
  }
}

