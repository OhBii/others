import React from 'react'
import {
  View
} from 'react-native'
import glamorous from 'glamorous-native'

import Constants   from '../../../global/Constants';

const Container = glamorous(View)(({ noPad, style, noShadow, noPadV }) => ({
  width: '100%',
  paddingVertical: noPadV ? 0 : 20,
  paddingHorizontal: noPad ? 0 : Constants.mainPadding,
  shadowColor: noShadow ? 'rgba(0, 0, 0, 0)' : 'rgba(0, 0, 0, 0.07)',
  shadowOffset: {
    width: 0,
    height: 1
  },
  shadowRadius: 5,
  shadowOpacity: 1,
  backgroundColor: 'white',
  marginTop: 10,
  ...style
}))

const SnowBox = ({ noPad, children, style, noShadow, noPadV} = this.props) =>
  <Container noPad={noPad} style={style} noShadow={noShadow} noPadV={noPadV}>
    {children}
  </Container>

export default SnowBox
