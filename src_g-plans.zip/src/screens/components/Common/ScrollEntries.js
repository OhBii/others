import React from 'react'
import PropTypes from 'prop-types'
import {
  View,
  ScrollView
} from 'react-native'
import glamorous from 'glamorous-native'

const Wrap = glamorous(View)({
	flex: 1
})

const ScrollEntries = (
  { data, elem, ...props } = this.props
) => {
  const Elem = elem
  return (
    <Wrap>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
      >
        {!!data && data.map((slide, index) =>
          <Elem
            key={index}
            index={index}
            slide={slide}
            {...slide}
            {...props}
          />
        )}
      </ScrollView>
    </Wrap>
  )
}

const { object } = PropTypes
ScrollEntries.propTypes = {
  props: object
}

export default ScrollEntries
