import React, { Component } from 'react';
import {
  View,
  Image
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import LottieView from 'lottie-react-native';

import Constants from '../../../global/Constants';

const PruvitLottie = glamorous(View)(({ size }) => ({
  width: size,
  height: size,
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center'
}))

const LogoImage = glamorous(Image)({
  resizeMode: 'contain'
})

const { number } = Proptypes;
export default class GplansLogoLoader extends Component {
  static propTypes = {
    size: number
  }

  constructor(props) {
    super(props);
  }

  componentDidMount() {
    this.animation.play();
  }

  render() {
    const { size } = this.props
    return(
      <PruvitLottie
        size={size || 223}
      >
        <LogoImage source={Constants.Images.GPLANS_LOGO}/>
        <LottieView
          ref={animation => {
            this.animation = animation;
          }}
          source={Constants.Images.LOTTIE_GPLANS_LOADER}
          loop={true}
          enableMergePathsAndroidForKitKatAndAbove
          style={{}}
        />
       </PruvitLottie>
    )
  }
}
