
import React, { Component } from 'react';
import {
  View,
  WebView,
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';

import Constants from '../../../global/Constants'
import ShowHeader from '../HeaderBar/ShowHeader';
import GplansLogoLoader from '../Common/GplansLoader'

const ContainerView = glamorous(View)({
  flexDirection: "column",
  flex: 1,
  backgroundColor: Constants.Colors.whiteFive
});

const ContainerLoader = glamorous(View)({
  position: 'absolute',
  left: 0,
  top: 0,
  right: 0,
  bottom: 0,
  flexDirection: "column",
  flex: 1,
  backgroundColor: 'rgba(100,100,100, 0.1)',
  alignItems: 'center',
  justifyContent: 'center'
})

const { object, string, bool } = Proptypes;
export default class StyledWebView extends Component {
  static propTypes = {
    navigator: object,
    title: string,
    hasNotify: bool,
    link: string,
  }

  constructor(props) {
    super(props);
  }

  render() {
    return(
      <ContainerView>
        <ShowHeader
          title={this.props.title}
          navigator={this.props.navigator}
          hasNotify={this.props.hasNotify}
         />
        <WebView
          source = {{ uri: this.props.link }}
          renderLoading={ () => <ContainerLoader><GplansLogoLoader size={60} /></ContainerLoader> }
          startInLoadingState={true}
        />
      </ContainerView>
    );
  }
}
