import React from 'react'
import {
  Text,
  View,
  Image,
  TouchableOpacity,
  Switch,
  Platform
} from 'react-native'
import glamorous from 'glamorous-native'

import Constants   from '../../../global/Constants'

const Container = glamorous(View)(({ hrPad }) => ({
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'space-between',
  width: '100%',
  marginBottom: 15,
  paddingHorizontal: hrPad || 0
}))

const Title = glamorous(Text)({
  fontSize: Platform.OS === 'ios' ? Constants.moderateScale(17, 1.8) : 18,
  fontWeight: 'bold',
  color: Constants.Colors.greyishBrownThree,
  paddingRight: 10
})

const More = glamorous(View)({
  alignItems: 'center',
  justifyContent: 'flex-end',
  flexDirection: 'row'
})

const MoreText = glamorous(Text)({
  fontSize: 12,
  fontWeight: '500',
  color: Constants.Colors.brownishGreyThree,
})

const Icon = glamorous(Image)({
  marginHorizontal: 5
})

const MainTitle = ({ title, onMore, value, onSwitch, hrPad, moreText } = this.props) =>
  <Container hrPad={hrPad}>
    <Title>{ title }</Title>
    {!!onMore && <TouchableOpacity onPress={onMore}>
      <More>
        <MoreText>{moreText || 'More'}</MoreText>
        <Icon source={Constants.Images.ICON_MORE} />
      </More>
    </TouchableOpacity>}
    {!!onSwitch && <Switch value={value} onValueChange={onSwitch}/>}
  </Container>

export default MainTitle
