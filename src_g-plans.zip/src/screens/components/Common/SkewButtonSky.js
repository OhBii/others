import React from 'react'
import {
  TouchableOpacity,
  Image
} from 'react-native'
import glamorous from 'glamorous-native'

const SkewButton = glamorous(TouchableOpacity)({
  justifyContent: 'center',
  alignItems: 'center',
  marginLeft: 20,
})

const Icon = glamorous(Image)({
  width: 61,
  height: 57
})

const SkewButtonSky = ({ onPress, source } = this.props) =>
  <SkewButton
    onPress={onPress}
  >
    <Icon
      source={source}
    />
  </SkewButton>

export default SkewButtonSky
