import React, { Component } from 'react'
import {
  Text,
  View,
  Animated,
  Image
} from 'react-native'
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native'
import { inject, observer } from 'mobx-react/native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import CircleGradient from './CircleGradient'
import Constants   from '../../../global/Constants'

const AnimatedView = glamorous(Animated.View)

const Progress = glamorous(View)({
  flexDirection: 'column'
})

const ProgressTop = glamorous(View)({
  flexDirection: 'row',
  alignItems: 'center'
})

const ProgressLeft = glamorous(View)({
  width: '37%',
  flexDirection: 'column',
  justifyContent: 'center'
})

const ProgressRight = glamorous(View)({
  width: '63%',
  justifyContent: 'space-between',
  flexDirection: 'row',
  paddingLeft: 15
})

const ProgressRow = glamorous(View)({
  flexDirection: 'column',
  height: 96,
  justifyContent: 'center'
})

const ProgressBar = glamorous(View)({
  width: '100%',
  height: 7,
  borderRadius: 5,
  backgroundColor: Constants.Colors.whiteThree,
  overflow: 'hidden'
})

const ProgressBarFull = AnimatedView(({ width }) => ({
  width: width || 0,
  height: 7,
  borderRadius: 5,
  position: 'absolute',
  left: 0
}))
ProgressBarFull.propsAreStyleOverrides = true

const CircleLabelView = glamorous(View)({
  position: 'absolute',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'space-between',
  width: '100%',
  height: '100%'
})

const CircleLabelName = glamorous(Text)({
  fontSize: 13,
  fontWeight: "bold",
  color: Constants.Colors.greyishBrownThree
})

const CircleLabelData = glamorous(Text)({
  fontSize: 18,
  color: Constants.Colors.warmGreyFour
})

const CircleLabelUnit = glamorous(Text)({
  fontSize: 12,
  color: Constants.Colors.warmGreyFour
})

const FcpWrap = glamorous(View)({
  flexDirection: 'row'
})

const Fcp = glamorous(Text)({
  color: Constants.Colors.greyishBrownThree,
  fontWeight: 'bold',
  fontSize: 10
})

const FcpFull = glamorous(Text)({
  color: Constants.Colors.greyishBrownThree,
  fontSize: 10
})

const CircleLabelCrown = glamorous(View) ({
  marginTop: -12
})

const CircleLabel = ({ title, data, unit, fcp, fcpFull, isFreemium } = this.props) =>
  <CircleLabelView>
    <CircleLabelName>{ title }</CircleLabelName>
    {
      isFreemium
        ? <CircleLabelCrown>
            <Icon name="crown" size={24} color={Constants.Colors.sandYellow} />
          </CircleLabelCrown>
        :
          <CircleLabelData>
            { data }
            <CircleLabelUnit>{ unit || '%' }</CircleLabelUnit>
          </CircleLabelData>
    }

    {
      isFreemium
        ? <View />
        : <FcpWrap>
            <Fcp>{ `${fcp}g` }</Fcp>
            <FcpFull>{ ` / ${fcpFull}g` }</FcpFull>
          </FcpWrap>
    }
  </CircleLabelView>

const Calories = glamorous(View)({
  flexDirection: 'column'
})

const CaloriesRow = glamorous(View)({
  flexDirection: 'row',
  alignItems: 'flex-end'
})

const Flame = glamorous(Image)({
  marginTop: -2,
  marginRight: 5
})

const CaloriesText = glamorous(Text)({
  fontSize: 26,
  fontWeight: 'bold',
  letterSpacing: 0,
  color: Constants.Colors.greyishBrownThree,
  marginRight: 1,
  top: 3
})

const CaloriesUnit = glamorous(Text)({
  fontSize: 13,
  fontWeight: 'bold',
  letterSpacing: 0,
  color: Constants.Colors.greyishBrownThree
})

const Percents = glamorous(Text)({
  fontSize: 12,
  fontWeight: 'bold',
  color: Constants.Colors.greyishBrownThree,
  marginRight: 1,
  width: 35
})

const ProgressWrap = glamorous(View)(({ top }) => ({
  flexDirection: 'row',
  width: '100%',
  alignItems: 'center',
  top: top ? 17 : 27
}))

const ProgressBarWrap = glamorous(View)({
  width: '72%'
})

const ProgressBarGradient = glamorous(LinearGradient)({
  width: '100%',
  position: 'absolute',
  left: 0,
  top: 0,
  bottom: 0
})

const { number, object, bool } = Proptypes
@inject( 'User') @observer
class MainProgress extends Component {
  static propTypes = {
    User: object,
    percent: number,
    calories: number,
    bar: number,
    fcpData: object,
    aboveFlame: bool
  }

  static defaultProps = {
    percent: 0,
    bar: 0
  }

  constructor(props) {
   super(props)
   this.state = {
     dataCircle: [{ x: 1, y: 10 }, { x: 2, y: 4 }],
     statePro: new Animated.Value(0),
     stateFats: new Animated.Value(0),
     stateCarbs: new Animated.Value(0)
   }

   //console.disableYellowBox = true
 }

  render() {
    const { calories, percent, bar, fcpData, aboveFlame, User: { isFreemium } } = this.props
    const dataFcp = {...fcpData}

   return (

      <Progress>
        <ProgressTop>
          <ProgressLeft>
            {
              aboveFlame && !isFreemium
              ? <Calories>
                  <Flame
                    source={Constants.Images.FLAME}
                  />
                  <CaloriesRow>
                    <CaloriesText>{ calories }</CaloriesText>
                    <CaloriesUnit>{'Cals'}</CaloriesUnit>
                  </CaloriesRow>
                </Calories>
              : <CaloriesRow>
                  <Flame
                    source={Constants.Images.FLAME}
                  />
                  <CaloriesText>{ calories }</CaloriesText>
                  <CaloriesUnit>{'Cals'}</CaloriesUnit>
                </CaloriesRow>
            }
            {
              isFreemium
                ? <View />
                : <ProgressWrap top={aboveFlame}>
                    <Percents>{`${percent}%`}</Percents>
                    <ProgressBarWrap>
                      <ProgressBar>
                        <ProgressBarFull
                          width={`${bar}%`}
                        >
                          <ProgressBarGradient
                            colors={['#4da1ff', '#39eeff']}
                            start={{x: 0, y: 1}}
                            end={{x: 1, y: 0}}
                          />
                        </ProgressBarFull>
                      </ProgressBar>
                    </ProgressBarWrap>
                  </ProgressWrap>
            }
          </ProgressLeft>
          <ProgressRight>
            <ProgressRow>
              <CircleGradient
                colors={['#2FA1F3', '#45F1FF']}
                size={60}
                stroke={4}
                corner={8}
                bgCircle={'#f1f1f1'}
                data={[{ x: 1, y: dataFcp.fats.data }, { x: 2, y: (100 - dataFcp.fats.data) }]}
              />
              <CircleLabel
                title={'Fats'}
                {...dataFcp.fats}
                isFreemium={isFreemium}
              />
            </ProgressRow>
            <ProgressRow>
              <CircleGradient
                colors={['#2FA1F3', '#45F1FF']}
                size={60}
                stroke={4}
                corner={8}
                bgCircle={'#f1f1f1'}
                data={[{ x: 1, y: dataFcp.carbs.data }, { x: 2, y: (100 - dataFcp.carbs.data) }]}
              />
              <CircleLabel
                title={'Carbs'}
                {...dataFcp.carbs}
                isFreemium={isFreemium}
              />
            </ProgressRow>
            <ProgressRow>
              <CircleGradient
                colors={['#2FA1F3', '#45F1FF']}
                size={60}
                stroke={4}
                corner={8}
                bgCircle={'#f1f1f1'}
                data={[{ x: 1, y: dataFcp.pro.data }, { x: 2, y: (100 - dataFcp.pro.data) }]}
              />
              <CircleLabel
                title={'Pro'}
                {...dataFcp.pro}
                isFreemium={isFreemium}
              />
            </ProgressRow>
          </ProgressRight>
        </ProgressTop>
      </Progress>
    )
  }
}

export default MainProgress
