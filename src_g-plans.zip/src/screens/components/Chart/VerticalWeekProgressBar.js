import React, { Component } from 'react'
import {
  View,
  Animated,
  Text
} from 'react-native'
import Proptypes from 'prop-types';
import { inject, observer } from 'mobx-react';
import moment from 'moment';
import glamorous from 'glamorous-native';
import LinearGradient from 'react-native-linear-gradient';

import Constants   from '../../../global/Constants';

const standardExerciseTime = 30

const AnimatedView = glamorous(Animated.View)

const Container = glamorous(View)({
  width: '100%',
  flexDirection: 'row',
  justifyContent: 'space-between'
})

const CellDate = glamorous(View)({
  flexDirection: 'column',
  width: '14%',
  alignItems: 'center'
})

const WeekDayStat = glamorous(View)(({ isStat, height }) => ({
  width: 7,
  height: height || 47,
  borderRadius: 3.5,
  backgroundColor: isStat ? 'rgba(1,39,84,1)' : 'rgb(238, 238, 238)',
  overflow: 'hidden'
}))

const WeekDayStatBar = AnimatedView(({ height }) => ({
  height: height || 0,
  position: 'absolute',
  bottom: 0,
  borderRadius: 3.5,
  width: 7
}))
WeekDayStatBar.propsAreStyleOverrides = true

const WeekDayGradient = glamorous(LinearGradient)({
  position: 'absolute',
  top: 0,
  left: 0,
  right: 0,
  bottom: 0,
  borderRadius: 3.5
})

const SelectDate = glamorous(View)(({ isActive }) => ({
  marginTop: 10,
  width: 26,
  height: 26,
  borderWidth: 1,
  borderColor: isActive ? '#979797' : 'transparent',
  justifyContent: 'center',
  alignItems: 'center',
  borderRadius: 13
}))

const SelectDateText = glamorous(Text)(({ isActive }) => ({
  fontSize: 12,
  fontWeight: '600',
  textAlign: 'center',
  color: isActive ? '#012754' : Constants.Colors.greyishBrownThree
}))

const ButtonSelectDate = ({day, isActive, disabled}=this.props) =>
  <SelectDate isActive={isActive} disabled={disabled}>
    <SelectDateText isActive={isActive}>{moment(day, 'ddd').format('ddd').slice(0, 1)}</SelectDateText>
  </SelectDate>

const { number, object, array } = Proptypes
@inject( 'User', 'DayIndex') @observer
export default class VerticalWeekProgressBar extends Component {
  static propTypes = {
    User: object,
    DayIndex: object,
    height: number,
    data: array,
  }

  constructor(props) {
    super(props)
  }

  render() {
    const {
      User: {
        userInfo: { last_checkin }
      },
      DayIndex,
      height,
      data,
    } = this.props;

    const startOfWeek = moment(last_checkin.created_at);
    const weekDays = Array(7).fill(0).map((item, index) => {
      return moment(startOfWeek).add(index, 'd');
    })

    const graph = data ? data : []
    return (
      <Container>
      {
        weekDays.map((day, i) =>
          <CellDate key={i}>
            <WeekDayStat
              isStat={i <= DayIndex.homeDayIndex}
              height={height}
            >
              <WeekDayStatBar
                height={`${graph[i] ? graph[i] * 100 / standardExerciseTime : 0}%`}
                opacity={i <= DayIndex.homeDayIndex ? 1 : 0}
              >
                <WeekDayGradient
                  colors={['rgb(77, 160, 255)', 'rgb(57, 238, 255)']}
                  start={{x: 0, y: 0.5}}
                  end={{x: 0.5, y: 0}}
                />
              </WeekDayStatBar>
            </WeekDayStat>
            <ButtonSelectDate
              day={day}
              isActive={DayIndex.homeDayIndex === i}
              disabled={i > DayIndex.homeDayIndex}
            />
          </CellDate>)
      }
      </Container>
    )
  }
}
