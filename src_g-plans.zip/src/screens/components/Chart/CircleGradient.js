import React, { Component } from 'react';
import Proptypes from 'prop-types';
import {
    View,
} from 'react-native';
import { VictoryPie } from "victory-native";
import {Defs, LinearGradient, Stop, Svg} from "react-native-svg";

const { string, number, array } = Proptypes;
export default class CircleGradient extends Component {
  static propTypes = {
    colors: array,
    size: number,
    stroke: number,
    corner: number,
    bgCircle: string,
    data: array
  }

  constructor() {
    super();
    this.state = {
      data: [{ x: 1, y: 0 }, { x: 2, y: 100 }]
    }
  }

  componentDidMount() {
    this.setState({
      data: this.props.data
    })
  }

  static getDerivedStateFromProps(props) {
    if(props.data) {
      return {
        data: props.data
      }
    }

    return null
  }

  render() {

    const { colors, size, stroke, corner, bgCircle } = this.props
    let start = 0
    let segment = (100 / colors.length).toFixed(1)
    return(
      <View>
        <Svg viewBox={`0 0 ${size} ${size}`} width={size} height={size}>

            <Defs>
              <LinearGradient id="gradient"
                x1="0%" y1="0%" x2="0%" y2="100%"
              >
              {
                colors.map((cc, ind) => {
                  if(ind > 0) {
                    start += segment
                  }
                  return(
                    <Stop key={ind} offset={`${ind === 0 ? 0 : ind === colors.length - 1 ? 100 : start}%`} stopColor={cc} />
                  )
                })
              }
              </LinearGradient>
            </Defs>
            <VictoryPie
              standalone={false}
              height={size}
              width={size}
              animate={{ duration: 600 }}
              innerRadius={size / 2 - stroke}
              cornerRadius={!!corner && ((data) =>
                data.index === 0 ? corner : 0
              )}
              padAngle={0}
              padding={0}
              labelRadius={0}
              labels={() => null}
              style={{
                data: { fill: (d) => {
                  const color = colors.length > 1 ? "url(#gradient)" : colors[0];
                  return d.x === 1 ? color : bgCircle || 'transparent';
                }
                }
              }}
              data={this.state.data}
            />
        </Svg>
      </View>
    )
  }
}
