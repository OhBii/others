import React, { Component } from 'react'
import {
  View,
  Animated
} from 'react-native'
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native'
import LinearGradient from 'react-native-linear-gradient';

import Constants   from '../../../global/Constants'

const AnimatedView = glamorous(Animated.View)

const Container = glamorous(View)({
  width: '100%',
  height: 7,
  borderRadius: 5,
  backgroundColor: Constants.Colors.whiteThree,
  overflow: 'hidden'
})

const ProgressBarFull = AnimatedView({
  height: 7,
  borderRadius: 5,
  position: 'absolute',
  left: 0
})
ProgressBarFull.propsAreStyleOverrides = true

const ProgressBarGradient = glamorous(LinearGradient)({
  width: '100%',
  position: 'absolute',
  left: 0,
  top: 0,
  bottom: 0
})

const { number } = Proptypes
export default class ProgressBar extends Component {

  static propTypes = {
    bar: number
  }

  constructor(props) {
    super(props)
    this.state = {
      bar: props.bar
    }
  }

  componentDidUpdate(prevProps){
    if(prevProps.bar !== this.state.bar) {
      this.setState({ bar: prevProps.bar });
    }
  }

  render() {
    return (
      <Container>
        <ProgressBarFull
          width={`${this.state.bar}%`}
        >
          <ProgressBarGradient
            colors={['#4da1ff', '#39eeff']}
            start={{x: 0, y: 1}}
            end={{x: 1, y: 0}}
          />
        </ProgressBarFull>
      </Container>
    )
  }
}
