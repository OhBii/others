import React from 'react'
import {
  View,
  Image
} from 'react-native';
import Svg from 'react-native-svg'
import { VictoryPie, VictoryAnimation, VictoryLabel } from "victory-native";
import glamorous from 'glamorous-native';
import Constants   from '../../../global/Constants'

const labelDefaultStyle = {
  fontSize: 28,
  fontWeight: '300',
  fill: Constants.Colors.greyishBrown
}

const N8View = glamorous(View)(({ width, height }) => ({
  width,
  height,
  left: -12
}))

const N8Inner = glamorous(View)(({ width, height }) => ({
  width,
  height,
  alignItems: 'center',
  justifyContent: 'center',
  position: 'absolute',
  left: 0,
  top: 0
}))

const N8Image = glamorous(Image)({

})

const CircleProgress = ({ pro, fats, carbs, data, labelStyle, size, n8, ...pieProps } = this.props) =>
  <N8View width={size + 55} height={size + 55}>
    <Svg width={size + 55} height={size + 55}>
      <VictoryPie
        standalone={false}
        width={size + 55} height={size + 55}
        animate={{ duration: 1000 }}
        radius={(data) => {
          return (data.index === 0 ? size / 1.4
                  : data.index === 1 ? (size / 1.4) - ((size / 1.4) / 12)
                  : data.index === 2 ? (size / 1.4) - ((size / 1.4) / 6)
                  : data.index === 3 ? (size / 1.4) - ((size / 1.4) / 4) : 0)
        }}
        innerRadius={30}
        padAngle={0}
        padding={0}
        labelRadius={40}
        data={
          [{ x: 1, y: pro },
           { x: 2, y: fats },
           { x: 3, y: carbs },
           { x: 4, y: 300 - pro - fats - carbs }]
        }
        labels={() => null}
        style={{
              data: { fill: (d) => {
                return (d.x === 1
                        ? Constants.Colors.brightCyan
                        : d.x === 2
                        ? Constants.Colors.azure
                        : d.x === 3
                        ? Constants.Colors.marineTwo
                        : d.x === 4
                        ? Constants.Colors.whiteThree
                        : 'transparent');
                     }
              }
            }}
        {...pieProps}
      />
      {!n8 && <VictoryAnimation duration={1000} data={data}>
            {(newProps) => {
              return (
                <VictoryLabel
                  textAnchor="middle" verticalAnchor="middle"
                  x={(size + 55) / 2} y={(size + 55) / 2}
                  text={`${Math.round(newProps.percent)}%`}
                  style={labelStyle || labelDefaultStyle}
                />
              );
            }}
      </VictoryAnimation>}
    </Svg>
    {!!n8 && <N8Inner width={size + 55} height={size + 55}>
      <N8Image source={Constants.Images.N8_WATER} />
    </N8Inner>}
  </N8View>

export default CircleProgress
