
import React, { Component } from 'react';
import {
  View,
  Alert,
  ScrollView
} from 'react-native';
import { inject, observer } from 'mobx-react/native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';

import ExerciseItem from './ExerciseItem';
import Constants from '../../../global/Constants';
import ShowHeader from '../HeaderBar/ShowHeader';

const Container = glamorous(View)({
  flex: 1,
  backgroundColor: Constants.Colors.backgroundColor
})

const List = glamorous(ScrollView)({
  marginTop: 10,
  backgroundColor: Constants.Colors.white
})

const { object } = Proptypes;
@inject( 'ExerciseTrack' ) @observer
export default class ExerciseList extends Component {
  static propTypes = {
    navigator: object,
    ExerciseTrack: object
  }

  constructor(props) {
    super(props);
  }

  onExerciseSelected(id, title) {
    const {
      ExerciseTrack: {
        trackExercise,
      },
      navigator
    } = this.props

    const onTrack = mins => {
      trackExercise(id, mins)
        .then(() => {
          //
        })
        .catch(error => {
          Alert.alert(error.message)
        })
    }
    navigator.showLightBox({
      ...Constants.Screens.EXERCISETRACKER_SCREEN,
      style: {
        backgroundColor: "#000000a0",
        tapBackgroundToDismiss: true
      },
      passProps: {
        title,
        onTrack,
      }
    });
  }

  render() {
    const { ExerciseTrack: { exerciseList } } = this.props;

    return(
      <Container>
        <ShowHeader
          navigator={this.props.navigator}
          title={'Add Exercise'}
          isModal
        />
        <List>
          {
            exerciseList.map(exercise =>
              <ExerciseItem
                key={exercise.id}
                source={Constants.Images.ICON_EX1}
                title={exercise.title}
                onPress={() => this.onExerciseSelected(exercise.id, exercise.title)}
              />
            )
          }
        </List>
      </Container>
    )
  }
}
