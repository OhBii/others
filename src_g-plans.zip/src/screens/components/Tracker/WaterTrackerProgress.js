import React, { Component } from 'react'
import {
  Text,
  View,
  TouchableOpacity
} from 'react-native'
import glamorous from 'glamorous-native'
import Proptypes from 'prop-types';
import EIcon from 'react-native-vector-icons/Entypo';

import CircleGradient from '../Chart/CircleGradient'
import VerticalWeekProgressBar from '../Chart/VerticalWeekProgressBar'
import Constants   from '../../../global/Constants'

import { inject, observer } from 'mobx-react/native';

//const { width } = Constants.windowDimensions

const Container = glamorous(View)({
  flexDirection: 'column',
  alignItems: 'center',
  width: '100%'
})

const Top = glamorous(View)({
  flexDirection: 'row',
  width: '100%',
  justifyContent: 'space-around',
  alignItems: 'center',
  marginBottom: 15
})

const Bottom = glamorous(View)({
  justifyContent: 'center',
  marginTop: 20
})

const Button = glamorous(TouchableOpacity)({
  width: 60,
  height: 60,
  borderRadius: 30,
  borderWidth: 1,
  borderColor: Constants.Colors.dodgerBlueFour,
  alignItems: 'center',
  justifyContent: 'center'
})

const IconPlus = glamorous(EIcon)({

})

const ProgressRow = glamorous(View)({
  flexDirection: 'column',
  height: 170,
  justifyContent: 'center',
  flexShrink: 1
})

const CircleLabelView = glamorous(View)({
  position: 'absolute',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  width: '100%',
  height: '100%',
  left: 0,
  top: 0
})

const CircleLabelName = glamorous(Text)({
  fontSize: 13,
  fontWeight: 'bold',
  textAlign: 'center',
  color: Constants.Colors.greyishBrownThree
})

const CircleLabelData = glamorous(Text)({
  fontSize: 48,
  textAlign: "center",
  color: Constants.Colors.greyishBrownThree,
  marginVertical: 1
})

const CircleLabelUnit = glamorous(Text)({
  fontSize: 13,
  fontWeight: 'bold',
  textAlign: 'center',
  color: Constants.Colors.greyishBrownThree
})

const Values = glamorous(View)({
  flexDirection: 'column',
  justifyContent: 'center',
  flexShrink: 2
})

const ValuesItem = glamorous(View)({
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center'
})

const ValuesTitle = glamorous(Text)({
  fontSize: 12,
  fontWeight: "bold",
  fontStyle: "normal",
  letterSpacing: 0,
  textAlign: "center",
  color: Constants.Colors.greyishBrownThree
})

const ValuesData = glamorous(Text)({
  fontSize: 30,
  fontWeight: '600',
  textAlign: 'center',
  color: Constants.Colors.greyishBrownThree
})

const ValuesUnit = glamorous(Text)({
  fontSize: 12,
  fontWeight: '600',
  textAlign: 'center',
  color: Constants.Colors.greyishBrownThree
})

const Divider = glamorous(View)({
  width: '100%',
  borderStyle: 'solid',
  borderBottomWidth: 1,
  borderColor: '#ededed',
  marginVertical: 18,
  minWidth: 82
})

const WeekWrap = glamorous(View)({
  maxWidth: '88%'
})

const { object } = Proptypes;
@inject( 'WaterTrack' ) @observer
class WaterTrackerProgress extends Component {
  static propTypes = {
    navigator: object,
    WaterTrack: object
  }

  constructor(props) {
    super(props)
  }

  onWaterTracked() {
    this.props.navigator.showLightBox({
      ...Constants.Screens.WATERTRACKER_SCREEN,
      style: {
        backgroundColor: "#000000a0",
        tapBackgroundToDismiss: true
      },
    });
  }

  getRoundValue(amount) {
    const { WaterTrack } = this.props;
    const amountRound = WaterTrack.unit === 2
      ?  (Math.round(amount * WaterTrack.Ratio * 100) / 100)
      :  WaterTrack.unit === 3
            ?  Math.round(amount * WaterTrack.Ratio)
            :  (Math.round(amount * WaterTrack.Ratio * 10) / 10);
    return amountRound;
  }

  render() {
    const { WaterTrack } = this.props

    const unit = WaterTrack.Unit.abbr
    const percent = (WaterTrack.percentageOfTrack > 100) ? 100 : WaterTrack.percentageOfTrack
    const amount = this.getRoundValue(WaterTrack.WaterTrackForToday.glasses)

    const maxGoal = this.getRoundValue(WaterTrack.waterMax)
    const minGoal = this.getRoundValue(WaterTrack.waterMax / 2)

    const data = WaterTrack.getPercentageOfWeek.map((item) => item.percent)

    return(
      <Container>
        <Top>
          <ProgressRow>
            <CircleGradient
              colors={['rgb(57,238,255)', 'rgb(0,80,171)']}
              size={170}
              stroke={5}
              corner={3}
              bgCircle={'#f1f1f1'}
              data={
                percent > 50
                ? [{ x: 1, y: (percent - 50) }, { x: 2, y: (100 - percent) }]
                : [{ x: 1, y: 0 }, { x: 2, y: 50 }]
              }
            />
            <CircleLabelView>
              <CircleGradient
                colors={['#45F1FF', 'rgb(77,160,255)']}
                size={146}
                stroke={5}
                corner={3}
                bgCircle={'#f1f1f1'}
                data={
                  percent > 50
                  ? [{ x: 1, y: 50 }, { x: 2, y: 0 }]
                  : [{ x: 1, y: percent }, { x: 2, y: (50 - percent) }]
                }
              />
            </CircleLabelView>
            <CircleLabelView>
              <CircleLabelName>{'Progress'}</CircleLabelName>
              <CircleLabelData>{amount}</CircleLabelData>
              <CircleLabelUnit>{unit}</CircleLabelUnit>
            </CircleLabelView>
          </ProgressRow>
          <Values>
            <ValuesItem>
              <ValuesTitle>{'Min Goal'}</ValuesTitle>
              <ValuesData>{minGoal}<ValuesUnit>{unit}</ValuesUnit></ValuesData>
            </ValuesItem>
            <Divider />
            <ValuesItem>
              <ValuesTitle>{'Max Goal'}</ValuesTitle>
              <ValuesData>{maxGoal}<ValuesUnit>{unit}</ValuesUnit></ValuesData>
            </ValuesItem>
          </Values>
        </Top>
        <WeekWrap>
          <VerticalWeekProgressBar
            data={data}
          />
        </WeekWrap>
        <Bottom>
          <Button onPress={() => this.onWaterTracked()}>
            <IconPlus name='plus' size={30} color={Constants.Colors.dodgerBlueFour} />
          </Button>
        </Bottom>
      </Container>
    )
  }
}

export default WaterTrackerProgress
