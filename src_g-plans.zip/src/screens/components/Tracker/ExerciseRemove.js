
import React, { Component } from 'react';
import {
  View,
  Text,
  TouchableWithoutFeedback,
  TouchableOpacity
} from 'react-native';

import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';

import Constants from '../../../global/Constants';

const { width, height } = Constants.windowDimensions

const Container = glamorous(View)({
  backgroundColor: 'transparent',
  width,
  height,
  flexDirection: 'column',
  justifyContent: 'flex-end'
})

const Overlay = glamorous(View)({
  position: 'absolute',
  left: 0,
  top: 0,
  width: '100%',
  height: '100%',
  backgroundColor: 'transparent'
})

const Dialog = glamorous(View)({
  width: '100%',
  paddingTop: 30,
  paddingHorizontal: 15,
  backgroundColor: Constants.Colors.white,
  flexDirection: 'column',
  paddingBottom: 40
})

const Title = glamorous(Text)({
  fontSize: 20,
  fontWeight: '500',
  textAlign: 'center',
  color: Constants.Colors.blackTwo
})

const Footer = glamorous(View)({
  flexDirection: 'row',
  justifyContent: 'center',
  marginTop: 30,
  width: '100%'
})

const Button = glamorous(View)(({ color }) => ({
  width: width * 0.4,
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'center',
  height: 50,
  borderRadius: 25,
  backgroundColor: Constants.Colors.white,
  borderStyle: "solid",
  borderWidth: 1,
  borderColor: color || Constants.Colors.softBlueThree,
  marginHorizontal: 5
}))

const ButtonText = glamorous(Text)(({ color }) => ({
  fontSize: 18,
  fontWeight: 'bold',
  textAlign: 'center',
  color: color || Constants.Colors.softBlueThree
}))

const ButtonAction = ({ color, text, onPress } = this.props) =>
  <TouchableOpacity onPress={onPress}>
    <Button color={color}>
      <ButtonText color={color}>{ text }</ButtonText>
    </Button>
  </TouchableOpacity>

const { object, string, func } = Proptypes;

export default class ExerciseRemove extends Component {
  static propTypes = {
    navigator: object,
    title: string,
    onUntrack: func,
  }

  static defaultProps = {
    title: ""
  }

  constructor(props) {
    super(props);
  }

  onRemoveExercise(){
    this.props.navigator.dismissLightBox();
    this.props.onUntrack()
  }

  render() {
    const { title, navigator } = this.props
    return(
      <Container>
        <TouchableWithoutFeedback
          onPress={() => navigator.dismissLightBox()}
        >
          <Overlay />
        </TouchableWithoutFeedback>
        <Dialog>
          <Title>{ `Are you sure you want to delete\n${title}` }</Title>
          <Footer>
            <ButtonAction
              text={'No'}
              onPress={() => navigator.dismissLightBox()}
            />
            <ButtonAction
              text={'Yes'}
              color={Constants.Colors.coral}
              onPress={() => this.onRemoveExercise()}
            />
          </Footer>
        </Dialog>
      </Container>
    )
  }
}
