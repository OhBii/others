import React, { Component } from 'react'
import {
  Text,
  View,
  TouchableOpacity,
  Image,
  Alert,
} from 'react-native'
import glamorous from 'glamorous-native'
import Proptypes from 'prop-types';
import EIcon from 'react-native-vector-icons/Entypo';
import FAIcon from 'react-native-vector-icons/FontAwesome';

import VerticalWeekProgressBar from '../Chart/VerticalWeekProgressBar'
import Constants   from '../../../global/Constants'

import { inject, observer } from 'mobx-react/native';

const Container = glamorous(View)({
  flexDirection: 'column',
  alignItems: 'center',
  width: '100%'
})

const Top = glamorous(View)({
  flexDirection: 'row',
  width: '100%',
  justifyContent: 'space-around',
  alignItems: 'center',
  marginBottom: 15,
  paddingHorizontal: Constants.mainPadding
})

const Bottom = glamorous(View)({
  justifyContent: 'center',
  marginTop: 20
})

const Button = glamorous(TouchableOpacity)({
  width: 60,
  height: 60,
  borderRadius: 30,
  borderWidth: 1,
  borderColor: Constants.Colors.dodgerBlueFour,
  alignItems: 'center',
  justifyContent: 'center'
})

const IconPlus = glamorous(EIcon)({

})

const Values = glamorous(View)({
  flexDirection: 'column',
  justifyContent: 'center',
  flexShrink: 2
})

const ValuesItem = glamorous(View)({
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center'
})

const ValuesTitle = glamorous(Text)({
  fontSize: 12,
  fontWeight: "bold",
  fontStyle: "normal",
  letterSpacing: 0,
  textAlign: "center",
  color: Constants.Colors.greyishBrownThree
})

const ValuesData = glamorous(Text)({
  fontSize: 30,
  fontWeight: '600',
  textAlign: 'center',
  color: Constants.Colors.greyishBrownThree
})

const Divider = glamorous(View)({
  width: '100%',
  borderStyle: 'solid',
  borderBottomWidth: 1,
  borderColor: '#ededed',
  marginVertical: 18,
  minWidth: 82
})

const WeekWrap = glamorous(View)({
  width: 220,
  paddingLeft: 30
})

const Axis = glamorous(View)({
  flexDirection: 'column',
  justifyContent: 'space-between',
  position: 'absolute',
  left: 0,
  top: 0,
  height: 150
})

const AxisLabel = glamorous(Text)({
  fontSize: 10,
  fontWeight: 'bold',
  color: Constants.Colors.dodgerBlueTwo
})

const List = glamorous(View)({
  width: '100%',
  flexDirection: 'column',
  marginTop: 25
})

const ListItem = glamorous(View)({
  borderTopWidth: 1,
  borderColor: '#ededed',
  paddingHorizontal: Constants.mainPadding,
  paddingVertical: 20,
  flexDirection: 'row',
  alignItems: 'center'
})

const ListTumb = glamorous(View)({
  height: 40,
  width: 70,
  borderRightWidth: 1,
  borderColor: '#ededed',
  alignItems: 'center',
  justifyContent: 'center'
})

const ListContent = glamorous(View)({
  flexDirection: 'column',
  paddingLeft: 20,
  flexShrink: 2
})

const ListTitle = glamorous(Text)({
  fontSize: 16,
  fontWeight: 'bold',
  color: Constants.Colors.greyishBrownThree,
  marginBottom: 5
})

const ListText = glamorous(Text)({
  fontSize: 16,
  fontWeight: '500',
  color: '#9aa8bb'
})

const ListIcon = glamorous(TouchableOpacity)({
  marginLeft: 'auto',
  flexShrink: 1
})

const ItemList = ({ source, title, text, onTrash } = this.props) =>
  <ListItem>
    <ListTumb><Image source={source}/></ListTumb>
    <ListContent>
      <ListTitle>{title}</ListTitle>
      <ListText>{text}</ListText>
    </ListContent>
    <ListIcon onPress={onTrash}><FAIcon name='trash-o' size={20} color='#9aa8bb' /></ListIcon>
  </ListItem>

const { object } = Proptypes;
@inject( 'User', 'ExerciseTrack' ) @observer
class ExerciseTrackerProgress extends Component {
  static propTypes = {
    navigator: object,
    User: object,
    WaterTrack: object,
    ExerciseTrack: object,
  }

  constructor(props) {
    super(props)
  }

  onExerciseTracked() {
    this.props.navigator.showModal({
      ...Constants.Screens.EXERCISELIST_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  onExerciseRemove(id, title) {
    const {
      ExerciseTrack: {
        untrackExercise
      },
      navigator,
    } = this.props
    const onUntrack = () => {
      untrackExercise(id)
        .then(() => {
          //
        })
        .catch(error => {
          Alert.alert(error.message)
        })
    }
    navigator.showLightBox({
      ...Constants.Screens.EXERCISEREMOVE_SCREEN,
      style: {
        backgroundColor: "#000000a0",
        tapBackgroundToDismiss: true
      },
      passProps: {
        title,
        onUntrack,
      }
    });
  }

  render() {
    const {
      ExerciseTrack: {
        latestWeekBarGraphData,
        selectedDayTrackedData,
      }
    } = this.props
    return(
      <Container>
        <Top>
        <WeekWrap>
          <Axis>
            <AxisLabel>{'100%'}</AxisLabel>
            <AxisLabel>{'50%'}</AxisLabel>
            <AxisLabel>{'0%'}</AxisLabel>
          </Axis>
          <VerticalWeekProgressBar
            height={150}
            data={latestWeekBarGraphData}
          />
        </WeekWrap>
          <Values>
            <ValuesItem>
              <ValuesTitle>{'MINUTES'}</ValuesTitle>
              <ValuesData>{selectedDayTrackedData ? selectedDayTrackedData.total_minutes : 0}</ValuesData>
            </ValuesItem>
            <Divider />
            <ValuesItem>
              <ValuesTitle>{'CALORIES'}</ValuesTitle>
              <ValuesData>{selectedDayTrackedData ? selectedDayTrackedData.total_calories : 0}</ValuesData>
            </ValuesItem>
          </Values>
        </Top>
        <Bottom>
          <Button onPress={() => this.onExerciseTracked()}>
            <IconPlus name='plus' size={30} color={Constants.Colors.dodgerBlueFour} />
          </Button>
        </Bottom>
        <List>
          {selectedDayTrackedData && selectedDayTrackedData.logged_exercises.map(exercise => (
            <ItemList
              key={exercise.id}
              source={Constants.Images.ICON_EX1}
              title={exercise.title}
              text={`${exercise.cal} calories burned`}
              onTrash={() => this.onExerciseRemove(exercise.id, exercise.title)}
            />
          ))}
        </List>
      </Container>
    )
  }
}

export default ExerciseTrackerProgress
