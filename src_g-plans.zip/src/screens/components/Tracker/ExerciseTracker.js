/*
*   author: denis
*   date:   08/03/2018
*/

import React, { Component } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  //Platform,
  ActivityIndicator
} from 'react-native';
import { inject, observer } from 'mobx-react/native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';

import Constants from '../../../global/Constants';

const { width } = Constants.windowDimensions

const ModalView = glamorous(View)({
  width: width * 0.9,
  borderRadius: 6,
  backgroundColor: "white",
  paddingVertical: 15,
  paddingHorizontal: 15
});

const TitleView = glamorous(View)({
  flexDirection: "column"
});

const TitleText = glamorous(Text)({
  fontSize: 24,
  fontWeight: "bold",
  lineHeight: 28,
  color: Constants.Colors.greyishBrownThree,
  textAlign: 'center'
});

const HeaderView = glamorous(View)({
  flexDirection: "row",
  justifyContent: "center"
});

const ContentView = glamorous(View)({
  flexDirection: "row",
  justifyContent: "center",
  alignItems: 'center',
  marginTop: 20,
  marginBottom: 30
});

const CountView = glamorous(View)({
  height: width * 0.32,
  width: width * 0.32,
  backgroundColor: "white",
  borderRadius: 6,
  borderStyle: "solid",
  borderColor: "#d6d6d6",
  borderWidth: 1,
  justifyContent: "center",
  alignItems: "center",
  marginHorizontal: 10
});

const CountText = glamorous(Text)({
  marginTop: -10,
  marginBottom: 5,
  fontSize: 50,
  fontWeight: '500',
  color: Constants.Colors.greyishBrownThree,
});

const MinusPlusView = glamorous(TouchableOpacity)({
  width: 40,
  height: 40,
  alignItems: 'center',
  justifyContent: 'center',
  flexDirection: 'row',
  backgroundColor: Constants.Colors.fillColor,
  borderRadius: 40
});

const MinusPlusText = glamorous(Text)({
  color: 'white',
  fontSize: 36,
  lineHeight: 36
});

const FooterWrap = glamorous(View)({
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center'
})

const SelectView = glamorous(View)({
  flexDirection: "row",
  justifyContent: 'space-between',
  width: width * 0.7
});

const ItemView = glamorous(View)({
  flexDirection: 'column',
  alignItems: 'center'
});

const AmountView = glamorous(TouchableOpacity)(({selectIdx, selfIdx}) => ({
  width: 53,
  height: 52,
  justifyContent: 'center',
  alignItems: 'center',
  borderStyle: 'solid',
  borderColor: selectIdx == selfIdx
    ? Constants.Colors.darkSkyBlue
    : Constants.Colors.warmGreyEight,
  borderWidth: 1,
  borderRadius: 7,
  shadowColor: selectIdx == selfIdx ? 'rgba(0, 0, 0, 0.11)' : 'transparent',
  shadowOffset: {
     width: 0,
     height: 2
  },
  shadowRadius: 14,
  elevation: selectIdx == selfIdx ? 2 : 0,
  shadowOpacity: selectIdx == selfIdx ? 1 : 0
}));

const OzText = glamorous(Text)({
  color: Constants.Colors.warmGreyEight,
  fontSize: 13,
  marginVertical: 7
});

const AmountText = glamorous(Text)(({selectIdx, selfIdx}) => ({
  color: selectIdx == selfIdx
    ? Constants.Colors.marineTwo
    : Constants.Colors.warmGreyEight,
  fontSize: 24,
  fontWeight: '600'
}));

const UnitText = glamorous(Text)({
  marginTop: -10,
  fontSize: 16,
  color: Constants.Colors.greyishBrownThree,
  fontWeight: 'bold'
});

const FooterView = glamorous(View)({
  flexDirection: "row",
  justifyContent: "space-between",
  marginTop: 7,
  width: width * 0.7
});

const ButtonTrack = glamorous(View)({
  width: '100%',
  height: 50,
  borderRadius: 31.8,
  shadowColor: "rgba(0, 0, 0, 0.06)",
  shadowOffset: {
    width: 0,
    height: 3
  },
  shadowRadius: 12,
  shadowOpacity: 1,
  borderStyle: "solid",
  borderWidth: 1,
  borderColor: Constants.Colors.softBlueThree,
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'center'
});

const TrackButton = glamorous(TouchableOpacity)({
  width: '100%',
  marginVertical: 12
});

const ButtonText = glamorous(Text)({
  fontSize: 16,
  fontWeight: '600',
  color: Constants.Colors.softBlueThree
})

const OvalWrap = glamorous(View)({
  width: width * 0.38,
  height: width * 0.38,
  alignItems: 'center',
  justifyContent: 'center'
})

const recommendedMins = [
  { id: 0, value: 10 },
  { id: 1, value: 15 },
  { id: 2, value: 30 },
  { id: 3, value: 60 },
]

const { object, string, func } = Proptypes;
@inject('ExerciseTrack') @observer
export default class ExerciseTracker extends Component {
  static propTypes = {
    navigator: object,
    title: string,
    onTrack: func,
  }

  constructor(props) {
    super(props);
    this.state = {
      selectIdx: -1,
      minutes: 0,
      isLoading: false
    };
  }

  toPlus() {
    const tempMinute = this.state.minutes + 1
    this.toAmount(tempMinute)
  }

  toMinus() {
    const tempMinute = this.state.minutes - 1 >= 0 ? this.state.minutes - 1 : 0
    this.toAmount(tempMinute)
  }

  toAmount(amount) {
    const selected = recommendedMins.reduce((accumulator, el) => {
      if (Math.abs(amount - accumulator.value) <= Math.abs(amount - el.value)) return accumulator;
      return el;
    });
    this.setState({
      selectIdx: selected.id,
      minutes: amount
    });
  }

  async toTrack(title) {
    if (this.state.minutes === 0) return;

    const { onTrack, navigator } = this.props
    navigator.dismissLightBox();
    navigator.dismissModal();
    navigator.showLightBox({
      ...Constants.Screens.SUCCESS_SCREEN,
      style: {
        backgroundColor: "transparent",
        tapBackgroundToDismiss: false
      },
      passProps: {
        title,
        points: 20
      }
    });

    this.setState({ isLoading: true })
    try {
      await onTrack(this.state.minutes)
      //await this.props.WaterTrack.waterTrackProc(this.state.minutes);
    }
    catch (err) {
      this.setState({ isLoading: false })
    }
  }

  // getRoundValues() {
  //   const { WaterTrack } = this.props;
  //   const amount = WaterTrack.unit === 2
  //     ?  (Math.round(this.state.minutes * WaterTrack.Ratio * 100) / 100)
  //     :  WaterTrack.unit === 3
  //           ?  Math.round(this.state.minutes * WaterTrack.Ratio)
  //           :  (Math.round(this.state.minutes * WaterTrack.Ratio * 10) / 10);
  //   const boxs = WaterTrack.unit === 2
  //     ? {
  //         first: Math.round(WaterTrack.Ratio * 100) / 100,
  //         second: Math.round(WaterTrack.Ratio * 200) / 100,
  //         third: Math.round(WaterTrack.Ratio * 300) / 100,
  //         fourth: Math.round(WaterTrack.Ratio * 400) / 100
  //     }
  //     : {
  //         first: Math.round(WaterTrack.Ratio),
  //         second: Math.round(WaterTrack.Ratio * 2),
  //         third: Math.round(WaterTrack.Ratio * 3),
  //         fourth: Math.round(WaterTrack.Ratio * 4)
  //     }
  //
  //   return {
  //     amount: amount,
  //     ...boxs
  //   }
  // }

  render() {
    const { title } = this.props;
    //const displays = this.getRoundValues();

    return(
      <ModalView>
        <HeaderView>
          <TitleView>
            <TitleText>{`How long did\nyou do ${title}?`}</TitleText>
          </TitleView>
        </HeaderView>
        <ContentView>
          <MinusPlusView onPress={() => this.toMinus()}>
            <MinusPlusText>-</MinusPlusText>
          </MinusPlusView>
          <OvalWrap>
            <CountView>
              <CountText>{this.state.minutes}</CountText>
              <UnitText>{'min'}</UnitText>
            </CountView>
          </OvalWrap>
          <MinusPlusView onPress={() => this.toPlus()}>
            <MinusPlusText>+</MinusPlusText>
          </MinusPlusView>
        </ContentView>
        <FooterWrap>
          <SelectView>
            {recommendedMins.map(el => (
              <ItemView
                key={el.id}
              >
                <AmountView
                  onPress={() => this.toAmount(el.value)}
                  selectIdx={this.state.selectIdx}
                  selfIdx={el.id}>
                  <AmountText
                    selectIdx={this.state.selectIdx}
                    selfIdx={el.id}>
                  { el.value }
                  </AmountText>
                </AmountView>
                <OzText>{'min'}</OzText>
              </ItemView>
            ))}
          </SelectView>
          <FooterView>
            <TrackButton onPress={() => this.toTrack(title)}>
              <ButtonTrack>
                {
                  this.state.isLoading
                    ? <ActivityIndicator size='small' color='#2a9af1' />
                    : <ButtonText>{'Track Exercise'}</ButtonText>
                }
              </ButtonTrack>
            </TrackButton>
          </FooterView>
        </FooterWrap>
      </ModalView>
    );
  }
}
