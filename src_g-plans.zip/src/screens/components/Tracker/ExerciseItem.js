import React, { Component } from 'react'
import {
  Text,
  View,
  TouchableOpacity,
  Image
} from 'react-native'
import glamorous from 'glamorous-native'
import Proptypes from 'prop-types';
import { inject, observer } from 'mobx-react/native';

import Constants   from '../../../global/Constants'

const ListItem = glamorous(TouchableOpacity)({
  borderTopWidth: 1,
  borderColor: '#ededed',
  paddingHorizontal: Constants.mainPadding,
  paddingVertical: 20,
  flexDirection: 'row',
  alignItems: 'center',
  width: '100%'
})

const ListTumb = glamorous(View)({
  height: 40,
  width: 70,
  borderRightWidth: 1,
  borderColor: '#ededed',
  alignItems: 'center',
  justifyContent: 'center'
})

const ListContent = glamorous(View)({
  flexDirection: 'column',
  paddingLeft: 20,
  flexShrink: 2
})

const ListTitle = glamorous(Text)({
  fontSize: 16,
  fontWeight: 'bold',
  color: Constants.Colors.greyishBrownThree,
  marginBottom: 5
})

const { object, string, number, func} = Proptypes;
@inject( 'User' ) @observer
class ExerciseItem extends Component {
  static propTypes = {
    navigator: object,
    source: number,
    title: string,
    onPress: func
  }

  constructor(props) {
    super(props)
  }

  onExerciseTracked() {
    this.props.navigator.showLightBox({
      ...Constants.Screens.EXERCISETRACKER_SCREEN,
      style: {
        backgroundColor: "#000000a0",
        tapBackgroundToDismiss: true
      },
    });
  }

  render() {
    const { source, title, onPress } = this.props
    return(
      <ListItem onPress={onPress} activeOpacity={0.8}>
        <ListTumb><Image source={source}/></ListTumb>
        <ListContent>
          <ListTitle>{title}</ListTitle>
        </ListContent>
      </ListItem>
    )
  }
}

export default ExerciseItem
