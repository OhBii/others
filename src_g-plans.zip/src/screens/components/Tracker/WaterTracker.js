/*
*   author: denis
*   date:   08/03/2018
*/

import React, { Component } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  Platform,
  ActivityIndicator
} from 'react-native';
import { inject, observer } from 'mobx-react/native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import CircleGradient from '../Chart/CircleGradient'
import ActionSheetAndroid from 'react-native-actionsheet'

import Constants from '../../../global/Constants';

const { width } = Constants.windowDimensions

const ModalView = glamorous(View)({
  width: width * 0.9,
  borderRadius: 6,
  backgroundColor: "white",
  paddingVertical: 15,
  paddingHorizontal: 15
});

const TitleView = glamorous(View)({
  flexDirection: "column"
});

const TitleText = glamorous(Text)({
  fontSize: 24,
  fontWeight: "bold",
  lineHeight: 37,
  color: Constants.Colors.greyishBrownThree

});

const SimpleText = glamorous(Text)({
  fontSize: 14,
  fontWeight: 'bold',
  letterSpacing: 0,
  color: Constants.Colors.greyishBrownThree

});

const HeaderView = glamorous(View)({
  flexDirection: "row",
  justifyContent: "space-between"
});

const SettingView = glamorous(View)({
  flexDirection: "row",
  alignItems: 'center'
});

const ImageView = glamorous(TouchableOpacity)({
  marginLeft: 10
});

const ContentView = glamorous(View)({
  flexDirection: "row",
  justifyContent: "space-between",
  alignItems: 'center',
  marginTop: 20,
  marginBottom: 30
});

const CountView = glamorous(View)({
  height: width * 0.32,
  width: width * 0.32,
  backgroundColor: "white",
  borderRadius: 6,
  borderStyle: "solid",
  borderColor: "#d6d6d6",
  borderWidth: 1,
  justifyContent: "center",
  alignItems: "center",
  marginHorizontal: 10
});

const OvalView = glamorous(View)({
  position: 'absolute',
  left: 0,
  top: 0
});

const OvalView2 = glamorous(View)({
  width: width * 0.48,
  height: width * 0.48,
  borderRadius: (width * 0.48) / 2,
  alignItems: 'center',
  justifyContent: 'center'
});

const CountText = glamorous(Text)({
  marginTop: -10,
  marginBottom: 5,
  fontSize: 50,
  fontWeight: '500',
  color: Constants.Colors.greyishBrownThree,
});

const MinusPlusView = glamorous(TouchableOpacity)({
  width: 40,
  height: 40,
  alignItems: 'center',
  justifyContent: 'center',
  flexDirection: 'row',
  backgroundColor: Constants.Colors.fillColor,
  borderRadius: 40
});

const MinusPlusText = glamorous(Text)({
  color: 'white',
  fontSize: 36,
  lineHeight: 36
});

const FooterWrap = glamorous(View)({
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center'
})

const SelectView = glamorous(View)({
  flexDirection: "row",
  justifyContent: 'space-between',
  width: width * 0.7
});

const ItemView = glamorous(View)({
  flexDirection: 'column',
  alignItems: 'center'
});

const AmountView = glamorous(TouchableOpacity)(({selectIdx, selfIdx}) => ({
  width: 53,
  height: 52,
  justifyContent: 'center',
  alignItems: 'center',
  borderStyle: 'solid',
  borderColor: selectIdx == selfIdx
    ? Constants.Colors.darkSkyBlue
    : Constants.Colors.warmGreyEight,
  borderWidth: 1,
  borderRadius: 7,
  shadowColor: selectIdx == selfIdx ? 'rgba(0, 0, 0, 0.11)' : 'transparent',
  shadowOffset: {
     width: 0,
     height: 2
  },
  shadowRadius: 14,
  elevation: selectIdx == selfIdx ? 2 : 0,
  shadowOpacity: selectIdx == selfIdx ? 1 : 0
}));

const OzText = glamorous(Text)({
  color: Constants.Colors.warmGreyEight,
  fontSize: 13,
  marginVertical: 7
});

const AmountText = glamorous(Text)(({selectIdx, selfIdx}) => ({
  color: selectIdx == selfIdx
    ? Constants.Colors.marineTwo
    : Constants.Colors.warmGreyEight,
  fontSize: 24,
  fontWeight: '600'
}));

const UnitText = glamorous(Text)({
  marginTop: -10,
  fontSize: 16,
  color: Constants.Colors.greyishBrownThree,
  fontWeight: 'bold'
});

const FooterView = glamorous(View)({
  flexDirection: "row",
  justifyContent: "space-between",
  marginTop: 7,
  width: width * 0.7
});

const ButtonTrack = glamorous(View)({
  width: '100%',
  height: 50,
  borderRadius: 31.8,
  shadowColor: "rgba(0, 0, 0, 0.06)",
  shadowOffset: {
    width: 0,
    height: 3
  },
  shadowRadius: 12,
  shadowOpacity: 1,
  borderStyle: "solid",
  borderWidth: 1,
  borderColor: Constants.Colors.softBlueThree,
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'center'
});

const TrackButton = glamorous(TouchableOpacity)({
  width: '100%',
  marginVertical: 12
});

const ButtonText = glamorous(Text)({
  fontSize: 16,
  fontWeight: '600',
  color: Constants.Colors.softBlueThree
})

const OvalWrap = glamorous(View)({
  width: width * 0.55,
  height: width * 0.55,
  alignItems: 'center',
  justifyContent: 'center'
})

const { object } = Proptypes;
@inject('WaterTrack') @observer
export default class WaterTracker extends Component {
  static propTypes = {
    navigator: object,
    WaterTrack: object
  }

  constructor(props) {
    super(props);
    // const waterCup = parseFloat(this.props.WaterTrack.WaterTrackForToday.glasses);
    // const selectIdx = [1, 2, 3, 4].reduce((accumulator, value) => {
    //   if (Math.abs(waterCup - accumulator) <= Math.abs(waterCup - value)) return accumulator;
    //   return value;
    // });
    this.state = {
      selectIdx: 1,
      waterCup: 0,
      dataCircleIn: [{ x: 1, y: 0 }, { x: 2, y: 2 }],
      dataCircleOut: [{ x: 1, y: 0 }, { x: 2, y: 2 }],
      isLoading: false
    };
  }

  toPlus() {
    // const waterMax = this.props.WaterTrack.waterMax;
    // const tempWater = (this.state.waterCup + 0.1) > waterMax
    //   ? waterMax
    //   : (this.state.waterCup + 0.1);
    const tempWater = this.state.waterCup + 0.1

    const selectIdx = [1, 2, 3, 4].reduce((accumulator, value) => {
      if (Math.abs(tempWater - accumulator) <= Math.abs(tempWater - value)) return accumulator;
      return value;
    });
    this.setState({
      selectIdx: selectIdx,
      waterCup: tempWater,
      dataCircleIn: tempWater > 2
        ? [{ x: 1, y: 2 }, { x: 2, y: 0 }]
        : [{ x: 1, y: tempWater }, { x: 2, y: (2 - tempWater) }],
      dataCircleOut: tempWater > 2
        ? [{ x: 1, y: (tempWater - 2) }, { x: 2, y: (4 - tempWater) }]
        : [{ x: 1, y: 0 }, { x: 2, y: 2 }]
    });
  }

  toMinus() {
    const tempWater = (this.state.waterCup - 0.1) < 0
      ? 0
      : (this.state.waterCup - 0.1);

    const selectIdx = [1, 2, 3, 4].reduce((accumulator, value) => {
      if (Math.abs(tempWater - accumulator) <= Math.abs(tempWater - value)) return accumulator;
      return value;
    });
    this.setState({
      selectIdx: selectIdx,
      waterCup: tempWater,
      dataCircleIn: tempWater > 2
        ? [{ x: 1, y: 2 }, { x: 2, y: 0 }]
        : [{ x: 1, y: tempWater }, { x: 2, y: (2 - tempWater) }],
      dataCircleOut: tempWater > 2
        ? [{ x: 1, y: (tempWater - 2) }, { x: 2, y: (4 - tempWater) }]
        : [{ x: 1, y: 0 }, { x: 2, y: 2 }]
    });
  }

  setUnits() {
    if (Platform.OS === 'ios') {
      const { ActionSheetIOS } = require('react-native')
      ActionSheetIOS.showActionSheetWithOptions({
        options: [ 'Ounces', 'Cups', 'Liters', 'Milliliters', 'Cancel' ],
        cancelButtonIndex: 4,
      },
      (buttonIndex) => {
          if (buttonIndex === 4) return;
          this.props.WaterTrack.setUnit(buttonIndex);
      });
    }
    else {
      this.ActionSheetAndroid.show()
    }
  }

  selectAmount(index) {
    if (index === this.state.selectIdx) {
      // const waterMax = this.props.WaterTrack.waterMax;
      // const tempWater = (this.state.waterCup + index) > waterMax
      //   ? waterMax
      //   : (this.state.waterCup + index);
      const tempWater = this.state.waterCup + index

      this.setState({
        selectIdx: index,
        waterCup: tempWater,
        dataCircleIn: tempWater > 2
          ? [{ x: 1, y: 2 }, { x: 2, y: 0 }]
          : [{ x: 1, y: tempWater }, { x: 2, y: (2 - tempWater) }],
        dataCircleOut: tempWater > 2
          ? [{ x: 1, y: (tempWater - 2) }, { x: 2, y: (4 - tempWater) }]
          : [{ x: 1, y: 0 }, { x: 2, y: 2 }]
      });
    }
    else {
      this.setState({
        selectIdx: index,
        waterCup: index,
        dataCircleIn: index > 2
          ? [{ x: 1, y: 2 }, { x: 2, y: 0 }]
          : [{ x: 1, y: index }, { x: 2, y: (2 - index) }],
        dataCircleOut: index > 2
          ? [{ x: 1, y: (index - 2) }, { x: 2, y: (4 - index) }]
          : [{ x: 1, y: 0 }, { x: 2, y: 2 }]
      });
    }
  }

  async toTrack() {
    if (this.state.waterCup === 0) return;
    this.setState({isLoading: true})
    try {
      await this.props.WaterTrack.waterTrackProc(this.state.waterCup);
      this.props.navigator.dismissLightBox();
    }
    catch (err) {
      this.setState({isLoading: false})
    }
  }

  getRoundValues() {
    const { WaterTrack } = this.props;
    const amount = WaterTrack.unit === 2
      ?  (Math.round(this.state.waterCup * WaterTrack.Ratio * 100) / 100)
      :  WaterTrack.unit === 3
            ?  Math.round(this.state.waterCup * WaterTrack.Ratio)
            :  (Math.round(this.state.waterCup * WaterTrack.Ratio * 10) / 10);
    const boxs = WaterTrack.unit === 2
      ? {
          first: Math.round(WaterTrack.Ratio * 100) / 100,
          second: Math.round(WaterTrack.Ratio * 200) / 100,
          third: Math.round(WaterTrack.Ratio * 300) / 100,
          fourth: Math.round(WaterTrack.Ratio * 400) / 100
      }
      : {
          first: Math.round(WaterTrack.Ratio),
          second: Math.round(WaterTrack.Ratio * 2),
          third: Math.round(WaterTrack.Ratio * 3),
          fourth: Math.round(WaterTrack.Ratio * 4)
      }

    return {
      amount: amount,
      ...boxs
    }
  }

  render() {
    const { WaterTrack } = this.props;
    const displays = this.getRoundValues();

    return(
      <ModalView>
        <HeaderView>
          <TitleView>
            <TitleText>{'Water Tracker'}</TitleText>
          </TitleView>
          <SettingView>
            <SimpleText>{'Units'}</SimpleText>
            <ImageView onPress={() => this.setUnits()}>
              <Image source={Constants.Images.GEAR} />
            </ImageView>
          </SettingView>
        </HeaderView>
        <ContentView>
          <MinusPlusView onPress={() => this.toMinus()}>
            <MinusPlusText>-</MinusPlusText>
          </MinusPlusView>
          <OvalWrap>
            <OvalView>
                <CircleGradient
                  colors={['rgb(57,238,255)', 'rgb(0,80,171)']}
                  size={width * 0.55}
                  stroke={6}
                  corner={15}
                  bgCircle={'#f1f1f1'}
                  data={this.state.dataCircleOut}
                />
            </OvalView>
            <OvalView2>
              <OvalView>
                <CircleGradient
                  colors={['#45F1FF', 'rgb(77,160,255)']}
                  size={width * 0.48}
                  stroke={6}
                  corner={15}
                  bgCircle={'#f1f1f1'}
                  data={this.state.dataCircleIn}
                />
              </OvalView>
              <CountView>
                <CountText>{displays.amount}</CountText>
                <UnitText>{WaterTrack.Unit.full}</UnitText>
              </CountView>
            </OvalView2>
          </OvalWrap>
          <MinusPlusView onPress={() => this.toPlus()}>
            <MinusPlusText>+</MinusPlusText>
          </MinusPlusView>
        </ContentView>
        <FooterWrap>
          <SelectView>
            <ItemView>
              <AmountView
                onPress={() => this.selectAmount(1)}
                selectIdx={this.state.selectIdx}
                selfIdx={1}>
                <AmountText
                  selectIdx={this.state.selectIdx}
                  selfIdx={1}>
                { displays.first }
                </AmountText>
              </AmountView>
              <OzText>{WaterTrack.Unit.abbr}</OzText>
            </ItemView>
            <ItemView>
              <AmountView
                onPress={() => this.selectAmount(2)}
                selectIdx={this.state.selectIdx}
                selfIdx={2}>
                <AmountText
                  selectIdx={this.state.selectIdx}
                  selfIdx={2}>
                { displays.second }
                </AmountText>
              </AmountView>
              <OzText>{WaterTrack.Unit.abbr}</OzText>
            </ItemView>
            <ItemView>
              <AmountView
                onPress={() => this.selectAmount(3)}
                selectIdx={this.state.selectIdx}
                selfIdx={3}>
                <AmountText
                  selectIdx={this.state.selectIdx}
                  selfIdx={3}>
                { displays.third }
                </AmountText>
              </AmountView>
              <OzText>{WaterTrack.Unit.abbr}</OzText>
            </ItemView>
            <ItemView>
              <AmountView
                onPress={() => this.selectAmount(4)}
                selectIdx={this.state.selectIdx}
                selfIdx={4}>
                <AmountText
                  selectIdx={this.state.selectIdx}
                  selfIdx={4}>
                { displays.fourth }
                </AmountText>
              </AmountView>
              <OzText>{WaterTrack.Unit.abbr}</OzText>
            </ItemView>
          </SelectView>
          <FooterView>
            <TrackButton onPress={() => this.toTrack()}>
              <ButtonTrack>
                {
                  this.state.isLoading
                    ? <ActivityIndicator size='small' color='#2a9af1' />
                    : <ButtonText>{'Track Water'}</ButtonText>
                }
              </ButtonTrack>
            </TrackButton>
          </FooterView>
        </FooterWrap>
        <ActionSheetAndroid
          ref={ref => this.ActionSheetAndroid = ref}
          options={[ 'Ounces', 'Cups', 'Liters', 'Milliliters', 'Cancel' ]}
          cancelButtonIndex={4}
          onPress={buttonIndex => {
            if (buttonIndex === 4) return;
            this.props.WaterTrack.setUnit(buttonIndex);
          }}
        />
      </ModalView>
    );
  }
}
