
import React, { Component } from 'react';
import {
  View,
  Text,
  TouchableOpacity
} from 'react-native';

import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import LinearGradient from 'react-native-linear-gradient';
import LottieView from 'lottie-react-native';

import Constants from '../../../global/Constants';

const { width, height } = Constants.windowDimensions

const Container = glamorous(View)({
  width,
  height,
  flexDirection: 'column',
  paddingTop: width * 0.3,
  paddingHorizontal: Constants.mainPadding,
  paddingBottom: width * 0.15,
  alignItems: 'center',
  justifyContent: 'center'
})

const Gradient = glamorous(LinearGradient)({
  position: 'absolute',
  left: 0,
  top: 0,
  width,
  height
})

const Title = glamorous(Text)({
  fontSize: 30,
  fontWeight: 'bold',
  textAlign: 'center',
  color: Constants.Colors.white,
  marginBottom: 10
})

const Points = glamorous(Text)({
  fontSize: 20,
  fontWeight: '500',
  textAlign: 'center',
  color: Constants.Colors.blackTwo
})

const Footer = glamorous(View)({
  flexDirection: 'row',
  justifyContent: 'center',
  marginTop: 'auto',
  marginBottom: 0,
  width: '100%'
})

const Button = glamorous(View)({
  width: '100%',
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'center',
  height: 50,
  borderRadius: 25,
  backgroundColor: Constants.Colors.white,
  borderStyle: "solid",
  borderWidth: 1,
  borderColor: Constants.Colors.softBlueThree,
  marginHorizontal: 5
})

const ButtonText = glamorous(Text)({
  fontSize: 18,
  fontWeight: 'bold',
  textAlign: 'center',
  color: Constants.Colors.softBlueThree
})

const ButtonAction = ({ text, onPress } = this.props) =>
  <TouchableOpacity onPress={onPress}>
    <Button>
      <ButtonText>{ text }</ButtonText>
    </Button>
  </TouchableOpacity>

const LottieStyle = {
  width: 180
}

const Top = glamorous(View)({
  width: 180,
  height: 180,
  marginBottom: 30
})

const { object, string, number } = Proptypes;

export default class SuccessScreen extends Component {
  static propTypes = {
    navigator: object,
    title: string,
    points: number
  }

  static defaultProps = {
    title: "",
    points: 0
  }

  constructor(props) {
    super(props);
  }

  componentDidMount(){
    setTimeout(() => {
      this.animation.play()
    }, 400)
  }

  onRemoveExercise(){
    this.props.navigator.dismissLightBox();
  }

  render() {
    const { title, points } = this.props
    return(
      <Container>
        <Gradient
          colors={['rgb(57, 238, 255)', 'rgb(77, 160, 255)']}
          start={{x: 0, y: 0.5}} end={{x: 0.5, y: 1}}
        />
        <Top>
          <LottieView
            ref={animation => {
              this.animation = animation;
            }}
            source={Constants.Images.LOTTIE_SUCCESS}
            loop={false}
            enableMergePathsAndroidForKitKatAndAbove
            style={LottieStyle}
          />
        </Top>
        <Title>{ `${title} has been tracked` }</Title>
        <Points>{ `+${points} points` }</Points>

        <Footer>
          <ButtonAction
            text={'Continue'}
            onPress={() => this.props.navigator.dismissLightBox()}
          />
        </Footer>
      </Container>
    )
  }
}
