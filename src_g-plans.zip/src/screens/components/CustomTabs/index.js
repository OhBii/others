import React, { Component } from "react";
import {
  Text,
  View,
  Animated,
  Easing,
  Image,
  TouchableWithoutFeedback,
  TouchableOpacity
} from "react-native";
import glamorous from 'glamorous-native';
import Proptypes from 'prop-types';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import ViewOverflow from 'react-native-view-overflow';
// import { inject, observer } from 'mobx-react/native';
// import LinearGradient from 'react-native-linear-gradient';
// import LottieView from 'lottie-react-native';

import NavBar      from '../../../global/NavBar';
import Constants   from '../../../global/Constants'
const AnimatedViewOverflow = Animated.createAnimatedComponent(ViewOverflow);

const SIZE = 54;
const durationIn = 300;
const durationOut = 200;

const transformIcons = (x, y, z) => {
    return [
        {translateX: x},
        {translateY: y},
        {scaleX: z},
        {scaleY: z}
    ];
}

const glamorousAnimatedView = glamorous(Animated.View)
//const glamorousAnimatedImage = glamorous(Animated.Image)
const { width, height } = Constants.windowDimensions

const Wrap = glamorousAnimatedView({
  position: 'absolute',
  bottom: Constants.platform === 'ios' ? 0 : 20,
  right: 0,
  left: 0,
  width,
  elevation: 12
})
Wrap.propsAreStyleOverrides = true

const Container = glamorous(ViewOverflow)({
  position: 'absolute',
  bottom: 0,
  right: 0,
  left: 0,
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'space-between',
  paddingHorizontal: Constants.mainPadding,
  width,
  height: 75,
  backgroundColor: Constants.Colors.white
})

const Overlay = glamorous(AnimatedViewOverflow)({
  backgroundColor: 'rgba(0,0,0,0.7)',
  flex: 1,
  width: 30,
  height: 30,
  borderRadius: 15,
  position: 'absolute',
  left: width / 2 - 15,
  bottom: 30
})

const OverlayTouch = glamorous(ViewOverflow)({
  width: '100%',
  height: '100%',
  position: 'absolute',
  left: 0,
  top: 0,
})

const Button = ({ onPress, icon, iconActive, text, isActive } = this.props) =>
  <TouchableWithoutFeedback onPress={onPress}>
    <ButtonWrap onPress={onPress}>
      <ButtonIcon source={isActive ? iconActive : icon}/>
      <ButtonText>{text}</ButtonText>
    </ButtonWrap>
  </TouchableWithoutFeedback>

const ButtonWrap = glamorous(View)({
  flexDirection: 'column',
  alignItems: 'center'
})

const ButtonIcon = glamorous(Image)({})

const ButtonText = glamorous(Text)({
  fontSize: 12,
  letterSpacing: 0.47,
  textAlign: "center",
  color: Constants.Colors.greyishTwo,
  marginTop: 5
})

const ViewOverflow1 = glamorous(AnimatedViewOverflow)({
  position: 'absolute',
  width: 36,
  height: 36
})

const Empty = glamorous(ViewOverflow)({
  width: SIZE,
  height: SIZE,
})

const ViewOverflow2 = glamorous(ViewOverflow)({
  position: 'absolute',
  alignItems: 'center',
  justifyContent: 'center',
  width: SIZE,
  height: SIZE,
  left: width / 2 - SIZE / 2,
  bottom: 15
})

const ViewOverflow3 = glamorous(ViewOverflow)({
  position: 'absolute',
  alignItems: 'center',
  justifyContent: 'center',
  width: SIZE,
  height: SIZE,
  left: width / 2 - SIZE / 2,
  bottom: 15
})

const IconButton = glamorous(TouchableOpacity)({
  position: 'absolute',
  alignItems: 'center',
  justifyContent: 'center',
  width: 36,
  height: 36,
  borderRadius: 18,
  backgroundColor: Constants.Colors.white,
  zIndex: 4
})

const SubAddButton = ({icon, onPress, style} = this.props) =>
    <ViewOverflow1 style={{...style}}>
        <IconButton
            onPress={() => onPress && onPress()}
        >
            <Icon name={icon} size={20} color={Constants.Colors.greyishTwo}/>
        </IconButton>
    </ViewOverflow1>

const AddButton = glamorous(View)({
  alignItems: 'center',
  justifyContent: 'center',
  width: SIZE,
  height: SIZE,
  borderRadius: SIZE / 2,
  backgroundColor: Constants.Colors.white,
  shadowColor: "rgba(0, 0, 0, 0.2)",
  shadowOffset: {
    width: 0,
    height: 5
  },
  shadowRadius: 14,
  shadowOpacity: 1,
  elevation: 14
})

const { object, number, func } = Proptypes;
export default class CustomTabs extends Component {

  static navigatorStyle = NavBar.Default;

  static propTypes = {
    navigator: object,
    active: number,
    initAction: func
  }

  static defaultProps = {
    initAction: () => {}
  }

  constructor(props){
    super(props)
    this.state = {
      active: this.props.active,
      size: 75,
      buttonView: SIZE
    }

    this.overlay = new Animated.Value(0);
    this.mode = new Animated.Value(0);
    this.icon1 = new Animated.Value(0);
    this.icon2 = new Animated.Value(0);
    this.icon3 = new Animated.Value(0);
  }

  onSelectedTab(index) {
    this.setState({ active: this.props.active })
    this.props.navigator.switchToTab({
      tabIndex: index
    })
  }

  toggleView = () => {
    if (this.mode._value) {
        this.setState({ size: 75 });
        Animated.parallel([
          Animated.timing(this.overlay, {
            toValue: 0,
            duration: 500,
          }),
          Animated.parallel(
              [this.mode, this.icon1, this.icon2, this.icon3].map((item) => Animated.timing(item, {
                  toValue: 0,
                  duration: durationIn,
                  easing: Easing.cubic
              }))
          )
        ]).start(() => this.setState({ buttonView: SIZE }));
      } else {
        this.setState({ size: height, buttonView: 140 });
        Animated.parallel([
          Animated.timing(this.overlay, {
            toValue: 1,
            duration: 500,
          }),
          Animated.parallel([
              Animated.timing(this.mode, {
                  toValue: 1,
                  duration: durationOut,
                  easing: Easing.cubic
              }),
              Animated.sequence([
                  ...[this.icon1, this.icon2, this.icon3].map((item) => Animated.timing(item, {
                      toValue: 1,
                      duration: durationOut,
                      easing: Easing.elastic(1)
                  }))
              ])
          ])
        ]).start();
      }
  }

  toFoodDiary() {
    this.toggleView()

    if (this.props.active === 1) {
      this.props.initAction()
    } else {
      this.onSelectedTab(1)
    }
  }

  toWaterTrack() {
    this.toggleView()

    this.props.navigator.showLightBox({
      ...Constants.Screens.WATERTRACKER_SCREEN,
      style: {
        backgroundColor: "#000000a0",
        tapBackgroundToDismiss: true
      },
    });
  }

  toExerciseTrack() {
    this.toggleView()

    this.props.navigator.showModal({
      ...Constants.Screens.EXERCISELIST_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  render() {
     const scaleOverlay = this.overlay.interpolate({
       inputRange: [0, 1],
       outputRange: [0.01, 50]
     });
     const opacityOverlay = this.overlay.interpolate({
       inputRange: [0, 1],
       outputRange: [0, 1]
     });

     const firstX = this.icon1.interpolate({
         inputRange: [0, 1],
         outputRange: [0, -50]
     });
     const firstY = this.icon1.interpolate({
         inputRange: [0, 1],
         outputRange: [20, -20]
     });
     const firstZ = this.icon1.interpolate({
         inputRange: [0, 1],
         outputRange: [0.01, 1]
     });

     const secondX = this.icon2.interpolate({
         inputRange: [0, 1],
         outputRange: [0, 0]
     });
     const secondY = this.icon2.interpolate({
         inputRange: [0, 1],
         outputRange: [20, -40]
     });
     const secondZ = this.icon2.interpolate({
         inputRange: [0, 1],
         outputRange: [0.01, 1]
     });

     const thirdX = this.icon3.interpolate({
         inputRange: [0, 1],
         outputRange: [0, 50]
     });
     const thirdY = this.icon3.interpolate({
         inputRange: [0, 1],
         outputRange: [20, -20]
     });
     const thirdZ = this.icon3.interpolate({
         inputRange: [0, 1],
         outputRange: [0.01, 1]
     });

     const rotation = this.mode.interpolate({
         inputRange: [0, 1],
         outputRange: ['0deg', '45deg']
     });

    return (
      <Wrap
        height={this.state.size}
      >
        <Container>
          <Button
            icon={Constants.Images.TAB_HOME}
            iconActive={Constants.Images.TAB_HOME_selected}
            isActive={this.state.active === 0}
            text={'Home'}
            onPress={() => this.onSelectedTab(0)}
          />
          <Button
            icon={Constants.Images.TAB_PLANNER}
            iconActive={Constants.Images.TAB_PLANNER_selected}
            text={'Planner'}
            isActive={this.state.active === 1}
            onPress={() => this.onSelectedTab(1)}
          />
          <Empty />
          <Button
            icon={Constants.Images.TAB_PROGRESS}
            iconActive={Constants.Images.TAB_PROGRESS_selected}
            text={'Progress'}
            isActive={this.state.active === 2}
            onPress={() => this.onSelectedTab(2)}
          />
          <Button
            icon={Constants.Images.TAB_MORE}
            iconActive={Constants.Images.TAB_MORE_selected}
            text={'More'}
            isActive={this.state.active === 3}
            onPress={() => this.onSelectedTab(3)}
          />
        </Container>
        <Overlay
          style={{
            transform: [{ scale: scaleOverlay }],
            opacity: opacityOverlay
          }}
        >
          <TouchableWithoutFeedback onPress={this.toggleView}>
            <OverlayTouch />
          </TouchableWithoutFeedback>
        </Overlay>
        <ViewOverflow2
          style={{ width: this.state.buttonView, height: this.state.buttonView, left: width / 2 - this.state.buttonView / 2, }}
        >
            <SubAddButton
                style={{transform: transformIcons(firstX, firstY, firstZ)}}
                icon="food-apple"
                onPress={() => this.toFoodDiary()}
            />
            <SubAddButton
                style={{transform: transformIcons(secondX, secondY, secondZ)}}
                icon="food"
                onPress={() => this.toWaterTrack()}
            />
            <SubAddButton
                style={{transform: transformIcons(thirdX, thirdY, thirdZ)}}
                icon="food-variant"
                onPress={() => this.toExerciseTrack()}
            />
         </ViewOverflow2>
         <ViewOverflow3>
            <AnimatedViewOverflow style={{
                transform: [{rotate: rotation}]
            }}>
                <TouchableWithoutFeedback
                  onPress={this.toggleView}
                >
                  <AddButton>
                      <Icon name="plus" size={26} color={Constants.Colors.greyishTwo} />
                  </AddButton>
                </TouchableWithoutFeedback>
            </AnimatedViewOverflow>
        </ViewOverflow3>
      </Wrap>
    )
  }
}
