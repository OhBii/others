import React from 'react';
import {
  View,
  Text,
  TouchableOpacity
} from 'react-native'
import glamorous from 'glamorous-native'
import MCIcon from 'react-native-vector-icons/MaterialCommunityIcons'

import Constants from '../../../global/Constants'

const ItemView = glamorous(View)({
  borderStyle: "solid",
  borderBottomColor: Constants.Colors.borderColor,
  borderBottomWidth: 1,
  backgroundColor: Constants.Colors.white
})

const ItemButton = glamorous(TouchableOpacity)({
  flexDirection: "row",
  justifyContent: "space-between",
  alignItems: 'center',
  marginHorizontal: 15,
  paddingVertical: 10
})

const ListContent = glamorous(View)({
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'space-between',
  backgroundColor: Constants.Colors.white,
  paddingHorizontal: 19,
})

const ListContentIcon = glamorous(View)({
  flexDirection: 'row',
  justifyContent: 'center',
  alignItems: 'center',
  width: 30,
  height: 30,
})

const ListContentLeft = glamorous(View)({
  marginLeft: 10,
})

const ItemIcon = glamorous(MCIcon)({
  backgroundColor: 'transparent',
})

const ListTitle = glamorous(Text)({
  fontSize: 16,
  color: Constants.Colors.warmGreyNine,
})

const CountView = glamorous(View) ({
  paddingVertical: 3,
  paddingHorizontal: 18,
  borderRadius: 18,
  borderWidth: 1,
  borderStyle: 'solid',
  borderColor: Constants.Colors.dodgerBlueFour
})

const CountText = glamorous(Text) ({
  fontSize: 14,
  color: Constants.Colors.dodgerBlueFour
})

const ListItem = ({
  onPress,
  iconName,
  iconSize,
  iconColor,
  title,
  count
} = this.props) => (
  <ItemView>
    <ItemButton onPress={onPress}>
      <ListContent>
        <ListContentIcon>
          <ItemIcon name={iconName} size={iconSize} color={iconColor} />
        </ListContentIcon>
        <ListContentLeft>
          <ListTitle>{title}</ListTitle>
        </ListContentLeft>
      </ListContent>
      {
        count && count !== 0
          ? <CountView>
              <CountText>{ count }</CountText>
            </CountView>
          : <View />
      }
    </ItemButton>
  </ItemView>
)

export default ListItem
