import React, { Component } from 'react'
import {
  View,
  Text,
  TouchableOpacity
} from 'react-native';
import Proptypes from 'prop-types'

import glamorous from 'glamorous-native'
import moment from 'moment'

import Constants   from '../../../global/Constants'

import { inject, observer } from 'mobx-react/native';

const { width } = Constants.windowDimensions
const multilingual = Constants.Multilingual;

const Container = glamorous(View)({
  flexDirection: 'column',
  width: '100%',
  marginTop: -40,
})

const RowTop = glamorous(View)({
  flexDirection: 'row',
  width: '100%',
  justifyContent: 'space-around',
  marginBottom: 10,
  paddingHorizontal: 10
})

const SelectWeek = glamorous(TouchableOpacity)(({ isActive }) => ({
  width: width / 3.8,
  height: 28,
  borderRadius: 14,
  backgroundColor: isActive ? Constants.Colors.white : 'rgba(255,255,255,0.47)',
  justifyContent: 'center',
  alignItems: 'center'
}))

const SelectWeekText = glamorous(Text)({
  fontSize: 12,
  color: Constants.Colors.marineTwo
})

const RowBottom = glamorous(View)({
  flexDirection: 'row',
  width: '100%',
  justifyContent: 'space-between',
  paddingVertical: 15,
  backgroundColor: Constants.Colors.marineTwo
})

const CellDate = glamorous(View)({
  flexDirection: 'column',
  width: width / 7,
  alignItems: 'center'
})

const WeekDay = glamorous(View)({})

const SelectDate = glamorous(TouchableOpacity)(({ isActive }) => ({
  marginTop: 10,
  width: 31,
  height: 31,
  backgroundColor: isActive ? Constants.Colors.white : 'transparent',
  shadowColor: isActive ? 'rgba(0, 0, 0, 0.22)' : 'transparent',
  shadowOffset: {
    width: 0,
    height: 2
  },
  shadowRadius: 4,
  shadowOpacity: 1,
  justifyContent: 'center',
  alignItems: 'center',
  borderRadius: 15
}))

const WeekDayText = glamorous(Text)({
  fontSize: 16,
  fontWeight: '600',
  textAlign: 'center',
  color: Constants.Colors.white
})

const SelectDateText = glamorous(Text)(({ isActive }) => ({
  textAlign: 'center',
  color: isActive ? Constants.Colors.marineTwo : Constants.Colors.white
}))

const ButtonSelectDate = ({day, isActive, onSelect}=this.props) =>
  <SelectDate onPress={onSelect} isActive={isActive}>
    <SelectDateText isActive={isActive}>{moment(day, 'ddd MMM DD').format('D')}</SelectDateText>
  </SelectDate>

const { func, object } = Proptypes
@inject('User', 'DayIndex', 'MealPlan') @observer
class WeekHeader extends Component {

  static propTypes = {
    onSelect: func,
    User: object,
    MealPlan: object,
    DayIndex: object
  }

  constructor(props) {
    super(props);

    this.state = {
    }
  }

  componentDidMount() {
    const { MealPlan: { currentWeekNumber } } = this.props
    this.onSetWeek(currentWeekNumber)
  }

  onSetWeek(week) {
    const {
      User: { userInfo: { last_checkin } },
      MealPlan: { currentWeekNumber, prevAndNextWeekNumber },
      DayIndex: { getPlannerDayIndex, setWeekDays, setWeekNnmber }
    }= this.props
    const { prevWeekNumber, nextWeekNumber } = prevAndNextWeekNumber;
    let startOfWeek
    let endOfWeek
    setWeekNnmber(week);
    if(week === currentWeekNumber) {
      startOfWeek = moment(last_checkin.created_at)
      endOfWeek = moment(startOfWeek).add(6, 'd')
    } else if(week === prevWeekNumber) {
      startOfWeek = moment(last_checkin.created_at).subtract(1, 'weeks')
      endOfWeek = moment(startOfWeek).add(6, 'd')
    } else if(week === nextWeekNumber) {
      startOfWeek = moment(last_checkin.created_at).add(1, 'weeks')
      endOfWeek = moment(startOfWeek).add(6, 'd')
    }
    const weekdays = setWeekDays( startOfWeek, endOfWeek )
    this.onSelect(weekdays[getPlannerDayIndex(week)])
  }

  onSelect(day) {
    this.props.onSelect(day)
  }

  render() {
    const {
      User,
      DayIndex: { weekNumber, getPlannerDayIndex, setPlannerDayIndex, weekDays },
      MealPlan: { currentWeekNumber, prevAndNextWeekNumber },
    } = this.props;
    const { prevWeekNumber, nextWeekNumber } = prevAndNextWeekNumber;
    const currentLanguage = User.language;
     return (
      <Container>
        <RowTop>
          <SelectWeek isActive={weekNumber === prevWeekNumber } onPress={() => this.onSetWeek(prevWeekNumber)}>
            <SelectWeekText>{multilingual.LAST_WEEK[currentLanguage]}</SelectWeekText>
          </SelectWeek>
          <SelectWeek isActive={weekNumber === currentWeekNumber } onPress={() => this.onSetWeek(currentWeekNumber)}>
            <SelectWeekText>{Constants.Multilingual.THIS_WEEK[currentLanguage]}</SelectWeekText>
          </SelectWeek>
          <SelectWeek isActive={weekNumber === nextWeekNumber } onPress={() => this.onSetWeek(nextWeekNumber)}>
            <SelectWeekText >{Constants.Multilingual.NEXT_WEEK[currentLanguage]}</SelectWeekText>
          </SelectWeek>
        </RowTop>
        <RowBottom>
            {
              weekDays.map((day, i) => {
                return (
                  <CellDate key={i}>
                    <WeekDay>
                      <WeekDayText>{moment(day, 'ddd').format('ddd').slice(0, 1)}</WeekDayText>
                    </WeekDay>

                    <ButtonSelectDate
                      day={day}
                      isActive={ i === getPlannerDayIndex(weekNumber) }
                      onSelect={() => {
                        setPlannerDayIndex( weekNumber, i);
                        this.onSelect(day)
                      }}
                    />
                  </CellDate>)
              })
            }
        </RowBottom>
      </Container>

    )
  }
}

export default WeekHeader
