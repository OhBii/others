/*
*   author: denis
*   date:   7/13/2018
*/
import React, { Component } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Platform,
  Image
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import { inject, observer } from 'mobx-react/native';

import HeaderNotify from './HeaderNotify';
import Constants   from '../../../global/Constants';
//const { width } = Constants.windowDimensions

const ContainerView = glamorous(View)(({height}) => ({
  width: "100%", //device width
  height: height,
  backgroundColor: Constants.Colors.white,
  flexDirection: 'column',
  justifyContent: 'center',
  paddingTop: 20
}));

const TitleWrap = glamorous(View)({
  justifyContent: 'center',
  alignItems: 'center',
  flexDirection: 'row',
  width: '100%',
  height: 30
})

const TitleText = glamorous(Text)(({ mTop }) => ({
  fontSize: Platform.OS === 'ios' ? Constants.moderateScale(20, 0.8) : 20,
  color: Constants.Colors.greyishBrownThree,
  lineHeight: 20,
  marginTop: mTop || 0,
  fontWeight: 'bold',
  textAlign: 'center'
}));

const RowView = glamorous(View)({
  width: '100%',
  paddingHorizontal: Constants.mainPadding
});

const ActionView = glamorous(TouchableOpacity)({
  position: 'absolute',
  top: -12,
  right: 0
});

const Action = glamorous(TouchableOpacity)({
  position: 'absolute',
  top: 0,
  left: 0
})

const { bool, string, number, object } = Proptypes;
@inject( 'User' ) @observer
export default class ShowHeader extends Component {

  static propTypes = {
      navigator: object,
      User: object,
      hasBack: bool,
      title: string,
      isNotif: bool,
      height: number,
      isModal: bool,
      hasNotify: bool,
  }

  static defaultProps = {
      hasBack: true,
      title: "",
      isNotif: false,
      height: 104,
      isModal: false,
      weakHeader: false,
      hasNotify: false
  }

  constructor(props) {
    super(props);
  }

  toBack() {
    if (this.props.isModal)
      this.props.navigator.dismissModal();
    else
      this.props.navigator.pop();
  }

  render() {
    //const  { User } = this.props

    return(
      <ContainerView
        height={this.props.height}>
          <RowView>
            <TitleWrap>
              {
                !!this.props.hasBack
                  && <Action onPress={() => this.toBack()}>
                      <Image source={Constants.Images.HEADER_BACK} />
                    </Action>
              }
              <TitleText>{this.props.title}</TitleText>
              <ActionView>
                {
                  this.props.hasNotify
                  ? <HeaderNotify navigator={this.props.navigator}/>
                  : <View />
                }
              </ActionView>
            </TitleWrap>
          </RowView>
      </ContainerView>
    );
  }
}
