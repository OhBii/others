/*
*   author: denis
*   date:   7/13/2018
*/
import React, { Component } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  Platform
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import IconMCI from 'react-native-vector-icons/MaterialCommunityIcons';
import LinearGradient from 'react-native-linear-gradient';
import { inject, observer } from 'mobx-react/native';

import HeaderNotify from './HeaderNotify'
import WeekHeader from './WeekHeader';
import Constants   from '../../../global/Constants';

//props
//  hasBack: true or false
//  hasSearch: true or false
//  isShare: true or false
//  title
//  info
//  isNotif: true or false
//  hasShadow: true or false
//  height:
//  isModal: true or false

const multilingual = Constants.Multilingual;

const ContainerView = glamorous(LinearGradient)(({height}) => ({
  width: "100%", //device width
  height: height,
  overflow: 'hidden',
  shadowColor: 'rgba(0, 0, 0, 0.25)',
  shadowOffset: {
    width: 0,
    height: 2
  },
  shadowRadius: 10,
  shadowOpacity: 1,
  elevation: 10
}));

const Inner = glamorous(View)({
  width: '100%',
  paddingHorizontal: 15,
  paddingTop: 35,
  paddingBottom: 15
})

const TitleText = glamorous(Text)(({ mTop }) => ({
  fontSize: Platform.OS === 'ios' ? Constants.moderateScale(34, 0.8) : 36,
  color: Constants.Colors.white,
  marginTop: mTop || 0,
  fontWeight: "bold",
  fontStyle: "normal",
  letterSpacing: 0,
  textShadowColor: "rgba(0, 0, 0, 0.05)",
  textShadowOffset: {
    width: 0,
    height: 2
  },
  textShadowRadius: 4
}));

const RowView = glamorous(View)({
  flexDirection: "row",
  justifyContent: "space-between"
});

const ActionView = glamorous(View)({
  top: 5
});

const ShareText = glamorous(Text)({
  fontSize: 16,
  color: "white",
  top: 10,
  marginBottom: 30
});

const InfoText = glamorous(Text)({
  fontSize: 16,
  color: "white",
  marginTop: 30
});

const SearchButton = glamorous(TouchableOpacity)({
  marginRight: 7,
  top: 15
});

const LogoFill = glamorous(Image)({
  position: 'absolute',
  left: 0,
  top: 0
});

const { bool, string, number, object , func} = Proptypes;
@inject( 'User' ) @observer
export default class Header extends Component {

  static propTypes = {
      navigator: object,
      User: object,
      hasBack: bool,
      isShare: bool,
      onShare: func,
      hasSearch: bool,
      title: string,
      info: string,
      isNotif: bool,
      hasShadow: bool,
      height: number,
      isModal: bool,
      weakHeader: bool,
      onSelect: func,
      hasAvatar: bool,
      isTipIcon: bool
  }

  static defaultProps = {
      hasBack: true,
      isShare: false,
      hasSearch: false,
      title: "",
      info: "",
      isNotif: false,
      hasShadow: true,
      height: 146,
      isModal: false,
      weakHeader: false,
      hasAvatar: true,
      isTipIcon: false
  }

  constructor(props) {
    super(props);
    this.state = {
      mealDate: new Date()
    }
  }

  toBack() {
    if (this.props.isModal)
      this.props.navigator.dismissModal();
    else
      this.props.navigator.pop();
  }

  toSearch() {
    this.props.navigator.showModal({
      ...Constants.Screens.SEARCH_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }
  onSelect(day) {
    this.props.onSelect(day)
  }
  render() {
    const  { User, onShare } = this.props
    const currentLanguage = User.language;
    const flex = !User.isPremium

    const gradient = flex ? ['#b4ec51', '#429321'] : ['#4da0ff', '#4da1ff', '#39eeff'];
    const x1 = flex ? 0 : 1;
    const x2 = flex ? 1 : 0;
    const y1 = flex ? 0 : 0.6;
    const y2 = flex ? 0.6 : 1;
    return(
      <ContainerView
        colors={gradient}
        start={{x: x1, y: y1}}
        end={{x: x2, y: y2}}
        height={this.props.height}>
        <LogoFill source={Constants.Images.HEADER_PAGE_LOGO} />
        <Inner>
          <RowView>
            <View>
              {
                this.props.hasBack
                  ? <TouchableOpacity onPress={() => this.toBack()}>
                      <Icon name="angle-left" size={60} color="white" />
                    </TouchableOpacity>
                  : <TitleText mTop={7}>{this.props.title}</TitleText>
              }
            </View>
            <ActionView>
              {
                this.props.isShare
                  ? <RowView>
                      <ShareText>{ multilingual.SHARE[currentLanguage] }</ShareText>
                      <TouchableOpacity
                        onPress={() => onShare()}
                      >
                        <Image source={Constants.Images.HEADER_SHARE} />
                      </TouchableOpacity>
                    </RowView>
                  : <RowView>
                    {
                      this.props.hasSearch
                        ? <SearchButton onPress={() => this.toSearch()}>
                            <Image source={Constants.Images.HEADER_SEARCH} />
                          </SearchButton>
                        :  <View></View>
                    }
                    {
                      this.props.hasAvatar
                      ? <HeaderNotify navigator={this.props.navigator} isNotif={this.props.isNotif} />
                      : <View />
                    }
                    {
                      this.props.isTipIcon
                      ? <IconMCI name="lightbulb-on" size={36} color="white"/>
                      : <View />
                    }
                  </RowView>
              }
            </ActionView>
          </RowView>
          <View>
              {
                this.props.hasBack
                  ? <TitleText>
                      {this.props.title}
                    </TitleText>
                  : <InfoText>
                      {this.props.info}
                    </InfoText>
              }
          </View>
        </Inner>
      {!!this.props.weakHeader && <WeekHeader onSelect={(date) => this.onSelect(date)}/>}
      </ContainerView>
    );
  }
}
