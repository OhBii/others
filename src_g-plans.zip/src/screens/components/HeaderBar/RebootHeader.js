import React, { Component }  from 'react';
import Proptypes from 'prop-types';
import {
  Text,
  View,
  Image,
  Platform
} from 'react-native';
import glamorous from 'glamorous-native';
import { inject, observer } from 'mobx-react/native';

import Constants   from '../../../global/Constants';

const multilingual = Constants.Multilingual;
const { width, height } = Constants.windowDimensions
const mainPadding = width * 0.045

const MainHeaderWrap = glamorous(View)({
  flex: 1
})

const MainHeaderInner = glamorous(View)({
  position: 'absolute',
  left: 0,
  right: 0,
  top: 40,
  width,
  flexDirection: 'column',
  paddingHorizontal: mainPadding
})

const MainHeaderBg = glamorous(Image)({
  width,
  height: height * 0.46,
  resizeMode: 'cover'
})

const MainHeaderTop = glamorous(View)({
  flexDirection: 'row',
  justifyContent: 'space-between',
  alignItems: 'center'
})
const MainHeaderBottom = glamorous(View)({})

const MainHeaderTopLeft = glamorous(View)({
  width: width - (80 + mainPadding * 2)
})

const MainHeaderName = glamorous(Text)({
  fontSize: Platform.OS === 'ios' ? Constants.moderateScale(34, 1.8) : 36,
  fontWeight: 'bold',
  fontStyle: 'normal',
  letterSpacing: 0,
  color: Constants.Colors.white,
  textShadowColor: 'rgba(0, 0, 0, 0.05)',
  textShadowOffset: {
    width: 0,
    height: 2
  },
  textShadowRadius: 4
})

const MainHeaderLogo = glamorous(Image)({
  marginTop: 10
})

const { object } = Proptypes;
@inject('App', 'User') @observer
class MainHeader extends Component {
  static propTypes = {
    navigator: object,
    User: object
  }

  constructor(props) {
    super(props);
  }

  toSearch() {
    this.props.navigator.showModal({
      ...Constants.Screens.SEARCH_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  render() {
    const { User } = this.props
    const firstName = User.userInfo.first_name ? User.userInfo.first_name : ''
    const currentLanguage = User.language;
    return(
      <MainHeaderWrap>
        <MainHeaderBg
          source={Constants.Images.REBOOT_MAIN_BG}
        />
        <MainHeaderInner>
          <MainHeaderTop>
            <MainHeaderTopLeft>
              <MainHeaderName>{`${multilingual.HI[currentLanguage]}, ${firstName}` }</MainHeaderName>
            </MainHeaderTopLeft>
          </MainHeaderTop>
          <MainHeaderBottom>
            <MainHeaderLogo source={Constants.Images.REBOOT_LOGO}/>
          </MainHeaderBottom>
        </MainHeaderInner>
      </MainHeaderWrap>
    )
  }
}

export default MainHeader
