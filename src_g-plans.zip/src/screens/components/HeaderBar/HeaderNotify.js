import React, { Component } from 'react';
import Proptypes from 'prop-types';
import {
  Text,
  View,
  TouchableOpacity
} from 'react-native';
import glamorous from 'glamorous-native';
import { inject, observer } from 'mobx-react/native';
import LottieView from 'lottie-react-native';

import Constants from '../../../global/Constants';

const Bell = glamorous(TouchableOpacity)({
  width: 50,
  height: 50,
  alignItems: 'center',
  justifyContent: 'center'
})

const Badge = glamorous(View)({
  position: 'absolute',
  right: 0,
  top: 0,
  backgroundColor: Constants.Colors.red,
  borderRadius: 11,
  shadowColor: "rgba(0, 0, 0, 0.32)",
  shadowOffset: {
    width: 0,
    height: 2
  },
  shadowRadius: 4,
  shadowOpacity: 1,
  elevation: 2,
  width: 22,
  height: 22,
  justifyContent: 'center',
  alignItems: 'center',
})

const BadgeText = glamorous(Text)({
  fontSize: 11,
  fontWeight: 'bold',
  color: Constants.Colors.white,
  lineHeight: 12,
})

const { object, bool } = Proptypes;
@inject('Tips') @observer
class HeaderNotify extends Component {

  static propTypes = {
    navigator: object,
    Tips: object,
    isWhite: bool
  }

  static defaultProps = {
    isWhite: false
  }

  constructor(props) {
    super(props);
  }

  toNotification() {
    this.props.navigator.showModal({
      ...Constants.Screens.NOTIFICATION_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  componentDidUpdate(prevProps){
    if(this.props.Tips.unreadTipsLen > 0 && prevProps.Tips.unreadTipsLen !== this.props.Tips.unreadTipsLen) {
      this.animation.play()
    }
  }

  render () {
    const { Tips: { unreadTipsLen }, isWhite } = this.props
    return(
      <Bell onPress={() => this.toNotification()}>
        <LottieView
          ref={animation => {
            this.animation = animation;
          }}
          source={isWhite ? Constants.Images.LOTTIE_BELL_WHITE : Constants.Images.LOTTIE_BELL_BLACK}
          loop={false}
          enableMergePathsAndroidForKitKatAndAbove
          style={{}}
        />
        {!!unreadTipsLen > 0 &&
          <Badge>
            <BadgeText>{unreadTipsLen <= 9 ? unreadTipsLen : '9+'}</BadgeText>
          </Badge>
        }
      </Bell>
    )
  }
}

export default HeaderNotify
