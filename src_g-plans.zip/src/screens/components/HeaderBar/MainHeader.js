import React, { Component }  from 'react';
import Proptypes from 'prop-types';
import {
  Text,
  View,
  Image,
  Platform,
  TouchableOpacity
} from 'react-native';
import glamorous from 'glamorous-native';
import LinearGradient from 'react-native-linear-gradient';
import { inject, observer } from 'mobx-react/native';

import HeaderNotify from './HeaderNotify'
import Constants   from '../../../global/Constants';

const multilingual = Constants.Multilingual;
const { width } = Constants.windowDimensions

const MainHeaderWrap = glamorous(LinearGradient)({
  flex: 1,
  height: 103,
  overflow: 'hidden',
  flexDirection: 'column',
  alignItems: 'center'
})

const MainHeaderInner = glamorous(View)({
  position: 'absolute',
  left: 0,
  right: 0,
  top: 40,
  width,
  flexDirection: 'column',
  paddingHorizontal: Constants.mainPadding
})

const MainHeaderBg = glamorous(Image)({
  width: 206,
  height: 103
})

const MainHeaderTop = glamorous(View)({
  flexDirection: 'row',
  justifyContent: 'space-between',
  alignItems: 'center'
})

const MainHeaderTopLeft = glamorous(View)({
  flexDirection: 'row',
  alignItems: 'center'
})

const MainHeaderTopRight = glamorous(View)({
  width: 70,
  flexDirection: 'row',
  justifyContent: 'flex-end'
})

const MainHeaderName = glamorous(Text)({
  fontSize: Platform.OS === 'ios' ? Constants.moderateScale(34, 1.8) : 36,
  fontWeight: 'bold',
  color: Constants.Colors.white,
  textShadowColor: 'rgba(0, 0, 0, 0.13)',
  textShadowOffset: {
    width: 0,
    height: 2
  },
  textShadowRadius: 4,
  marginLeft: 12
})

const { object, bool } = Proptypes;
@inject('App', 'User') @observer
class MainHeader extends Component {
  static propTypes = {
    App: object,
    navigator: object,
    User: object,
    hideSearch: bool,
    MealPlan: object
  }

  constructor(props) {
    super(props);
  }

  toSearch() {
    this.props.navigator.showModal({
      ...Constants.Screens.SEARCH_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  onDrawer = () => {
    this.props.navigator.toggleDrawer({
      side: 'left',
      animated: true
    })
  }

  render() {
    const { navigator, User } = this.props
    const firstName = User.userInfo.first_name ? User.userInfo.first_name : ''
    const currentLanguage = User.language;
    const flex = !User.isPremium

    const gradient = flex ? ['#b4ec51', '#429321'] : ['#4da0ff', '#4da1ff', '#39eeff'];
    const x1 = flex ? 0 : 1;
    const x2 = flex ? 1 : 0;
    const y1 = flex ? 0 : 0.6;
    const y2 = flex ? 0.6 : 1;
    return(
      <MainHeaderWrap
        colors={gradient}
        start={{x: x1, y: y1}}
        end={{x: x2, y: y2}}
      >
        <MainHeaderBg
          source={ Constants.Images.HEADER_PAGE_LOGO }
        />
        <MainHeaderInner>
          <MainHeaderTop>
            <MainHeaderTopLeft>
              <TouchableOpacity onPress={() => this.onDrawer()}>
                <Image source={Constants.Images.HAMBURGER}/>
              </TouchableOpacity>
              <MainHeaderName>{`${multilingual.HI[currentLanguage]}, ${firstName}` }</MainHeaderName>
            </MainHeaderTopLeft>
            <MainHeaderTopRight>
              <HeaderNotify isWhite={true} navigator={navigator} />
            </MainHeaderTopRight>
          </MainHeaderTop>
        </MainHeaderInner>
      </MainHeaderWrap>
    )
  }
}

export default MainHeader
