import React, { Component } from 'react';
import Proptypes from 'prop-types';
import {
  Text,
  View,
  TouchableOpacity
} from 'react-native';
import glamorous from 'glamorous-native';
import { inject, observer } from 'mobx-react/native';
import { CachedImage, ImageCacheProvider } from 'react-native-cached-image'

import Constants   from '../../../global/Constants';

const AvatarWrap = glamorous(View)({
  width: 50,
  height: 50,
  alignItems: 'center',
  justifyContent: 'center'
})

const AvatarWrapInner = glamorous(TouchableOpacity)({
  width: 30,
  height: 30,
  borderRadius: 15,
  shadowColor: "rgba(0, 0, 0, 0.32)",
  shadowOffset: {
    width: 0,
    height: 2
  },
  shadowRadius: 4,
  shadowOpacity: 1,
  elevation: 2
})

const AvatarImage = glamorous(CachedImage)({
  width: 30,
  height: 30,
  borderRadius: 15
})

const Badge = glamorous(TouchableOpacity)({
  position: 'absolute',
  right: 0,
  top: 0,
  backgroundColor: Constants.Colors.red,
  borderRadius: 11,
  shadowColor: "rgba(0, 0, 0, 0.32)",
  shadowOffset: {
    width: 0,
    height: 2
  },
  shadowRadius: 4,
  shadowOpacity: 1,
  elevation: 2,
  width: 22,
  height: 22,
  justifyContent: 'center',
  alignItems: 'center',
})

const BadgeText = glamorous(Text)({
  fontSize: 11,
  fontWeight: 'bold',
  color: Constants.Colors.white,
  lineHeight: 12,
})

const { object, bool } = Proptypes;
@inject('App', 'Tips', 'Profile') @observer
class Avatar extends Component {

  static propTypes = {
    App: object,
    navigator: object,
    isNotif: bool,
    Tips: object,
    Profile: object
  }

  static defaultProps = {
    isNotif: false
  }

  constructor(props) {
    super(props);
  }

  toProfile() {
    this.props.navigator.showModal({
      ...Constants.Screens.PROFILE_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  toNotification() {
    if (this.props.isNotif) return;
    this.props.navigator.push({
      ...Constants.Screens.NOTIFICATION_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    });
  }

  render () {
    const { Tips: { unreadTipsLen }, Profile } = this.props
    const image = Profile.getLastImage
      ? Profile.getLastImage
      : 'https://static0.misionesonline.net/wp-content/uploads/2017/07/angelina-10j7i2e4qnf8.jpg'
    return(
      <AvatarWrap>
        <AvatarWrapInner onPress={() => this.toProfile()}>
          <ImageCacheProvider
            urlsToPreload={[image]}
          >
            <AvatarImage source={{ uri: image }} />
          </ImageCacheProvider>
        </AvatarWrapInner>
        {unreadTipsLen > 0 &&
          <Badge onPress={() => this.toNotification()}>
            <BadgeText>{unreadTipsLen <= 9 ? unreadTipsLen : '9+'}</BadgeText>
          </Badge>
        }
      </AvatarWrap>
    )
  }
}

export default Avatar
