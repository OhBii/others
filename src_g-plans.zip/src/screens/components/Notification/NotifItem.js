/*
*   author: denis
*   date:   7/12/2018
*/

import React, { Component } from 'react';
import {
  View,
  Text,
  Image,
  TouchableWithoutFeedback,
  TouchableOpacity,
  LayoutAnimation,
  Alert,
} from 'react-native';
import glamorous from 'glamorous-native';
import FAIcon from 'react-native-vector-icons/FontAwesome';
import MCIcon from 'react-native-vector-icons/MaterialCommunityIcons'
import Proptypes from 'prop-types'
import Swipeable from 'react-native-swipeable'
import moment from 'moment'

import Constants from '../../../global/Constants';
import { getStores } from '../../../stores'

//Notification Item
//props- iconIndex, title, date, content, isRead

const ContainerOverall = glamorous(View)({
  flexDirection: 'column',
  borderStyle: 'solid',
  borderBottomColor: Constants.Colors.borderColor,
  borderBottomWidth: 1,
})

const Notif = glamorous(View)({
  flexDirection: 'row',
  marginLeft: 15,
  marginRight: 20,
  paddingTop: 12,
  paddingBottom: 16,
  flex: 1,
});

const TitleText = glamorous(Text)({
  fontSize: 18,
  color: Constants.Colors.marineTwo,
});

const DateText = glamorous(Text)({
  fontSize: 14,
  color: Constants.Colors.pinkishGrey,
  paddingTop: 5
});

const ContentText = glamorous(Text)(({ isLess }) => ({
  fontSize: 14,
  color: Constants.Colors.greyishBrown,
  height: isLess? 18: null
}));

const ContentView = glamorous(View)({
  marginLeft: 20,
  flex: 1,
});

const IconView = glamorous(View)(({isLess}) => ({
  flexDirection: "row",
  justifyContent: "flex-end",
  opacity: isLess
}));

const ContainerDelReadBtn = glamorous(View)({
  flex: 1,
  justifyContent: 'center',
  alignItems: 'center',
  paddingVertical: 25,
  paddingHorizontal: 25,
})

const DelButton = glamorous(TouchableOpacity)({
  flex: 1,
  backgroundColor: Constants.Colors.melon,
  alignItems: 'flex-start'
})

const ReadButton = glamorous(TouchableOpacity)({
  flex: 1,
  backgroundColor: Constants.Colors.skyBlue,
  alignItems: 'flex-end',
})

const DelReadBtnText = glamorous(Text)({
  fontSize: 16,
  color: Constants.Colors.white,
  fontWeight: '600',
})

const leftButtons = onPress => [
  <ReadButton
    onPress={onPress}
    key={'read'}
  >
    <ContainerDelReadBtn>
      <MCIcon name='email-open' color={Constants.Colors.white} size={25} />
      <DelReadBtnText>Read</DelReadBtnText>
    </ContainerDelReadBtn>
  </ReadButton>,
]

const rightButtons = onPress => [
  <DelButton
    onPress={onPress}
    key={'del'}
  >
    <ContainerDelReadBtn>
      <MCIcon name='delete-forever' color={Constants.Colors.white} size={25} />
      <DelReadBtnText>Delete</DelReadBtnText>
    </ContainerDelReadBtn>
  </DelButton>,
]

const ButtonExpandWrap = glamorous(View)(({ visible }) => ({
  overflow: 'hidden',
  flexDirection: 'row',
  justifyContent: 'center',
  alignItems: 'center',
  opacity: 1,
  display: visible ? 'flex' : 'none',
  marginTop: -20,
  paddingBottom: 5,
}))

const ButtonExpand = glamorous(TouchableOpacity)(({ backgroundColor, borderColor, visible }) => ({
  flexDirection: 'row',
  justifyContent: 'center',
  alignItems: 'center',
  paddingHorizontal: 20,
  height: 38,
  borderRadius: 22,
  borderWidth: 1,
  borderColor,
  marginTop: 25,
  marginBottom: 10,
  overflow: 'hidden',
  backgroundColor,
  marginHorizontal: 15,
  display: visible ? 'flex' : 'none',
}))

const ButtonExpandText = glamorous(Text)(({color}) => ({
  fontSize: 14,
  color,
}))

const { string, number, bool, func } = Proptypes

export default class NotifItem extends Component {
  static propTypes = {
    id: number,
    title: string,
    date: string,
    message: string,
    event: string,
    isRead: bool,
    iconIndex: number,
    setAsRead: func,
    deleteTip: func,
    initalOpened: bool,
  }

  constructor(props) {
    super(props);

    this.state = {
      isLess: props.initalOpened ? 0 : 1,
      height: props.initalOpened ? null : 0,
      linesText: props.initalOpened ? null : 2,
      linesTitle: props.initalOpened ? null : 1,
      opacity: props.initalOpened ? null : 0,
    };
  }

  toggleAnimation() {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.spring);
    this.setState({
      isLess: this.state.isLess ? 0: 1,
      height: this.state.height === null ? 0 : null,
      linesText: this.state.linesText ? null : 2,
      linesTitle: this.state.linesTitle ? null : 1,
      opacity: this.state.opacity === null ? 0 : null,
    });
  }

  onReadBtn = id => {
    if (this.props.isRead)  {
      this.swipeable.recenter()
      return
    }
    this.props.setAsRead(id)
      .then(() => {
        this.toggleAnimation()
        this.swipeable.recenter()
      })
      .catch(err => {
        err
        const { User: { language } } = getStores()
        Alert.alert(Constants.Multilingual.MSG_GENERAL[language])
      })
  }

  onReadSwipBtn = id => {
    if (this.props.isRead)  {
      this.swipeable.recenter()
      return
    }
    this.props.setAsRead(id)
      .then(() => {
        this.swipeable.recenter()
      })
      .catch(err => {
        err
        const { User: { language } } = getStores()
        Alert.alert(Constants.Multilingual.MSG_GENERAL[language])
      })
  }

  onDeleteBtn = id => {
    this.props.deleteTip(id)
      .then(() => {})
      .catch(err => {
        err
        const { User: { language } } = getStores()
        Alert.alert(Constants.Multilingual.MSG_GENERAL[language])
      })
  }

  render() {
    const {
      id,
      title,
      date,
      message,
      //event,
      isRead,
      //iconIndex,
    } = this.props

    const dateFormated = moment(date).format('MMM[, ]DD[, ]YYYY')
    const { height, opacity } = this.state

    return(
      <Swipeable
        leftButtons={leftButtons(() => this.onReadSwipBtn(id))}
        rightButtons={rightButtons(() => this.onDeleteBtn(id))}
        leftButtonWidth={95}
        rightButtonWidth={95}
        onRef={ref => this.swipeable = ref}
      >
        <TouchableWithoutFeedback onPress={() => this.toggleAnimation()}>
          <ContainerOverall>
            <Notif>
              <View>
                <Image
                  source={isRead
                    ? require("../../../../img/notif1gray.png")
                    : require('../../../../img/notif1.png')
                  }
                />
              </View>
              <ContentView>
                <TitleText>
                  {title}
                </TitleText>
                <DateText>{dateFormated}</DateText>
                <IconView isLess={this.state.isLess}>
                  <FAIcon name="angle-right" size={18} color={Constants.Colors.pinkishGrey} />
                </IconView>
                <ContentText isLess={this.state.isLess} numberOfLines={this.state.isLess}>
                  {message}
                </ContentText>
              </ContentView>
            </Notif>
            <ButtonExpandWrap
              style={{ height, opacity }}
              visible={height === null}
            >
              <ButtonExpand
                visible={!isRead}
                onPress={() => this.onReadBtn(id)}
                borderColor={Constants.Colors.white}
                backgroundColor={Constants.Colors.skyBlue}
              >
                <ButtonExpandText color={Constants.Colors.white}>Cool, Got it!</ButtonExpandText>
              </ButtonExpand>
              <ButtonExpand
                visible={true}
                onPress={() => this.onDeleteBtn(id)}
                borderColor={Constants.Colors.warmGreySix}
                backgroundColor={Constants.Colors.white}
              >
                <ButtonExpandText color={Constants.Colors.warmGreySix}>Delete</ButtonExpandText>
              </ButtonExpand>
            </ButtonExpandWrap>
          </ContainerOverall>
        </TouchableWithoutFeedback>
      </Swipeable>
    );
  }
}
