/*
*   author: denis
*   date:   08/24/2018
*/

import React, { Component } from 'react';
import {
  View,
  Image,
  Text,
  TouchableOpacity
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import Icon from 'react-native-vector-icons/MaterialIcons'

import Constants from '../../../global/Constants';

const { height } = Constants.windowDimensions

const ContainerView = glamorous(View)({
  flexDirection: "column",
  flex: 1,
  justifyContent: 'space-between',
  alignItems: 'center',
  backgroundColor: Constants.Colors.whiteFive
});

const ImageView = glamorous(View)({
  width: '80%',
  height: height * 0.6,
  marginTop: 60
});

const UploadImage = glamorous(Image)({
  width: '100%',
  height: '100%',
  borderRadius: 7
})

const ButtonView = glamorous(View)({
  width: '80%',
  marginBottom: 40
});

const Button = glamorous(TouchableOpacity)({
  flexDirection: 'row',
  justifyContent: 'center',
  alignItems: "center",
  marginTop: 20,
  padding: 15,
  borderRadius: 30,
  borderWidth: 1,
  borderStyle: 'solid',
  borderColor: Constants.Colors.softBlueThree
});

const LightText = glamorous(Text)({
  marginLeft: 7,
  fontSize: 16,
  color: Constants.Colors.softBlueThree
});

const { object, string, func } = Proptypes;
export default class PreviewImage extends Component {
  static propTypes = {
    navigator: object,
    imageUri: string,
    uploadImage: func
  }

  static defaultProps = {
    imageUri: ''
  }

  constructor(props) {
    super(props);
  }

  toUpload() {
    this.props.uploadImage();
    this.props.navigator.dismissModal();
  }

  toCancel() {
    this.props.navigator.dismissModal();
  }

  render() {
    return(
      <ContainerView>
        <ImageView>
          <UploadImage source={{uri: this.props.imageUri}} />
        </ImageView>
        <ButtonView>
          <Button onPress={() => this.toUpload()} >
            <Icon name="check" size={18} color={Constants.Colors.dodgerBlueFour} />
            <LightText>Upload this photo</LightText>
          </Button>
          <Button onPress={() => this.toCancel()} >
            <Icon name="clear" size={18} color={Constants.Colors.dodgerBlueFour} />
            <LightText>Cancel</LightText>
          </Button>
        </ButtonView>
      </ContainerView>
    );
  }
}