import React from 'react'
import {
  Text,
  View,
  Image,
  TouchableOpacity
} from 'react-native'
import glamorous from 'glamorous-native'
import Icon from 'react-native-vector-icons/Octicons'
import LinearGradient from 'react-native-linear-gradient'

import Constants   from '../../../global/Constants'

const { width } = Constants.windowDimensions

const Container = glamorous(TouchableOpacity)(({ paddingLeft, mnRight }) => ({
  flexDirection: 'column',
  alignItems: 'flex-start',
  width: width * 0.8,
  marginRight: mnRight || 10,
  marginBottom: 15,
  paddingLeft
}))

const Body = glamorous(View)({
  width: '100%',
  height: 124,
  flexDirection: 'row',
  paddingVertical: 20,
  justifyContent: 'flex-start'
})

const Thumbnail = glamorous(Image)({
  resizeMode: 'cover',
  width: '100%',
  height: 124,
  borderRadius: 6,
  position: 'absolute',
  left: 0,
  top: 0
})

const Title = glamorous(Text)({
  fontSize: 20,
  fontWeight: 'bold',
  letterSpacing: -0.5,
  color: Constants.Colors.white,
  marginBottom: 7
})

const Desrc = glamorous(Text)({
  fontSize: 14,
  fontWeight: '500',
  letterSpacing: -0.35,
  color: Constants.Colors.white
})

const Left = glamorous(View)({
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  width: 100,
})

const Right = glamorous(View)({
  flexDirection: 'column',
  flexShrink: 2,
  paddingRight: 15
})

const Avatar = glamorous(View)({
  width: 60,
  height: 60,
  borderRadius: 8,
  backgroundColor: "#000000",
  marginBottom: 5
})

const Likes = glamorous(View)({
  flexDirection: 'row',
  width: 60,
  paddingVertical: 3,
  paddingHorizontal: 15,
  borderRadius: 15,
  backgroundColor: "rgba(0, 0, 0, 0.16)",
  alignItems: 'center',
  justifyContent: 'center'
})

const LikesCount = glamorous(Text)({
  fontSize: 11,
  color: Constants.Colors.white
})

const Gradient = glamorous(LinearGradient)({
  position: 'absolute',
  left: 0,
  top: 0,
  right: 0,
  bottom: 0,
  borderRadius: 6,
  opacity: 0.8
})

const ModuleItem = ({
  index,
  name,
  text,
  color1,
  color2,
  likes,
  onSelected,
  paddingLeft
} = this.props) => {
    return(
      <Container
        onPress={ () => onSelected({index}) }
        paddingLeft={ index === 0 ? paddingLeft : 0 }
      >
        <Body>
          <Thumbnail
            source={Constants.Images.MODULE_BG1}
          />
          <Gradient
            colors={[color1, color2]}
            start={{x: 0, y: 0.5}} end={{x: 0.5, y: 0}}
          />
          <Left>
            <Avatar />
            <Likes>
              <Icon name="heart" size={14} color={Constants.Colors.whiteTwo} />
              <LikesCount>{ likes }</LikesCount>
            </Likes>
          </Left>
          <Right>
            <Title numberOfLines={1}>{ name }</Title>
            <Desrc numberOfLines={3}>{ text }</Desrc>
          </Right>
        </Body>
      </Container>
    )
  }

export default ModuleItem
