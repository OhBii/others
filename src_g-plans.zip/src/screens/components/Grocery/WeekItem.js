/*
*   author: denis
*   date:   7/13/2018
*/

import React, { Component } from 'react';
import {
  View,
  Text,
  TouchableOpacity
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import Icon from 'react-native-vector-icons/Octicons';
import ActionSheet  from 'react-native-actionsheet'
import { inject, observer } from 'mobx-react/native';

import Constants from '../../../global/Constants';

//
const multilingual = Constants.Multilingual;
const ItemView = glamorous(TouchableOpacity)({
  marginHorizontal: 15,
  marginVertical: 5,
  paddingHorizontal: 10,
  paddingVertical: 5,
  backgroundColor: "white",
  borderRadius: 6
});

const MoreView = glamorous(TouchableOpacity)({

})
const RowView = glamorous(View) ({
  flexDirection: "row",
  justifyContent: "space-between",
  marginVertical: 10
});

const TitleText = glamorous(Text) ({
  fontSize: 24,
  color: Constants.Colors.marineTwo
})

const RadiusView = glamorous(View) ({
  backgroundColor: Constants.Colors.whiteFour,
  borderRadius: 10,
  paddingHorizontal: 15,
  paddingVertical: 3
});

const CountText = glamorous(Text)({
  fontSize: 12,
  color: Constants.Colors.marineTwo
})

const TimeView = glamorous(View)({
  flexDirection: "row"
});

const TimeText = glamorous(Text)({
  fontSize: 14,
  color: Constants.Colors.warmGrey,
  marginLeft: 3
});

const { object, string, number, func } = Proptypes;
@inject('User') @observer
export default class WeekItem extends Component {
  static propTypes = {
    User: object,
    navigator: object,
    name: string,
    cntItem: number,
    createdDate: string,
    listName: string,
    deleteList:func,
  }

  constructor(props) {
    super(props);
  }

  toWeekGrocery() {
      this.props.navigator.push({
        ...Constants.Screens.WEEKGROCERY_SCREEN,
        navigatorStyle: {
          navBarHidden: true,
          tabBarHidden: true
        },
        passProps: {
          navigator: this.props.navigator,
          name: this.props.name,
          listName: this.props.listName
        }
      });

  }

  toMoreView() {
    this.ActionSheet.show();
  }

  render() {
    const {
      User: {
        language,
        isPremium,
      }
    } = this.props
    return(
      <ItemView onPress={() => this.toWeekGrocery()}>
        <RowView>
          <TitleText>{this.props.name}</TitleText>
          { isPremium
              ?<Icon name="kebab-horizontal" size={24} color={Constants.Colors.marineTwo} />
              :<MoreView onPress={() => this.toMoreView()}>
                <Icon name="kebab-horizontal" size={24} color={Constants.Colors.marineTwo} />
              </MoreView>
          }
          <ActionSheet
            ref={ref => this.ActionSheet = ref}
            options={[multilingual.VIEW[language], multilingual.DELETE[language], multilingual.CANCEL[language]]}
            cancelButtonIndex={2}
            onPress={buttonIndex => {
              if (buttonIndex === 2) return
              if (buttonIndex === 0) { this.toWeekGrocery() }
              if (buttonIndex === 1) { this.props.deleteList() }
            }}
          />
        </RowView>
        <RowView>
          <RadiusView>
            <CountText>{this.props.cntItem} {multilingual.ITEMS[language]}</CountText>
          </RadiusView>
          <TimeView>
            <Icon name="clock" size={14} color={Constants.Colors.warmGrey} />
            <TimeText>{multilingual.CREATED[language]} {this.props.createdDate}</TimeText>
          </TimeView>
        </RowView>
      </ItemView>
    );
  }
}
