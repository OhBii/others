/*
*   author: denis
*   date:   7/16/2018
*/

import React, { Component } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  Platform,
  TextInput,
  Alert,
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import ActionSheetAndroid from 'react-native-actionsheet'
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import { inject, observer } from 'mobx-react/native';

import Constants from '../../../global/Constants';
import ParallelButton from '../Common/ParallelButton';
import { caseRoundValue, roundValue } from '../../../utils/GlobalFunctions'

const multilingual = Constants.Multilingual;
const ContainerOverall = glamorous(View)({
  width: Constants.windowDimensions.width,
  height: 415,
  justifyContent: 'center',
  alignItems: 'center',
  alignSelf: 'center',
})

const ModalView = glamorous(View)({
  width: 316,
  height: 309,
  borderRadius: 6,
  backgroundColor: "white",
  paddingVertical: 20,
  paddingHorizontal: 15,
});

const SimpleText = glamorous(Text)({
  fontSize: 14,
  color: Constants.Colors.marineTwo,
  marginTop: 5
});

const HeaderView = glamorous(View)({
  flexDirection: "row",
  justifyContent: "space-between"
});

const SettingView = glamorous(View)({
  flexDirection: "row"
});

const ImageView = glamorous(TouchableOpacity)({
  marginLeft: 10
});

const TitleText = glamorous(Text)({
  width: "80%",
  fontSize: 30,
  color: Constants.Colors.greyishBrown
});

const ContentView = glamorous(View)({
  flexDirection: "row",
  justifyContent: "center",
  alignItems: 'center',
  marginTop: 7,
  marginBottom: 5
});

const CountView = glamorous(View)({
  width: 145,
  height: 120,
  borderRadius: 6,
  borderStyle: "solid",
  borderColor: "#d6d6d6",
  borderWidth: 1,
  justifyContent: "center",
  alignItems: "center",
  marginHorizontal: 10
});

const CountText = glamorous(TextInput)(({fontSize}) => ({
  width: '100%',
  fontSize: fontSize,
  color: Constants.Colors.marineTwo,
}));

const MinusPlusView = glamorous(TouchableOpacity)({
  width: 40,
  height: 40,
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'center',
  backgroundColor: Constants.Colors.fillColor,
  borderRadius: 40
});

const MinusPlusText = glamorous(Text)({
  color: 'white',
  fontSize: 36,
  lineHeight: 36
});

const UnitView = glamorous(View)({
  alignItems: "center"
});

const UnitText = glamorous(Text)({
  fontSize: 13,
  color: Constants.Colors.marineTwo,
});

const FooterView = glamorous(View)({
  flexDirection: "row",
  justifyContent: "space-between",
  marginTop: 18
})

const RemoveText = glamorous(Text)({
  fontSize: 16,
  color: Constants.Colors.greyishBrown
});

const RemoveView = glamorous(View)({
  marginTop: 12
});

const CompleteBtnView = glamorous(View)({
  flexDirection: 'row',
  flex: 1,
  justifyContent: 'flex-end',
})

const { object, string, number, func, shape, bool } = Proptypes;
@inject('User') @observer
export default class ItemChange extends Component {
  static propTypes = {
    User: object,
    navigator: object,
    itemName: string,
    item: shape({
      portion: Proptypes.oneOfType([string, number]),
      portion_si: Proptypes.oneOfType([string, number]),
      unit: string,
      unit_si: string,
    }),
    groceryFlag: bool,
    changeValue: func,
    ratioSIOverUS: number,
    deleteItem: func,
    unitType: string,
    changeUnit: func,
    addedItemFlag: bool,
  }

  constructor(props) {
    super(props)
    let item, exchanges, amount;
    item = props.item
    exchanges = isFinite(parseFloat(item.exchanges)) ? item.exchanges : 1
    if(props.groceryFlag){
      amount = props.unitType === 'us'
      ? caseRoundValue(item.amount)
      : caseRoundValue(item.amount_si)
    }else {
      amount = props.unitType === 'us'
        ? caseRoundValue(parseFloat(item.portion) * exchanges)
        : caseRoundValue(parseFloat(item.portion_si) * exchanges)
    }
    this.state = {
      amount: amount,
      unit: this.props.unitType === 'us' ? this.props.item.unit : this.props.item.unit_si,
      fontSizePortion: this.getFontSizePortion(amount.toString()),
    };

  }

  convertUS2SI(amountUS) {
    return caseRoundValue(amountUS * this.props.ratioSIOverUS)
  }

  convertSI2US(amountSI) {
    return caseRoundValue(amountSI / this.props.ratioSIOverUS)
  }

  toPlus() {
    const isUS = this.state.unit === this.props.item.unit
    const amount = roundValue((this.state.amount + (isUS ? 0.1 : 5)), 1)
    if ((isUS && amount >= 100) || (!isUS && amount >= 100 * this.props.ratioSIOverUS)) return
    const fontSize = this.getFontSizePortion(amount.toString())
    this.setState({
      amount,
      fontSizePortion: fontSize,
    })
  }

  toMinus() {
    const isUS = this.state.unit === this.props.item.unit
    const amount = roundValue((this.state.amount - (isUS ? 0.1 : 5)), 1)
    if (amount < 0) return
    const fontSize = this.getFontSizePortion(amount.toString())
    this.setState({
      amount,
      fontSizePortion: fontSize,
     })
  }

  getFontSizePortion(text) {
    return text.length > 4 ? 40 : text.length > 3 ? 50 : 60
  }

  onChangeTextPortion(text) {
    const fontSize = this.getFontSizePortion(text)
    this.setState({ fontSizePortion: fontSize })
  }

  toAmount(value) {
    const isUS = this.state.unit === this.props.item.unit
    let amount = isFinite(value) ? value : 0
    if (amount < 0) {
      amount = 0
    } else if (isUS && amount > 100) {
      Alert.alert(
        'Warnning',
        `Amount cannot be bigger than ${100}${this.state.unit}`,
        [
          {
            text: 'OK',
            onPress: () => {
              this.setState({ amount: 100 })
            },
          },
        ],
        { cancelable: false }
      )
      return
    } else if (!isUS && amount > 100 * this.props.ratioSIOverUS) {
      Alert.alert(
        'Warnnig',
        `Amount cannot be bigger than ${100 * this.props.ratioSIOverUS}${this.state.unit}`,
        [
          {
            text: 'OK',
            onPress: () => {
              this.setState({ amount: caseRoundValue(100 * this.props.ratioSIOverUS) })
            },
          },
        ],
        { cancelable: false }
      )
      return
    }
    const fontSize = this.getFontSizePortion(amount.toString())
    this.setState({
      amount: amount,
      fontSizePortion: fontSize,
    })
  }

  toUnit(unit) {
    let amount
    if (unit != this.state.unit) {
      if (unit === this.props.item.unit) {
        amount = caseRoundValue(this.state.amount / this.props.ratioSIOverUS)
      } else {
        amount = caseRoundValue(this.state.amount * this.props.ratioSIOverUS)
      }
    } else {
      return
    }
    const fontSize = this.getFontSizePortion(amount.toString())
    this.setState({
      unit,
      amount,
      fontSizePortion: fontSize,
    })
  }

  setUnits() {
    if (Platform.OS === 'ios') {
      const { ActionSheetIOS } = require('react-native')
      ActionSheetIOS.showActionSheetWithOptions({
        options: [this.props.item.unit, this.props.item.unit_si, 'Cancel'],
        cancelButtonIndex: 2
      },
      (buttonIndex) => {
        if (buttonIndex === 2) return;
        if (buttonIndex === 0) { this.toUnit(this.props.item.unit) }
        if (buttonIndex === 1) { this.toUnit(this.props.item.unit_si) }
      });
    }
    else {
      this.ActionSheetAndroid.show()
    }
  }

  toRemoveFromList() {
    this.props.deleteItem()
    this.props.navigator.dismissLightBox()
  }

  toComplete() {
    const item = this.props.item
    const exchanges = isFinite(parseFloat(item.exchanges)) ? item.exchanges : 1
    const isUS = this.state.unit === item.unit
    if (this.state.amount === 0) {
      Alert.alert(
        'Amount is 0',
        'Would you like to remove this item from meal?',
        [
          { text: 'Remove', onPress: () => this.toRemoveFromList() },
          { text: 'Cancel', onPress: () => {
              const amount = isUS
                ? caseRoundValue(parseFloat(item.portion) * exchanges)
                : caseRoundValue(parseFloat(item.portion_si) * exchanges)
              this.setState({ amount })
            }, style: 'cancel'
          },
        ],
        { cancelable: true }
      )
      return
    }

    if(this.props.groceryFlag){
      this.props.changeValue(this.state.amount, isUS)
      this.props.changeUnit(isUS ? 'us' : 'si')
      this.props.navigator.dismissLightBox()
      return
    }
    this.props.changeValue(this.state.amount, isUS)
    this.props.changeUnit(isUS ? 'us' : 'si')
    this.props.navigator.dismissLightBox()
  }

  render() {
    const {
      User: {
        language,
        isPremium,
      }
    } = this.props
    return(
      <KeyboardAwareScrollView>
      <ContainerOverall>
      <ModalView>
        <HeaderView>
          <SimpleText>{multilingual.SELECTED_ITEM[language]}</SimpleText>
          <SettingView>
            <SimpleText>{multilingual.UNITS[language]}</SimpleText>
            <ImageView onPress={() => this.setUnits()}>
              <Image source={require("../../../../img/settingIcon.png")} />
            </ImageView>
          </SettingView>
        </HeaderView>
        <View>
          <TitleText numberOfLines={1}>{this.props.itemName}</TitleText>
        </View>
        <ContentView>
          <MinusPlusView  onPress={() => this.toMinus()}>
            <MinusPlusText>-</MinusPlusText>
          </MinusPlusView>
          <CountView>
            <CountText
              value={this.state.amount.toString()}
              onChangeText={text => {
                this.onChangeTextPortion(text)
                this.toAmount(parseFloat(text))
              }}
              maxLength={5}
              keyboardType={'decimal-pad'}
              textAlign={'center'}
              underlineColorAndroid={'rgba(0, 0, 0, 0)'}
              fontSize={this.state.fontSizePortion}
            />
          </CountView>
          <MinusPlusView  onPress={() => this.toPlus()}>
            <MinusPlusText>+</MinusPlusText>
          </MinusPlusView>
        </ContentView>
        <UnitView>
          <UnitText>{this.state.unit}</UnitText>
        </UnitView>
        <FooterView>
          {
            this.props.groceryFlag == true && isPremium && !this.props.addedItemFlag
              ? <RemoveView></RemoveView>
              : this.props.deleteItem &&
                <RemoveView>
                  <TouchableOpacity onPress={() => this.toRemoveFromList()}>
                    <RemoveText>{multilingual.REMOVE_FROM_LIST[language]}</RemoveText>
                  </TouchableOpacity>
                </RemoveView>
          }
          <CompleteBtnView>
            <ParallelButton
              title={multilingual.COMPLETE[language]}
              icon={"check"}
              proc={() => this.toComplete()}
            />
          </CompleteBtnView>
        </FooterView>
        <ActionSheetAndroid
          ref={ref => this.ActionSheetAndroid = ref}
          options={[this.props.item.unit, this.props.item.unit_si, multilingual.CANCEL[language]]}
          cancelButtonIndex={2}
          onPress={buttonIndex => {
            if (buttonIndex === 2) return;
            if (buttonIndex === 0) { this.toUnit(this.props.item.unit) }
            if (buttonIndex === 1) { this.toUnit(this.props.item.unit_si) }
          }}
        />
        </ModalView>
        </ContainerOverall>
      </KeyboardAwareScrollView>
    );
  }
}
