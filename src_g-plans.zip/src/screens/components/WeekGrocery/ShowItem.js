/*
*   author: denis
*   date:   7/16/2018
*/

import React, { Component } from 'react';
import {
  View,
  Text,
  Image,
  TouchableWithoutFeedback
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import { inject, observer } from 'mobx-react/native';

import Constants from '../../../global/Constants';

const ItemView = glamorous(View)({
  flexDirection: "row",
  paddingHorizontal: 15,
  paddingTop: 8,
  paddingBottom: 10,
  borderStyle: "solid",
  borderBottomColor: Constants.Colors.borderColor,
  borderBottomWidth: 1
});

const TextView = glamorous(View)({
  width: '60%',
  paddingLeft: 18,
  paddingTop: 2
})

const ItemText = glamorous(Text)(({isChecked}) => ({
  fontSize: 18,
  color: isChecked
    ? Constants.Colors.warmGrey
    : Constants.Colors.marineTwo
}));

const CountView = glamorous(View)(({isChecked}) => ({
  width: '15%',
  marginLeft: 15,
  paddingVertical: 3,
  alignItems: "center",
  borderRadius: 6,
  borderStyle: "solid",
  borderWidth: 1,
  borderColor: isChecked
    ? Constants.Colors.pinkishGrey
    : Constants.Colors.warmGrey,
  backgroundColor: isChecked
    ? Constants.Colors.whiteFive
    : 'white'
}));

const UnitView = glamorous(View)({
  paddingLeft: 5,
  paddingTop: 15
});

const UnitText = glamorous(Text)(({isChecked}) => ({
  fontSize: 10,
  color: isChecked
    ? Constants.Colors.pinkishGrey
    : Constants.Colors.greyishBrown
}));

const { object, string, number, func, boolean } = Proptypes;
@inject('GroceryList', 'User') @observer
export default class ShowItem extends Component {
  static propTypes = {
    navigator: object,
    GroceryList: object,
    User: object,
    itemName: string,
    itemAmount: number,
    listName: string,
    changeCheckFlag: func,
    addedItemFlag: boolean
  }

  constructor(props) {
    super(props);
  }

  changeCheck() {
    this.props.changeCheckFlag();
  }

  changeItemCount() {
    const {
      GroceryList:{
        mealItemsGroceryList,
        addedMealItemsGroceryList,
        deleteItem: deleteListItem
      },
      User:{
        unit,
        setUnit,
      },
      listName,
      itemName,
      addedItemFlag
    } = this.props
    const { checkFlag } = addedItemFlag ? addedMealItemsGroceryList[listName][itemName]: mealItemsGroceryList[listName][itemName]
    const item = addedItemFlag ? {...addedMealItemsGroceryList[listName][itemName]} : {...mealItemsGroceryList[listName][itemName]}
    const changeUnit = unit => setUnit(unit)
    const deleteItem = () => deleteListItem(listName, itemName, addedItemFlag)
    if (checkFlag) return;

    this.props.navigator.showLightBox({
      ...Constants.Screens.ITEMCHANGE_SCREEN,
      style: {
        backgroundColor: "#000000a0",
        tapBackgroundToDismiss: true
      },
      passProps: {
        groceryFlag: true,
        item,
        navigator: this.props.navigator,
        itemName: this.props.itemName,
        ratioSIOverUS : parseFloat(item.portion_si) / parseFloat(item.portion),
        unitType: unit,
        changeValue : (amount, isUS) => this.changeAmount(amount, isUS),
        changeUnit,
        deleteItem,
        addedItemFlag
      }
    });
  }

  changeAmount(amount, isUS) {
    const {
      GroceryList:{
        setItemAmount
      },
      listName,
      itemName,
      addedItemFlag
    } = this.props
    setItemAmount( amount, listName, itemName, isUS,addedItemFlag)
  }


  render() {
    const {
      GroceryList:{
        mealItemsGroceryList,
        addedMealItemsGroceryList
       },
      User:{
        unit: unitFlag
      },
      listName,
      itemName,
      addedItemFlag
    } = this.props
    const { checkFlag, amount, amount_si, unit, unit_si } = addedItemFlag ? addedMealItemsGroceryList[listName][itemName] : mealItemsGroceryList[listName][itemName]
    const currentAmount = unitFlag == "us" ? amount : amount_si;
    const currentItemUnit = unitFlag == "us" ? unit : unit_si;
    return(
      <ItemView>
        <TouchableWithoutFeedback onPress={() => this.changeCheck()} >
          {
            checkFlag
              ? <Image  source={require("../../../../img/checked.png")} />
              : <Image  source={require("../../../../img/unchecked.png")} />
          }
        </TouchableWithoutFeedback>
        <TextView>
          <ItemText numberOfLines={1} isChecked={checkFlag}>
            {this.props.itemName}
          </ItemText>
        </TextView>
        <TouchableWithoutFeedback onPress={() => this.changeItemCount()}>
          <CountView isChecked={checkFlag}>
              <ItemText isChecked={checkFlag}>{currentAmount}</ItemText>
          </CountView>
        </TouchableWithoutFeedback>
        <UnitView>
          <UnitText isChecked={checkFlag}>{currentItemUnit}</UnitText>
        </UnitView>
      </ItemView>
    );
  }
}
