import React, { Component } from 'react';
import {
  Text,
  View,
  Image,
  TouchableOpacity
} from 'react-native'
import Proptypes from 'prop-types'
import glamorous from 'glamorous-native'
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialIcons';
import IconCommunity from 'react-native-vector-icons/MaterialCommunityIcons';
import { CachedImage, ImageCacheProvider } from 'react-native-cached-image'
import { inject, observer } from 'mobx-react';

import RecipeItemTracked from '../Recipe/RecipeItemTracked'
import RecipeItemMissed from '../Recipe/RecipeItemMissed'
import Constants   from '../../../global/Constants'


//const { width } = Constants.windowDimensions
const multilingual = Constants.Multilingual;
const ContainerView = glamorous(TouchableOpacity)({
  width: '100%',
  alignItems: 'stretch',
  flexDirection: 'column'
})

const Container = glamorous(TouchableOpacity)(({ width, mBottom, hideShadow }) => ({
  width: width || '95%',
  borderRadius: 6,
  backgroundColor: Constants.Colors.white,
  shadowColor: !hideShadow ? "rgba(0, 0, 0, 0.07)" : null,
  shadowOffset: {
    width: 0,
    height: 2
  },
  shadowRadius: !hideShadow ? 5 : 0,
  shadowOpacity: !hideShadow ? 1 : 0,
  flexDirection: 'column',
  justifyContent: 'center',
  marginBottom: mBottom || 10,
  elevation: !hideShadow ? 5 : 0
}))

const Inner = glamorous(View)(({ height, radius }) => ({
  flexDirection: 'column',
  alignItems: 'flex-start',
  width: '100%',
  height: height || 180,
  borderRadius: radius ? 6 : null,
  overflow: 'hidden'
}))

const Overlay = glamorous(LinearGradient)({
  width: '100%',
  height: '100%',
  borderTopLeftRadius: 6,
  borderTopRightRadius: 6,
  position: 'absolute',
  left: 0,
  top: 0,
  flexDirection: 'column',
  justifyContent: 'space-between',
  paddingHorizontal: 13,
  paddingTop: 20,
  paddingBottom: 15,
  zIndex: 0
})

const Header = glamorous(View)({
  flexDirection: 'row',
  justifyContent: 'flex-end',
  width: '100%',
  position: 'absolute',
  top: 0,
  left: 0,
  right: 0,
  paddingTop: 15,
  paddingHorizontal: 10,
  zIndex: 1
})

const Thumbnail = glamorous(CachedImage)({
  width: '100%',
  height: '100%',
  borderRadius: 6
})

const Title = glamorous(Text)({
  fontSize: 20,
  fontWeight: '600',
  color: Constants.Colors.marineTwo,
  marginBottom: 10,
})

const Footer = glamorous(View)({
  flexDirection: 'column',
  justifyContent: 'flex-start',
  alignItems: 'flex-start',
  width: '100%',
  padding: 10,
  height: 80
})

const StateInfo = glamorous(View)({
  flexDirection: 'column',
  width: '100%'
})

const StateInfoRow = glamorous(View)({
  flexDirection: 'row',
  width: '100%',
  alignItems: 'center'
})

const BadgeTracked = glamorous(View)({
  borderRadius: 10,
  ...Constants.flex('row', 'center', 'center'),
  marginRight: 5,
  marginBottom:7
})

const BadgeGradient = glamorous(LinearGradient)({
  position: 'absolute',
  left: 0,
  top: 0,
  width: '100%',
  height: '100%',
  borderRadius: 10
})

const BadgeTrackedText = glamorous(Text)({
  fontSize: 12,
  fontWeight: "bold",
  color: Constants.Colors.white,
  paddingVertical: 3,
  paddingHorizontal: 12
})

const BadgeMissed = glamorous(Text)({
  overflow: 'hidden',
  paddingVertical: 3,
  paddingHorizontal: 12,
  fontSize: 12,
  borderRadius: 10,
  fontWeight: "bold",
  textAlign: "center",
  color: Constants.Colors.white,
  backgroundColor: '#787878'
})

const RowPCF = glamorous(View)({
  flex: 1,
  flexDirection: 'row',
  flexWrap:'wrap',
  alignItems:'flex-start'
})

const RowPCFitem = glamorous(View)({
  flexDirection: 'row',
  marginLeft: 10
})

const RowPCFbold = glamorous(Text)({
  fontSize: 11,
  color: Constants.Colors.greyishBrown,
  fontWeight: 'bold'
})

const RowPCFnormal = glamorous(Text)({
  fontSize: 11,
  color: Constants.Colors.greyishBrown
})

const RecipeFlexWrap = glamorous(View)({
  position: 'absolute',
  top: 40,
  left: 0,
  right: 0,
  bottom: 0,
  flexDirection: 'column',
  justifyContent: 'flex-start',
  alignItems: 'center'
})

const RecipeFlexCircle = glamorous(View)({
  width: 129,
  height: 133,
  alignItems: 'center',
  justifyContent: 'center'
})

const CircleTracked = glamorous(Image)({
  width: 129,
  height: 133,
  position: 'absolute',
  left: 0,
  top: 0
})

const CircleCount = glamorous(Text)({
  fontSize: 36,
  fontWeight: "bold",
  letterSpacing: 0,
  color: Constants.Colors.white
})

const RecipeFlex = ({ count } = this.props) =>
  <RecipeFlexWrap>
    <RecipeFlexCircle>
      <CircleTracked
        source={Constants.Images.CIRCLE_TRACKED}
      />
      <CircleCount>{ count }</CircleCount>
    </RecipeFlexCircle>
  </RecipeFlexWrap>

const InfoFlex = glamorous(View)({
  width: '100%',
  flexDirection: 'column'
})

const FlexSearch = glamorous(TouchableOpacity)({
  width: 58,
  height: 58,
  position: 'absolute',
  right: 20,
  bottom: 48,
  zIndex: 1
})

const InfoSubtitle = glamorous(Text)({
  fontSize: 15,
  color: Constants.Colors.warmGrey
})

const FooterHome = glamorous(View)({
  flexDirection: 'column',
  justifyContent: 'flex-start',
  alignItems: 'flex-start',
  width: '100%',
  paddingHorizontal: 10,
  overflow: 'hidden'
})

const TitleHome = glamorous(Text)({
  fontSize: 16,
  fontWeight: '500',
  letterSpacing: -0.53,
  color: Constants.Colors.greyishBrown,
  marginTop: 5,
  marginBottom: 3
})

const StateHome = glamorous(View)({
  alignItems: 'center',
  flexDirection: 'row'
})

const Oval = glamorous(View)(({ color }) => ({
  width: 8,
  height: 8,
  borderRadius: 4,
  backgroundColor: color || Constants.Colors.white,
  marginRight: 5
}))

const StateHomeText = glamorous(Text)(({ color }) => ({
  fontSize: 10,
  fontWeight: '500',
  letterSpacing: 0,
  color: color || Constants.Colors.pinkishGrey
}))

// Full mode

const ContainerFull = glamorous(TouchableOpacity)(({ isSmall }) => ({
  width: isSmall ? '95%' : '100%',
  flexDirection: 'row',
  justifyContent: 'center',
  marginBottom: 25
}))

const InnerFull = glamorous(View)({
  flexDirection: 'column',
  alignItems: 'flex-start',
  width: '100%',
  height: 200,
  position: 'relative',
  borderRadius: 6,
  overflow: 'hidden'
})

const OverlayGradient = glamorous(LinearGradient)({
  width: '100%',
  height: '100%',
  borderRadius: 6,
  position: 'absolute',
  left: 0,
  top: 0,
})

const OverlayFull = glamorous(View)({
  width: '100%',
  height: '100%',
  borderRadius: 6,
  position: 'absolute',
  left: 0,
  top: 0,
  flexDirection: 'column',
  justifyContent: 'space-between',
  paddingHorizontal: 13,
  paddingTop: 20,
  paddingBottom: 15
})

const HeaderFull = glamorous(View)({
  flexDirection: 'row',
  justifyContent: 'flex-end',
  width: '100%'
})

const ThumbnailFull = glamorous(Image)({
  width: '100%',
  height: '100%',
  resizeMode: 'cover',
  borderRadius: 6
})

const TitleFull = glamorous(Text)({
  fontSize: 20,
  fontWeight: '600',
  color: Constants.Colors.white,
  marginBottom: 10,
})

const FooterFull = glamorous(View)({
  flexDirection: 'column',
  justifyContent: 'flex-start',
  alignItems: 'flex-start',
  width: '100%'
})

const { object, number, func, bool } = Proptypes;
@inject('User', 'Recipe', 'MealPlan') @observer
export default class MealCardListItem extends Component {
  static propTypes = {
    navigator: object,
    data: object,
    mealNumber: number,
    onSelected: func,
    mBottom: number,
    width: number,
    height: number,
    hideShadow: bool,
    radius: bool,
    User: object,
    Recipe: object,
    MealPlan: object,
    flex: bool,
    homeMode: bool,
    fullMode: bool,
    isSmall: bool
  }

  static defaultProps = {
    isSmall: false
  }

  constructor(props) {
    super(props);
  }

  toggleFavorite(favId) {
    if (this.props.data.id === undefined) {
      //in Recipe case
      if (favId === -1) {
        this.props.Recipe.addRecipeToFavorite(this.props.data.recipe.id);
      }
      else {
        this.props.Recipe.deleteRecipeFromFavorite(favId);
      }
    }
    else {
      //in Meal case
    }
  }

  toSearch() {
    this.props.navigator.showModal({
      ...Constants.Screens.SEARCH_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      },
      passProps: {
        mealId: this.props.data.id,
        forFlex: true
      }
    });
  }

  render() {
    const {
      data: {
        recipe, id, logged, skipped, label
      },
      width,
      height,
      hideShadow,
      radius,
      mBottom,
      onSelected,
      User,
      Recipe,
      MealPlan,
      flex,
      homeMode,
      fullMode,
      isSmall
    } = this.props
    const currentLanguage = User.language;
    const { image: { small: image } } = recipe ? recipe : this.props.data;

    const favId = id
      ?  -1 //in Meal case
      :  Recipe.favoriteRecipes.reduce((accumulator, fav) => {
           if (fav.recipe === recipe.id) return fav.id;
           return accumulator;
         }, -1) //in Recipe case

    const { pro, fats, carbs } = id
      ? MealPlan.getPFCByMealId(id)
      : Recipe.getPFCByRecipeId(recipe.id)

    return(
      <ContainerView>
      {!fullMode ?
        <Container
          onPress={ () => onSelected() }
          activeOpacity={0.9}
          width={width}
          mBottom={mBottom}
          hideShadow={hideShadow}
        >
          <Inner height={height} radius={radius}>
            <ImageCacheProvider
              urlsToPreload={[image]}>
              <Thumbnail
                source={{ uri: image }}
              />
            </ImageCacheProvider>
            {!logged && !skipped && <Overlay
              colors={['transparent', '#000000']}
              start={{x: 0, y: 0}} end={{x: 0, y: 1}}
            />}
            <RecipeItemTracked
              pro={MealPlan.getPercentage(id).pro}
              fats={MealPlan.getPercentage(id).fats}
              carbs={MealPlan.getPercentage(id).carbs}
              percent={MealPlan.getPercentage(id).percent}
              logged={logged}
              homeMode={homeMode}
            />
            <RecipeItemMissed
              missed={skipped}
              homeMode={homeMode}
            />
            {!!flex && !logged && !skipped && <RecipeFlex
              count={MealPlan.getItemCountOfMeal(id)}
            />}
          </Inner>
          {!!flex && !logged && !skipped &&
            <FlexSearch activeOpacity={0.8} onPress={() => this.toSearch()}>
              <Image source={Constants.Images.CIRCLE_PLUS} />
            </FlexSearch>
          }
          {!homeMode
            ? <Footer>
                <Title numberOfLines={1}>{ label }</Title>
              {!!flex && !logged && !skipped && <InfoFlex>
                  <InfoSubtitle>{ multilingual.ADD_TO_TRACK[currentLanguage] }</InfoSubtitle>
                </InfoFlex>}
              {!logged && !skipped
              ? <View />
              : <StateInfo>
                  {!!logged && <StateInfoRow>
                    <BadgeTracked>
                      <BadgeGradient
                        colors={['rgb(42, 154, 241)', 'rgb(84, 202, 249)']}
                        start={{x: 0, y: 0.5}} end={{x: 0.5, y: 0}}
                      />
                      <BadgeTrackedText>{multilingual.TRACKED[currentLanguage]}</BadgeTrackedText>
                    </BadgeTracked>
                    <RowPCF>
                      <RowPCFitem>
                        <RowPCFbold>{multilingual.CARB[currentLanguage]}</RowPCFbold>
                        {
                          User.isFreemium
                            ? <IconCommunity name="crown" size={16} color={Constants.Colors.sandYellow} />
                            : <RowPCFnormal>{pro}{'g'}</RowPCFnormal>
                        }
                      </RowPCFitem>
                      <RowPCFitem>
                        <RowPCFbold>{multilingual.PRO[currentLanguage]}</RowPCFbold>
                        {
                          User.isFreemium
                            ? <IconCommunity name="crown" size={16} color={Constants.Colors.sandYellow} />
                            : <RowPCFnormal>{fats}{'g'}</RowPCFnormal>
                        }
                      </RowPCFitem>
                      <RowPCFitem>
                        <RowPCFbold>{multilingual.FAT[currentLanguage]}</RowPCFbold>
                        {
                          User.isFreemium
                            ? <IconCommunity name="crown" size={16} color={Constants.Colors.sandYellow} />
                            : <RowPCFnormal>{carbs}{'g'}</RowPCFnormal>
                        }
                      </RowPCFitem>
                    </RowPCF>
                  </StateInfoRow>}
                  {!!skipped && <StateInfoRow>
                    <BadgeMissed>{multilingual.MISSED[currentLanguage]}</BadgeMissed>
                  </StateInfoRow>}
                </StateInfo>}
              </Footer>
            : <FooterHome>
                <TitleHome numberOfLines={1}>{ label }</TitleHome>
                <StateHome>
                  <Oval color={logged ? '#7ED321' : skipped ? '#9B9B9B' : '#D8D8D8'}/>
                  <StateHomeText
                    color={logged ? '#417505' : skipped ? '#4A4A4A' : '#D8D8D8'}
                  >
                    {logged ? multilingual.TRACKED[currentLanguage] : skipped ? multilingual.MISSED[currentLanguage] : multilingual.UNTRACKED[currentLanguage]}
                  </StateHomeText>
                </StateHome>
              </FooterHome>
          }
          </Container>
        : <ContainerFull
            onPress={ onSelected }
            activeOpacity={0.9}
            isSmall={isSmall}
          >
          {
            id
            ? <View />
            : <Header>
                <TouchableOpacity onPress={() => this.toggleFavorite(favId)}>
                  {
                    favId === -1
                      ? <Icon name="favorite-border" size={36} color="white" />
                      : <Icon name="favorite" size={36} color="red" />
                  }
                </TouchableOpacity>
              </Header>
          }
          <InnerFull>
            <ImageCacheProvider
              urlsToPreload={[image]}>
              <ThumbnailFull
                source={{ uri: image }}
              />

            </ImageCacheProvider>
              {!logged && !skipped && <OverlayGradient
                colors={['transparent', '#000000']}
                start={{x: 0, y: 0}} end={{x: 0, y: 1}}
              />}
              {!logged && !skipped && <OverlayFull>
                <HeaderFull>
                  {/*<TouchableOpacity>
                    <IconLike source={Constants.Images.ICON_LIKE} />
                  </TouchableOpacity>*/}
                </HeaderFull>
                <FooterFull>
                  <TitleFull numberOfLines={1}>{ label }</TitleFull>
                </FooterFull>
            </OverlayFull>}

            <RecipeItemTracked
              pro={MealPlan.getPercentage(id).pro}
              fats={MealPlan.getPercentage(id).fats}
              carbs={MealPlan.getPercentage(id).carbs}
              percent={MealPlan.getPercentage(id).percent}
              logged={logged}
              homeMode={homeMode}
            />
            <RecipeItemMissed
              missed={skipped}
              homeMode={homeMode}
            />
          </InnerFull>
        </ContainerFull>}
      </ContainerView>
    );
  }
}
