import React, { Component } from 'react'
import Proptypes from 'prop-types'
import {
  Text,
  View,
  Image,
  TouchableOpacity
} from 'react-native'
import glamorous from 'glamorous-native'
import LinearGradient from 'react-native-linear-gradient';
import { inject, observer } from 'mobx-react/native';

import RecipeItemTracked from '../Recipe/RecipeItemTracked'
import RecipeItemMissed from '../Recipe/RecipeItemMissed'
import Constants   from '../../../global/Constants'

//const { width } = Constants.windowDimensions

const Container = glamorous(TouchableOpacity)({
  width: '100%',
  flexDirection: 'row',
  justifyContent: 'center'
})

const Inner = glamorous(View)({
  flexDirection: 'column',
  alignItems: 'flex-start',
  width: '95%',
  height: 223,
  position: 'relative',
  borderRadius: 6,
})

const Overlay = glamorous(LinearGradient)({
  width: '100%',
  height: '100%',
  borderRadius: 6,
  position: 'absolute',
  left: 0,
  top: 0,
  flexDirection: 'column',
  justifyContent: 'space-between',
  paddingHorizontal: 13,
  paddingTop: 20,
  paddingBottom: 15
})

const Header = glamorous(View)({
  flexDirection: 'row',
  justifyContent: 'flex-end',
  width: '100%'
})

const Thumbnail = glamorous(Image)({
  width: '100%',
  height: '100%',
  resizeMode: 'cover',
  borderRadius: 6
})

const Title = glamorous(Text)({
  fontSize: 20,
  fontWeight: '600',
  color: Constants.Colors.white,
  marginBottom: 10,
})

const Footer = glamorous(View)({
  flexDirection: 'column',
  justifyContent: 'flex-start',
  alignItems: 'flex-start',
  width: '100%'
})

const Period = glamorous(View)({
  flexDirection: 'row',
  justifyContent: 'flex-end',
  alignItems: 'center'
})

const TimeText = glamorous(Text)({
  fontSize: 14,
  fontWeight: "600",
  fontStyle: "normal",
  letterSpacing: 0,
  textAlign: "right",
  color: Constants.Colors.warmGreyTwo
})

const IconTime = glamorous(Image)({
  width: 16,
  height: 16,
  marginHorizontal: 7
})

const IconLike = glamorous(Image)({
  width: 27,
  height: 24,
  marginHorizontal: 7
})

const Info = glamorous(View)({
  flexDirection: 'row',
  width: '100%',
  alignItems: 'center',
})

const MealNumber = glamorous(Text)({
  fontWeight: "bold",
  letterSpacing: 0,
  color: Constants.Colors.white,
  fontSize: 12,
  width: 75,
  height: 19,
  borderRadius: 10,
  borderStyle: 'solid',
  borderWidth: 1,
  borderColor: Constants.Colors.white,
  textAlign: 'center',
  lineHeight: 17,
  marginRight: 10
})

const { object, func, number, bool } = Proptypes;
@inject('App') @observer

class MealCardItem extends Component {

  static propTypes = {
    App: object,
    navigator: object,
    data: object,
    onSelected: func,
    mealNumber: number,
    logged: bool,
    missed: bool
  }

  render() {
    const {
        data: {
        image,
        title,
        dateFrom,
        dateTo
      },
      mealNumber,
      onSelected,
      logged = true,
      missed = false
    } = this.props
  return (
      <Container
        onPress={ onSelected }
        activeOpacity={0.9}
      >
        <Inner>
          <Thumbnail
            source={{ uri: image }}
          />
          <Overlay
            colors={['transparent', '#000000']}
            start={{x: 0, y: 0}} end={{x: 0, y: 1}}
          >
            <Header>
              <TouchableOpacity>
                <IconLike source={Constants.Images.ICON_LIKE} />
              </TouchableOpacity>
            </Header>
            <Footer>
              <Title>{ title }</Title>
              <Info>
                <MealNumber>{ `Meal ${mealNumber}`.toUpperCase() }</MealNumber>
                <Period>
                  <IconTime source={Constants.Images.ICON_TIME} />
                  <TimeText>{ `${dateFrom} - ${dateTo}` }</TimeText>
                </Period>
              </Info>
            </Footer>
          </Overlay>
          <RecipeItemTracked
            pro={22}
            fats={7}
            carbs={30}
            percent={100}
            logged={logged}
          />
          <RecipeItemMissed
            missed={missed}
          />
        </Inner>
      </Container>
    )
  }
}

export default MealCardItem
