import React from 'react'
import {
  Text,
  View,
  TouchableOpacity
} from 'react-native'
import glamorous from 'glamorous-native'
import { CachedImage, ImageCacheProvider } from 'react-native-cached-image'

import Constants   from '../../../global/Constants'

const { width } = Constants.windowDimensions

const Container = glamorous(TouchableOpacity)(({ paddingLeft }) => ({
  marginRight: 17,
  flexDirection: 'column',
  alignItems: 'flex-start',
  width: width * 0.75,
  paddingLeft
}))

const Picture = glamorous(View)({
  width: '100%',
  height: 214,
  borderRadius: 8
})

const Thumbnail = glamorous(CachedImage)({
  width: '100%',
  height: 214,
  borderRadius: 8
})

const Title = glamorous(Text)({
  fontSize: 18,
  fontWeight: '600',
  color: Constants.Colors.marineTwo,
  marginBottom: 10,
  width: '100%',
})

const Footer = glamorous(View)({
  flexDirection: 'column',
  justifyContent: 'flex-start',
  alignItems: 'flex-start',
  width: '100%',
  marginTop: 20,
})

const Content = glamorous(Text)({
  fontSize: 14,
  color: Constants.Colors.warmGreyTwo,
  width: '100%'
})

const BlogItem = ({
  index,
  link,
  title,
  excerpt,
  onSelected,
  paddingLeft,
  featured_image,
} = this.props) =>
  <Container
    onPress={ () => onSelected(link) }
    paddingLeft={ index === 0 ? paddingLeft : 0 }
  >
    <Picture>
    {
      featured_image && <ImageCacheProvider
        urlsToPreload={[featured_image ? featured_image.source : null]}
      >
        <Thumbnail
          source={{ uri: featured_image ? featured_image.source : null }}
        />
      </ImageCacheProvider>
    }
    </Picture>
    <Footer>
      <Title numberOfLines={1}>
        {
          title
          .replace(/<p>/g, '')
          .replace(/&#(\d+);/g, (match, num) => String.fromCharCode(num))
          .replace(/&#x([A-Za-z0-9]+);/g, (match, num) => String.fromCharCode(parseInt(num, 16)))
          .replace(/&nbsp;/g, '')
          .replace(/&gt;/g, '>')
          .replace(/&lt;/g, '<')
        }
      </Title>
      <Content numberOfLines={3}>
        {
          excerpt
          .replace(/<p>/g, '')
          .replace(/&#(\d+);/g, (match, num) => String.fromCharCode(num))
          .replace(/&#x([A-Za-z0-9]+);/g, (match, num) => String.fromCharCode(parseInt(num, 16)))
          .replace(/&nbsp;/g, '')
          .replace(/&gt;/g, '>')
          .replace(/&lt;/g, '<')
        }
      </Content>
    </Footer>
  </Container>

export default BlogItem
