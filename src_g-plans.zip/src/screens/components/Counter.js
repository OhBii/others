// @flow

import React, { Component } from 'react';
import PropTypes from 'prop-types';
import {
  StyleSheet,
  Text,
  View,
  Button,
} from 'react-native';

const { number, func } = PropTypes

export default class Counter extends Component {

  static propTypes = {
    count: number,
    onMinus: func,
    onPlus: func,
  }
  render() {
    const { count, onPlus, onMinus } = this.props;

    return (
      <View style={styles.container}>
        <Button
          style={styles.button}
          title={`-`}
          onPress={onMinus}
        />

        <Text style={styles.text}>
          { count }
        </Text>

        <Button
          style={styles.button}
          title={`+`}
          onPress={onPlus}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    margin: 10,
  },
  text: {
    margin: 10,
  },
  button: {
    height: 10,
    width: 10,
  }
});
