import React, { Component } from 'react'
import {
  Text,
  View,
  TextInput,
  TouchableOpacity,
  Alert
} from 'react-native'
import Proptypes from 'prop-types'
import glamorous from 'glamorous-native'
import MCIcons from 'react-native-vector-icons/MaterialCommunityIcons'

import Constants   from '../../../global/Constants'


const Container = glamorous(View)({
  width: 270,
  height: 141,
  borderRadius: 13,
  backgroundColor: "rgba(255, 255, 255, 0.82)",
  overflow: 'hidden'
})

const Body = glamorous(View)({
  paddingHorizontal: 20,
  paddingVertical: 15,
  ...Constants.flex('column', 'center', 'space-between')
})

const Title = glamorous(Text)({
  fontSize: 17,
  fontWeight: '600',
  lineHeight: 22,
  textAlign: 'center',
  color: 'black',
  marginBottom: 25
})

const InputWrap = glamorous(View)({
  width: '100%'
})

const Input = {
  width: '100%',
  height: 24,
  backgroundColor: Constants.Colors.white,
  borderStyle: 'solid',
  borderWidth: 0.5,
  borderColor: '#3f3f3f',
  paddingHorizontal: 15
}

const Footer = glamorous(View)({
  borderTopWidth: 1,
  borderTopColor: 'rgb(63,63,63)',
  flexDirection: 'row',
  width: '100%'
})

const Divider = glamorous(View)({
  width: 1,
  borderLeftWidth: 1,
  borderLeftColor: 'rgb(63,63,63)',
  height: 46
})

const FooterButton = glamorous(TouchableOpacity)({
  ...Constants.flex('column', 'center', 'center'),
  width: 134,
  height: 46
})

const ButtonText = glamorous(Text)({
  fontSize: 17,
  letterSpacing: -0.41,
  textAlign: 'center',
  color: '#5ac8fa',
  lineHeight: 17
})

const HelpIconBtn = glamorous(TouchableOpacity)({
  position: 'absolute',
  right: 3,
  width: 20,
  height: 20,
  top: 2
})

const HelpIcon = glamorous(MCIcons)()

const { object, func } = Proptypes
class AppleIdBox extends Component {
  static propTypes = {
    navigator: object,
    onCancel: func,
    onDone: func
  }

  render() {
    const { onCancel, onDone } = this.props
    return (
      <Container>
        <Body>
          <Title>{'Complete Payment'}</Title>
          <InputWrap>
            <TextInput
              style={Input}
              underlineColorAndroid={'transparent'}
              placeholder={'Apple ID'}
              onSubmitEditing={onDone}
              returnKeyType={'done'}
            />
            <HelpIconBtn
              onPress={() => Alert.alert('Please enter your \nAppleID account!')}
            >
              <HelpIcon name='help-box' size={18} color={'#8e8e93'}/>
            </HelpIconBtn>
          </InputWrap>
        </Body>
        <Footer>
          <FooterButton
            onPress={onCancel}
          >
            <ButtonText>{'Cancel'}</ButtonText>
          </FooterButton>
          <Divider />
          <FooterButton
            onPress={onDone}
          >
            <ButtonText>{'Done'}</ButtonText>
          </FooterButton>
        </Footer>
      </Container>
    );
  }
}

export default AppleIdBox
