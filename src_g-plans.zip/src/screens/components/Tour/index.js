import React, { Component } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  Animated,
  Platform,
  AsyncStorage
} from 'react-native';
import Proptypes from 'prop-types';
import { inject, observer } from 'mobx-react/native';
import glamorous from 'glamorous-native';

import Constants from '../../../global/Constants';

const { width, height } = Constants.windowDimensions;
const multilingual = Constants.Multilingual;
const WIDTH = width * 0.9;

const glamorousAnimatedView = glamorous(Animated.View)

const Container = glamorous(View)({
  width,
  height
})

const Overlay = glamorousAnimatedView({
  width,
  height,
  position: 'absolute',
  left: 0,
  top: 0,
  backgroundColor: 'rgba(0,0,0,0.7)'
})
Overlay.propsAreStyleOverrides = true

const Screen = glamorous(View)({
  width,
  height,
  ...Constants.flex('column', 'center', 'center')
})

const Land = glamorousAnimatedView({
  width: WIDTH,
  backgroundColor: '#ffffff',
  borderRadius: 8,
  shadowColor: 'rgba(0, 0, 0, 0.2)',
	shadowOffset: {
		width: 0,
		height: 12
	},
	shadowRadius: 14,
	shadowOpacity: 1,
  elevation: 12
})
Land.propsAreStyleOverrides = true

const LandBody = glamorous(View)({
  width: '100%',
  ...Constants.flex('column', 'center', 'flex-start'),
  padding: 25
})

const LangBGWrap = glamorous(View)({
  borderTopLeftRadius: 8,
  borderTopRightRadius: 8,
  width: WIDTH,
  height: 235,
  overflow: 'hidden',
  ...Constants.flex('column', 'center', 'center')
})

const LandBg = glamorous(Image)({
  width: WIDTH,
  height: 235,
  resizeMode: 'cover',
  position: 'absolute',
  left: 0,
  top: 0
})

const TourLogo = glamorous(Image)({})

const Title = glamorous(Text)({
  fontSize: Platform.OS === 'ios' ? Constants.moderateScale(25, 1.8) : 26,
  fontWeight: 'bold',
  textAlign: 'center',
  color: '#4A4A4A',
  marginBottom: 20
})

const TitleSlide = glamorous(Text)({
  fontSize: Platform.OS === 'ios' ? Constants.moderateScale(26, 1.8) : 26,
  fontWeight: 'bold',
  color: '#4A4A4A'
})

const Description = glamorous(Text)({
  fontSize: Platform.OS === 'ios' ? Constants.moderateScale(18, 1.8) : 18,
  textAlign: 'center',
  color: '#4A4A4A',
  marginBottom: 30
})

const DescriptionSlide = glamorous(Text)({
  fontSize: Platform.OS === 'ios' ? Constants.moderateScale(18, 1.8) : 18,
  color: '#4A4A4A'
})

const LandAction = glamorous(TouchableOpacity)({})

const IconNext = glamorous(Image)({
  width: 34,
  height: 21
})

const Slide = glamorousAnimatedView({
  height,
  width,
  ...Constants.flex('column', 'center', 'flex-start')
})
Slide.propsAreStyleOverrides = true

const ViewOpacity = glamorousAnimatedView({})

ViewOpacity.propsAreStyleOverrides = true

const Tour1 = glamorous(Animated.Image)({
  width: width,
  marginTop: height * 0.09
})
Tour1.propsAreStyleOverrides = true

const Tour6 = glamorous(Animated.Image)({
  width: width,
  marginTop: height * 0.22
})
Tour6.propsAreStyleOverrides = true

const TourFull = glamorous(Animated.Image)({
  height: 812,
  width : width,
  top: height < 667 ? -60 : undefined
})
TourFull.propsAreStyleOverrides = true

const TourFullDetail = glamorous(Animated.Image)({
  height: 812,
  width : width,
  position: 'absolute',
  left: 0,
  top: height < 667 ? -80 : 0
})
TourFullDetail.propsAreStyleOverrides = true

const CloudView = glamorousAnimatedView({
  width: width,
  height: height * 0.38,
  ...Constants.flex('column', 'center', 'center')
})
CloudView.propsAreStyleOverrides = true

const CloudInner = glamorous(View)({
  width: WIDTH,
  height: height * 0.38 - 21,
  backgroundColor: '#ffffff',
  borderRadius: 8,
  paddingHorizontal: 15,
  paddingVertical: 20,
  ...Constants.flex('column', 'flex-start', 'space-between')
})

const CloudArr = glamorous(Image)({
  width: 22,
  height: 11,
  position: 'absolute',
  left: width / 2 - 11,
  top: 0
})

const CloudTop = glamorous(View)({
  width: '100%',
  ...Constants.flex('column', 'flex-start', 'flex-start')
})

const CloudBottom = glamorous(View)({
  width: '100%',
  ...Constants.flex('row', 'center', 'space-between')
})

const CloudTitle = glamorous(View)({
  ...Constants.flex('row', 'center', 'space-between'),
  width: '100%',
  marginBottom: 15
})

const Count = glamorous(Text)({
  fontWeight: 'bold',
  fontSize: Platform.OS === 'ios' ? Constants.moderateScale(16, 1.8) : 16,
  color: '#4A90E2'
})

const StyleScreen1 = {
  top: 10
}

const StyleScreenFull = {
  position: 'absolute',
  left: 0,
  top: height < 812 ? undefined : height * 0.45,
  bottom: height < 812 ? height * 0.08 : undefined
}

const StyleScreenFull2 = {
  position: 'absolute',
  left: 0,
  top: height < 812 ? undefined : height * 0.45,
  bottom: height < 812 ? height * 0.2 : undefined
}

const TourTrack = glamorous(Animated.Image)({
  position: 'absolute',
  bottom: 0,
  width
})
TourTrack.propsAreStyleOverrides = true

const arrowStyle3 = {
  top: undefined,
  bottom: 0,
  transform: [{ rotate: '180deg' }]
}

const arrowStyle4 = {
  left: width * 0.84,
}

const Cloud = ({ title, text, count, onNext, onPrev, style, arrowStyle, translateCard, opacity } = this.props) =>
  <CloudView
    style={style}
    transform={[{ translateY: translateCard }]}
    opacity={opacity}
  >
    <CloudArr style={arrowStyle} source={Constants.Images.CLOUD_ARROW}/>
    <CloudInner>
      <CloudTop>
        <CloudTitle>
          <TitleSlide>{ title }</TitleSlide>
          <Count>{ count }</Count>
        </CloudTitle>
        <DescriptionSlide>{ text }</DescriptionSlide>
      </CloudTop>
      <CloudBottom>
        <LandAction
          onPress={onPrev}
        >
          <IconNext
            source={Constants.Images.ICON_ACCEPTED_PREV}
          />
        </LandAction>
        <LandAction
          onPress={onNext}
        >
          <IconNext
            source={Constants.Images.ICON_ACCEPTED_NEXT}
          />
        </LandAction>
      </CloudBottom>
    </CloudInner>
  </CloudView>

const Screen0 = ({ onNext, opacity, translateDetail, title, text } = this.props) =>
  <Screen>
    <Overlay opacity={opacity} />
    <Land transform={[{ translateY: translateDetail }]}>
      <LangBGWrap>
        <LandBg
          source={Constants.Images.TOUR_0}
        />
        <TourLogo
          source={Constants.Images.TOUR_LOGO_LIFE}
        />
      </LangBGWrap>
      <LandBody>
        <Title>{title}</Title>
        <Description>{text}</Description>
        <LandAction
          onPress={onNext}
        >
          <IconNext
            source={Constants.Images.ICON_ACCEPTED_NEXT}
          />
        </LandAction>
      </LandBody>
    </Land>
  </Screen>

  const Screen1 = ({ onPrev, onNext, opacity, opacityCard, translateCard, title, text } = this.props) =>
    <Slide opacity={opacityCard}>
      <Overlay opacity={opacity} />
      <Tour1 source={Constants.Images.TOUR_1} resizeMode='contain' />
      <Cloud
        title={title}
        text={text}
        count={'1/6'}
        onNext={onNext}
        onPrev={onPrev}
        style={StyleScreen1}
        translateCard={translateCard}
        opacity={opacity}
      />
    </Slide>

  const Screen2 = ({ onPrev, onNext, opacity, translateDetail, translateCard, title, text} = this.props) =>
    <Slide transform={[{ translateY: translateDetail }]} >
      <TourFullDetail source={Constants.Images.TOUR_DETAIL} resizeMode='contain' />
      <ViewOpacity opacity={opacity}>
        <TourFull source={Constants.Images.TOUR_2} resizeMode='contain' />
      </ViewOpacity>
      <Cloud
        title={title}
        text={text}
        count={'2/6'}
        onNext={onNext}
        onPrev={onPrev}
        style={StyleScreenFull}
        translateCard={translateCard}
        opacity={opacity}
      />
    </Slide>

  const Screen3 = ({ onPrev, onNext, opacity, translateCard, title, text } = this.props) =>
    <Slide>
      <ViewOpacity opacity={opacity}>
        <TourFull source={Constants.Images.TOUR_3} resizeMode='contain' />
      </ViewOpacity>
      <TourTrack opacity={opacity} source={Constants.Images.TOUR_TRACK} />
      <Cloud
        title={title}
        text={text}
        count={'3/6'}
        onNext={onNext}
        onPrev={onPrev}
        style={StyleScreenFull2}
        arrowStyle={arrowStyle3}
        translateCard={translateCard}
        opacity={opacity}
      />
    </Slide>

  const Screen4 = ({ onPrev, onNext, opacity, translateCard, title, text } = this.props) =>
    <Slide>
      <ViewOpacity opacity={opacity}>
        <TourFull source={Constants.Images.TOUR_4} resizeMode='contain' />
      </ViewOpacity>
      <Cloud
        title={title}
        text={text}
        count={'4/6'}
        onNext={onNext}
        onPrev={onPrev}
        style={StyleScreenFull}
        arrowStyle={arrowStyle4}
        translateCard={translateCard}
        opacity={opacity}
      />
    </Slide>

  const Screen5 = ({ onPrev, onNext, opacity, translateCard, title, text } = this.props) =>
    <Slide>
      <ViewOpacity opacity={opacity}>
        <TourFull source={Constants.Images.TOUR_5} resizeMode='contain' />
      </ViewOpacity>
      <Cloud
        title={title}
        text={text}
        count={'5/6'}
        onNext={onNext}
        onPrev={onPrev}
        style={StyleScreenFull}
        arrowStyle={arrowStyle4}
        translateCard={translateCard}
        opacity={opacity}
      />
    </Slide>

  const Screen6 = ({ onPrev, onNext, opacity, opacityWater, translateCard, title, text } = this.props) =>
    <Slide opacity={opacityWater}>
      <Overlay opacity={opacity} />
      <Tour6 source={Constants.Images.TOUR_6} resizeMode='contain' />
      <Cloud
        title={title}
        text={text}
        count={'6/6'}
        onNext={onNext}
        onPrev={onPrev}
        style={StyleScreen1}
        translateCard={translateCard}
        opacity={opacity}
      />
    </Slide>

  const Screen7 = ({ onNext, opacity, title, text } = this.props) =>
    <Screen>
      <Overlay opacity={opacity} />
      <Land>
        <LangBGWrap>
          <LandBg
            source={Constants.Images.TOUR_0}
          />
          <TourLogo
            source={Constants.Images.TOUR_LOGO_LIFE}
          />
        </LangBGWrap>
        <LandBody>
          <Title>{title}</Title>
          <Description>{text}</Description>
          <LandAction
            onPress={onNext}
          >
            <IconNext
              source={Constants.Images.ICON_ACCEPTED_NEXT}
            />
          </LandAction>
        </LandBody>
      </Land>
    </Screen>

const { object, func } = Proptypes;
@inject('App', 'User') @observer
export default class Tour extends Component {

  static propTypes = {
    App: object,
    navigator: object,
    User: object,
    showTips: func
  }

  constructor(props) {
    super(props);
    this.state = {
      index: 0,
      toggle: true,
      overlay: new Animated.Value(0),
      detail: new Animated.Value(0),
      start: new Animated.Value(0),
      card: new Animated.Value(0),
      water: new Animated.Value(0),
      translate: new Animated.Value(0)
    }
  }

  componentDidMount(){
    Animated.sequence([
      Animated.timing(this.state.overlay, {
        toValue : 1,
        duration: 300
      }),
      Animated.spring(this.state.start, {
        toValue : 1
      })
    ]).start()
  }

  onNext() {
    let toValue = this.state.toggle ? 0 : 1;
    Animated.timing(this.state.overlay, {
      toValue,
      duration: 300
    }).start(
      () => {
        this.setState({
          index: this.state.index + 1,
          toggle: false,
        });

        switch (this.state.index) {
          case 1:
            this.props.App.setScrollTo(1)
            setTimeout(() => {
              toValue = this.state.toggle ? 0 : 1;
              Animated.parallel([
                Animated.timing(this.state.card, {
                  toValue : 1,
                  duration: 300
                }),
                Animated.timing(this.state.overlay, {
                  toValue,
                  duration: 500
                })
              ]).start(() => {
                this.setState({
                  toggle: true,
                });
              });
            }, 500)
            break
          case 2: Animated.timing(this.state.detail, {
            toValue: 1,
              duration: 600
            }).start(() => {
              toValue = this.state.toggle ? 0 : 1;
              Animated.timing(this.state.overlay, {
                toValue,
                duration: 300
              }).start(() => {
                this.setState({
                  toggle: true,
                });
              })
            })
            break
          case 6:
            this.props.App.setScrollTo(2)
            setTimeout(() => {
              toValue = this.state.toggle ? 0 : 1;
                Animated.parallel([
                  Animated.timing(this.state.water, {
                    toValue : 1,
                    duration: 300
                  }),
                  Animated.timing(this.state.overlay, {
                    toValue,
                    duration: 500
                  })
                ]).start(() => {
                  this.setState({
                    toggle: true,
                  });
                });
            }, 500)
            break
          case 7:
            this.props.App.setScrollTo(3)
            setTimeout(() => {
              toValue = this.state.toggle ? 0 : 1;
              Animated.timing(this.state.overlay, {
                toValue,
                duration: 500
              }).start(() => {
                this.setState({
                  toggle: true,
                });
              });
            }, 500)
            break
          default: toValue = this.state.toggle ? 0 : 1;
            Animated.timing(this.state.overlay, {
              toValue,
              duration: 500
            }).start(() => {
              this.setState({
                toggle: true,
              });
            })
        }
      }
    )
  }

  onPrev() {
    Animated.timing(this.state.overlay, {
      toValue: 0,
      duration: 200
    }).start(),
    setTimeout(() => {
      this.setState({
        index: this.state.index - 1,
        toggle: true,
      });
      setTimeout(() => {
        if(this.state.index === 1) {
          this.setState({
            toggle: true,
          });
          Animated.timing(this.state.detail, {
            toValue: 0,
            duration: 400
          }).start()
          Animated.timing(this.state.overlay, {
            toValue: 1,
            duration: 200
          }).start()
        } else {
          Animated.timing(this.state.overlay, {
            toValue: 1,
            duration: 200
          }).start()
        }
      }, 10);
    }, 200);
  }

  toBack() {
    //
    const { User, navigator, showTips } = this.props;
    try {
      const key = User.userInfo.email + ':' + 'tour';
      AsyncStorage.setItem(key, 'success');
    } catch(error) {
      //
    }
    //
    navigator.dismissLightBox();
    showTips();
  }

  render() {
    const { User } = this.props
    const currentLanguage = User.language

    const opacityOverlay = this.state.overlay.interpolate({
      inputRange: [0, 1],
      outputRange: [0, 1]
    })

    const translateCard = this.state.overlay.interpolate({
      inputRange: [0, 1],
      outputRange: [-40, 0]
    })

    const opacityCard = this.state.card.interpolate({
      inputRange: [0, 1],
      outputRange: [0, 1]
    })

    const opacityWater = this.state.water.interpolate({
      inputRange: [0, 1],
      outputRange: [0, 1]
    })

    const translateContent = this.state.detail.interpolate({
      inputRange: [0, 1],
      outputRange: [height, 0]
    })

    const startTranslateContent = this.state.start.interpolate({
      inputRange: [0, 1],
      outputRange: [height, 0]
    })

    return(
      <Container>
        <TourFullDetail opacity={this.state.index > 2 &&  this.state.index < 6 ? 1 : 0}
                        source={Constants.Images.TOUR_DETAIL}
                        resizeMode='contain' />
        {{
            0: <Screen0 title={multilingual.TOUR_LIFE.title[0][currentLanguage]}
                        text={multilingual.TOUR_LIFE.text[0][currentLanguage]}
                        onNext={() => this.onNext()}
                        opacity={opacityOverlay}
                        translateDetail={startTranslateContent} />,
            1: <Screen1 title={multilingual.TOUR_LIFE.title[1][currentLanguage]}
                        text={multilingual.TOUR_LIFE.text[1][currentLanguage]}
                        onPrev={() => this.onPrev()}
                        onNext={() => this.onNext()}
                        opacity={opacityOverlay}
                        opacityCard={opacityCard}
                        translateCard={translateCard} />,
            2: <Screen2 title={multilingual.TOUR_LIFE.title[2][currentLanguage]}
                        text={multilingual.TOUR_LIFE.text[2][currentLanguage]}
                        onPrev={() => this.onPrev()}
                        onNext={() => this.onNext()}
                        opacity={opacityOverlay}
                        translateDetail={translateContent}
                        translateCard={translateCard} />,
            3: <Screen3 title={multilingual.TOUR_LIFE.title[3][currentLanguage]}
                        text={multilingual.TOUR_LIFE.text[3][currentLanguage]}
                        onPrev={() => this.onPrev()}
                        onNext={() => this.onNext()}
                        opacity={opacityOverlay}
                        translateCard={translateCard} />,
            4: <Screen4 title={multilingual.TOUR_LIFE.title[4][currentLanguage]}
                        text={multilingual.TOUR_LIFE.text[4][currentLanguage]}
                        onPrev={() => this.onPrev()}
                        onNext={() => this.onNext()}
                        opacity={opacityOverlay}
                        translateCard={translateCard} />,
            5: <Screen5 title={multilingual.TOUR_LIFE.title[5][currentLanguage]}
                        text={multilingual.TOUR_LIFE.text[5][currentLanguage]}
                        onPrev={() => this.onPrev()}
                        onNext={() => this.onNext()}
                        opacity={opacityOverlay}
                        translateCard={translateCard} />,
            6: <Screen6 title={multilingual.TOUR_LIFE.title[6][currentLanguage]}
                        text={multilingual.TOUR_LIFE.text[6][currentLanguage]}
                        onPrev={() => this.onPrev()}
                        onNext={() => this.onNext()}
                        opacity={opacityOverlay}
                        opacityWater={opacityWater}
                        translateCard={translateCard} />,
            7: <Screen7 title={multilingual.TOUR_LIFE.title[7][currentLanguage]}
                        text={multilingual.TOUR_LIFE.text[7][currentLanguage]}
                        onNext={() => this.toBack()}/>,
            default: <View />
        }[this.state.index]}
      </Container>
    )
  }
}
