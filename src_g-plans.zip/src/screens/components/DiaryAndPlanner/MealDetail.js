/*
*   author: denis
*   date:   10/08/2018
*/

import React, { Component } from 'react'
import {
  View
} from 'react-native';
import glamorous from 'glamorous-native'
import Proptypes from 'prop-types'

import Constants from '../../../global/Constants'
import MealInfo from './MealInfo'
import Ingredients from './Ingredients'

const ContainerView = glamorous(View) ({
  flex: 1
})

const WrapView = glamorous(View) ({
  paddingBottom: 12,
  borderBottomWidth: 1,
  borderStyle: 'solid',
  borderColor: Constants.Colors.whiteSix
})

const { object } = Proptypes
export default class MealDetail extends Component {
  static propTypes = {
    meal: object
  }

  constructor(props) {
    super(props)
  }

  render() {
    const { meal } = this.props
    return(
      <ContainerView>
        <WrapView>
          <MealInfo
            data={meal}
            forMeal={true}
          />
        </WrapView>
        <Ingredients
            data={meal}
            forMeal={true}
            logged={meal.logged ? meal.logged : false}
            missed={meal.skipped ? meal.skipped : false}
            setTrackItems={() => {}}
            forView={true}
        />
      </ContainerView>
    )
  }
}