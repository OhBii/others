/*
*   author: denis
*   date:   10/08/2018
*/

import React, { Component } from 'react'
import {
  View,
  ScrollView
} from 'react-native';
import glamorous from 'glamorous-native'
import Proptypes from 'prop-types'
import { inject, observer } from 'mobx-react/native'

import Constants from '../../../global/Constants'
import SnowBox from '../Common/SnowBox'
import SelectDate from './SelectDate'
import MainProgress from '../Chart/MainProgress'
import MealDetail from './MealDetail'

const ContainerView = glamorous(View) ({
  flex: 1,
  backgroundColor: Constants.Colors.paleGreyThree
})

const { object } = Proptypes
@inject( 'MealPlan' ) @observer
export default class Diary extends Component {
  static propTypes = {
    MealPlan: object
  }

  constructor(props) {
    super(props)
  }

  render() {
    const { MealPlan } = this.props
    const data = MealPlan.getMealsByIndexes
    const progressData = MealPlan.getPercentageByIndexes
    return(
      <ContainerView>
        <SelectDate />
        <ScrollView>
          <SnowBox>
             <MainProgress
               calories={progressData.calories.fcpFull}
               percent={progressData.calories.data}
               bar={progressData.calories.data}
               fcpData={progressData}
             />
          </SnowBox>
          {
            data.map((item, index) =>
              <SnowBox key={index} >
                <MealDetail meal={item} />
              </SnowBox>
            )
          }
        </ScrollView>
      </ContainerView>
    )
  }
}
