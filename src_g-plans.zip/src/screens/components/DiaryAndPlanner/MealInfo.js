/*
*   author: denis
*   date:   10/08/2018
*/

import React, { Component } from 'react'
import {
  View,
  Text,
  Image
} from 'react-native'
import { inject, observer } from 'mobx-react/native'
import glamorous from 'glamorous-native'
import Proptypes from 'prop-types'

import Constants from '../../../global/Constants'

const ContainerView = glamorous(View) ({
  flex: 1
})

const TimeText = glamorous(Text) ({
  fontSize: 12,
  color: Constants.Colors.dodgerBlueFour
});

const TitleText = glamorous(Text) ({
  width: '100%',
  paddingTop: 5,
  fontSize: 25,
  color: Constants.Colors.greyishBrown
});

const RowView = glamorous(View) ({
  flexDirection: 'row',
  justifyContent: 'space-between',
  paddingVertical: 7
})

const PFCView = glamorous(View) ({
  width: '30%',
  paddingVertical: 3,
  alignItems: 'center',
  borderWidth: 1,
  borderColor: Constants.Colors.greyish,
  borderStyle: 'solid',
  borderRadius: 12
})

const PFCText = glamorous(Text) ({
  fontSize: Constants.platform === 'ios' ? Constants.moderateScale(12, 0.8) : 12,
  color: 'black'
})

const ItemView = glamorous(View) ({
  flexDirection: 'row'
})

const BigText = glamorous(Text) ({
  fontSize: Constants.platform === 'ios' ? Constants.moderateScale(18, 0.8) : 18,
  marginHorizontal: 5,
  color: Constants.Colors.greyishBrown
})

const SmallText = glamorous(Text) ({
  fontSize: 11,
  marginTop: 7,
  color: Constants.Colors.greyishBrown
})

const WrapView = glamorous(View) ({
  width: '72%'
})

const { object, bool } = Proptypes
@inject('Recipe', 'MealPlan') @observer
export default class MealInfo extends Component {
  static propTypes = {
    navigator: object,
    Recipe: object,
    MealPlan: object,
    data: object,
    forMeal: bool //true: for meal, false: for recipe
  }

  constructor(props) {
    super(props)
  }

  render() {
    const { MealPlan, Recipe, data, forMeal } = this.props
    const meal = forMeal ? data : null
    const recipe = forMeal ? meal.recipe : data
    const valuePFC = forMeal
      ? MealPlan.getPFCByMealId(meal.id)
      : Recipe.getPFCByRecipeId(recipe.id)
    return(
      <ContainerView>
        <RowView>
          <WrapView>
            {
              meal
                ? <TimeText>{meal.label.toUpperCase()}</TimeText>
                : <View />
            }
            <TitleText  numberOfLines={1}>
              { recipe ? recipe.name : meal.label }
            </TitleText>
          </WrapView>
        </RowView>
        <RowView>
          <PFCView>
            <PFCText>{`Pro: ${valuePFC.pro}g`}</PFCText>
          </PFCView>
          <PFCView>
            <PFCText>{`Carbs: ${valuePFC.fats}g`}</PFCText>
          </PFCView>
          <PFCView>
            <PFCText>{`Fat: ${valuePFC.carbs}g`}</PFCText>
          </PFCView>
        </RowView>
        {
          recipe
            ? <RowView>
                  <ItemView>
                    <Image source={Constants.Images.FLAME} />
                    <BigText>{valuePFC.calories}</BigText>
                    <SmallText>cals</SmallText>
                  </ItemView>
                  <ItemView>
                    <Image source={Constants.Images.PASSAGE_OF_TIME} />
                    <BigText>{recipe.cook_time ? recipe.cook_time : 15}</BigText>
                    <SmallText>min</SmallText>
                  </ItemView>
                  <ItemView>
                    <Image source={Constants.Images.DIFFICULTY_LEVEL} />
                    <BigText>{recipe.difficulty ? recipe.difficulty : 'easy'}</BigText>
                  </ItemView>
              </RowView>
            : <View />
        }
      </ContainerView>
    )
  }
}