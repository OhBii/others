/*
*   author: denis
*   date:   10/08/2018
*/

import React, { Component } from 'react'
import {
  View,
  Text,
  TouchableOpacity
} from 'react-native'
import { inject, observer } from 'mobx-react/native'
import glamorous from 'glamorous-native'
import Proptypes from 'prop-types'
import Icon from 'react-native-vector-icons/FontAwesome'

import Constants from '../../../global/Constants'
import RecipeRow from '../Recipe/RecipeRow'
import { caseRoundValue } from '../../../utils/GlobalFunctions'

const ContainerView = glamorous(View) ({
  flex: 1,
  paddingVertical: 12
})

const WrapView = glamorous(View) ({
  flexDirection: 'row',
  marginTop: 18
})

const AddView = glamorous(TouchableOpacity) ({
  flexDirection: 'row',
  paddingVertical: 5,
  paddingHorizontal: 12,
  borderRadius: 12,
  borderWidth: 1,
  borderStyle: 'solid',
  borderColor: Constants.Colors.dodgerBlueFour
})

const AddText = glamorous(Text) ({
  fontSize: 12,
  color: Constants.Colors.dodgerBlueFour,
  marginLeft: 5
})

const TitleText = glamorous(Text) ({
  fontSize: 18,
  color: Constants.Colors.greyishBrown,
  marginBottom: 12
})

const RowView = glamorous(View) ({
  flexDirection: 'row',
  justifyContent: 'space-between',
  paddingBottom: 18,
  marginBottom: 18,
  borderBottomWidth: 1,
  borderStyle: 'solid',
  borderColor: Constants.Colors.whiteSix
})

const AmountText = glamorous(Text) ({
  fontSize: 24,
  color: Constants.Colors.dodgerBlueFour
})

const ServingText = glamorous(Text) ({
  paddingLeft: 5,
  paddingTop: 10,
  fontSize: 14,
  color: Constants.Colors.greyishBrown
})

const AmountView = glamorous(View) ({
  flexDirection: 'row'
})

const PlusMinusView = glamorous(View) ({
  flexDirection: 'row',
  borderRadius: 14,
  borderWidth: 1,
  borderStyle: 'solid',
  borderColor: Constants.Colors.dodgerBlueFour
})

const PlusMinusButton = glamorous(TouchableOpacity) ({
  justifyContent: 'center',
  alignItems: 'center',
  paddingHorizontal: 15,
  paddingVertical: 3
})

const { object, bool, func } = Proptypes
@inject('MealPlan', 'Recipe', 'User') @observer
export default class Ingredients extends Component {
  static propTypes = {
    navigator: object,
    MealPlan: object,
    Recipe: object,
    User: object,
    data: object,
    forMeal: bool,
    logged: bool,
    missed: bool,
    setTrackItems: func,
    forView: bool
  }

  constructor(props) {
    super(props)

    this.setInfos(true)
  }

  componentDidUpdate(prevProps) {
    if (!this.isEquivalent(this.props.data, prevProps.data)) {
      this.setInfos(false)
    }
  }

  setInfos(isInit) {
    const { data, forMeal } = this.props
    if (forMeal) {
      const mealItems = this.props.MealPlan.getMealItemsByIds(data.meal_items)
      const extraItems = data.extra_items ? data.extra_items : []
      const loggedItems = data.logged_meal_items

      if (isInit) {
        this.state = { /* eslint-disable-line */
          forFlex: data.recipe ? false : true,
          ingredients: JSON.parse(JSON.stringify(mealItems)),
          extraItems: JSON.parse(JSON.stringify(extraItems)),
          loggedItems: JSON.parse(JSON.stringify(loggedItems))
        }
      }
      else {
        this.setState({
          forFlex: data.recipe ? false : true,
          ingredients: JSON.parse(JSON.stringify(mealItems)),
          extraItems: JSON.parse(JSON.stringify(extraItems)),
          loggedItems: JSON.parse(JSON.stringify(loggedItems))
        })
      }

      this.setTrackItems()
    }
    else {
      if (isInit) {
        this.state = { /* eslint-disable-line */
          forFlex: false,
          ingredients: JSON.parse(JSON.stringify(data.template_recipe_ingredients)),
          extraItems: [],
          loggedItems: []
        }
      }
      else {
        this.setState({
          forFlex: false,
          ingredients: JSON.parse(JSON.stringify(data.template_recipe_ingredients)),
          extraItems: [],
          loggedItems: []
        })
      }

    }
    this.extraMealOfStore = this.state.extraItems

    this.state.ingredients.forEach(el => {
      if (!el.portion || !isFinite(el.portion)) el.portion = 0
      if (!el.portion_si || !isFinite(el.portion_si)) el.portion_si = 0
      if (el.portion === 0 || el.portion_si === 0) el.ratioSIOverUS = 1
      else el.ratioSIOverUS = parseFloat(el.portion_si) / parseFloat(el.portion)
    })
    this.state.extraItems.forEach(el => {
      if (!el.portion || !isFinite(el.portion)) el.portion = 0
      if (!el.portion_si || !isFinite(el.portion_si)) el.portion_si = 0
      if (el.portion === 0 || el.portion_si === 0) el.ratioSIOverUS = 1
      else el.ratioSIOverUS = parseFloat(el.portion_si) / parseFloat(el.portion)
    })
    this.state.loggedItems.forEach(el => {
      if (!el.portion || !isFinite(el.portion)) el.portion = 0
      if (!el.portion_si || !isFinite(el.portion_si)) el.portion_si = 0
      if (el.portion === 0 || el.portion_si === 0) el.ratioSIOverUS = 1
      else el.ratioSIOverUS = parseFloat(el.portion_si) / parseFloat(el.portion)
    })
  }

  isEquivalent(first, second) {
      var firstProps = Object.getOwnPropertyNames(first)
      var secondProps = Object.getOwnPropertyNames(second)

      if (firstProps.length !== secondProps.length) return false

      for (var i = 0; i < firstProps.length; i++) {
          var propName = firstProps[i]
          if (first[propName] !== second[propName]) return false
      }
      return true;
  }

  changeItemCount(itemType, index) {
    //
    if (!this.props.forMeal || this.props.logged || this.props.missed || this.props.forView) return;
    //
    let changeValue, currentItem, ratioSIOverUS, deleteItem
    const {
      User: {
        unit,
        setUnit,
      },
      MealPlan: {
        deleteItemsFromMeal,
        getAmountChangedItem,
        getMealItemsByIds,
      }
    } = this.props
    const changeUnit = unit => setUnit(unit)
    switch (itemType) {
      case 'ingredients':
        currentItem = this.state.ingredients[index]
        ratioSIOverUS = currentItem.ratioSIOverUS
        changeValue = (newValue, isUS) => {
          const temp = this.state.ingredients
          const original = getMealItemsByIds([currentItem.id])
          if (original.length) {
            temp[index] = {
              ratioSIOverUS: temp[index].ratioSIOverUS,
              ...JSON.parse(JSON.stringify(original[0])),
            }
          }
          temp[index] = getAmountChangedItem(temp[index], newValue, isUS, 2)
          this.setState({ ingredients: temp })
          this.setTrackItems()
        }
        deleteItem = () => {
          const temp = this.state.ingredients
          temp.splice(index, 1)
          this.setState({ ingredients: temp })
          this.setTrackItems()
        }
        break
      case 'extraItems':
        currentItem = this.state.extraItems[index]
        ratioSIOverUS = currentItem.ratioSIOverUS
        changeValue = (newValue, isUS) => {
          const temp = this.state.extraItems
          const original = this.extraMealOfStore[index]
          if (original) {
            temp[index] = {
              ratioSIOverUS: temp[index].ratioSIOverUS,
              ...JSON.parse(JSON.stringify(original)),
            }
          }
          temp[index] = getAmountChangedItem(temp[index], newValue, isUS, 2)
          this.setState({ extraItems: temp })
          this.setTrackItems()
        }
        deleteItem = () => {
          const temp = this.state.extraItems
          deleteItemsFromMeal(this.props.data.id, temp[index])
          temp.splice(index, 1)
          this.setState({ extraItems: temp })
          this.setTrackItems()
        }
    }

    this.props.navigator.showLightBox({
      ...Constants.Screens.ITEMCHANGE_SCREEN,
      style: {
        backgroundColor: "#000000a0",
        tapBackgroundToDismiss: true
      },
      passProps: {
        navigator: this.props.navigator,
        itemName: currentItem.name,
        item: { ...currentItem },
        ratioSIOverUS,
        unitType: unit,
        changeValue,
        changeUnit,
        deleteItem,
      }
    });
  }

  setTrackItems() {
    const { User: { isPremium }, setTrackItems } = this.props
    const trackItems = isPremium
      ? this.state.ingredients.concat(this.state.extraItems)
      : this.state.extraItems
    setTrackItems(trackItems)
  }

  toItemSwap(mealItem) {
    //
    if (!this.props.forMeal || this.props.logged || this.state.missed) return;
    //
    const { MealPlan: { getSwapableMealItems } } = this.props
    getSwapableMealItems(mealItem)
    this.props.navigator.push({
      ...Constants.Screens.SWAP_MODAL_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      },
      passProps: {
        curMealItem: mealItem,
        MealId: this.props.data.id
      }
    });
  }

  toSearch(mealId) {
    this.props.navigator.showModal({
      ...Constants.Screens.SEARCH_SCREEN,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      },
      passProps: {
        mealId,
        forFlex: this.state.forFlex
      }
    });
  }

  render() {
    const { User: { unit, isPremium }, data, forMeal, logged, missed, forView } = this.props
    return(
      <ContainerView>
        <View>
          <TitleText>Ingredients</TitleText>
            {
              logged || missed || forView
                ? <View />
                : <RowView>
                    <AmountView>
                      <AmountText>1</AmountText>
                      <ServingText>SERVINGS</ServingText>
                    </AmountView>
                    <PlusMinusView>
                      <PlusMinusButton>
                        <Icon name='minus' size={12} color={Constants.Colors.dodgerBlueFour} />
                      </PlusMinusButton>
                      <PlusMinusButton>
                        <Icon name='plus' size={12} color={Constants.Colors.dodgerBlueFour} />
                      </PlusMinusButton>
                    </PlusMinusView>
                  </RowView>
            }
        </View>
        <View>
          {logged
          ? this.state.loggedItems.map((_el, index) =>
            <RecipeRow
              key={index}
              title={_el.name}
              value={caseRoundValue(unit === 'us'
                ? _el.portion * (isFinite(_el.exchanges) ? _el.exchanges : 1)
                : _el.portion_si * (isFinite(_el.exchanges) ? _el.exchanges : 1)
              )}
              unit={unit === 'us' ? _el.unit : _el.unit_si}
              onValue={() => {}}
              onSwap={() => {}}
              forView={true}
            />)
          : isPremium || !forMeal
            ? this.state.ingredients.map((_el, index) =>
              <RecipeRow
                key={index}
                title={_el.name}
                value={caseRoundValue(unit === 'us'
                  ? _el.portion * (isFinite(_el.exchanges) ? _el.exchanges : 1)
                  : _el.portion_si * (isFinite(_el.exchanges) ? _el.exchanges : 1)
                )}
                unit={unit === 'us' ? _el.unit : _el.unit_si}
                onValue={() => this.changeItemCount('ingredients', index)}
                onSwap={() => this.toItemSwap(_el)}
                forView={!forMeal || missed || forView}
              />)
            : null
          }
          {logged || missed
          ? null
          : this.state.extraItems.map((_el, index) =>
            <RecipeRow
              key={index}
              title={_el.name}
              value={caseRoundValue(unit === 'us'
                ? _el.portion * (isFinite(_el.exchanges) ? _el.exchanges : 1)
                : _el.portion_si * (isFinite(_el.exchanges) ? _el.exchanges : 1)
              )}
              unit={unit === 'us' ? _el.unit : _el.unit_si}
              onValue={() => this.changeItemCount('extraItems', index)}
              onSwap={() => {}}
              forView={true}
            />)
          }
        </View>
        {
          logged || missed || forView
            ? <View />
            : <WrapView>
                <AddView onPress={() => this.toSearch(data.id)}>
                  <Icon name='plus' size={12} color={Constants.Colors.dodgerBlueFour} />
                  <AddText>Add Item</AddText>
                </AddView>
              </WrapView>
        }
      </ContainerView>
    )
  }
}