/*
*   author: denis
*   date:   10/08/2018
*/

import React, { Component } from 'react';
import {
  View,
  Text,
  TouchableOpacity
} from 'react-native';
import Proptypes from 'prop-types';
import { inject, observer } from 'mobx-react/native';
import glamorous from 'glamorous-native';
import moment from 'moment';
import DateTimePicker from 'react-native-modal-datetime-picker';
import Icon from 'react-native-vector-icons/FontAwesome';

import Constants from '../../../global/Constants';

const ContainerView = glamorous(View) ({
  flexDirection: 'row',
  justifyContent: 'space-between',
  paddingHorizontal: Constants.mainPadding,
  paddingVertical: 5,
  backgroundColor: Constants.Colors.white,
  borderBottomWidth: 1,
  borderStyle: 'solid',
  borderColor: 'rgba(0, 0, 0, 0.07)'
})

const PickerView = glamorous(TouchableOpacity) ({
  flexDirection: 'row',
  paddingVertical: 10
})

const DateText = glamorous(Text) ({
  fontSize: 18,
  color: Constants.Colors.black
})

const InfoText = glamorous(Text) ({
  fontSize: 18,
  color: Constants.Colors.dodgerBlueFour,
  paddingVertical: 10
})

const strFormat = 'MMMM   DD  YYYY  '

const { object } = Proptypes;
@inject( 'DayIndex' ) @observer
export default class SelectDate extends Component {
  static propTypes = {
    DayIndex: object
  }

  constructor(props) {
    super(props)
    this.state = {
      isPickerShow: false
    }
  }

  showDatePicker() {
    this.setState({isPickerShow: true})
  }

  hideDatePicker() {
    this.setState({isPickerShow: false})
  }

  handleDatePicker(date) {
    const { DayIndex } = this.props
    DayIndex.setSelectedDate(date)
    this.hideDatePicker()
  }

  render() {
    const { DayIndex } = this.props
    return(
      <ContainerView>
        <PickerView onPress={() => this.showDatePicker()}>
          <DateText>{ moment(DayIndex.getSelectedDate.selectedDate).format(strFormat) }</DateText>
          <Icon name="angle-down" size={24} color={Constants.Colors.black} />
        </PickerView>
        <InfoText>{DayIndex.getSelectedDate.displayStr}</InfoText>
        <DateTimePicker
          isVisible={this.state.isPickerShow}
          mode={'date'}
          onConfirm={(date) => this.handleDatePicker(date)}
          onCancel={() => this.hideDatePicker()}
          date={DayIndex.getSelectedDate.selectedDate}
          minimumDate={DayIndex.getDateOfLimits().downLimit}
          maximumDate={DayIndex.getDateOfLimits().upLimit}
        />
      </ContainerView>
    )
  }
}