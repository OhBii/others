/*
*   author: denis
*   date:   10/08/2018
*/

import React, { Component } from 'react'
import {
  View,
  Text,
  Image
} from 'react-native';
import glamorous from 'glamorous-native'
import Proptypes from 'prop-types'
import { CachedImage, ImageCacheProvider } from 'react-native-cached-image'

import Constants from '../../../global/Constants'

const ContainerView = glamorous(View) ({
  flex: 1,
  flexDirection: 'column'
})

const TitleText = glamorous(Text) ({
  fontSize: 20,
  color: Constants.Colors.greyishBrown
})

const Thumbnail = glamorous(CachedImage) (({ width }) => ({
  width: width,
  height: width,
  borderRadius: 7
}))

const DescriptionText = glamorous(Text) ({
  fontSize: 16,
  marginTop: 12,
  color: Constants.Colors.greyishBrown
})

const InfoView = glamorous(View) ({
  marginTop: 12,
  flexDirection: 'row',
  justifyContent: 'space-around',
  width: '100%'
})

const ItemView = glamorous(View) ({
  marginHorizontal: 5,
  flexDirection: 'row'
})

const BigText = glamorous(Text) ({
  fontSize: 20,
  marginHorizontal: 5,
  marginTop: -3,
  color: Constants.Colors.greyishBrown
})

const SmallText = glamorous(Text) ({
  fontSize: 11,
  marginTop: 7,
  color: Constants.Colors.greyishBrown
})

const WrapView = glamorous(View) ({
  alignItems: 'center',
  marginBottom: 12,
})

const { object, number } = Proptypes;
export default class MealCard extends Component {
  static propTypes = {
    meal: object,
    width: number
  }

  constructor(props) {
    super(props)
  }

  render() {
    const { meal, width } = this.props
    const recipe = meal.recipe
    const image = meal.image.medium
    return(
      <ContainerView>
        <WrapView>
          <TitleText>{meal.label}</TitleText>
        </WrapView>
        <ImageCacheProvider
          urlsToPreload={[image]}>
          <Thumbnail
            width={width}
            source={{ uri: image}}
          />
        </ImageCacheProvider>
        {
          recipe
            ? <WrapView>
                {
                  recipe.name
                    ? <DescriptionText>{recipe.name}</DescriptionText>
                    : <View />
                }
                <InfoView>
                  <ItemView>
                    <Image source={Constants.Images.PASSAGE_OF_TIME} />
                    <BigText>{recipe.cook_time ? recipe.cook_time : 15}</BigText>
                    <SmallText>min</SmallText>
                  </ItemView>
                  <ItemView>
                    <Image source={Constants.Images.DIFFICULTY_LEVEL} />
                    <BigText>{recipe.difficulty ? recipe.difficulty : 'easy'}</BigText>
                  </ItemView>
                </InfoView>
              </WrapView>
            : <WrapView />
        }
      </ContainerView>
    )
  }
}