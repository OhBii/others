/*
*   author: denis
*   date:   10/08/2018
*/

import React, { Component } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity
} from 'react-native';
import { inject, observer } from 'mobx-react/native'
import Proptypes from 'prop-types'
import glamorous from 'glamorous-native'
import SnapCarousel from 'react-native-snap-carousel'
import LinearGradient from 'react-native-linear-gradient'

import Constants from '../../../global/Constants'
import SnowBox from '../Common/SnowBox'
import SelectDate from './SelectDate'
import MealCard from './MealCard'

const { width } = Constants.windowDimensions

const ContainerView = glamorous(View) ({
  flex: 1,
  backgroundColor: Constants.Colors.paleGreyThree
})

const ContentView = glamorous(View) ({
  alignItems: 'center'
})

const WrapView = glamorous(LinearGradient) ({
  position: 'absolute',
  bottom: 0,
  width: '100%'
})

const ToolView = glamorous(View) ({
  flexDirection: 'row',
  marginTop: 20,
  marginBottom: 30,
  marginHorizontal: Constants.mainPadding,
  justifyContent: 'space-between',
  borderRadius: 30,
  borderWidth: 1,
  borderStyle: 'solid',
  borderColor: Constants.Colors.dodgerBlueFour,
  backgroundColor: Constants.Colors.white,
})

const SaveButton = glamorous(TouchableOpacity) ({
  alignItems: 'center',
  width: '50%',
  paddingVertical: 12
})

const SaveText = glamorous(Text) ({
  fontSize: 15,
  color: Constants.Colors.dodgerBlueFour
})

const styleSnowBox = {
  marginBottom: 50
}

const { object } = Proptypes;
@inject('MealPlan') @observer
export default class Planner extends Component {
  static propTypes = {
    MealPlan: object
  }

  constructor(props) {
    super(props)
  }

  render() {
    const { MealPlan } = this.props
    const data = MealPlan.getMealsByIndexes
    return(
      <ContainerView>
        <SelectDate />
        <ScrollView>
          <SnowBox style={styleSnowBox}>
            <ContentView>
              <SnapCarousel
                onSnapToItem={() => {}}
                sliderWidth={width}
                itemWidth={width * 0.8}
                ref={c => { this.carousel = c }}
                data={data}
                inactiveSlideOpacity={0.5}
                activeSlideOffset={1}
                renderItem={({item}) =>
                  <MealCard
                    width={width * 0.8}
                    meal={item}
                  />
                }
              />
            </ContentView>
          </SnowBox>
        </ScrollView>
        <WrapView
          colors={['#ffffff00', '#ffffffff']}
          start={{x: 0, y: 0}}
          end={{x: 0, y: 1}}
        >
          <ToolView>
            <SaveButton>
              <SaveText>Save for day</SaveText>
            </SaveButton>
            <SaveButton>
              <SaveText>Save for week</SaveText>
            </SaveButton>
          </ToolView>
        </WrapView>
      </ContainerView>
    )
  }
}