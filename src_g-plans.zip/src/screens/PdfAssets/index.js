/*
*   author: denis
*   date:   7/17/2018
*/

import React, { Component } from 'react';
import {
  View,
  FlatList,
  Alert,
  Platform,
  Linking
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import { inject, observer } from 'mobx-react/native';
import SafariView from "react-native-safari-view";

import Constants from '../../global/Constants';
import ShowHeader from '../components/HeaderBar/ShowHeader';
import ListItem from '../components/MoreTab/ListItem'

const multilingual = Constants.Multilingual;

const ContainerView = glamorous(View)({
  flexDirection: "column",
  flex: 1,
  backgroundColor: Constants.Colors.whiteFive
})

const pdfList = [
  {
    id: 0,
    title: 'Turn Up the Heat',
    icon: 'book-open-variant',
    link: 'https://gplans.storage.googleapis.com/media/pdfs/2016/02/06/TurnUptheHeat_GogliaNutrition.pdf',
    quantity: ''
  },
  {
    id: 1,
    title: 'G-plans Shake Recipes',
    icon: 'food',
    link: 'https://gplans.storage.googleapis.com/media/pdfs/2017/04/06/G-Plans-shake-recipes.pdf',
    quantity: ''
  },
  {
    id: 2,
    title: 'Free Foods List',
    icon: 'library-books',
    link: 'https://gplans.storage.googleapis.com/media/pdfs/2016/02/06/Free-foods-GogliaNutrition.pdf',
    quantity: ''
  },
  {
    id: 3,
    title: 'Exchange List',
    icon: 'library-books',
    link: 'https://gplans.storage.googleapis.com/media/pdfs/2016/02/06/Exchange-list-GogliaNutrition.pdf',
    quantity: ''
  },
  {
    id: 4,
    title: 'G-plans Metacookbook',
    icon: 'book-open-page-variant',
    link: 'https://gplans.storage.googleapis.com/media/pdfs/2016/03/25/G-Plans-Meta-Cook_Book.pdf',
    quantity: ''
  },
  {
    id: 5,
    title: 'G-plans Starter Guide',
    icon: 'book-secure',
    link: 'https://gplans.storage.googleapis.com/media/pdfs/2016/04/08/G-Plans_StarterGuide.pdf',
    quantity: ''
  }
]

const { object } = Proptypes;
@inject('User') @observer
export default class PdfAssets extends Component {
  static propTypes = {
    navigator: object,
    User: object
  }

  constructor(props) {
    super(props);
  }

  toDisplay(uri) {
    if (Platform.OS === 'ios') {
      this.toSafariView(uri)
    }
    else {
      this.toLinking(uri)
    }
  }

  toSafariView(url) {
    SafariView.isAvailable()
      .then(() => {
        SafariView.show({ url: url })
      })
      .catch(() => {
        Alert.alert('Sorry, something went wrong!')
      });
  }

  toLinking(url) {
    Linking.canOpenURL(url)
      .then(() => {
        Linking.openURL(url)
      })
      .catch(() => {
        Alert.alert('Sorry, something went wrong!')
      })
  }

  render() {
    const { User } = this.props
    const currentLanguage = User.language;
    return(
      <ContainerView>
        <ShowHeader
          title= { multilingual.RESOURCES[currentLanguage] }
          navigator={this.props.navigator}
          hasNotify />
        <FlatList
          data={pdfList}
          renderItem={({item}) =>
            <ListItem
              onPress={() => this.toDisplay(item.link)}
              title={item.title}
              iconName={item.icon}
              iconSize={18}
              iconColor={Constants.Colors.greyish}
            />
          }
          keyExtractor={(item, index) => index.toString()}
        />
      </ContainerView>
    );
  }
}
