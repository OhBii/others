import React, { Component } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  TextInput,
  Alert,
  //ActivityIndicator,
  AsyncStorage
} from 'react-native';
import Proptypes from 'prop-types';
import glamorous from 'glamorous-native';
import { inject, observer } from 'mobx-react/native';
import Swiper from 'react-native-swiper';
import ImagePicker from 'react-native-image-picker';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import LinearGradient from 'react-native-linear-gradient'

import Constants from '../../global/Constants';

const { width, height } = Constants.windowDimensions

const Container = glamorous(View)({
  flex: 1,
  backgroundColor: Constants.Colors.backgroundColor
})

const Header = glamorous(View)({
  ...Constants.flex('row', 'center', 'space-between'),
  width: '100%',
  position: 'absolute',
  left: 0,
  top: 0,
  paddingTop: 40,
  paddingHorizontal: Constants.mainPadding,
  borderBottomWidth: 10,
  borderBottomColor: Constants.Colors.backgroundColor,
  paddingBottom: 24
})

const ProgressBar = glamorous(View)({
  height: 6,
  width: width * 0.65,
  justifyContent: 'center',
  flexDirection: 'row'
})

const Bar = glamorous(View)({
  width: '100%',
  height: 6,
  borderRadius: 7,
  backgroundColor: Constants.Colors.whiteSeven
})

const Progress = glamorous(LinearGradient)({
  height: 6,
  borderRadius: 7,
  backgroundColor: Constants.Colors.whiteSeven,
  position: 'absolute',
  left: 0,
  top: 0
})

const HeaderBack = glamorous(Image)({})

const SlideWrap = glamorous(View)({
  flex: 1,
  backgroundColor: Constants.Colors.white
})

const Slide = glamorous(View)({
  flex: 1,
  paddingTop: 100,
  ...Constants.flex('row', 'center', 'center'),
})

const Question = glamorous(Text)({
  fontSize: 38,
  fontWeight: 'bold',
  textAlign: 'center',
  color: Constants.Colors.marineTwo,
  marginVertical: 25
})

const BigInputWrap = glamorous(View)({
  width: '100%',
  height: 60,
  borderRadius: 30,
  backgroundColor: Constants.Colors.paleGreyThree,
  ...Constants.flex('row', 'center', 'space-between'),
  padding: Constants.platform === 'ios' ? 0  : 5,
  paddingHorizontal: Constants.mainPadding,
  marginTop: 20
})

const BigInputTitle = glamorous(Text)({
  textAlign: 'right',
  fontSize: 20,
  fontWeight: '500',
  fontStyle: 'normal',
  color: Constants.Colors.blueyGrey
})

const BigInput = {
  fontSize: 20,
  fontWeight: '500',
  color: Constants.Colors.blueyGrey,
  padding: 0,
  width: '80%'
}

const SelectWrap = glamorous(View)({
  flex: 1,
  width: '100%',
  paddingBottom: 50,
  ...Constants.flex('column', 'center', 'center')
})

const SelectInner = glamorous(View)({
  width: '100%',
  paddingHorizontal: Constants.mainPadding,
  ...Constants.flex('column', 'center', 'center')
})

const SelectItem = glamorous(TouchableOpacity)(({ active }) => ({
  width: '100%',
  height: 60,
  borderRadius: 30,
  backgroundColor: active ? Constants.Colors.softBlueThree : Constants.Colors.white,
  borderStyle: 'solid',
  borderWidth: 1,
  borderColor: Constants.Colors.softBlueThree,
  ...Constants.flex('row', 'center', 'center'),
  marginBottom: 20
}))

const SelectLabel = glamorous(Text)(({ active }) => ({
  fontSize: 18,
  fontWeight: "bold",
  fontStyle: "normal",
  letterSpacing: 0,
  textAlign: "center",
  color: active ? Constants.Colors.white : Constants.Colors.softBlueThree
}))

const SlideIntro = glamorous(View)({
  flex: 1,
  ...Constants.flex('column', 'center', 'center'),
  paddingHorizontal: Constants.mainPadding,
  paddingBottom: 50
})

const CardTitle = glamorous(Text)({
  fontSize: 26,
  fontWeight: 'bold',
  textAlign: 'center',
  color: Constants.Colors.greyishBrownThree,
  marginBottom: 20,
  maxWidth: 300
})

const SlideTitle = glamorous(Text)({
  fontSize: 26,
  textAlign: 'center',
  color: Constants.Colors.greyishBrownThree,
})

const TitleBold = glamorous(Text)({
  fontSize: 26,
  textAlign: 'center',
  color: Constants.Colors.greyishBrownThree,
  fontWeight: 'bold'
})

const CardText= glamorous(Text)({
  fontSize: 18,
  fontWeight: '300',
  textAlign: 'center',
  color: Constants.Colors.greyishBrownThree
})

const SlideButton = glamorous(TouchableOpacity)(({ mTop }) => ({
  width: '100%',
  height: 60,
  borderRadius: 30,
  backgroundColor: Constants.Colors.white,
  borderStyle: 'solid',
  borderWidth: 1,
  borderColor: '#4da0ff',
  ...Constants.flex('column', 'center', 'center'),
  marginTop: mTop || 20
}))

const SlideButtonText = glamorous(Text)({
  fontSize: 18,
  fontWeight: "bold",
  fontStyle: "normal",
  letterSpacing: 0,
  color: Constants.Colors.softBlueThree
})

const SkipTxt = glamorous(Text)({
  fontSize: 16,
  fontWeight: '500',
  textAlign: 'center',
  color: Constants.Colors.softBlueThree
})

const SkipButton = glamorous(TouchableOpacity) ({
  marginTop: 35
})

const RowTitle = glamorous(Text)({
  flexDirection: 'row',
  flexWrap: 'wrap',
  maxWidth: 300,
  marginBottom: 20
})

const ProgressLength = glamorous(Text)({
  fontSize: 16,
  fontWeight: '500',
  color: Constants.Colors.blueyGrey
})

const ContentContainer = {
  flex: 1,
  paddingBottom: 50
}

const CheckinPhoto = glamorous(View)({
  width: '100%',
  borderRadius: 6,
  overflow: 'hidden',
  ...Constants.flex('row', 'center', 'center'),
  marginTop: 20
})

const CheckinPhotoSide = glamorous(View)({
  width: '50%',
  height: height * 0.4,
  ...Constants.flex('column', 'center', 'center')
})

const CheckinPhotoText = glamorous(Text)({
  color: Constants.Colors.paleGreyThree,
  fontSize: 26,
  textAlign: 'center',
  paddingHorizontal: 15
})

const UserPhoto = glamorous(Image)({
  width: '100%',
  height: '100%',
  resizeMode: 'cover'
})

const GetPhoto = glamorous(View)({
  width: '100%',
  ...Constants.flex('row', 'center', 'space-between'),
  marginTop: 20
})

const UserAvatar = glamorous(Image)({
  width: 60,
  height: 60,
  borderRadius: 30,
  overflow: 'hidden',
  resizeMode: 'cover'
})

const GetPhotoButton = glamorous(View)({
  width: width * 0.7,
})

const progressWith = (data, currentIndex) => {
  let progress = `${currentIndex * (100 / (data.length - 2))}%`
  return (
    <Progress
      colors={['rgb(77,160,255)', 'rgb(57,238,255)']}
      start={{x: 0, y: 1}}
      end={{x: 1, y: 0}}
      style={{ width: progress }}
    />
  )
}

const CheckinHeader = ({ data, index, onBack } = this.props) =>
  <Header>
    <TouchableOpacity
      onPress={onBack}
    >
      <HeaderBack
        source={Constants.Images.HEADER_BACK}
      />
    </TouchableOpacity>
    {index !== data.length - 1 && <ProgressBar>
        <Bar>
          { progressWith(data, index) }
        </Bar>
      </ProgressBar>}
    {index !== data.length -1 && <ProgressLength>
        {`${index}/${data.length - 2}`}
      </ProgressLength>}
  </Header>

const SlideInfo = ({ title, description, buttonTxt, skipTxt, onNext, onSkip } = this.props) =>
  <SlideIntro>
    <SelectInner>
      <CardTitle>{ title }</CardTitle>
      <CardText>{ description }</CardText>
      <SlideButton onPress={onNext} mTop={55}>
        <SlideButtonText>{ buttonTxt }</SlideButtonText>
      </SlideButton>
      {!!skipTxt && <SkipButton onPress={onSkip}>
        <SkipTxt>{ skipTxt }</SkipTxt>
      </SkipButton>}
    </SelectInner>
  </SlideIntro>

const SplitTitle = ({ slide } = this.props) => {
  let arrTitle = slide.title.split(slide.highlightedTitle)
  return(
    <RowTitle>
      <SlideTitle>{ arrTitle[0] }</SlideTitle>
      <TitleBold>{ slide.highlightedTitle }</TitleBold>
      <SlideTitle>{ arrTitle[1] }</SlideTitle>
    </RowTitle>)
}

const Select = ({ slide, onSelect, selected } = this.props) =>
  <SelectWrap>
    <SelectInner>
      <SplitTitle slide={slide}/>
      {
        slide.select.map((el, ind) =>
        <SelectItem
          key={ind}
          onPress={() => onSelect(el)}
          active={selected === el}
        >
          <SelectLabel active={selected === el}>
            { el.title }
          </SelectLabel>
        </SelectItem>)
      }
    </SelectInner>
  </SelectWrap>

const TakePhoto = ({ slide, firstCheckinPhoto, nextCheckinPhoto, userPhoto, onGetPhoto, skipTxt, onNext } = this.props) => {
  return(
    <SelectInner>
      <SlideTitle>{ slide.title }</SlideTitle>
      <TitleBold>{ slide.highlightedTitle }</TitleBold>
      {!firstCheckinPhoto ? <CheckinPhoto>
          <CheckinPhotoText>{'Upload your photo'}</CheckinPhotoText>
        </CheckinPhoto>
      : <CheckinPhoto>
        <CheckinPhotoSide>
          <UserPhoto source={{uri: firstCheckinPhoto}} />
          </CheckinPhotoSide>
          <CheckinPhotoSide>
            {nextCheckinPhoto ? <UserPhoto source={{ uri: nextCheckinPhoto }} />
             : <CheckinPhotoText>{'Upload your photo'}</CheckinPhotoText>}
          </CheckinPhotoSide>
        </CheckinPhoto>
       }
       <GetPhoto>
        <UserAvatar source={{ uri: userPhoto }} />
        <GetPhotoButton>
          <SlideButton onPress={onGetPhoto} mTop={0.01}>
            <SlideButtonText>{ 'Get Photo' }</SlideButtonText>
          </SlideButton>
        </GetPhotoButton>
       </GetPhoto>
       <SkipButton onPress={onNext}>
         <SkipTxt>{ skipTxt }</SkipTxt>
       </SkipButton>
    </SelectInner>
)}

const CustomInput = ({ children, unit } = this.props) =>
  <BigInputWrap>
    { children }
    <BigInputTitle>{unit}</BigInputTitle>
  </BigInputWrap>

const { object, string } = Proptypes;
@inject('User', 'Checkin') @observer
export default class Checkin extends Component {
  static propTypes = {
    User: object,
    Checkin: object,
    navigator: object,
    userPhoto: string,
    firstCheckinPhoto: string
  }

  constructor(props) {
    super(props);
    this.state = {
      swiperIndex: 0,
      value: '',
      imageUri: '',
      isLoading: false,
    }

    let feetMum = []
    let valNum = []
    for (let i = 0; i <= 60; i++) {
      feetMum.push(i)
    }
    for (let i = 1; i <= 10; i++) {
      valNum.push({[i] : feetMum})
    }

    this.dataTall = [
      {
        'Feet/inches' : valNum
      },
      {
        'Feet/cm' : valNum
      },
    ]
  }

  toScreen(screen) {
    this.props.navigator.push({
      ...screen,
      navigatorStyle: {
        navBarHidden: true,
        tabBarHidden: true
      }
    })
  }

  goBack() {
    this.swiper.scrollBy(-1)
    this.setState({value: ''})
  }

  goNext() {
    this.swiper.scrollBy(1)
    this.setState({value: ''})
  }

  onSwiperSliderChange(index) {
    this.setState({ swiperIndex : index })
  }

  componentDidUpdate(){
    setTimeout(() => {
      switch (this.props.Checkin.checkin[this.state.swiperIndex].ref) {
        case 'weight' : this.weight.focus(), this.hips.blur(), this.waist.blur()
        break
        case 'hips' : this.hips.focus(), this.weight.blur(), this.waist.blur()
        break
        case 'waist' : this.waist.focus(), this.weight.blur(), this.hips.blur()
        break
        default: this.weight.blur(), this.hips.blur(), this.waist.blur()
      }
    }, 10)
  }

  getValue(slide) {
    const curResult = this.props.Checkin.checkinResult
    let result
    curResult[curResult.indexOf(curResult.find(res => res.id === slide.id))] !== undefined
    ? result = curResult[curResult.indexOf(curResult.find(res => res.id === slide.id))].value
    : result = ''
    return result
  }

  toLogin() {
    this.props.User.logout();
    Constants.Global.startSingleScreenApp();
  }

  toSkip(id) {
    this.props.Checkin.setCheckinResult({ id: id, value: null })
    this.goNext()
  }

  showAlert() {
    Alert.alert(
      'Sorry, something went wrong',
      '',
      [{
        text: 'OK',
        onPress: () => {
          this.toLogin()
        }
      }]
    );
  }

  async onComplete() {
    const { User: { userInfo, isPremium }, Checkin: { createCheckin } } = this.props
    try {
      this.setState({ isLoading: true });
      await createCheckin(this.state.imageUri);

      const key = isPremium
        ? userInfo.email + ':' + 'premium'
        : userInfo.email + ':' + 'maintenance-freemium'
      const value = await AsyncStorage.getItem(key);
      if (value === 'success') {
        Constants.Global.startTabBasedApp()
      }
      else {
        const screen = isPremium
          ? Constants.Screens.INTRO_SCREEN
          : Constants.Screens.INTRO_FLEX_SCREEN

        this.props.navigator.push({
          ...screen,
          navigatorStyle: {
            navBarHidden: true,
            tabBarHidden: true
          }
        })
      }
    } catch (error) {
      this.setState({ isLoading: false });
      this.showAlert();
    }
  }

  toUploadImage() {
    const options = {
      title: 'Select Avatar',
      storageOptions: {
        skipBackup: true,
        path: 'images'
      },
      quality: 0.3
    }

    ImagePicker.showImagePicker(options, response => {
      if (response.didCancel) {
        //
      } else if (response.error) {
        //
        Alert.alert(response.error);
      } else {
        //
        this.props.navigator.showModal({
          ...Constants.Screens.PREVIEW_IMAGE_SCREEN,
          navigatorStyle: {
            navBarHidden: true,
            tabBarHidden: true
          },
          passProps: {
            imageUri: response.uri,
            uploadImage: () => this.uploadImage(response.uri)
          }
        });
      }
    })
  }

  uploadImage(imageUri) {
    this.setState({ imageUri: imageUri });
    //this.swiper.scrollBy(1)
  }

  render() {
    const {
      Checkin: {
        checkin,
        setCheckinResult,
        getRoundedWeight,
        getRoundedHipsAndWaist
      },
      User: {
        unit,
        userInfo
      },
      firstCheckinPhoto='https://imgix.ranker.com/user_node_img/3102/62021533/original/emily-ratajkowski-photo-u66?w=650&q=50&fm=jpg&fit=crop&crop=faces',
      userPhoto='https://imgix.ranker.com/user_node_img/3102/62021533/original/emily-ratajkowski-photo-u66?w=650&q=50&fm=jpg&fit=crop&crop=faces'
    } = this.props
    let isUSUnit = unit === 'us'
    const firstName = userInfo.first_name ? userInfo.first_name.replace(/^\w/, (chr) => chr.toUpperCase()) : ''
    return(
      <Container>
        <Swiper
          showsPagination={false}
          onIndexChanged={(index) => this.onSwiperSliderChange(index)}
          showsButtons={false}
          autoplay={false}
          scrollEnabled={false}
          ref={ref => this.swiper = ref}
          loop={false}
        >
          {
            checkin.map((slide) => {

            return(
              <SlideWrap
                key={slide.id}
              >
               {
                  slide.type === 'info'
                  ? <SlideInfo
                      title={ slide.title.replace(/name/gi, firstName) }
                      description={ slide.description }
                      buttonTxt={'Let’s do it'}
                      skipTxt={'Remind me later'}
                      onNext={() => this.goNext()}
                      onSkip={() => this.toLogin()}
                    />
                  : slide.type === 'input' ?

                    <Slide>
                      <CheckinHeader
                        index={this.state.swiperIndex}
                        data={checkin}
                        onBack={() => this.goBack()}
                      />
                      <KeyboardAwareScrollView
                        contentContainerStyle={ContentContainer}
                        extraScrollHeight={30}
                      >
                      <SelectWrap>
                          <SelectInner>
                            <SplitTitle slide={slide}/>
                            <CardText>{ slide.description }</CardText>
                            <CustomInput
                              unit={isUSUnit ? slide.imperial.unit : slide.metric.unit}
                            >
                              <TextInput
                                ref={(ref) => slide.ref === 'weight'
                                              ? this.weight = ref
                                              : slide.ref === 'hips'
                                                ? this.hips = ref
                                                : this.waist = ref}
                                keyboardType={'numeric'}
                                underlineColorAndroid={'transparent'}
                                placeholder={'0'}
                                returnKeyType={'done'}
                                style={BigInput}
                                maxLength = {5}
                                onChangeText={(value) => {
                                  if (Number.isInteger(Math.round(value))) {
                                    this.setState({value: value})
                                  }
                                }}
                                onSubmitEditing={() => {
                                  const value = Math.round(parseFloat(this.state.value) * 10) / 10
                                  const min = isUSUnit ? slide.imperial.min : slide.metric.min
                                  const max = isUSUnit ? slide.imperial.max : slide.metric.max
                                  if( min < +value && +value < max ) {
                                    const valueUS = slide.ref === 'weight'
                                      ? getRoundedWeight(value)
                                      : getRoundedHipsAndWaist(value)
                                    setCheckinResult({ id: slide.id, value: valueUS })
                                    this.goNext()
                                  } else {
                                    Alert.alert(`Please enter correct value!\n${slide.ref} should be > ${min} and < ${max}`)
                                  }
                                }}
                                value={this.state.value}
                              />
                            </CustomInput>
                            {slide.ref !== 'weight' && <SkipButton onPress={() => this.toSkip(slide.id)}>
                              <SkipTxt>{ 'Skip this' }</SkipTxt>
                            </SkipButton>}
                          </SelectInner>
                        </SelectWrap>
                      </KeyboardAwareScrollView>
                    </Slide>
                  : slide.type === 'select' ?
                    <Slide>
                      <CheckinHeader
                        index={this.state.swiperIndex}
                        data={checkin}
                        onBack={() => this.goBack()}
                      />
                      { !!slide.question && <Question>{ slide.question }</Question> }
                      <Select
                        slide={slide}
                        onSelect={(value) => {
                            setCheckinResult({ id: slide.id, value: value })
                            this.goNext()
                          }
                        }
                        selected={this.getValue(slide)}
                      />
                    </Slide>
                  : slide.type === 'takePhoto' ?
                    <Slide>
                      <CheckinHeader
                        index={this.state.swiperIndex}
                        data={checkin}
                        onBack={() => this.goBack()}
                      />
                      <TakePhoto
                        slide={slide}
                        firstCheckinPhoto={firstCheckinPhoto}
                        nextCheckinPhoto={this.state.imageUri}
                        userPhoto={userPhoto}
                        onGetPhoto={() => this.toUploadImage()}
                        skipTxt={this.state.imageUri ? 'Continue' : 'Skip this'}
                        onNext={() => this.goNext()}
                      />
                    </Slide>
                  : slide.type === 'info_complete' ?
                    <SlideInfo
                      title={ slide.title }
                      description={ slide.description }
                      onNext={() => this.onComplete()}
                      buttonTxt={'Continue'}
                    />
                  : null
                }
              </SlideWrap>
            )})
          }
        </Swiper>
      </Container>
    )
  }
}
