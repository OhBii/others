// @flow
import { cloneElement } from 'react';

import { Text, StyleSheet } from 'react-native';
import Provider       from './utils/MobxRnnProvider';
import Stores         from './stores';
import Constants      from './global/Constants';

import { registerScreens } from './screens';
// set global default font-famaly
let oldRender = Text.prototype.render;
const styles = StyleSheet.create({
  defaultFontFamily: {
    fontFamily: 'SanFranciscoDisplay-Regular'
  }
})

Text.prototype.render = function (...args) {
    let origin = oldRender.call(this, ...args);
    return cloneElement(origin, {
        style: [styles.defaultFontFamily, origin.props.style]
    })
}


Stores.instance.hydrateStores()
.then(() => {
  registerScreens(Stores, Provider);
  Constants.Global.startSingleScreenApp();
})

//Constants.Global.startTabBasedApp();
